"use strict";

function loadScoutScript() {
    var t = document.createElement("script");
    t.setAttribute("type", "text/javascript"), t.setAttribute("src", "https://d335luupugsy2.cloudfront.net/scout/bundle.js"), t.onload = initScoutBanner, document.head.appendChild(t)
}
var RDStation = function() {
        var t = {
            windowLoaded: !1
        };
        return window.addEventListener("load", function() {
            t.windowLoaded = !0
        }), t
    }(),
    RDCookieControl = function() {
        var t = {
            analytics: {
                eventName: "rd_cookie_consent_allow_analytics",
                track: !1
            },
            functional: {
                eventName: "rd_cookie_consent_allow_functional",
                track: !1
            },
            configuration: {
                position: "bottom-right",
                content: {
                    message: '<span id="cookieconsent:desc" class="cc-message" style="overflow-wrap:break-word">Utilizamos cookies para oferecer melhor experi\xeancia, melhorar o desempenho, analisar como voc\xea interage em nosso site e personalizar conte\xfado. Ao utilizar este site, voc\xea concorda com o uso de cookies.</span>',
                    href: "",
                    link: "Saiba mais",
                    dismiss: "Ok, entendi!",
                    allow: "Aceitar Cookies",
                    deny: "Recusar Cookies"
                },
                palette: {
                    popup: {
                        background: "#ffffff",
                        text: "#000000",
                        link: "#409cff"
                    },
                    button: {
                        background: "#000000",
                        text: "#ffffff"
                    },
                    shadow: {
                        border: "2px solid rgba(0, 0, 0, .2)",
                        boxShadow: "1px 2px 4px rgba(0, 0, 0, .1)"
                    }
                },
                type: "info",
                showLink: !1,
                cookie: {
                    expiryDays: 365
                },
                display_on_all_pages: !0
            }
        };
        return document.addEventListener(t.analytics.eventName, function() {
            t.analytics.track = !0
        }), document.addEventListener(t.functional.eventName, function() {
            t.functional.track = !0
        }), t
    }();
! function() {
    var t = function() {
            var t = document.createElement("iframe");
            t.onload = function() {
                RDStation.windowLoaded = !0, e()
            }, t.setAttribute("style", "width: 1px; height: 1px; position: absolute; top: -100px;"), t.setAttribute("id", "rd_tmgr"), t.setAttribute("title", "RD Tag Manager"), document.body.appendChild(t)
        },
        s = function() {
            !window.opener || -1 == window.name.indexOf("TAGMANAGER_VERIFY") && -1 == window.location.href.indexOf("tagmanager_verify") || window.opener.postMessage(JSON.stringify({
                task: "checkTagManager",
                tagManagerChecked: !0
            }), "https://app.rdstation.com.br")
        },
        e = function() {
            (function(t, e, n, o, a, r) {
                var i = function() {
                        RdstationPopup.init(e, n, t, r)
                    },
                    c = function(t, e) {
                        return t + "/js/rdstation-popups/" + e + "/rdstation-popup.min.js?v=1"
                    },
                    d = function(t) {
                        t.readyState ? t.onreadystatechange = function() {
                            "loaded" != t.readyState && "complete" != t.readyState || (t.onreadystatechange = null, i())
                        } : t.onload = i
                    },
                    s = function(t, e) {
                        var n = document.createElement("script");
                        return n.setAttribute("type", "text/javascript"), n.setAttribute("src", c(t, e)), d(n), n
                    },
                    u = function() {
                        return null !== document.querySelector("#landing-page-attributes")
                    },
                    l = function() {
                        return u() && null !== document.querySelector("body > .bricks--container")
                    };
                if (!u() || l()) {
                    var f = s(o, a);
                    document.body.appendChild(f)
                }
            })("UA-150748037-1", "abb82a65d76c5ec2f934c94da3366483", "3836", "https://d335luupugsy2.cloudfront.net", "bricks", "");
            var t = document.createElement("script"),
                e = function() {
                    RdIntegration.integrateAll("abb82a65d76c5ec2f934c94da3366483"), console.log("FormIntegration; ver.1.3.3", "initialized")
                };
            t.setAttribute("type", "text/javascript"), t.setAttribute("src", "https://d335luupugsy2.cloudfront.net/js/integration/stable/rd-js-integration.min.js?v=1"), t.readyState ? t.onreadystatechange = function() {
                    "loaded" != t.readyState && "complete" != t.readyState || (t.onreadystatechange = null, e())
                } : t.onload = function() {
                    e()
                }, document.body.appendChild(t),
                function i(e) {
                    function n() {
                        return "https://d1sag09wwfbul8.cloudfront.net/rdtracker/rdtracker.min.js"
                    }

                    function o() {
                        var t = document.createElement("script");
                        return t.type = "text/javascript", t.defer = !0, t.src = n(), t
                    }

                    function a() {
                        try {
                            window.rdtracker && "function" == typeof window.rdtracker.init && (window.rdtracker.init(e.token), console.log("[RDTracker] initialized"))
                        } catch (t) {
                            console.error("[RDTracker] init failed:", t)
                        }
                    }

                    function t() {
                        var t = o();
                        t.onload = a, t.onreadystatechange = function() {
                            "complete" === this.readyState && a()
                        }, document.body.appendChild(t)
                    }

                    function r() {
                        window.__rdtrackerLoadedOnce || (window.__rdtrackerLoadedOnce = !0, t())
                    }
                    window.__rdtrackerInjected || (window.__rdtrackerInjected = !0, window.RDCookieControl.analytics.track ? r() : document.addEventListener(window.RDCookieControl.analytics.eventName, r))
                }({
                    token: "abb82a65d76c5ec2f934c94da3366483"
                })
        },
        u = function() {
            return "complete" === document.readyState
        };
    (function(t) {
        function e() {
            r.onload = i, r.onreadystatechange = function() {
                "complete" === this.readyState && i()
            }, document.body.appendChild(r)
        }

        function n() {
            TrafficSourceCookie.init("__trf.src", [".next4.com.br", ".teste-utmsform.next2dev.com.br", ".rds.land"]), console.log("TrafficSourceCookie", "initialized");
            try {
                s()
            } catch (t) {
                console.error(t)
            }
        }

        function o() {
            c.onload = n, c.onreadystatechange = function() {
                "complete" === this.readyState && n()
            }, document.body.appendChild(c)
        }
        if (window.hasOwnProperty("RDStationTrackingCodeChecker") && window.RDStationTrackingCodeChecker) return;
        if (window.RDStationTrackingCodeChecker = !0, -1 != navigator.userAgent.toLowerCase().indexOf("safari")) var a = setInterval(function d() {
            u() && (clearInterval(a), t())
        }, 500);
        else u() ? t() : window.addEventListener("load", t);
        var r = document.createElement("script"),
            i = function() {
                LeadTracking.init({
                    token: "abb82a65d76c5ec2f934c94da3366483"
                }), console.log("LeadTracking", "initialized")
            };
        r.setAttribute("type", "text/javascript"), r.setAttribute("src", "https://d335luupugsy2.cloudfront.net/js/lead-tracking/stable/lead-tracking.min.js"), RDCookieControl.analytics.track ? e() : document.addEventListener(RDCookieControl.analytics.eventName, e);
        var c = document.createElement("script");
        c.setAttribute("type", "text/javascript"), c.setAttribute("src", "https://d335luupugsy2.cloudfront.net/js/traffic-source-cookie/stable/traffic-source-cookie.min.js"), RDCookieControl.analytics.track ? o() : document.addEventListener(RDCookieControl.analytics.eventName, o)
    })(t)
}();
var initScoutBanner = function() {
    new Scout(RDCookieControl)
};
"loading" == document.readyState ? document.addEventListener("DOMContentLoaded", loadScoutScript) : loadScoutScript();
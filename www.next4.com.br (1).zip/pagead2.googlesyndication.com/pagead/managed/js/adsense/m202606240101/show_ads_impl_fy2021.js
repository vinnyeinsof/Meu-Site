(function(sttc) {
    'use strict';
    var aa, ba, ca = Object.create,
        da = Object.defineProperty,
        ea = globalThis,
        fa = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ha = {},
        ja = {};

    function ka(a, b, c) {
        if (!c || a != null) {
            c = ja[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function ma(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in ha ? f = ha : f = ea;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = fa && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? da(ha, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ja[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ja[d] = fa ? ea.Symbol(d) : "$jscp$" + a + "$" + d), da(f, ja[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    var na = Object.setPrototypeOf;

    function oa(a, b) {
        a.prototype = ca(b.prototype);
        a.prototype.constructor = a;
        na(a, b);
        a.xn = b.prototype
    }
    ma("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    ma("String.prototype.replaceAll", function(a) {
        return a ? a : function(b, c) {
            if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
            return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
        }
    }, "es_2021");
    ma("Promise.withResolvers", function(a) {
        return a ? a : function() {
            var b, c;
            return {
                promise: new Promise(function(d, e) {
                    b = d;
                    c = e
                }),
                resolve: b,
                reject: c
            }
        }
    }, "es_next");
    ma("AggregateError", function(a) {
        function b(c, d) {
            d = Error(d);
            "stack" in d && (this.stack = d.stack);
            this.errors = c;
            this.message = d.message
        }
        if (a) return a;
        oa(b, Error);
        b.prototype.name = "AggregateError";
        return b
    }, "es_2021");
    ma("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : Array.from(b);
            return Promise.all(b.map(function(c) {
                return Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new ha.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var r = this || self;

    function pa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = r, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    }

    function qa(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function ra(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function sa(a) {
        return Object.prototype.hasOwnProperty.call(a, ua) && a[ua] || (a[ua] = ++va)
    }
    var ua = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        va = 0;

    function xa(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function za(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function Aa(a, b, c) {
        Aa = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? xa : za;
        return Aa.apply(null, arguments)
    }

    function Ba(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function Da(a, b, c) {
        a = a.split(".");
        c = c || r;
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function Ea(a) {
        return a
    }

    function Ga(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.xn = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.ap = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    };
    var Ha = {
        Mo: 0,
        Lo: 1,
        Ko: 2
    };
    var Ia;
    let Ja;

    function Ka(a) {
        r.setTimeout(() => {
            throw a;
        }, 0)
    };

    function La(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };
    var Ma = pa(610401301, !1),
        Na = pa(748402147, !0);

    function Oa() {
        var a = r.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Pa;
    const Qa = r.navigator;
    Pa = Qa ? Qa.userAgentData || null : null;

    function Ra(a) {
        if (!Ma || !Pa) return !1;
        for (let b = 0; b < Pa.brands.length; b++) {
            let {
                brand: c
            } = Pa.brands[b];
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function Sa(a) {
        return Oa().indexOf(a) != -1
    };

    function Ta() {
        return Ma ? !!Pa && Pa.brands.length > 0 : !1
    }

    function Ua() {
        return Ta() ? !1 : Sa("Opera")
    }

    function Ya() {
        return Sa("Firefox") || Sa("FxiOS")
    }

    function Za() {
        return Sa("Safari") && !($a() || (Ta() ? 0 : Sa("Coast")) || Ua() || (Ta() ? 0 : Sa("Edge")) || (Ta() ? Ra("Microsoft Edge") : Sa("Edg/")) || (Ta() ? Ra("Opera") : Sa("OPR")) || Ya() || Sa("Silk") || Sa("Android"))
    }

    function $a() {
        return Ta() ? Ra("Chromium") : (Sa("Chrome") || Sa("CriOS")) && !(Ta() ? 0 : Sa("Edge")) || Sa("Silk")
    };

    function ab(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function bb(a, b) {
        var c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function cb(a, b) {
        var c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (--c; c >= 0; --c) c in d && b.call(void 0, d[c], c, a)
    }

    function db(a, b) {
        var c = a.length,
            d = [],
            e = 0,
            f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                let h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function eb(a, b) {
        var c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function gb(a, b) {
        var c = 1;
        bb(a, function(d, e) {
            c = b.call(void 0, c, d, e, a)
        });
        return c
    }

    function hb(a, b) {
        var c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function ib(a, b) {
        return ab(a, b) >= 0
    }

    function jb(a, b) {
        b = ab(a, b);
        var c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function kb(a, b) {
        var c = 0;
        cb(a, function(d, e) {
            b.call(void 0, d, e, a) && Array.prototype.splice.call(a, e, 1).length == 1 && c++
        })
    }

    function mb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function nb(a) {
        var b = a.length;
        if (b > 0) {
            let c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function ob(a, b) {
        for (let d = 1; d < arguments.length; d++) {
            let e = arguments[d];
            var c = qa(e);
            if (c == "array" || c == "object" && typeof e.length == "number") {
                c = a.length || 0;
                let f = e.length || 0;
                a.length = c + f;
                for (let g = 0; g < f; g++) a[c + g] = e[g]
            } else a.push(e)
        }
    }

    function pb(a, b, c) {
        c = c || qb;
        for (var d = 0, e = a.length, f; d < e;) {
            let g = d + (e - d >>> 1),
                h;
            h = c(b, a[g]);
            h > 0 ? d = g + 1 : (e = g, f = !h)
        }
        return f ? d : -d - 1
    }

    function qb(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function rb(a, b) {
        b = b || Math.random;
        for (let c = a.length - 1; c > 0; c--) {
            let d = Math.floor(b() * (c + 1)),
                e = a[c];
            a[c] = a[d];
            a[d] = e
        }
    };

    function sb(a) {
        sb[" "](a);
        return a
    }
    sb[" "] = function() {};

    function tb(a, b) {
        try {
            return sb(a[b]), !0
        } catch (c) {}
        return !1
    };
    var ub = Ta() ? !1 : Sa("Trident") || Sa("MSIE"),
        vb = Sa("Edge") || ub,
        wb = Sa("Gecko") && !(Oa().toLowerCase().indexOf("webkit") != -1 && !Sa("Edge")) && !(Sa("Trident") || Sa("MSIE")) && !Sa("Edge"),
        xb = Oa().toLowerCase().indexOf("webkit") != -1 && !Sa("Edge");
    const zb = {};
    let Ab = null;

    function Bb(a, b) {
        b === void 0 && (b = 0);
        Cb();
        b = zb[b];
        for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function Db(a) {
        var b = [];
        Eb(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Eb(a, b) {
        function c(e) {
            for (; d < a.length;) {
                let f = a.charAt(d++),
                    g = Ab[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        Cb();
        for (var d = 0;;) {
            let e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Cb() {
        if (!Ab) {
            Ab = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                let d = a.concat(b[c].split(""));
                zb[c] = d;
                for (let e = 0; e < d.length; e++) {
                    let f = d[e];
                    Ab[f] === void 0 && (Ab[f] = e)
                }
            }
        }
    };
    var Fb = typeof structuredClone != "undefined";

    function Hb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    let Ib = void 0,
        Jb;

    function Mb(a) {
        if (Jb) throw Error("");
        Jb = b => {
            r.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function Nb(a) {
        if (Jb) try {
            Jb(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function Ob() {
        var a = Error();
        Hb(a, "incident");
        Jb ? Nb(a) : Ka(a)
    }

    function Pb(a) {
        a = Error(a);
        Hb(a, "warning");
        Nb(a);
        return a
    }

    function Qb(a, b) {
        if (a != null) {
            var c = Ib ? ? (Ib = {});
            var d = c[a] || 0;
            d >= b || (c[a] = d + 1, Ob())
        }
    };

    function Rb(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var Tb = Rb(),
        Ub = Rb(),
        Wb = Rb(),
        Xb = Rb(),
        Yb = Rb(),
        Zb = Rb("m_m", !0);
    const t = Rb("jas", !0);
    var $b;
    const ac = [];
    ac[t] = 7;
    $b = Object.freeze(ac);

    function bc(a, b) {
        a[t] |= b
    }

    function dc(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function ec(a) {
        bc(a, 34);
        return a
    }

    function fc(a) {
        bc(a, 8192);
        return a
    }

    function hc(a) {
        bc(a, 32);
        return a
    };
    var ic = {};

    function jc(a, b) {
        return b === void 0 ? a.j !== kc && !!(2 & (a.aa[t] | 0)) : !!(2 & b) && a.j !== kc
    }
    const kc = {};
    class lc {
        constructor(a, b, c) {
            this.g = a;
            this.j = b;
            this.l = c
        }
        next() {
            var a = this.g.next();
            a.done || (a.value = this.j.call(this.l, a.value));
            return a
        }[Symbol.iterator]() {
            return this
        }
    }
    var mc = Object.freeze({});

    function nc(a, b, c) {
        var d = b & 128 ? 0 : -1,
            e = a.length,
            f;
        if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && f.constructor === Object;
        var g = e + (f ? -1 : 0);
        for (b = b & 128 ? 1 : 0; b < g; b++) c(b - d, a[b]);
        if (f) {
            a = a[e - 1];
            for (let h in a) Object.prototype.hasOwnProperty.call(a, h) && !isNaN(h) && c(+h, a[h])
        }
    }
    var oc = {};

    function pc(a) {
        a.hp = !0;
        return a
    };
    var qc = pc(a => typeof a === "number"),
        v = pc(a => typeof a === "string"),
        rc = pc(a => typeof a === "boolean"),
        sc = pc(a => typeof a === "function"),
        tc = pc(a => !!a && (typeof a === "object" || typeof a === "function"));

    function yc() {
        return zc(pc((a, b) => a === void 0 ? !0 : v(a, b)))
    }

    function zc(a) {
        a.jm = !0;
        return a
    }
    var Ac = pc(a => Array.isArray(a));

    function Bc() {
        return pc(a => Ac(a) ? a.every(b => qc(b)) : !1)
    };

    function Cc(a) {
        if (v(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (qc(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var Fc = pc(a => a >= Dc && a <= Ec);
    const Dc = BigInt(Number.MIN_SAFE_INTEGER),
        Ec = BigInt(Number.MAX_SAFE_INTEGER);
    let Gc = 0,
        Hc = 0,
        Ic;

    function Jc(a) {
        var b = a >>> 0;
        Gc = b;
        Hc = (a - b) / 4294967296 >>> 0
    }

    function Kc(a) {
        if (a < 0) {
            Jc(-a);
            a = Gc;
            var b = Hc;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            let [c, d] = [a, b];
            Gc = c >>> 0;
            Hc = d >>> 0
        } else Jc(a)
    }

    function Nc(a, b) {
        var c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : Oc(a, b)
    }

    function Oc(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function Pc() {
        var a = Gc,
            b = Hc,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = Oc(a, b);
        return c
    }

    function Qc(a) {
        a.length < 16 ? Kc(Number(a)) : (a = BigInt(a), Gc = Number(a & BigInt(4294967295)) >>> 0, Hc = Number(a >> BigInt(32) & BigInt(4294967295)))
    };

    function Rc(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const Sc = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Tc = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        Uc = Number.isSafeInteger,
        Vc = Number.isFinite,
        Wc = Math.trunc;

    function Xc(a) {
        if (a != null && typeof a !== "number") throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);
        return a
    }

    function Yc(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function bd(a) {
        if (typeof a !== "boolean") throw Error(`Expected boolean but got ${qa(a)}: ${a}`);
        return a
    }

    function cd(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    const dd = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function ed(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Vc(a);
            case "string":
                return dd.test(a);
            default:
                return !1
        }
    }

    function fd(a) {
        if (!Vc(a)) throw Pb("enum");
        return a | 0
    }

    function gd(a) {
        return a == null ? a : Vc(a) ? a | 0 : void 0
    }

    function hd(a) {
        if (typeof a !== "number") throw Pb("int32");
        if (!Vc(a)) throw Pb("int32");
        return a | 0
    }

    function id(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Vc(a) ? a | 0 : void 0
    }

    function jd(a) {
        if (typeof a !== "number") throw Pb("uint32");
        if (!Vc(a)) throw Pb("uint32");
        return a >>> 0
    }

    function kd(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Vc(a) ? a >>> 0 : void 0
    }

    function ld(a, b) {
        b ? ? (b = 1024);
        if (!ed(a)) throw Pb("int64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return od(a);
                    case "bigint":
                        return String(Sc(64, a));
                    default:
                        return pd(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return qd(a);
                    case "bigint":
                        return Cc(Sc(64, a));
                    default:
                        return rd(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return od(a);
                    case "bigint":
                        return Cc(Sc(64, a));
                    default:
                        return sd(a)
                }
            default:
                return Rc(b, "Unknown format requested type for int64")
        }
    }

    function sd(a) {
        a = Wc(a);
        if (!Uc(a)) {
            Kc(a);
            var b = Gc,
                c = Hc;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            b = Nc(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function td(a) {
        a = Wc(a);
        a >= 0 && Uc(a) || (Kc(a), a = Nc(Gc, Hc));
        return a
    }

    function pd(a) {
        a = Wc(a);
        Uc(a) ? a = String(a) : (Kc(a), a = Pc());
        return a
    }

    function ud(a) {
        a = Wc(a);
        a >= 0 && Uc(a) ? a = String(a) : (Kc(a), a = Oc(Gc, Hc));
        return a
    }

    function od(a) {
        var b = Wc(Number(a));
        if (Uc(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        b = a.length;
        (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") || (Qc(a), a = Pc());
        return a
    }

    function qd(a) {
        var b = Wc(Number(a));
        if (Uc(b)) return Cc(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Cc(Sc(64, BigInt(a)))
    }

    function rd(a) {
        return Uc(a) ? Cc(sd(a)) : Cc(pd(a))
    }

    function vd(a) {
        return Uc(a) ? Cc(td(a)) : Cc(ud(a))
    }

    function wd(a) {
        var b = Wc(Number(a));
        if (Uc(b) && b >= 0) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        a[0] === "-" ? b = !1 : (b = a.length, b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615");
        b || (Qc(a), a = Oc(Gc, Hc));
        return a
    }

    function xd(a) {
        var b = Wc(Number(a));
        if (Uc(b) && b >= 0) return Cc(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Cc(Tc(64, BigInt(a)))
    }

    function yd(a) {
        if (a == null) return a;
        if (typeof a === "bigint") return Fc(a) ? a = Number(a) : (a = Sc(64, a), a = Fc(a) ? Number(a) : String(a)), a;
        if (ed(a)) return typeof a === "number" ? sd(a) : od(a)
    }

    function zd(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Cc(Sc(64, a));
        if (ed(a)) return b === "string" ? qd(a) : rd(a)
    }

    function Ad(a, b) {
        b ? ? (b = 1024);
        if (!ed(a)) throw Pb("uint64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return wd(a);
                    case "bigint":
                        return String(Tc(64, a));
                    default:
                        return ud(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return xd(a);
                    case "bigint":
                        return Cc(Tc(64, a));
                    default:
                        return vd(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return wd(a);
                    case "bigint":
                        return Cc(Tc(64, a));
                    default:
                        return td(a)
                }
            default:
                return Rc(b, "Unknown format requested type for int64")
        }
    }

    function Bd(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Cc(Tc(64, a));
        if (ed(a)) return b === "string" ? xd(a) : vd(a)
    }

    function Cd(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Sc(64, a));
        if (ed(a)) {
            if (b === "string") return od(a);
            if (b === "number") return sd(a)
        }
    }

    function Dd(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Tc(64, a));
        if (ed(a)) {
            if (b === "string") return wd(a);
            if (b === "number") return td(a)
        }
    }

    function Ed(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function Fd(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function Gd(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function Hd(a, b, c, d) {
        if (a != null && a[Zb] === ic) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? b[Tb] || (b[Tb] = Id(b)) : new b : void 0;
        c = a[t] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[t] = d);
        return new b(a)
    }

    function Id(a) {
        a = new a;
        ec(a.aa);
        return a
    }

    function Jd(a, b, c) {
        return b ? Ed(a) : Gd(a) ? ? (c ? "" : void 0)
    }

    function Kd(a, b, c) {
        a = b ? fd(a) : gd(a);
        return a == null ? c ? 0 : void 0 : a
    };

    function Ld(a) {
        return a
    };
    const Md = {},
        Nd = (() => class extends Map {
            constructor() {
                super()
            }
        })();

    function Od(a) {
        return a
    }

    function Pd(a) {
        if (a.kd & 2) throw Error("Cannot mutate an immutable Map");
    }
    var Sd = class extends Nd {
        constructor(a, b, c = Od, d = Od) {
            super();
            this.kd = a[t] | 0;
            this.dd = b;
            this.zf = c;
            this.dk = this.dd ? Qd : d;
            for (let e = 0; e < a.length; e++) {
                let f = a[e],
                    g = c(f[0], !1, !0),
                    h = f[1];
                b ? h === void 0 && (h = null) : h = d(f[1], !1, !0, void 0, void 0, this.kd);
                super.set(g, h)
            }
        }
        ii(a) {
            return fc(Array.from(super.entries(), a))
        }
        clear() {
            Pd(this);
            super.clear()
        }
        delete(a) {
            Pd(this);
            return super.delete(this.zf(a, !0, !1))
        }
        entries() {
            if (this.dd) {
                var a = super.keys();
                a = new lc(a, Rd, this)
            } else a = super.entries();
            return a
        }
        values() {
            if (this.dd) {
                var a =
                    super.keys();
                a = new lc(a, Sd.prototype.get, this)
            } else a = super.values();
            return a
        }
        forEach(a, b) {
            this.dd ? super.forEach((c, d, e) => {
                a.call(b, e.get(d), d, e)
            }) : super.forEach(a, b)
        }
        set(a, b) {
            Pd(this);
            a = this.zf(a, !0, !1);
            return a == null ? this : b == null ? (super.delete(a), this) : super.set(a, this.dk(b, !0, !0, this.dd, !1, this.kd))
        }
        has(a) {
            return super.has(this.zf(a, !1, !1))
        }
        get(a) {
            a = this.zf(a, !1, !1);
            var b = super.get(a);
            if (b !== void 0) {
                var c = this.dd;
                return c ? (c = this.dk(b, !1, !0, c, this.Uk, this.kd), c !== b && super.set(a, c), c) : b
            }
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    Sd.prototype.toJSON = void 0;

    function Qd(a, b, c, d, e, f) {
        a = Hd(a, d, c, f);
        e && (a = Td(a));
        return a
    }

    function Rd(a) {
        return [a, this.get(a)]
    }
    let Ud;

    function Vd() {
        return Ud || (Ud = new Sd(ec([]), void 0, void 0, void 0, Md))
    };

    function Wd(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            k = !1,
            l = !!(b & 64),
            m = l ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var n = g && a[g - 1];
            n != null && typeof n === "object" && n.constructor === Object ? (g--, h = g) : n = void 0;
            !l || b & 128 || e || (k = !0, h = (Xd ? ? Ld)(h - m, m, a, n, void 0) + m)
        }
        b = void 0;
        for (e = 0; e < g; e++) {
            let p = a[e];
            if (p != null && (p = c(p, d)) != null)
                if (l && e >= h) {
                    let q = e - m;
                    (b ? ? (b = {}))[q] = p
                } else f[e] = p
        }
        if (n)
            for (let p in n) {
                if (!Object.prototype.hasOwnProperty.call(n, p)) continue;
                a = n[p];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +p;
                let q;
                l && !Number.isNaN(g) && (q = g + m) < h ? f[q] = a : (b ? ? (b = {}))[p] = a
            }
        b && (k ? f.push(b) : f[h] = b);
        return f
    }

    function Yd(a) {
        a[0] = Zd(a[0]);
        a[1] = Zd(a[1]);
        return a
    }

    function Zd(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return Fc(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[t] | 0;
                    return a.length === 0 && b & 1 ? void 0 : Wd(a, b, Zd)
                }
                if (a != null && a[Zb] === ic) return $d(a);
                if (a instanceof Sd) return a = a.size !== 0 ? a.ii(Yd) : void 0, a;
                return
        }
        return a
    }
    var ae = Fb ? structuredClone : a => Wd(a, 0, Zd);
    let Xd;

    function $d(a) {
        a = a.aa;
        return Wd(a, a[t] | 0, Zd)
    };
    let be, ce;

    function de(a) {
        switch (typeof a) {
            case "boolean":
                return be || (be = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? ce || (ce = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    }

    function ge(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[t] | 0;
            if (Na && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && he();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[t] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    let k = c[g];
                    if (k != null && typeof k === "object" && k.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in k) {
                            if (!Object.prototype.hasOwnProperty.call(k,
                                    h)) continue;
                            f = +h;
                            if (f < g) c[f + b] = k[h], delete k[h];
                            else break
                        }
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -16760833 | (h & 1023) << 14
                }
            }
        }
        a[t] = e | 64 | d;
        return a
    }

    function he() {
        if (Na) throw Error("carr");
        Qb(Yb, 5)
    };

    function ie(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[t] | 0;
            return a.length === 0 && c & 1 ? void 0 : je(a, c, b)
        }
        if (a != null && a[Zb] === ic) return ke(a);
        if (a instanceof Sd) {
            c = a.kd;
            if (c & 2) return a;
            if (a.size) {
                b = ec(a.ii());
                if (a.dd)
                    for (a = 0; a < b.length; a++) {
                        let d = b[a],
                            e = d[1];
                        e == null || typeof e !== "object" ? e = void 0 : e != null && e[Zb] === ic ? e = ke(e) : Array.isArray(e) ? e = je(e, e[t] | 0, !!(c & 32)) : e = void 0;
                        d[1] = e
                    }
                return b
            }
        }
    }

    function je(a, b, c) {
        if (b & 2) return a;
        !c || 4096 & b || 16 & b ? a = le(a, b, !1, c && !(b & 16)) : (bc(a, 34), b & 4 && Object.freeze(a));
        return a
    }

    function me(a, b, c) {
        a = new a.constructor(b);
        c && (a.j = kc);
        a.D = kc;
        return a
    }

    function ke(a) {
        var b = a.aa,
            c = b[t] | 0;
        return jc(a, c) ? a : ne(a, b, c) ? me(a, b) : le(b, c)
    }

    function oe(a) {
        var b = a.aa,
            c = b[t] | 0;
        return ne(a, b, c) ? me(a, b, !0) : new a.constructor(le(b, c, !1))
    }

    function le(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = Wd(a, b, ie, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[t] = b;
        return a
    }

    function Td(a) {
        var b = a.aa,
            c = b[t] | 0;
        return jc(a, c) ? ne(a, b, c) ? me(a, b, !0) : new a.constructor(le(b, c, !1)) : a
    }

    function pe(a) {
        var b = a.aa,
            c = b[t] | 0;
        return jc(a, c) ? a : ne(a, b, c) ? me(a, b) : new a.constructor(le(b, c, !0))
    }

    function qe(a) {
        if (a.j !== kc) return !1;
        var b = a.aa;
        b = le(b, b[t] | 0);
        bc(b, 2048);
        a.aa = b;
        a.j = void 0;
        a.D = void 0;
        return !0
    }

    function re(a) {
        if (!qe(a) && jc(a, a.aa[t] | 0)) throw Error();
    }

    function se(a, b) {
        b === void 0 && (b = a[t] | 0);
        b & 32 && !(b & 4096) && (a[t] = b | 4096)
    }

    function ne(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[t] = c | 2, a.j = kc, !0) : !1
    };
    const te = Cc(0),
        ue = {};

    function ve(a, b, c, d, e) {
        b = we(a.aa, b, c, e);
        if (b !== null || d && a.D !== kc) return b
    }

    function we(a, b, c, d) {
        if (b === -1) return null;
        var e = b + (c ? 0 : -1),
            f = a.length - 1;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f) {
                var g = a[f];
                if (g != null && typeof g === "object" && g.constructor === Object) {
                    c = g[b];
                    var h = !0
                } else if (e === f) c = g;
                else return
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function xe(a, b, c) {
        re(a);
        var d = a.aa;
        ye(d, d[t] | 0, b, c);
        return a
    }

    function ye(a, b, c, d, e) {
        var f = c + (e ? 0 : -1),
            g = a.length - 1;
        if (g >= 1 + (e ? 0 : -1) && f >= g) {
            let h = a[g];
            if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        d !== void 0 && (g = (b ? ? (b = a[t] | 0)) >> 14 & 1023 || 536870912, c >= g ? d != null && (a[g + (e ? 0 : -1)] = {
            [c]: d
        }) : a[f] = d);
        return b
    }

    function ze(a, b, c) {
        a = a.aa;
        return Ae(a, a[t] | 0, b, c) !== void 0
    }

    function Be(a, b, c, d) {
        var e = a.aa;
        return Ae(e, e[t] | 0, b, Ce(a, d, c)) !== void 0
    }

    function De(a, b, c) {
        return ve(a, b, void 0, c, Yc)
    }

    function w(a) {
        return a === mc ? 2 : 4
    }

    function Ee(a, b, c, d, e, f, g) {
        var h = a.aa,
            k = h[t] | 0;
        d = jc(a, k) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && qe(a) && (h = a.aa, k = h[t] | 0);
        var l = Fe(h, b, g),
            m = l === $b ? 7 : l[t] | 0,
            n = He(m, k);
        var p = n;
        4 & p ? f == null ? a = !1 : (!e && f === 0 && (512 & p || 1024 & p) && (a.constructor[Wb] = (a.constructor[Wb] | 0) + 1) < 5 && Ob(), a = f === 0 ? !1 : !(f & p)) : a = !0;
        if (a) {
            4 & n && (l = [...l], m = 0, n = Ie(n, k), k = ye(h, k, b, l, g));
            let q = p = 0;
            for (; p < l.length; p++) {
                let u = c(l[p]);
                u != null && (l[q++] = u)
            }
            q < p && (l.length = q);
            c = (n | 4) & -513;
            n = c &= -1025;
            f && (n |= f);
            n &= -4097
        }
        n !== m && (l[t] = n, 2 & n && Object.freeze(l));
        return l =
            Je(l, n, h, k, b, g, d, a, e)
    }

    function Je(a, b, c, d, e, f, g, h, k) {
        var l = b;
        g === 1 || (g !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Ke(b) || (b |= !a.length || h && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== l && (a[t] = b), Object.freeze(a)) : (g === 2 && Ke(b) && (a = [...a], l = 0, b = Ie(b, d), d = ye(c, d, e, a, f)), Ke(b) || (k || (b |= 16), b !== l && (a[t] = b)));
        2 & b || !(4096 & b || 16 & b) || se(c, d);
        return a
    }

    function Fe(a, b, c) {
        a = we(a, b, c);
        return Array.isArray(a) ? a : $b
    }

    function He(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Ke(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Le(a, b, c, d) {
        var e = a.aa,
            f = e[t] | 0;
        var g = jc(a, f);
        a: {!g && qe(a) && (e = a.aa, f = e[t] | 0);
                var h = we(e, b);a = !1;
                if (h == null) {
                    if (g) {
                        b = Vd();
                        break a
                    }
                    h = []
                } else if (h.constructor === Sd)
                    if (h.kd & 2 && !g) h = h.ii();
                    else {
                        b = h;
                        break a
                    }
                else Array.isArray(h) ? a = !!((h[t] | 0) & 2) : h = [];
                if (g) {
                    if (!h.length) {
                        b = Vd();
                        break a
                    }
                    a || (a = !0, ec(h))
                } else if (a) {
                    a = !1;
                    fc(h);
                    h = [...h];
                    for (let k = 0; k < h.length; k++) {
                        let l = h[k] = [...h[k]];
                        Array.isArray(l[1]) && (l[1] = ec(l[1]))
                    }
                    h = fc(h)
                }!a && f & 32 && hc(h);d = new Sd(h, c, Jd, d);f = ye(e, f, b, d);a || se(e, f);b = d
            }!g && c &&
            (b.Uk = !0);
        return b
    }

    function Me(a, b) {
        this.set(b, a)
    }

    function Ne(a, b, c, d) {
        re(a);
        var e = a.aa,
            f = e[t] | 0;
        if (c == null) return ye(e, f, b), a;
        var g = c === $b ? 7 : c[t] | 0,
            h = g,
            k = Ke(g),
            l = k || Object.isFrozen(c);
        k || (g = 0);
        l || (c = [...c], h = 0, g = Ie(g, f), l = !1);
        g |= 5;
        k = dc(g) ? ? 1024;
        g |= k;
        for (let m = 0; m < c.length; m++) {
            let n = c[m],
                p = d(n, k);
            Object.is(n, p) || (l && (c = [...c], h = 0, g = Ie(g, f), l = !1), c[m] = p)
        }
        g !== h && (l && (c = [...c], g = Ie(g, f)), c[t] = g);
        ye(e, f, b, c);
        return a
    }

    function Oe(a, b, c, d) {
        re(a);
        var e = a.aa;
        ye(e, e[t] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function Pe(a, b, c, d) {
        re(a);
        var e = a.aa,
            f = e[t] | 0;
        if (d == null) {
            var g = Qe(e);
            if (Re(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = Qe(e);
            let h = Re(g, e, f, c);
            h !== b && (h && (f = ye(e, f, h)), g.set(c, b))
        }
        ye(e, f, b, d);
        return a
    }

    function Ce(a, b, c) {
        return Se(a, b) === c ? c : -1
    }

    function Se(a, b) {
        a = a.aa;
        return Re(Qe(a), a, void 0, b)
    }

    function Qe(a) {
        return a[Ub] ? ? (a[Ub] = new Map)
    }

    function Re(a, b, c, d) {
        var e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            let g = d[f];
            we(b, g) != null && (e !== 0 && (c = ye(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function Ae(a, b, c, d) {
        var e = !1;
        d = we(a, d, void 0, f => {
            var g = Hd(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !jc(d) && se(a, b), d
    }

    function Te(a, b, c) {
        a = a.aa;
        return Ae(a, a[t] | 0, b, c) || b[Tb] || (b[Tb] = Id(b))
    }

    function x(a, b, c) {
        var d = a.aa,
            e = d[t] | 0;
        b = Ae(d, e, b, c);
        if (b == null) return b;
        e = d[t] | 0;
        if (!jc(a, e)) {
            let f = Td(b);
            f !== b && (qe(a) && (d = a.aa, e = d[t] | 0), b = f, e = ye(d, e, c, b), se(d, e))
        }
        return b
    }

    function Ue(a, b, c, d, e, f, g, h, k) {
        var l = jc(a, c);
        f = l ? 1 : f;
        h = !!h || f === 3;
        l = k && !l;
        (f === 2 || l) && qe(a) && (b = a.aa, c = b[t] | 0);
        a = Fe(b, e, g);
        var m = a === $b ? 7 : a[t] | 0,
            n = He(m, c);
        if (k = !(4 & n)) {
            var p = a,
                q = c;
            let u = !!(2 & n);
            u && (q |= 2);
            let A = !u,
                D = !0,
                K = 0,
                I = 0;
            for (; K < p.length; K++) {
                let G = Hd(p[K], d, !1, q);
                if (G instanceof d) {
                    if (!u) {
                        let E = jc(G);
                        A && (A = !E);
                        D && (D = E)
                    }
                    p[I++] = G
                }
            }
            I < K && (p.length = I);
            n |= 4;
            n = D ? n & -4097 : n | 4096;
            n = A ? n | 8 : n & -9
        }
        n !== m && (a[t] = n, 2 & n && Object.freeze(a));
        if (l && !(8 & n || !a.length && (f === 1 || (f !== 4 ? 0 : 2 & n || !(16 & n) && 32 & c)))) {
            Ke(n) && (a = [...a], n = Ie(n, c), c = ye(b, c, e, a, g));
            d = a;
            l = n;
            for (m = 0; m < d.length; m++) p = d[m], n = Td(p), p !== n && (d[m] = n);
            l |= 8;
            n = l = d.length ? l | 4096 : l & -4097;
            a[t] = n
        }
        return a = Je(a, n, b, c, e, g, f, k, h)
    }

    function Ve(a, b, c, d) {
        var e = a.aa;
        return Ue(a, e, e[t] | 0, b, c, d, void 0, !1, !0)
    }

    function We(a) {
        a == null && (a = void 0);
        return a
    }

    function y(a, b, c) {
        c = We(c);
        xe(a, b, c);
        c && !jc(c) && se(a.aa);
        return a
    }

    function z(a, b, c, d) {
        d = We(d);
        Pe(a, b, c, d);
        d && !jc(d) && se(a.aa);
        return a
    }

    function Xe(a, b, c) {
        re(a);
        var d = a.aa,
            e = d[t] | 0;
        if (c == null) return ye(d, e, b), a;
        var f = c === $b ? 7 : c[t] | 0,
            g = f,
            h = Ke(f),
            k = h || Object.isFrozen(c),
            l = !0,
            m = !0;
        for (let p = 0; p < c.length; p++) {
            var n = c[p];
            h || (n = jc(n), l && (l = !n), m && (m = n))
        }
        h || (f = l ? 13 : 5, f = m ? f & -4097 : f | 4096);
        k && f === g || (c = [...c], g = 0, f = Ie(f, e));
        f !== g && (c[t] = f);
        e = ye(d, e, b, c);
        2 & f || !(4096 & f || 16 & f) || se(d, e);
        return a
    }

    function Ie(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function Ye(a, b, c, d, e, f, g, h) {
        re(a);
        b = Ee(a, b, e, 2, !0, void 0, f);
        e = dc(b === $b ? 7 : b[t] | 0) ? ? 1024;
        if (h)
            if (Array.isArray(d))
                for (g = d.length, h = 0; h < g; h++) b.push(c(d[h], e));
            else
                for (let k of d) b.push(c(k, e));
        else {
            if (g) throw Error();
            b.push(c(d, e))
        }
        return a
    }

    function Ze(a, b, c, d) {
        var e = d;
        re(a);
        d = a.aa;
        b = Ue(a, d, d[t] | 0, c, b, 2, void 0, !0);
        e = e != null ? e : new c;
        b.push(e);
        var f = c = b === $b ? 7 : b[t] | 0;
        (e = jc(e)) ? (c &= -9, b.length === 1 && (c &= -4097)) : c |= 4096;
        c !== f && (b[t] = c);
        e || se(d);
        return a
    }

    function $e(a, b) {
        var c = af;
        re(a);
        var d = a.aa;
        c = Ue(a, d, d[t] | 0, c, 2, 2, void 0, !0);
        var e = 0,
            f = 0;
        if (Array.isArray(b)) {
            var g = b.length;
            for (let k = 0; k < g; k++) {
                var h = b[k];
                c.push(h);
                (h = jc(h)) && !e++ && (c[t] &= -9);
                h || f++ || bc(c, 4096)
            }
        } else
            for (g of b) b = g, c.push(b), (b = jc(b)) && !e++ && (c[t] &= -9), b || f++ || bc(c, 4096);
        f && se(d);
        return a
    }

    function bf(a, b) {
        return yd(ve(a, b, void 0, void 0, zd))
    }

    function cf(a, b, c) {
        return ve(a, b, void 0, c, zd)
    }

    function df(a, b) {
        return Ee(a, b, zd, 1, void 0, 1024)
    }

    function ef(a, b, c, d) {
        return cd(ve(a, b, c, d))
    }

    function ff(a, b, c) {
        return id(ve(a, b, void 0, c))
    }

    function B(a, b) {
        return ef(a, b) ? ? !1
    }

    function gf(a, b) {
        return ff(a, b) ? ? 0
    }

    function hf(a, b) {
        return cf(a, b) ? ? te
    }

    function jf(a, b, c = 0) {
        return De(a, b) ? ? c
    }

    function C(a, b) {
        return Gd(ve(a, b)) ? ? ""
    }

    function F(a, b) {
        return gd(ve(a, b)) ? ? 0
    }

    function kf(a) {
        {
            a = ve(a, 10, void 0, void 0, Bd);
            let b = typeof a;
            a = a == null ? a : b === "bigint" ? String(Tc(64, a)) : ed(a) ? b === "string" ? wd(a) : td(a) : void 0
        }
        return a ? ? "0"
    }

    function lf(a, b) {
        return Ee(a, b, id, w())
    }

    function mf(a, b) {
        return Ee(a, b, gd, w())
    }

    function nf(a, b, c, d) {
        return x(a, b, Ce(a, d, c))
    }

    function of (a, b) {
        return ef(a, b, void 0, ue)
    }

    function pf(a, b) {
        return Gd(ve(a, b, void 0, ue))
    }

    function qf(a, b) {
        return gd(ve(a, b, void 0, ue))
    }

    function rf(a, b, c) {
        return xe(a, b, c == null ? c : bd(c))
    }

    function sf(a, b, c) {
        return Oe(a, b, c == null ? c : bd(c), !1)
    }

    function tf(a, b, c) {
        return xe(a, b, c == null ? c : hd(c))
    }

    function uf(a, b, c) {
        return Oe(a, b, c == null ? c : hd(c), 0)
    }

    function vf(a, b, c) {
        return xe(a, b, c == null ? c : ld(c, void 0))
    }

    function wf(a, b, c) {
        return Oe(a, b, c == null ? c : ld(c, void 0), "0")
    }

    function xf(a, b, c, d) {
        return Pe(a, b, c, d == null ? d : ld(d, void 0))
    }

    function yf(a, b, c) {
        return Oe(a, b, c == null ? c : Ad(c, void 0), "0")
    }

    function If(a, b, c) {
        return xe(a, b, Fd(c))
    }

    function Jf(a, b, c) {
        return Oe(a, b, Fd(c), "")
    }

    function Kf(a, b, c) {
        return xe(a, b, c == null ? c : fd(c))
    }

    function H(a, b, c) {
        return Oe(a, b, c == null ? c : fd(c), 0)
    }

    function Lf(a, b) {
        return Gd(ve(a, b)) != null
    }

    function Mf(a, b) {
        b = Ce(a, Nf, b);
        return Gd(ve(a, b)) != null
    };

    function Of(a) {
        return new Pf(a & 4294967295, Math.floor(a / 4294967296))
    }

    function Qf(a) {
        if (!a) return Rf || (Rf = new Pf(0, 0));
        if (!/^\d+$/.test(a)) return null;
        Qc(a);
        return new Pf(Gc, Hc)
    }
    var Pf = class {
        constructor(a, b) {
            this.j = a >>> 0;
            this.g = b >>> 0
        }
    };
    let Rf;

    function Sf(a) {
        return new Tf(a & 4294967295, Math.floor(a / 4294967296))
    }

    function Uf(a) {
        if (!a) return Vf || (Vf = new Tf(0, 0));
        if (!/^-?\d+$/.test(a)) return null;
        Qc(a);
        return new Tf(Gc, Hc)
    }
    var Tf = class {
        constructor(a, b) {
            this.j = a >>> 0;
            this.g = b >>> 0
        }
    };
    let Vf, Wf, Xf, Yf, Zf, $f, ag, bg;

    function cg(a, b, c) {
        if (typeof BigInt64Array !== "undefined") return ag || (ag = new BigInt64Array(1), bg = new Uint32Array(ag.buffer), ag[0] = BigInt(1), $f = bg[0] === 1), ag[0] = a, a = $f ? 0 : 1, new b(bg[a], bg[1 - a]);
        Zf || (Wf = BigInt(Number.MIN_SAFE_INTEGER), Xf = BigInt(Number.MAX_SAFE_INTEGER), Yf = BigInt(4294967295), Zf = BigInt(32));
        if (a >= Wf && a <= Xf) return c(Number(a));
        a = BigInt.asUintN(64, a);
        return new b(Number(a & Yf), Number(a >> Zf))
    };

    function dg(a, b, c) {
        for (; c > 0 || b > 127;) a.g.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
        a.g.push(b)
    }

    function eg(a, b) {
        for (; b > 127;) a.g.push(b & 127 | 128), b >>>= 7;
        a.g.push(b)
    }

    function fg(a, b) {
        if (b >= 0) eg(a, b);
        else {
            for (let c = 0; c < 9; c++) a.g.push(b & 127 | 128), b >>= 7;
            a.g.push(1)
        }
    }
    var gg = class {
        constructor() {
            this.g = []
        }
        length() {
            return this.g.length
        }
        end() {
            var a = this.g;
            this.g = [];
            return a
        }
    };

    function hg(a, b) {
        b.length !== 0 && (a.l.push(b), a.j += b.length)
    }

    function ig(a, b, c) {
        eg(a.g, b * 8 + c)
    }

    function jg(a, b) {
        ig(a, b, 2);
        b = a.g.end();
        hg(a, b);
        b.push(a.j);
        return b
    }

    function kg(a, b) {
        var c = b.pop();
        for (c = a.j + a.g.length() - c; c > 127;) b.push(c & 127 | 128), c >>>= 7, a.j++;
        b.push(c);
        a.j++
    }
    var lg = class {
        constructor() {
            this.l = [];
            this.j = 0;
            this.g = new gg
        }
    };

    function mg() {
        var a = class {
            constructor() {
                throw Error();
            }
        };
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var ng = mg(),
        og = mg(),
        pg = mg(),
        qg = mg(),
        rg = mg(),
        sg = mg(),
        tg = mg(),
        ug = mg(),
        vg = mg();

    function wg(a) {
        return Td(a)
    }

    function xg(a) {
        return JSON.stringify($d(a))
    }

    function yg(a) {
        return pe(a)
    }
    var J = class {
        constructor(a) {
            this.aa = ge(a, void 0, void 0, 2048)
        }
        toJSON() {
            return $d(this)
        }
    };
    J.prototype[Zb] = ic;

    function zg(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error();
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error();
        return new a(hc(b))
    };
    var Ag = class {
        constructor(a, b) {
            this.g = a;
            a = Ea(ng);
            this.j = !!a && b === a || !1
        }
    };

    function Bg(a, b, c, d, e) {
        b = Cg(b, d);
        b != null && (c = jg(a, c), e(b, a), kg(a, c))
    }
    const Dg = new Ag(Bg, ng),
        Eg = new Ag(Bg, ng);
    var Fg = Symbol(),
        Gg = Symbol();
    let Hg, Ig;

    function Jg(a) {
        var b = Kg,
            c = Lg,
            d = a[Fg];
        if (d) return d;
        d = {};
        d.bp = a;
        d.sj = de(a[0]);
        var e = a[1],
            f = 1;
        e && e.constructor === Object && (d.El = e, e = a[++f], typeof e === "function" && (d.im = !0, Hg ? ? (Hg = e), Ig ? ? (Ig = a[f + 1]), e = a[f += 2]));
        for (var g = {}; e && Array.isArray(e) && e.length && typeof e[0] === "number" && e[0] > 0;) {
            for (var h = 0; h < e.length; h++) g[e[h]] = e;
            e = a[++f]
        }
        for (h = 1; e !== void 0;) {
            typeof e === "number" && (h += e, e = a[++f]);
            let m;
            var k = void 0;
            e instanceof Ag ? m = e : (m = Dg, f--);
            if (m ? .j) {
                e = a[++f];
                k = a;
                var l = f;
                typeof e === "function" && (e = e(), k[l] =
                    e);
                k = e
            }
            e = a[++f];
            l = h + 1;
            typeof e === "number" && e < 0 && (l -= e, e = a[++f]);
            for (; h < l; h++) {
                let n = g[h];
                k ? c(d, h, m, k, n) : b(d, h, m, n)
            }
        }
        return a[Fg] = d
    }

    function Cg(a, b) {
        if (a instanceof J) return a.aa;
        if (Array.isArray(a)) return ge(a, b[0], b[1])
    };

    function Kg(a, b, c) {
        a[b] = c.g
    }

    function Lg(a, b, c, d) {
        var e, f, g = c.g;
        a[b] = (h, k, l) => g(h, k, l, f || (f = Jg(d).sj), e || (e = Mg(d)))
    }

    function Mg(a) {
        var b = a[Gg];
        if (!b) {
            let c = Jg(a);
            b = (d, e) => Ng(d, e, c);
            a[Gg] = b
        }
        return b
    }

    function Ng(a, b, c) {
        nc(a, a[t] | 0, (d, e) => {
            if (e != null) {
                var f = Og(c, d);
                f ? f(b, e, d) : d < 500 || Qb(Xb, 3)
            }
        })
    }

    function Og(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.El)
            if (c = c[b]) {
                c = Array.isArray(c) ? c[0] instanceof Ag ? c : [Eg, c] : [c, void 0];
                var d = c[0].g;
                if (c = c[1]) {
                    let e = Mg(c),
                        f = Jg(c).sj;
                    c = a.im ? Ig(f, e) : (g, h, k) => d(g, h, k, f, e)
                } else c = d;
                return a[b] = c
            }
    };
    var lh = (a, b) => {
        var c = new lg;
        Ng(a.aa, c, Jg(b));
        hg(c, c.g.end());
        a = new Uint8Array(c.j);
        b = c.l;
        var d = b.length,
            e = 0;
        for (let f = 0; f < d; f++) {
            let g = b[f];
            a.set(g, e);
            e += g.length
        }
        c.l = [a];
        return a
    };

    function mh(a, b) {
        return new Ag(a, b)
    }
    var nh = mh(function(a, b, c) {
            b = Yc(b);
            b != null && (ig(a, c, 5), a = a.g, c = Ic || (Ic = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), Hc = 0, b = Gc = c.getUint32(0, !0), a.g.push(b >>> 0 & 255), a.g.push(b >>> 8 & 255), a.g.push(b >>> 16 & 255), a.g.push(b >>> 24 & 255))
        }, ug),
        oh = mh(function(a, b, c) {
            b = Cd(b);
            if (b != null) {
                switch (typeof b) {
                    case "string":
                        Uf(b)
                }
                if (b != null) switch (ig(a, c, 0), typeof b) {
                    case "number":
                        a = a.g;
                        Kc(b);
                        dg(a, Gc, Hc);
                        break;
                    case "bigint":
                        c = cg(b, Tf, Sf);
                        dg(a.g, c.j, c.g);
                        break;
                    default:
                        c = Uf(b), dg(a.g, c.j, c.g)
                }
            }
        }, sg),
        ph = mh(function(a,
            b, c) {
            b = Dd(b);
            if (b != null) {
                switch (typeof b) {
                    case "string":
                        Qf(b)
                }
                if (b != null) switch (ig(a, c, 0), typeof b) {
                    case "number":
                        a = a.g;
                        Kc(b);
                        dg(a, Gc, Hc);
                        break;
                    case "bigint":
                        c = cg(b, Pf, Of);
                        dg(a.g, c.j, c.g);
                        break;
                    default:
                        c = Qf(b), dg(a.g, c.j, c.g)
                }
            }
        }, tg),
        qh = mh(function(a, b, c) {
            b = id(b);
            b != null && b != null && (ig(a, c, 0), fg(a.g, b))
        }, qg),
        rh = mh(function(a, b, c) {
            b = cd(b);
            b != null && (ig(a, c, 0), a.g.g.push(b ? 1 : 0))
        }, og),
        sh = mh(function(a, b, c) {
            b = Gd(b);
            b != null && (b = (Ja || (Ja = new TextEncoder)).encode(b), ig(a, c, 2), eg(a.g, b.length), hg(a, a.g.end()),
                hg(a, b))
        }, pg),
        th = function(a, b, c = ng) {
            return new Ag(b, c)
        }(function(a, b, c, d, e) {
            if (a.g() !== 2) return !1;
            var f = a.j;
            d = ge(void 0, d[0], d[1]);
            var g = b[t] | 0;
            if (g & 2) throw Error();
            var h = g & 128 ? oc : void 0,
                k = Fe(b, c, h),
                l = k === $b ? 7 : k[t] | 0,
                m = He(l, g);
            if (2 & m || Ke(m) || 16 & m) m === l || Ke(m) || (k[t] = m), k = [...k], l = 0, m = Ie(m, g), ye(b, g, c, k, h);
            m &= -13;
            m !== l && (k[t] = m);
            k.push(d);
            f.call(a, d, e);
            return !0
        }, function(a, b, c, d, e) {
            if (Array.isArray(b)) {
                for (let l = 0; l < b.length; l++) {
                    var f = a,
                        g = c,
                        h = e,
                        k = Cg(b[l], d);
                    k != null && (g = jg(f, g), h(k, f), kg(f, g))
                }
                a = b[t] |
                    0;
                a & 1 || (b[t] = a | 1)
            }
        }),
        uh = mh(function(a, b, c) {
            b = kd(b);
            b != null && b != null && (ig(a, c, 0), eg(a.g, b))
        }, rg),
        vh = mh(function(a, b, c) {
            b = id(b);
            b != null && (b = parseInt(b, 10), ig(a, c, 0), fg(a.g, b))
        }, vg),
        wh;
    wh = new Ag(function(a, b, c) {
        if (Array.isArray(b)) {
            var d = b[t] | 0;
            if (!(d & 4)) {
                for (var e = 0, f = 0; e < b.length; e++) {
                    let g = id(b[e]);
                    g != null && (b[f++] = g)
                }
                f < e && (b.length = f);
                e = (d | 5) & -1537;
                e !== d && (b[t] = e);
                e & 2 && Object.freeze(b)
            }
        } else b = void 0;
        if (b != null && b.length) {
            c = jg(a, c);
            for (d = 0; d < b.length; d++) fg(a.g, b[d]);
            kg(a, c)
        }
    }, vg);

    function xh(a) {
        return () => a[Tb] || (a[Tb] = Id(a))
    }

    function yh(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(hc(b))
            }
            return b
        }
    };
    var zh = class extends J {};
    var Ah = class extends J {};
    var Bh = class extends J {
        getLevel() {
            return F(this, 1)
        }
    };

    function Ch(a) {
        return C(a, 1)
    }

    function Dh(a) {
        var b = new Eh;
        return If(b, 1, a)
    }
    var Eh = class extends J {};
    var Fh = class extends J {};

    function Gh(a, b) {
        return z(a, 2, Hh, b)
    }
    var Ih = class extends J {},
        Hh = [1, 2, 3, 5];

    function Jh(a) {
        var b = new Kh;
        return Xe(b, 1, a)
    }
    var Kh = class extends J {};
    var Lh = class extends J {};
    var Mh = class extends J {
        Bb() {
            return x(this, Kh, 1)
        }
        setContent(a) {
            return y(this, 1, a)
        }
        g() {
            return ze(this, Kh, 1)
        }
        pf() {
            return F(this, 3)
        }
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var Nh = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Oh(a) {
        return new Nh(a[0].toLowerCase())
    };
    let Ph = globalThis.trustedTypes,
        Qh;

    function Rh() {
        var a = null;
        if (!Ph) return a;
        try {
            let b = c => c;
            a = Ph.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    }

    function Sh() {
        Qh === void 0 && (Qh = Rh());
        return Qh
    };
    var Th = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Uh(a) {
        var b = Sh();
        a = b ? b.createHTML(a) : a;
        return new Th(a)
    }

    function Vh(a) {
        if (a instanceof Th) return a.g;
        throw Error("");
    };
    var Wh = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Xh(a) {
        if (a instanceof Wh) return a.g;
        throw Error("");
    };

    function Yh(a) {
        return new Wh(a[0])
    };
    var Zh = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function $h(a) {
        var b = Sh();
        a = b ? b.createScriptURL(a) : a;
        return new Zh(a)
    }

    function ai(a) {
        if (a instanceof Zh) return a.g;
        throw Error("");
    };
    var bi = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function ci(a) {
        if (bi.test(a)) return a
    };

    function di(a) {
        return a instanceof Th ? a : Uh(String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"))
    }

    function ei(a) {
        return fi(a)
    }

    function fi(a) {
        var b = di("");
        return Uh(a.map(c => Vh(di(c))).join(Vh(b).toString()))
    }
    const gi = /^[a-z][a-z\d-]*$/i,
        hi = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" ");
    var ii = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" ");
    const ji = ["action", "formaction", "href"];

    function ki(a) {
        if (!gi.test(a)) throw Error("");
        if (hi.indexOf(a.toUpperCase()) !== -1) throw Error("");
    }

    function li(a, b, c) {
        ki(a);
        var d = `<${a}`;
        b && (d += mi(b));
        Array.isArray(c) || (c = c === void 0 ? [] : [c]);
        ii.indexOf(a.toUpperCase()) !== -1 ? d += ">" : (b = ei(c.map(e => e instanceof Th ? e : di(String(e)))), d += ">" + b.toString() + "</" + a + ">");
        return Uh(d)
    }

    function mi(a) {
        var b = "",
            c = Object.keys(a);
        for (let f = 0; f < c.length; f++) {
            var d = c[f],
                e = a[d];
            if (!gi.test(d)) throw Error("");
            if (e !== void 0 && e !== null) {
                if (/^on./i.test(d)) throw Error("");
                ji.indexOf(d.toLowerCase()) !== -1 && (e = ci(String(e)) || "about:invalid#zClosurez");
                e = `${d}="${di(String(e))}"`;
                b += " " + e
            }
        }
        return b
    };

    function ni(a, ...b) {
        if (b.length === 0) return $h(a[0]);
        var c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return $h(c)
    }

    function oi(a, b) {
        a = ai(a).toString();
        var c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return pi(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function pi(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(k => e(k, h)) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(g => e(g[1], g[0])) : d.forEach(e);
        return $h(a + b + c)
    };
    ni `https://www.google.com/recaptcha/api2/aframe`;
    let qi = [];

    function ri() {
        var a = qi;
        qi = [];
        for (let b of a) try {
            b()
        } catch {}
    };

    function si() {
        return !1
    }

    function ti() {
        return !0
    }

    function ui(a) {
        var b = arguments,
            c = b.length;
        return function() {
            for (let d = 0; d < c; d++)
                if (!b[d].apply(this, arguments)) return !1;
            return !0
        }
    }

    function vi(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function wi(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function xi(a) {
        var b = a;
        return function() {
            if (b) {
                let c = b;
                b = null;
                c()
            }
        }
    }

    function yi(a, b) {
        var c = 0;
        return function(d) {
            r.clearTimeout(c);
            var e = arguments;
            c = r.setTimeout(function() {
                a.apply(b, e)
            }, 63)
        }
    }

    function zi(a, b) {
        function c() {
            e = r.setTimeout(d, 63);
            var h = g;
            g = [];
            a.apply(b, h)
        }

        function d() {
            e = 0;
            f && (f = !1, c())
        }
        var e = 0,
            f = !1,
            g = [];
        return function(h) {
            g = arguments;
            e ? f = !0 : c()
        }
    };

    function Ai(a, b) {
        return Math.min(Math.max(a, 0), b)
    }

    function Bi(a) {
        return Array.prototype.reduce.call(arguments, function(b, c) {
            return b + c
        }, 0)
    }

    function Ci(a) {
        return Bi.apply(null, arguments) / arguments.length
    };

    function Di(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    }
    aa = Di.prototype;
    aa.equals = function(a) {
        return a instanceof Di && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    aa.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    aa.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    aa.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    aa.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };

    function Ei(a, b) {
        this.width = a;
        this.height = b
    }

    function Fi(a, b) {
        return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
    }
    aa = Ei.prototype;
    aa.aspectRatio = function() {
        return this.width / this.height
    };
    aa.isEmpty = function() {
        return !(this.width * this.height)
    };
    aa.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    aa.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    aa.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    aa.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function Gi(a, b) {
        for (let c in a) b.call(void 0, a[c], c, a)
    }

    function Hi(a, b) {
        var c = {};
        for (let d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function Ii(a, b) {
        for (let c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function Ji(a) {
        var b = Ki;
        a: {
            for (let c in b)
                if (b[c] == a) {
                    a = !0;
                    break a
                }
            a = !1
        }
        return a
    }

    function Li(a) {
        var b = [],
            c = 0;
        for (let d in a) b[c++] = a[d];
        return b
    }

    function $i(a) {
        var b = {};
        for (let c in a) b[c] = a[c];
        return b
    }
    const aj = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function bj(a, b) {
        for (let e = 1; e < arguments.length; e++) {
            var c = arguments[e];
            for (d in c) a[d] = c[d];
            for (let f = 0; f < aj.length; f++) {
                var d = aj[f];
                Object.prototype.hasOwnProperty.call(c, d) && (a[d] = c[d])
            }
        }
    };

    function cj(a, b) {
        b = ci(b);
        b !== void 0 && (a.href = b)
    };

    function dj(a, b) {
        a.src = ai(b).toString()
    };

    function ej(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function fj(a, b) {
        a.src = ai(b);
        (b = ej(a.ownerDocument)) && a.setAttribute("nonce", b)
    };

    function gj(a, b) {
        if (a.nodeType === 1 && /^(script|style)$/i.test(a.tagName)) throw Error("");
        a.innerHTML = Vh(b)
    }

    function hj(a, b, c) {
        var d = [Oh `width`, Oh `height`];
        if (d.length === 0) throw Error("");
        d = d.map(f => {
            if (f instanceof Nh) f = f.g;
            else throw Error("");
            return f
        });
        var e = b.toLowerCase();
        if (d.every(f => e.indexOf(f) !== 0)) throw Error(`Attribute "${b}" does not match any of the allowed prefixes.`);
        a.setAttribute(b, c)
    }

    function ij(a, b, c) {
        if (a.namespaceURI !== "http://www.w3.org/1999/xhtml") throw Error(`Cannot set attribute '${b}' on '${a.tagName}'.Element is not in the HTML namespace`);
        b = b.toLowerCase();
        switch (`${a.tagName} ${b}`) {
            case "A href":
                cj(a, c);
                break;
            case "AREA href":
                b = ci(c);
                b !== void 0 && (a.href = b);
                break;
            case "BASE href":
                a.href = ai(c);
                break;
            case "BUTTON formaction":
                b = ci(c);
                b !== void 0 && (a.formAction = b);
                break;
            case "EMBED src":
                a.src = ai(c);
                break;
            case "FORM action":
                b = ci(c);
                b !== void 0 && (a.action = b);
                break;
            case "IFRAME src":
                dj(a,
                    c);
                break;
            case "IFRAME srcdoc":
                a.srcdoc = Vh(c);
                break;
            case "IFRAME sandbox":
                throw Error("Can't set 'sandbox' on iframe tags. Use setIframeSrcWithIntent or setIframeSrcdocWithIntent instead");
            case "INPUT formaction":
                b = ci(c);
                b !== void 0 && (a.formAction = b);
                break;
            case "LINK href":
                throw Error("Can't set 'href' attribute on link tags. Use setLinkHrefAndRel instead");
            case "LINK rel":
                throw Error("Can't set 'rel' attribute on link tags. Use setLinkHrefAndRel instead");
            case "OBJECT data":
                a.data = ai(c);
                break;
            case "SCRIPT src":
                fj(a,
                    c);
                break;
            default:
                if (/^on./.test(b)) throw Error(`Attribute "${b}" looks like an event handler attribute. Please use a safe alternative like addEventListener instead.`);
                a.setAttribute(b, c)
        }
    };

    function jj(a, b) {
        var c = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        var d = b ? b.createElement("div") : r.document.createElement("div");
        return a.replace(kj, function(e, f) {
            var g = c[e];
            if (g) return g;
            f.charAt(0) == "#" && (f = Number("0" + f.slice(1)), isNaN(f) || (g = String.fromCharCode(f)));
            g || (gj(d, Uh(e + " ")), g = d.firstChild.nodeValue.slice(0, -1));
            return c[e] = g
        })
    }
    var kj = /&([^;\s<&]+);?/g;

    function lj() {
        return Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36)
    }

    function mj(a) {
        var b = 0;
        for (let c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
        return b
    }

    function nj(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function oj(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };

    function pj(a) {
        return a ? new qj(rj(a)) : Ia || (Ia = new qj)
    }

    function sj(a, b) {
        Gi(b, function(c, d) {
            d == "style" ? a.style.cssText = c : d == "class" ? a.className = c : d == "for" ? a.htmlFor = c : uj.hasOwnProperty(d) ? a.setAttribute(uj[d], c) : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0 ? a.setAttribute(d, c) : a[d] = c
        })
    }
    var uj = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };

    function vj(a) {
        a = a.document;
        a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
        return new Ei(a.clientWidth, a.clientHeight)
    }

    function wj(a) {
        return a.scrollingElement ? a.scrollingElement : xb || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement
    }

    function xj(a) {
        return a ? a.defaultView : window
    }

    function yj(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function zj(a) {
        a && a.parentNode && a.parentNode.removeChild(a)
    }

    function rj(a) {
        return a.nodeType == 9 ? a : a.ownerDocument || a.document
    }
    var Aj = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        },
        Bj = {
            IMG: " ",
            BR: "\n"
        };

    function Cj(a) {
        var b = [];
        Dj(a, b, !0);
        a = b.join("");
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g, "");
        a = a.replace(/ +/g, " ");
        a != " " && (a = a.replace(/^\s*/, ""));
        return a
    }

    function Dj(a, b, c) {
        if (!(a.nodeName in Aj))
            if (a.nodeType == 3) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in Bj) b.push(Bj[a.nodeName]);
        else
            for (a = a.firstChild; a;) Dj(a, b, c), a = a.nextSibling
    }

    function Ej(a, b, c) {
        if (!b && !c) return null;
        var d = b ? String(b).toUpperCase() : null;
        return Ij(a, function(e) {
            return (!d || e.nodeName == d) && (!c || typeof e.className === "string" && ib(e.className.split(/\s+/), c))
        })
    }

    function Ij(a, b) {
        for (var c = 0; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function qj(a) {
        this.g = a || r.document || document
    }
    qj.prototype.j = function(a) {
        var b = this.g;
        return typeof a === "string" ? b.getElementById(a) : a
    };
    qj.prototype.l = qj.prototype.j;

    function Jj(a, b) {
        return yj(a.g, b)
    }

    function Kj(a, b) {
        var c = a.g;
        a = yj(c, "DIV");
        gj(a, b);
        if (a.childNodes.length == 1) b = a.removeChild(a.firstChild);
        else
            for (b = c.createDocumentFragment(); a.firstChild;) b.appendChild(a.firstChild);
        return b
    }
    qj.prototype.Ba = function() {
        return this.g.defaultView
    };
    qj.prototype.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };

    function Lj(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    aa = Lj.prototype;
    aa.getWidth = function() {
        return this.right - this.left
    };
    aa.getHeight = function() {
        return this.bottom - this.top
    };

    function Mj(a) {
        return new Lj(a.top, a.right, a.bottom, a.left)
    }
    aa.contains = function(a) {
        return this && a ? a instanceof Lj ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    aa.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    aa.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    aa.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    aa.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };

    function Nj(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    }

    function Oj(a) {
        return new Lj(a.top, a.left + a.width, a.top + a.height, a.left)
    }

    function Pj(a, b) {
        var c = Math.max(a.left, b.left),
            d = Math.min(a.left + a.width, b.left + b.width);
        if (c <= d) {
            let e = Math.max(a.top, b.top);
            a = Math.min(a.top + a.height, b.top + b.height);
            if (e <= a) return new Nj(c, e, d - c, a - e)
        }
        return null
    }
    aa = Nj.prototype;
    aa.contains = function(a) {
        return a instanceof Di ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    aa.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    aa.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    aa.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    aa.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.width *= a;
        this.top *= b;
        this.height *= b;
        return this
    };

    function Qj(a, b, c) {
        if (typeof b === "string") Rj(a, c, b);
        else
            for (let d in b) Rj(a, b[d], d)
    }
    var Sj = /^--.+/;

    function Rj(a, b, c) {
        (c = Tj(a, c)) && (Sj.test(c) ? a.style.setProperty(c, b) : a.style[c] = b)
    }
    var Uj = {};

    function Tj(a, b) {
        var c = Uj[b];
        if (!c) {
            var d = nj(b);
            c = d;
            a.style[d] === void 0 && (d = (xb ? "Webkit" : wb ? "Moz" : null) + oj(d), a.style[d] !== void 0 && (c = d));
            Uj[b] = c
        }
        return c
    }

    function Vj(a, b) {
        var c = a.style[nj(b)];
        return typeof c !== "undefined" ? c : a.style[Tj(a, b)] || ""
    }

    function Wj(a, b) {
        a: {
            var c = rj(a);
            if (c.defaultView && c.defaultView.getComputedStyle && (c = c.defaultView.getComputedStyle(a, null))) {
                c = c[b] || c.getPropertyValue(b) || "";
                break a
            }
            c = ""
        }
        return c || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function Xj(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function Yj(a) {
        var b = rj(a),
            c = Wj(a, "position"),
            d = c == "fixed" || c == "absolute";
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (a.nodeType == 11 && a.host && (a = a.host), c = Wj(a, "position"), d = d && c == "static" && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || c == "fixed" || c == "absolute" || c == "relative")) return a;
        return null
    }

    function Zj(a) {
        var b = rj(a),
            c = new Di(0, 0);
        if (a == (b ? rj(b) : document).documentElement) return c;
        a = Xj(a);
        var d = pj(b).g;
        b = wj(d);
        d = d.defaultView;
        b = new Di(d ? .pageXOffset || b.scrollLeft, d ? .pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function ak(a) {
        typeof a == "number" && (a = Math.round(a) + "px");
        return a
    }

    function bk(a) {
        var b = ck;
        if (Wj(a, "display") != "none") return b(a);
        var c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function ck(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = xb && !b && !c;
        return (b === void 0 || d) && a.getBoundingClientRect ? (a = Xj(a), new Ei(a.right - a.left, a.bottom - a.top)) : new Ei(b, c)
    };
    var dk = {
            passive: !0
        },
        ek = wi(() => {
            var a = !1;
            try {
                let b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                r.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function fk(a) {
        return a ? a.passive && ek() ? a : a.capture || !1 : !1
    }

    function gk(a, b, c, d) {
        return typeof a.addEventListener === "function" ? (a.addEventListener(b, c, fk(d)), !0) : !1
    }

    function hk(a, b, c, d) {
        return typeof a.removeEventListener === "function" ? (a.removeEventListener(b, c, fk(d)), !0) : !1
    }

    function ik(a, b) {
        a.document.readyState === "complete" ? (qi.push(b), qi.length === 1 && (window.Promise ? Promise.resolve().then(ri) : (a = window.setImmediate, sc(a) ? a(ri) : setTimeout(ri, 0)))) : a.addEventListener("load", b)
    };

    function jk(a) {
        var b = window;
        new Promise((c, d) => {
            function e() {
                f.onload = null;
                f.onerror = null;
                f.parentElement ? .removeChild(f)
            }
            var f = b.document.createElement("script");
            f.onload = () => {
                e();
                c()
            };
            f.onerror = () => {
                e();
                d(void 0)
            };
            f.type = "text/javascript";
            fj(f, a);
            b.document.readyState !== "complete" ? gk(b, "load", () => {
                b.document.body.appendChild(f)
            }) : b.document.body.appendChild(f)
        })
    };

    function kk() {
        lk || (lk = new mk);
        return lk
    }
    async function nk() {
        try {
            await window.android.webview.getExperimentalMediaIntegrityTokenProvider({
                cloudProjectNumber: 187810013193
            })
        } catch (b) {
            if (b && typeof b === "object" && typeof b.mediaIntegrityErrorName !== "string") {
                var a = b.code;
                if (typeof a === "function") try {
                    a()
                } catch (c) {}
            }
        }
    }
    var mk = class {
            constructor() {
                this.Kb = !1
            }
        },
        lk;
    async function ok(a) {
        var b = `${a.Bc?"https://ep1.adtrafficquality.google/getconfig/sodar":"https://pagead2.googlesyndication.com/getconfig/sodar"}?sv=200&tid=${a.j}&tv=${a.l}&st=${a.g==="cr"&&a.zc==="env"?a.g+"_"+a.zc:a.zc}${a.Sc?`&sjk=${a.Sc}`:""}${a.A?"&sde=1":""}`,
            c = void 0;
        try {
            c = await pk(b)
        } catch (g) {}
        if (c && !a.C) {
            b = a.Sc || c.sodar_query_id;
            var d = c.rc_enable !== void 0 && a.B ? c.rc_enable : "n",
                e = c.bg_snapshot_delay_ms === void 0 ? "0" : c.bg_snapshot_delay_ms,
                f = c.is_gen_204 === void 0 ? "1" : c.is_gen_204;
            if (b && c.bg_hash_basename &&
                c.bg_binary) return c = {
                context: a.g,
                Qk: c.bg_hash_basename,
                Pk: c.bg_binary,
                lm: a.j + "_" + a.l,
                Sc: b,
                zc: a.zc,
                yf: d,
                Uf: e,
                wf: f,
                Bc: a.Bc,
                Ee: a.Ee
            }, a.Kb ? { ...c,
                Kb: !0
            } : c
        }
    }
    let pk = a => new Promise((b, c) => {
        var d = new XMLHttpRequest;
        d.onreadystatechange = () => {
            d.readyState === d.DONE && (d.status >= 200 && d.status < 300 ? b(Object.assign(Object.create(null), JSON.parse(d.responseText))) : c())
        };
        d.open("GET", a, !0);
        d.send()
    });
    async function qk(a) {
        if (a.Kb) {
            kk().Kb = !0;
            var b = kk();
            window.android && window.android.webview && window.android.webview.getExperimentalMediaIntegrityTokenProvider && b.Kb && nk()
        }
        if (a = await ok(a)) {
            b = window;
            var c = b.GoogleGcLKhOms;
            c && typeof c.push === "function" || (c = b.GoogleGcLKhOms = []);
            let d = {
                _ctx_: a.context,
                _bgv_: a.Qk,
                _bgp_: a.Pk,
                _li_: a.lm,
                _jk_: a.Sc,
                _st_: a.zc,
                _rc_: a.yf,
                _dl_: a.Uf,
                _g2_: a.wf,
                _atqg_: a.Bc ? "1" : "0",
                _sic_: a.Ee ? "1" : "0"
            };
            a.Kb && (d._wvp_ = "1");
            c.push(d);
            if (c = b.GoogleDX5YKUSkRag) {
                if (c.length > 0 && (b = c.shift())) try {
                    b()
                } catch (e) {}
            } else if (c =
                b.GoogleDX5YKUSk) b.GoogleDX5YKUSk = void 0, c[1]();
            a = a.Bc ? ni `https://ep2.adtrafficquality.google/sodar/${"sodar2"}.js` : ni `https://tpc.googlesyndication.com/sodar/${"sodar2"}.js`;
            jk(a)
        }
    };
    var rk = class extends J {
        g() {
            return C(this, 1)
        }
    };
    var sk = class extends J {};

    function tk(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            case 8:
                return "afs";
            case 9:
                return "oos";
            default:
                return "unk"
        }
    }
    var uk = class {
            constructor(a) {
                this.j = a.A;
                this.l = a.B;
                this.g = a.C;
                this.Sc = a.Sc;
                this.win = a.Ba();
                this.zc = a.zc;
                this.yf = a.yf;
                this.Uf = a.Uf;
                this.wf = a.wf;
                this.B = a.j;
                this.Bc = a.Bc;
                this.Kb = a.Kb;
                this.A = a.g;
                this.Ee = a.Ee;
                this.C = a.l
            }
        },
        vk = class {
            constructor(a, b, c) {
                this.A = a;
                this.B = b;
                this.C = c;
                this.win = window;
                this.zc = "env";
                this.yf = "n";
                this.Uf = "0";
                this.wf = "1";
                this.j = !0;
                this.l = this.Ee = this.g = this.Kb = this.Bc = !1
            }
            Ba() {
                return this.win
            }
            build() {
                return new uk(this)
            }
        };
    var wk = class extends J {
            jb() {
                return C(this, 1)
            }
        },
        Nf = [2, 3, 5];

    function xk() {
        var a = new yk;
        return If(a, 1, "")
    }

    function zk(a) {
        return Ve(a, wk, 2, w())
    }

    function Ak(a, b) {
        return Xe(a, 2, b)
    }
    var yk = class extends J {};
    var Bk = class extends J {};

    function Ck(a) {
        var b = new Dk;
        return If(b, 1, a)
    }
    var Dk = class extends J {
        getValue() {
            return C(this, 1)
        }
        getVersion() {
            return F(this, 5)
        }
    };
    var Ek = class extends J {};

    function Fk(a) {
        var b = new Gk;
        return Kf(b, 1, a)
    }
    var Gk = class extends J {};

    function Hk(a) {
        var b = new Ik;
        return If(b, 1, a)
    }

    function Jk(a) {
        var b = window.Date.now();
        b = Number.isFinite(b) ? Math.round(b) : 0;
        return vf(a, 3, b)
    }
    var Ik = class extends J {
            jb() {
                return pf(this, 1)
            }
            g() {
                return Lf(this, 2)
            }
            l() {
                return Gd(ve(this, 2))
            }
            setError(a) {
                return y(this, 10, a)
            }
        },
        Kk = yh(Ik);
    var Lk = class extends J {};
    Lk.prototype.g = function(a) {
        return function() {
            return lh(this, a)
        }
    }([0, th, [0, 1, [0, ph, -2], -1, sh, -1, rh, [0, 3, vh, sh], oh, wh, uh], th, [0, sh, -1, oh, qh, -2, oh, nh, rh, [0, vh], rh]]);
    var Mk = class extends J {};

    function Nk(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Ok(a) {
        var b = [];
        Nk(a, c => {
            b.push(c)
        });
        return b
    };

    function Pk(a) {
        var b = a.location.href;
        if (a === a.top) return {
            url: b,
            sh: !0
        };
        var c = !1,
            d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        (a = a.location.ancestorOrigins) && (a = a[a.length - 1]) && b ? .indexOf(a) === -1 && (c = !1, b = a);
        return {
            url: b,
            sh: c
        }
    }

    function Qk(a) {
        try {
            return !!a && a.location.href != null && tb(a, "foo")
        } catch {
            return !1
        }
    }

    function Rk(a, b = r) {
        b = Sk(b);
        for (var c = 0; b && c++ < 40 && !a(b);) b = Sk(b)
    }

    function Sk(a) {
        try {
            let b = a.parent;
            if (b && b !== a) return b
        } catch {}
        return null
    }

    function Tk(a) {
        return Qk(a.top) ? a.top : null
    }

    function Uk(a) {
        for (var b = a; a && a !== a.parent;) a = a.parent, Qk(a) && (b = a);
        return b
    };

    function Vk() {
        return Ma && Pa ? Pa.mobile : !Wk() && (Sa("iPod") || Sa("iPhone") || Sa("Android") || Sa("IEMobile"))
    }

    function Wk() {
        return Ma && Pa ? !Pa.mobile && (Sa("iPad") || Sa("Android") || Sa("Silk")) : Sa("iPad") || Sa("Android") && !Sa("Mobile") || Sa("Silk")
    };

    function Xk(a) {
        return Oa().indexOf(a) != -1
    }

    function Yk(a) {
        return $a() && Vk() ? Zk(a) : 1
    }
    var $k = wi(() => Vk() ? 2 : Wk() ? 1 : 0);

    function Zk(a) {
        var b = Tk(a);
        if (!b) return 1;
        a = $k() === 0;
        var c = !!b.document.querySelector('meta[name=viewport][content*="width=device-width"]'),
            d = b.innerWidth;
        b = b.outerWidth;
        if (d === 0) return 1;
        var e = Math.round((b / d + Number.EPSILON) * 100) / 100;
        return e === 1 ? 1 : a || c ? e : Math.round((b / d / .4 + Number.EPSILON) * 100) / 100
    }
    var al = wi(() => {
        var a = Math.random;
        return ["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"].some(Xk) || a() < 1E-4
    });

    function bl() {
        if (!globalThis.crypto) return Math.random();
        try {
            let a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (a) {
            return Math.random()
        }
    };
    let cl, dl = 64;

    function el() {
        try {
            return cl ? ? (cl = new Uint32Array(64)), dl >= 64 && (crypto.getRandomValues(cl), dl = 0), cl[dl++]
        } catch (a) {
            return Math.floor(Math.random() * 2 ** 32)
        }
    };

    function fl(a, b) {
        if (!qc(a.goog_pvsid)) try {
            let c = el() + (el() & 2 ** 21 - 1) * 2 ** 32;
            Object.defineProperty(a, "goog_pvsid", {
                value: c,
                configurable: !1
            })
        } catch (c) {
            b.Ka({
                methodName: 784,
                hb: c
            })
        }
        a = Number(a.goog_pvsid);
        (!a || a <= 0) && b.Ka({
            methodName: 784,
            hb: Error(`Invalid correlator, ${a}`)
        });
        return a || -1
    };

    function gl(a, b) {
        var c = hl("SCRIPT", a);
        fj(c, b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function il(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }
    var jl = /^([0-9.]+)px$/,
        kl = /^(-?[0-9.]{1,30})$/;

    function ll(a) {
        if (!kl.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function ml(a) {
        return (a = jl.exec(a)) ? +a[1] : null
    }
    var nl = {
        Kn: "allow-forms",
        Ln: "allow-modals",
        Mn: "allow-orientation-lock",
        Nn: "allow-pointer-lock",
        On: "allow-popups",
        Pn: "allow-popups-to-escape-sandbox",
        Qn: "allow-presentation",
        Rn: "allow-same-origin",
        Sn: "allow-scripts",
        Tn: "allow-top-navigation",
        Un: "allow-top-navigation-by-user-activation"
    };
    const ol = wi(() => Ok(nl));

    function pl(a) {
        var b = ol();
        return a.length ? db(b, c => !ib(a, c)) : b
    }

    function ql() {
        var a = hl("IFRAME"),
            b = {};
        bb(ol(), c => {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    }
    var rl = () => {
            var a = ql();
            return !(!a["allow-top-navigation-by-user-activation"] || !a["allow-popups-to-escape-sandbox"])
        },
        sl = (a, b) => {
            try {
                return !(!a.frames || !a.frames[b])
            } catch {
                return !1
            }
        },
        tl = (a, b) => {
            for (let c = 0; c < 50; ++c) {
                if (sl(a, b)) return a;
                if (!(a = Sk(a))) break
            }
            return null
        },
        L = (a, b) => {
            Nk(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        },
        vl = (a, b) => {
            if ("length" in a.style) {
                a = a.style;
                let c = a.length;
                for (let d = 0; d < c; d++) {
                    let e = a[d];
                    b(a[e], e, a)
                }
            } else a = ul(a.style.cssText), Nk(a, b)
        },
        ul = a => {
            var b = {};
            if (a) {
                let c = /\s*:\s*/;
                bb((a || "").split(/\s*;\s*/), d => {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d && e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        wl = a => {
            var b = /!\s*important/i;
            vl(a, (c, d) => {
                b.test(c) ? b.test(c) : a.style.setProperty(d, c, "important")
            })
        };
    const xl = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        yl = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        zl = /.*domain\.test$/,
        Al = /\.prod\.google\.com(:\d+)?$/;
    var Bl = a => xl[a] || yl.test(a) || zl.test(a) || Al.test(a),
        Cl = (a, b) => fl(a, {
            Ka: c => {
                var d = c.methodName;
                c = c.hb;
                b ? .Da(d, c)
            }
        }),
        Dl = (a, b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        }),
        El = a => a.top == a ? 0 : Qk(a.top) ? 1 : 2;

    function hl(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function Fl(a, b, c = null, d = !1, e = !1) {
        Gl(a, b, c, d, e)
    }

    function Gl(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        var f = hl("IMG", a.document);
        if (c || d) {
            let g = h => {
                c && c(h);
                d && jb(a.google_image_requests, f);
                hk(f, "load", g);
                hk(f, "error", g)
            };
            gk(f, "load", g);
            gk(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function Hl(a, b) {
        var c = `https://pagead2.googlesyndication.com/pagead/gen_204?id=${b}`;
        Nk(a, (d, e) => {
            if (d || d === 0) c += `&${e}=${encodeURIComponent(String(d))}`
        });
        Il(c)
    }

    function Il(a) {
        var b = window;
        b.fetch ? b.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }) : Fl(b, a, void 0, !1, !1)
    };
    let Jl = null;
    var Kl = window;
    var Ll = class extends J {};
    var Ml = class extends J {
        getCorrelator() {
            return hf(this, 1)
        }
        setCorrelator(a) {
            return wf(this, 1, a)
        }
    };
    var Nl = class extends J {};
    let Ol = null,
        Pl = null;

    function Ql() {
        if (Ol != null) return Ol;
        Ol = !1;
        try {
            let a = Tk(r);
            a && a.location.hash.indexOf("google_logging") !== -1 && (Ol = !0)
        } catch (a) {}
        return Ol
    }

    function Rl() {
        if (Pl != null) return Pl;
        Pl = !1;
        try {
            let a = Tk(r);
            a && a.location.hash.indexOf("auto_ads_logging") !== -1 && (Pl = !0)
        } catch (a) {}
        return Pl
    }
    var Sl = (a, b = []) => {
        var c = !1;
        r.google_logging_queue || (c = !0, r.google_logging_queue = []);
        r.google_logging_queue.push([a, b]);
        c && Ql() && gl(r.document, ni `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };
    var Tl = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function Ul(a) {
        return new Tl(a, {
            message: Vl(a)
        })
    }

    function Vl(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        a.stack && (b = Wl(a.stack, b));
        return b
    }

    function Wl(a, b) {
        try {
            a.indexOf(b) == -1 && (a = b + "\n" + a);
            let c;
            for (; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (c) {
            return b
        }
    };
    const Xl = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Yl = class {
            constructor(a, b) {
                this.g = a;
                this.j = b
            }
        },
        Zl = class {
            constructor(a, b, c) {
                this.url = a;
                this.win = b;
                this.g = !!c;
                this.depth = null
            }
        };
    let $l = null;

    function tm() {
        var a = window;
        if ($l === null) {
            $l = "";
            try {
                let b = "";
                try {
                    b = a.top.location.hash
                } catch (c) {
                    b = a.location.hash
                }
                if (b) {
                    let c = b.match(/\bdeid=([\d,]+)/);
                    $l = c ? c[1] : ""
                }
            } catch (b) {}
        }
        return $l
    };

    function um() {
        var a = r.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function vm() {
        var a = r.performance;
        return a && a.now ? a.now() : null
    };
    var wm = class {
        constructor(a, b) {
            var c = vm() || um();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const xm = r.performance,
        ym = !!(xm && xm.mark && xm.measure && xm.clearMarks),
        zm = wi(() => {
            var a;
            if (a = ym) a = tm(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function Am(a) {
        a && xm && zm() && (xm.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), xm.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Bm(a) {
        a.g = !1;
        a.events !== a.j.google_js_reporting_queue && (zm() && bb(a.events, Am), a.events.length = 0)
    }
    var Cm = class {
        constructor(a) {
            this.events = [];
            this.j = a || r;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.events = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = zm() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new wm(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            xm && zm() && xm.mark(b);
            return a
        }
        end(a) {
            if (this.g && qc(a.value)) {
                a.duration = (vm() || um()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                xm && zm() && xm.mark(b);
                !this.g || this.events.length >
                    2048 || this.events.push(a)
            }
        }
    };

    function Dm(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    }

    function Em(a, b, c, d, e) {
        var f = [];
        Nk(a, (g, h) => {
            (g = Fm(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function Fm(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        v(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                let f = [];
                for (let g = 0; g < a.length; g++) f.push(Fm(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Em(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Gm(a) {
        var b = 1;
        for (let c in a.j) c.length > b && (b = c.length);
        return 3997 - b - a.l.length - 1
    }

    function Hm(a, b, c, d) {
        b = b + "//" + c + d;
        var e = Gm(a) - d.length;
        if (e < 0) return "";
        a.g.sort((f, g) => f - g);
        d = null;
        c = "";
        for (let f = 0; f < a.g.length; f++) {
            let g = a.g[f],
                h = a.j[g];
            for (let k = 0; k < h.length; k++) {
                if (!e) {
                    d = d == null ? g : d;
                    break
                }
                let l = Em(h[k], a.l, ",$");
                if (l) {
                    l = c + l;
                    if (e >= l.length) {
                        e -= l.length;
                        b += l;
                        c = a.l;
                        break
                    }
                    d = d == null ? g : d
                }
            }
        }
        a = "";
        d != null && (a = `${c}trn=${d}`);
        return b + a
    }
    var Im = class {
        constructor() {
            this.l = "&";
            this.j = {};
            this.A = 0;
            this.g = []
        }
    };
    const Um = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Vm(a, b, c) {
        if (Array.isArray(b))
            for (let d = 0; d < b.length; d++) Vm(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    }

    function Wm(a, b, c) {
        c = c != null ? "=" + encodeURIComponent(String(c)) : "";
        if (b += c) {
            c = a.indexOf("#");
            c < 0 && (c = a.length);
            let d = a.indexOf("?"),
                e;
            d < 0 || d > c ? (d = c, e = "") : e = a.substring(d + 1, c);
            a = [a.slice(0, d), e, a.slice(c)];
            c = a[1];
            a[1] = b ? c ? c + "&" + b : b : c;
            a = a[0] + (a[1] ? "?" + a[1] : "") + a[2]
        }
        return a
    }
    const Xm = /#|$/;

    function Ym(a, b) {
        var c = a.search(Xm);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    };
    var an = class {
        constructor(a = null) {
            this.F = Zm;
            this.j = a;
            this.g = null;
            this.A = !1;
            this.qa = this.Da
        }
        l(a) {
            this.g = a
        }
        B(a) {
            this.A = a
        }
        uc(a, b, c) {
            try {
                if (this.j && this.j.g) {
                    var d = this.j.start(a.toString(), 3);
                    var e = b();
                    this.j.end(d)
                } else e = b()
            } catch (f) {
                b = !0;
                try {
                    Am(d), b = this.qa(a, Ul(f), void 0, c)
                } catch (g) {
                    this.Da(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return e
        }
        wc(a, b, c, d) {
            return (...e) => this.uc(a, () => b.apply(c, e), d)
        }
        Da(a, b, c, d, e) {
            e = e || "jserror";
            var f = void 0;
            try {
                let E = new Im;
                var g = E;
                g.g.push(1);
                g.j[1] = Dm("context",
                    a);
                b.error && b.meta && b.id || (b = Ul(b));
                g = b;
                if (g.msg) {
                    b = E;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.j[2] = Dm("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.g) try {
                    this.g(h)
                } catch (ia) {}
                if (d) try {
                    d(h)
                } catch (ia) {}
                d = E;
                k = [k];
                d.g.push(3);
                d.j[3] = k;
                var l;
                if (!(l = p)) {
                    d = r;
                    k = [];
                    h = null;
                    do {
                        var m = d;
                        if (Qk(m)) {
                            var n = m.location.href;
                            h = m.document && m.document.referrer || null
                        } else n = h, h = null;
                        k.push(new Zl(n || "", m));
                        try {
                            d = m.parent
                        } catch (ia) {
                            d = null
                        }
                    } while (d && m !== d);
                    for (let ia = 0, Fa = k.length - 1; ia <= Fa; ++ia) k[ia].depth = Fa - ia;
                    m = r;
                    if (m.location &&
                        m.location.ancestorOrigins && m.location.ancestorOrigins.length === k.length - 1)
                        for (n = 1; n < k.length; ++n) {
                            let ia = k[n];
                            ia.url || (ia.url = m.location.ancestorOrigins[n - 1] || "", ia.g = !0)
                        }
                    l = k
                }
                var p = l;
                let Q = new Zl(r.location.href, r, !1);
                l = null;
                let wa = p.length - 1;
                for (m = wa; m >= 0; --m) {
                    var q = p[m];
                    !l && Xl.test(q.url) && (l = q);
                    if (q.url && !q.g) {
                        Q = q;
                        break
                    }
                }
                q = null;
                let Ca = p.length && p[wa].url;
                Q.depth !== 0 && Ca && (q = p[wa]);
                f = new Yl(Q, q);
                if (f.j) {
                    p = E;
                    var u = f.j.url || "";
                    p.g.push(4);
                    p.j[4] = Dm("top", u)
                }
                var A = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    let ia =
                        f.g.url.match(Um);
                    var D = ia[1],
                        K = ia[3],
                        I = ia[4];
                    u = "";
                    D && (u += D + ":");
                    K && (u += "//", u += K, I && (u += ":" + I));
                    var G = u
                } else G = "";
                D = E;
                A = [A, {
                    url: G
                }];
                D.g.push(5);
                D.j[5] = A;
                $m(this.F, e, E, this.A, c)
            } catch (E) {
                try {
                    $m(this.F, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Vl(E),
                        url: f ? .g.url ? ? ""
                    }, this.A, c)
                } catch (Q) {}
            }
            return !0
        }
        va(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.Da(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    var bn = class extends J {};

    function cn(a, b) {
        try {
            let c = d => [{
                [d.Yf]: d.Ff
            }];
            return JSON.stringify([a.filter(d => d.pe).map(c), $d(b), a.filter(d => !d.pe).map(c)])
        } catch (c) {
            return dn(c, b), ""
        }
    }

    function dn(a, b) {
        try {
            Hl({
                m: Vl(a instanceof Error ? a : Error(String(a))),
                b: F(b, 1) || null,
                v: C(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }

    function en(a) {
        if (a.C) {
            var b = a.A,
                c = Set;
            var d = lf(a.A, 3);
            c = [...(new c([...d, ...a.C()]))];
            Ne(b, 3, c, hd)
        }
        return pe(a.A)
    }
    var fn = class {
        constructor(a, b, c) {
            this.C = c;
            c = new bn;
            a = H(c, 1, a);
            this.A = Jf(a, 2, b)
        }
    };

    function gn(a) {
        return Math.round(a)
    }

    function hn(a) {
        var b = new CompressionStream("gzip"),
            c = (new Response(b.readable)).arrayBuffer(),
            d = b.writable.getWriter(),
            e = typeof a === "string" ? (new TextEncoder).encode(a) : a;
        return d.ready.then(() => d.write(e)).then(() => d.close()).then(() => c).then(f => new Uint8Array(f))
    };

    function jn(a, b) {
        return Pe(a, 1, kn, Fd(b))
    }

    function ln(a, b) {
        return xf(a, 2, kn, b)
    }

    function mn(a, b) {
        return Pe(a, 3, kn, b == null ? b : bd(b))
    }
    var M = class extends J {},
        kn = [1, 2, 3];

    function nn(a, b) {
        return xf(a, 2, on, b)
    }

    function pn(a, b) {
        return Pe(a, 4, on, Xc(b))
    }
    var qn = class extends J {},
        on = [2, 4];

    function rn(a) {
        var b = new sn;
        return Jf(b, 1, a)
    }

    function tn(a, b) {
        return y(a, 3, b)
    }

    function N(a, b) {
        return Ze(a, 4, M, b)
    }
    var sn = class extends J {};
    var un = class extends J {
        g() {
            return C(this, 2)
        }
        getWidth() {
            return C(this, 3)
        }
        getHeight() {
            return C(this, 4)
        }
    };
    var vn = class extends J {};
    var wn = class extends J {};
    var xn = class extends J {};
    var yn = class extends J {},
        zn = [5, 6];
    var An = class extends J {
        getValue() {
            return F(this, 1)
        }
    };

    function Bn(a) {
        var b = new Cn;
        return Kf(b, 1, a)
    }
    var Cn = class extends J {
        getValue() {
            return F(this, 1)
        }
    };
    var Dn = class extends J {
        getValue() {
            return F(this, 1)
        }
    };
    var En = class extends J {
        getHeight() {
            return gf(this, 2)
        }
    };

    function Fn(a, b) {
        return tf(a, 1, b)
    }

    function Gn(a, b) {
        return Xe(a, 2, b)
    }
    var Hn = class extends J {};
    var In = class extends J {};
    var Jn = class extends J {};
    var Ln = class extends J {
            setError(a) {
                return z(this, 3, Kn, a)
            }
        },
        Kn = [2, 3];

    function Mn(a, b) {
        return wf(a, 1, b)
    }

    function Nn(a, b) {
        return wf(a, 2, b)
    }

    function On(a, b) {
        return wf(a, 3, b)
    }

    function Pn(a, b) {
        return wf(a, 4, b)
    }

    function Qn(a, b) {
        return wf(a, 5, b)
    }

    function Rn(a, b) {
        return Oe(a, 8, Xc(b), 0)
    }

    function Sn(a, b) {
        return Oe(a, 9, Xc(b), 0)
    }
    var Tn = class extends J {};

    function Un(a, b) {
        return wf(a, 1, b)
    }

    function Vn(a, b) {
        return wf(a, 2, b)
    }
    var Wn = class extends J {};

    function Xn(a, b) {
        Ze(a, 1, Wn, b)
    }
    var Yn = class extends J {};
    var Zn = class extends J {};

    function $n(a, b) {
        return Ne(a, 1, b, Ed)
    }

    function ao(a, b) {
        return Ne(a, 12, b, Ad)
    }

    function bo() {
        var a = new co;
        return Ye(a, 2, Ed, "irr", Gd)
    }

    function eo(a, b) {
        return sf(a, 3, b)
    }

    function fo(a, b) {
        return sf(a, 4, b)
    }

    function go(a, b) {
        return sf(a, 5, b)
    }

    function ho(a, b) {
        return sf(a, 7, b)
    }

    function io(a, b) {
        return sf(a, 8, b)
    }

    function jo(a, b) {
        return wf(a, 9, b)
    }

    function ko(a, b) {
        return Xe(a, 10, b)
    }

    function lo(a, b) {
        return Ne(a, 11, b, ld)
    }
    var co = class extends J {};

    function mo(a) {
        var b = no();
        y(a, 1, b)
    }

    function oo(a, b) {
        return wf(a, 2, b)
    }

    function po(a, b) {
        return Xe(a, 3, b)
    }

    function qo(a, b) {
        return Xe(a, 4, b)
    }

    function ro(a, b) {
        return Ze(a, 4, Cn, b)
    }

    function so(a, b) {
        return Xe(a, 5, b)
    }

    function to(a, b) {
        return Ne(a, 6, b, Ed)
    }

    function uo(a, b) {
        return wf(a, 7, b)
    }

    function vo(a, b) {
        return wf(a, 8, b)
    }

    function wo(a, b) {
        y(a, 9, b)
    }

    function xo(a, b) {
        return sf(a, 10, b)
    }

    function yo(a, b) {
        return sf(a, 11, b)
    }

    function zo(a, b) {
        return sf(a, 12, b)
    }
    var Ao = class extends J {};
    var Bo = class extends J {};
    var Co = class extends J {};
    var Do = class extends J {
        setLocation(a) {
            return H(this, 2, a)
        }
    };

    function Eo(a, b) {
        return If(a, 1, b)
    }

    function Fo(a, b) {
        return If(a, 2, b)
    }
    var Go = class extends J {};
    var Ho = class extends J {};

    function Io(a) {
        var b = new Jo;
        return H(b, 1, a)
    }
    var Jo = class extends J {};
    var Ko = class extends J {};
    var Lo = class extends J {};
    var Mo = class extends J {};
    var No = class extends J {},
        Oo = [1, 2];
    var Po = class extends J {};
    var Qo = class extends J {},
        Ro = [1];
    var So = class extends J {};
    var To = class extends J {};
    var Uo = class extends J {};
    var Vo = class extends J {};
    var Wo = class extends J {};
    var Xo = class extends J {};
    var Yo = class extends J {};
    var Zo = class extends J {};
    var $o = class extends J {};
    var ap = class extends J {
        getContentUrl() {
            return C(this, 1)
        }
    };
    var bp = class extends J {};

    function cp(a) {
        var b = new dp;
        return Ne(b, 1, a, fd)
    }
    var dp = class extends J {};
    var ep = class extends J {};

    function fp() {
        var a = new gp,
            b = new ep;
        return z(a, 1, hp, b)
    }

    function ip() {
        var a = new gp,
            b = new ep;
        return z(a, 9, hp, b)
    }

    function jp() {
        var a = new gp,
            b = new ep;
        return z(a, 13, hp, b)
    }

    function kp(a, b) {
        return z(a, 14, hp, b)
    }
    var gp = class extends J {},
        hp = [1, 9, 13, 14];
    var lp = class extends J {};
    var mp = class extends J {};
    var np = class extends J {};
    var op = class extends J {};

    function pp(a, b) {
        return yf(a, 10, b)
    }

    function qp(a, b) {
        return H(a, 1, b)
    }

    function rp(a, b) {
        return Jf(a, 4, b)
    }

    function sp(a, b) {
        return sf(a, 13, b)
    }
    var af = class extends J {};

    function tp(a) {
        return Ve(a, af, 2, w())
    }
    var up = class extends J {};
    var vp = class extends J {};
    var xp = class extends J {
            l() {
                return nf(this, up, 4, wp)
            }
            g() {
                return Be(this, up, 4, wp)
            }
        },
        wp = [4, 5];
    var yp = class extends J {
        pf() {
            return F(this, 2)
        }
    };
    var zp = class extends J {},
        Ap = [3];

    function Bp(a) {
        var b = new Cp;
        return Jf(b, 4, a)
    }

    function Dp(a, b) {
        return xe(a, 6, b == null ? b : Ad(b, void 0))
    }

    function Ep(a, b) {
        return y(a, 10, b)
    }
    var Cp = class extends J {};
    var Fp = class extends J {};
    var Gp = class extends J {
        l() {
            return x(this, up, 1)
        }
        g() {
            return ze(this, up, 1)
        }
    };
    var Hp = class extends J {};
    var Ip = class extends J {};
    var Jp = class extends J {};
    var Kp = class extends J {};
    var Lp = class extends J {};
    var Mp = class extends J {
            getClickPageEventIndex() {
                return hf(this, 1)
            }
            setClickPageEventIndex(a) {
                return wf(this, 1, a)
            }
        },
        Np = [2, 3, 4];
    var Pp = class extends J {
            l() {
                return nf(this, up, 4, Op)
            }
            g() {
                return Be(this, up, 4, Op)
            }
        },
        Op = [4, 6];
    var Qp = class extends J {},
        Rp = [3, 4, 5, 6, 7, 8, 9, 12, 14, 16, 17, 19, 20, 21, 22, 23, 24, 25, 26];

    function Sp(a, b) {
        return wf(a, 3, b)
    }
    var Tp = class extends J {},
        Up = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24];
    var Vp = class extends J {};

    function Wp() {
        var a = wg(Xp());
        return Jf(a, 1, Yp())
    }
    var Zp = class extends J {};
    var $p = class extends J {};
    var aq = class extends J {
        getTagSessionCorrelator() {
            return hf(this, 1)
        }
    };
    var bq = class extends J {},
        cq = [1, 7],
        dq = [4, 6, 8];
    var eq = class extends J {
            getTagSessionCorrelator() {
                return hf(this, 2)
            }
        },
        fq = [6, 7];
    class gq {
        constructor(a) {
            this.F = a;
            this.Zb = new hq(this.F)
        }
    }
    class hq {
        constructor(a) {
            this.F = a;
            this.Oe = new iq(this.F);
            this.vk = new jq(this.F);
            this.qf = new kq(this.F)
        }
    }
    class iq {
        constructor(a) {
            this.F = a;
            this.g = new lq(this.F);
            this.Tj = new mq(this.F)
        }
    }
    class lq {
        constructor(a) {
            this.F = a;
            this.j = new nq(this.F);
            this.g = new oq(this.F)
        }
    }
    class nq {
        constructor(a) {
            this.F = a
        }
        Od(a) {
            pq(this.F, tn(N(rn("xR0Czf"), jn(new M, a.status)), pn(new qn, a.Yc)))
        }
    }
    class oq {
        constructor(a) {
            this.F = a
        }
        Od(a) {
            pq(this.F, tn(N(rn("jM4CPd"), ln(new M, gn(a.Bn))), pn(new qn, a.Yc)))
        }
    }
    class mq {
        constructor(a) {
            this.F = a;
            this.wk = new qq(this.F);
            this.Ak = new rq(this.F);
            this.pg = new sq(this.F);
            this.Bk = new tq(this.F);
            this.Ck = new uq(this.F);
            this.Ek = new vq(this.F);
            this.Fk = new wq(this.F);
            this.qg = new xq(this.F);
            this.Yk = new yq(this.F);
            this.Kl = new zq(this.F);
            this.Rm = new Aq(this.F);
            this.nn = new Bq(this.F);
            this.Zh = new Cq(this.F);
            this.on = new Dq(this.F);
            this.bi = new Eq(this.F);
            this.qn = new Fq(this.F)
        }
    }
    class qq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(rn("VEDP7d"), jn(new M, a.language)), ln(new M, a.Pa)), nn(new qn, gn(a.ca))))
        }
    }
    class rq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(rn("igjuhc"), jn(new M, a.language)), ln(new M, a.Pa)), nn(new qn, gn(a.ca))))
        }
    }
    class sq {
        constructor(a) {
            this.F = a
        }
        Od(a) {
            pq(this.F, tn(N(N(N(N(N(rn("i3zJEd"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.outcome)), mn(new M, a.nc)), mn(new M, a.Oc)), pn(new qn, a.Yc)))
        }
    }
    class tq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(N(N(rn("JN0hVd"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.outcome)), mn(new M, a.nc)), mn(new M, a.Oc)), nn(new qn, gn(a.ca))))
        }
    }
    class uq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(rn("rmHfOd"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.reason)), nn(new qn, gn(a.ca))))
        }
    }
    class vq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(rn("VEyQic"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.format)), nn(new qn, gn(a.ca))))
        }
    }
    class wq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(rn("QFcNxc"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.format)), nn(new qn, gn(a.ca))))
        }
    }
    class xq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(N(rn("SIhp4"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.format)), mn(new M, a.nc)), nn(new qn, gn(a.ca))))
        }
    }
    class yq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(rn("Eeiun"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.format)), nn(new qn, gn(a.ca))))
        }
    }
    class zq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(N(rn("pVNWme"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.Lb)), ln(new M, a.format)), nn(new qn, gn(a.ca))))
        }
    }
    class Aq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(rn("pYLGPe"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.type)), nn(new qn, gn(a.ca))))
        }
    }
    class Bq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(rn("OyfJgf"), jn(new M, a.language)), ln(new M, a.Pa)), nn(new qn, gn(a.ca))))
        }
    }
    class Cq {
        constructor(a) {
            this.F = a
        }
        Od(a) {
            pq(this.F, tn(N(N(N(N(rn("vkypFe"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.outcome)), mn(new M, a.Oc)), pn(new qn, a.Yc)))
        }
    }
    class Dq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(N(rn("U2cYzb"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.outcome)), mn(new M, a.Oc)), nn(new qn, gn(a.ca))))
        }
    }
    class Eq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(rn("PsAR8b"), jn(new M, a.language)), ln(new M, a.Pa)), ln(new M, a.format)), nn(new qn, gn(a.ca))))
        }
    }
    class Fq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(rn("Ah4H"), jn(new M, a.language)), ln(new M, a.Pa)), nn(new qn, gn(a.ca))))
        }
    }
    class jq {
        constructor(a) {
            this.F = a;
            this.il = new Gq(this.F)
        }
    }
    class Gq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(N(N(rn("pA20Lb"), jn(new M, a.qk)), jn(new M, a.gl)), jn(new M, a.Dm)), nn(new qn, gn(a.ca))))
        }
    }
    class kq {
        constructor(a) {
            this.F = a;
            this.autoRefresh = new Hq(this.F);
            this.Ab = new Iq(this.F);
            this.outstream = new Jq(this.F);
            this.request = new Kq(this.F);
            this.threadYield = new Lq(this.F)
        }
    }
    class Hq {
        constructor(a) {
            this.F = a
        }
    }
    class Iq {
        constructor(a) {
            this.F = a;
            this.cf = new Mq(this.F)
        }
    }
    class Mq {
        constructor(a) {
            this.F = a
        }
        ua(a) {
            pq(this.F, tn(N(rn("Ka9ewd"), ln(new M, a.Vf)), nn(new qn, gn(a.ca))))
        }
    }
    class Jq {
        constructor(a) {
            this.F = a
        }
    }
    class Kq {
        constructor(a) {
            this.F = a
        }
    }
    class Lq {
        constructor(a) {
            this.F = a
        }
    }
    class Nq extends fn {
        constructor() {
            super(...arguments);
            this.Tb = new gq(this)
        }
    }

    function pq(a, ...b) {
        a.l(...b.map(c => ({
            pe: !1,
            Yf: 1,
            Ff: $d(c)
        })))
    }

    function Oq(a, ...b) {
        a.l(...b.map(c => ({
            pe: !0,
            Yf: 3,
            Ff: $d(c)
        })))
    }

    function Pq(a, ...b) {
        a.l(...b.map(c => ({
            pe: !0,
            Yf: 7,
            Ff: $d(c)
        })))
    }

    function Qq(a, ...b) {
        a.l(...b.map(c => ({
            pe: !0,
            Yf: 37,
            Ff: $d(c)
        })))
    }
    var Rq = class extends Nq {};

    function Sq(a, b) {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    }

    function Tq(a, b, c = 1, d = !1) {
        if (d) {
            d = typeof CompressionStream === "function";
            var e = b.length > 1024;
            typeof document !== "undefined" && document.visibilityState !== "hidden" && d && e ? hn(b).then(f => {
                var g = c === 1 ? 5 : 6;
                f = Bb(f);
                Sq(`${a}?e=${g}`, f)
            }).catch(() => {
                Sq(`${a}?e=${c}`, b)
            }) : Sq(`${a}?e=${c}`, b)
        } else Sq(`${a}?e=${c}`, b)
    }
    var Uq = class extends Rq {
            constructor(a) {
                super(2, a, void 0);
                this.g = Tq
            }
            l(...a) {
                try {
                    let b = cn(a, en(this));
                    this.g("https://pagead2.googlesyndication.com/pagead/ping", b, 1, !1)
                } catch (b) {
                    dn(b, en(this))
                }
            }
        },
        Vq = class extends Uq {};

    function Wq(a) {
        a.j !== null && (clearTimeout(a.j), a.j = null);
        if (a.g.length) {
            var b = cn(a.g, en(a));
            a.O("https://pagead2.googlesyndication.com/pagead/ping", b, 1, !1);
            a.g = []
        }
    }
    var Zq = class extends Rq {
            constructor(a, b, c, d, e) {
                super(2, a, Xq);
                this.O = Tq;
                this.T = b;
                this.G = c;
                this.J = d;
                this.B = e;
                this.g = [];
                this.j = null;
                this.D = !1
            }
            l(...a) {
                try {
                    this.J && cn(this.g.concat(a), en(this)).length >= 65536 && Wq(this), this.B && !this.D && (this.D = !0, Yq(this.B, () => {
                        Wq(this)
                    })), this.g.push(...a), this.g.length >= this.G && Wq(this), this.g.length && this.j === null && (this.j = setTimeout(() => {
                        Wq(this)
                    }, this.T))
                } catch (b) {
                    dn(b, en(this))
                }
            }
        },
        $q = class extends Zq {
            constructor(a, b = 1E3, c = 100, d = !1, e) {
                super(a, b, c, d && !0, e)
            }
        };
    var ar = a => {
        var b = "Pc";
        if (a.Pc && a.hasOwnProperty(b)) return a.Pc;
        b = new a;
        return a.Pc = b
    };

    function br(a, b, c) {
        return b[a] || c
    };

    function cr(a, b) {
        a.j = (c, d) => br(2, b, () => [])(c, 1, d);
        a.g = c => br(3, b, () => [])(c ? ? 1)
    }
    class dr {
        j() {
            return []
        }
        g() {
            return []
        }
    }

    function er(a, b) {
        return ar(dr).j(a, b)
    }

    function Xq(a) {
        return ar(dr).g(a)
    };

    function $m(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Im ? f = c : (f = new Im, Nk(c, (h, k) => {
                var l = f,
                    m = l.A++;
                h = Dm(k, h);
                l.g.push(m);
                l.j[m] = h
            }));
            let g = Hm(f, a.protocol, a.domain, a.path + b + "&");
            g && Fl(r, g)
        } catch (f) {}
    }

    function fr(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    var gr = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.protocol = "https:";
            this.g = Math.random()
        }
    };
    let Zm, hr;
    const ir = new Cm(window);
    (function(a) {
        Zm = a ? ? new gr;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        fr(Zm, window.google_srt);
        hr = new an(ir);
        hr.l(() => {});
        hr.B(!0);
        window.document.readyState === "complete" ? window.google_measure_js_timing || Bm(ir) : ir.g && gk(window, "load", () => {
            window.google_measure_js_timing || Bm(ir)
        })
    })();

    function jr(a) {
        hr.va(1085, a)
    };
    const kr = {
        "AMP-CAROUSEL": "ac",
        "AMP-FX-FLYING-CARPET": "fc",
        "AMP-LIGHTBOX": "lb",
        "AMP-STICKY-AD": "sa"
    };

    function lr(a = r) {
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function mr(a = lr()) {
        return a && a.mode ? +a.mode.version || null : null
    }

    function nr(a = lr()) {
        if (a && a.container) {
            a = a.container.split(",");
            let b = [];
            for (let c = 0; c < a.length; c++) b.push(kr[a[c]] || "x");
            return b.join()
        }
        return null
    }

    function or() {
        var a = lr();
        return a && a.initialIntersection
    }

    function pr() {
        var a = or();
        return a && a.rootBounds && ra(a.rootBounds) ? new Ei(a.rootBounds.width, a.rootBounds.height) : null
    }

    function qr(a = lr()) {
        return a ? Qk(a.master) ? a.master : null : null
    }

    function Pr(a, b) {
        var c = a.ampInaboxIframes = a.ampInaboxIframes || [],
            d = () => {},
            e = () => {};
        b && (c.push(b), e = () => {
            a.AMP && a.AMP.inaboxUnregisterIframe && a.AMP.inaboxUnregisterIframe(b);
            jb(c, b);
            d()
        });
        if (a.ampInaboxInitialized) return e;
        a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
        var f = g => {
            if (a.ampInaboxInitialized) g = !0;
            else {
                var h, k = g.data === "amp-ini-load";
                a.ampInaboxPendingMessages && !k && (h = /^amp-(\d{15,20})?/.exec(g.data)) && (a.ampInaboxPendingMessages.push(g), g = h[1], a.ampInaboxInitialized || g && !/^\d{15,20}$/.test(g) ||
                    a.document.querySelector('script[src$="amp4ads-host-v0.js"]') || gl(a.document, g ? ni `https://cdn.ampproject.org/rtv/${g}/amp4ads-host-v0.js` : ni `https://cdn.ampproject.org/amp4ads-host-v0.js`));
                g = !1
            }
            g && d()
        };
        c.google_amp_listener_added || (c.google_amp_listener_added = !0, gk(a, "message", f), d = () => {
            hk(a, "message", f)
        });
        return e
    };

    function Qr(a, b) {
        a = Rr(a);
        if (!a) return b;
        var c = b.slice(-1);
        return b + (c === "?" || c === "#" ? "" : "&") + a
    }

    function Rr(a) {
        var b = {};
        Nk(a, (c, d) => {
            if (c || c === 0 || c === !1) rc(c) && (c = c ? 1 : 0), b[d] = c
        });
        return Object.entries(b).map(([c, d]) => `${c}=${encodeURIComponent(String(d))}`).join("&")
    }

    function Sr(a) {
        if (a === "localhost") return ["localhost"];
        a = a.split(".");
        if (a.length < 2) return [];
        var b = [];
        for (let c = 0; c < a.length - 1; ++c) b.push(a.slice(c).join("."));
        return b
    };
    var Tr = a => {
            a = qr(lr(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1;
            return a.google_unique_id
        },
        Ur = a => {
            a = a.google_unique_id;
            return qc(a) ? a : 0
        },
        Vr = a => (a = a.google_ad_format) ? a.indexOf("_0ads") > 0 : !1,
        Wr = a => {
            var b = Number(a.google_ad_width),
                c = Number(a.google_ad_height);
            if (!(b > 0 && c > 0)) {
                a: {
                    try {
                        let e = String(a.google_ad_format);
                        if (e && e.match) {
                            let f = e.match(/(\d+)x(\d+)/i);
                            if (f) {
                                let g = parseInt(f[1], 10),
                                    h = parseInt(f[2], 10);
                                if (g > 0 && h > 0) {
                                    var d = {
                                        width: g,
                                        height: h
                                    };
                                    break a
                                }
                            }
                        }
                    } catch (e) {}
                    d = null
                }
                a = d;
                if (!a) return null;
                b = b > 0 ? b : a.width;c = c > 0 ? c : a.height
            }
            return {
                width: b,
                height: c
            }
        },
        Xr = a => {
            if (!a) return "";
            a = a.toLowerCase();
            a.substring(0, 3) != "ca-" && (a = "ca-" + a);
            return a
        };
    let Yr = (new Date).getTime();
    var Zr = {
        vo: 0,
        uo: 1,
        qo: 2,
        lo: 3,
        ro: 4,
        mo: 5,
        so: 6,
        oo: 7,
        po: 8,
        ko: 9,
        no: 10,
        wo: 11
    };
    var $r = {
        yo: 0,
        zo: 1,
        xo: 2
    };

    function as(a, b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
    }

    function bs(a) {
        a = a.map(b => new Lj(b.top, b.right, b.bottom, b.left));
        a = cs(a);
        return {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left
        }
    }

    function cs(a) {
        if (!a.length) throw Error("pso:box:m:nb");
        return a.slice(1).reduce((b, c) => {
            b.left = Math.min(b.left, c.left);
            b.top = Math.min(b.top, c.top);
            b.right = Math.max(b.right, c.right);
            b.bottom = Math.max(b.bottom, c.bottom);
            return b
        }, Mj(a[0]))
    };
    var Ki = {
        No: 0,
        bo: 1,
        fo: 2,
        co: 3,
        eo: 4,
        jo: 8,
        So: 9,
        Go: 10,
        Ho: 11,
        Ro: 16,
        ao: 17,
        Zn: 24,
        Fo: 25,
        Wn: 26,
        Vn: 27,
        lk: 30,
        Bo: 32,
        Eo: 40,
        Uo: 41,
        To: 42,
        Yn: 43,
        Io: 44
    };
    var ds = {
            overlays: 1,
            interstitials: 2,
            vignettes: 2,
            inserts: 3,
            immersives: 4,
            list_view: 5,
            full_page: 6,
            side_rails: 7
        },
        es = {
            [1]: 1,
            [2]: 1,
            [3]: 7,
            [4]: 7,
            [8]: 2,
            [27]: 3,
            [9]: 4,
            [30]: 5
        };
    var fs = 728 * 1.38;

    function gs(a, b = -1) {
        if (a !== a.top) {
            if (b < 0) a = !1;
            else {
                var c = hs(a, !0, !0),
                    d = is(a, !0);
                a = c > 0 && d > 0 && Math.abs(1 - a.screen.width / c) <= b && Math.abs(1 - a.screen.height / d) <= b
            }
            a = a ? 0 : 512
        } else a = 0;
        return a
    }

    function js(a, b = 420, c = !1, d = !1) {
        return (a = hs(a, c, d)) ? a > b ? 32768 : a < 320 ? 65536 : 0 : 16384
    }

    function ks(a) {
        return Math.max(0, ls(a, !0) - is(a))
    }

    function ms(a) {
        a = a.document;
        var b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function is(a, b = !1) {
        var c = ms(a).clientHeight;
        return b ? c * Yk(a) : c
    }

    function hs(a, b = !1, c = !1) {
        c = ms(a).clientWidth ? ? (c ? a.innerWidth : void 0);
        return b ? c * Yk(a) : c
    }

    function ls(a, b) {
        var c = ms(a);
        return b ? (a = is(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    }

    function ns(a, b) {
        return os(b) || b === 10 || !a.adCount ? !1 : b === 1 || b === 2 ? !(!a.adCount[1] && !a.adCount[2]) : (a = a.adCount[b]) ? a >= 1 : !1
    }

    function ps(a, b) {
        return a && a.source ? a.source === b || a.source.parent === b : !1
    }

    function qs(a) {
        return a.pageYOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    }

    function rs(a) {
        return a.pageXOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollLeft : a.pageXOffset
    }

    function ss(a) {
        var b = {},
            c;
        Array.isArray(a) ? c = a : a && a.key_value && (c = a.key_value);
        if (c)
            for (a = 0; a < c.length; a++) {
                let d = c[a];
                if ("key" in d && "value" in d) {
                    let e = d.value;
                    b[d.key] = e == null ? null : String(e)
                }
            }
        return b
    }

    function ts(a, b, c, d) {
        $m(c, b, {
            c: d.data.substring(0, 500),
            u: a.location.href.substring(0, 500)
        }, !0, .1);
        return !0
    }

    function us(a) {
        var b = {
            bottom: "auto",
            clear: "none",
            display: "inline",
            "float": "none",
            height: "auto",
            left: "auto",
            margin: 0,
            "margin-bottom": 0,
            "margin-left": 0,
            "margin-right": "0",
            "margin-top": 0,
            "max-height": "none",
            "max-width": "none",
            opacity: 1,
            overflow: "visible",
            padding: 0,
            "padding-bottom": 0,
            "padding-left": 0,
            "padding-right": 0,
            "padding-top": 0,
            position: "static",
            right: "auto",
            top: "auto",
            "vertical-align": "baseline",
            visibility: "visible",
            width: "auto",
            "z-index": "auto"
        };
        bb(Object.keys(b), c => {
            Vj(a, c) || Qj(a, c, b[c])
        });
        wl(a)
    }

    function os(a) {
        return a === 26 || a === 27 || a === 40 || a === 41 || a === 44
    };

    function vs(a, b) {
        ws(a).forEach(b, void 0)
    }

    function ws(a) {
        var b = [],
            c = a.length;
        for (let d = 0; d < c; d++) b.push(a[d]);
        return b
    };

    function xs(a, b) {
        return a.g[ys(b)] !== void 0
    }

    function zs(a) {
        var b = [];
        for (let c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.j[c]);
        return b
    }

    function As(a) {
        var b = [];
        for (let c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.g[c]);
        return b
    }
    var Bs = class {
        constructor() {
            this.g = {};
            this.j = {}
        }
        set(a, b) {
            var c = ys(a);
            this.g[c] = b;
            this.j[c] = a
        }
        get(a, b) {
            a = ys(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        je() {
            return zs(this).length
        }
        clear() {
            this.g = {};
            this.j = {}
        }
    };

    function ys(a) {
        return a instanceof Object ? String(sa(a)) : a + ""
    };
    var Cs = class {
        constructor(a) {
            this.g = new Bs;
            if (a)
                for (let b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return xs(this.g, a)
        }
    };
    const Ds = new Cs("IMG AMP-IMG IFRAME AMP-IFRAME HR EMBED OBJECT VIDEO AMP-VIDEO INPUT BUTTON SVG".split(" "));

    function Es(a) {
        sb(a.document.body.offsetHeight)
    };

    function Fs(a) {
        a && typeof a.dispose == "function" && a.dispose()
    };

    function Gs() {
        this.A = this.A;
        this.O = this.O
    }
    Gs.prototype.A = !1;
    Gs.prototype.dispose = function() {
        this.A || (this.A = !0, this.j())
    };
    Gs.prototype[ka(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function Hs(a, b) {
        Is(a, Ba(Fs, b))
    }

    function Is(a, b) {
        a.A ? b() : (a.O || (a.O = []), a.O.push(b))
    }
    Gs.prototype.j = function() {
        if (this.O)
            for (; this.O.length;) this.O.shift()()
    };

    function Xs(a) {
        a.g.forEach((b, c) => {
            if (b.overrides.delete(a)) {
                b = Array.from(b.overrides.values()).pop() || b.originalValue;
                var d = a.element;
                b ? d.style.setProperty(c, b.value, b.priority) : d.style.removeProperty(c)
            }
        })
    }

    function Ys(a, b, c) {
        c = {
            value: c,
            priority: "important"
        };
        var d = a.g.get(b);
        if (!d) {
            d = a.element;
            var e = d.style.getPropertyValue(b);
            d = {
                originalValue: e ? {
                    value: e,
                    priority: d.style.getPropertyPriority(b)
                } : null,
                overrides: new Map
            };
            a.g.set(b, d)
        }
        d.overrides.delete(a);
        d.overrides.set(a, c);
        a = a.element;
        c ? a.style.setProperty(b, c.value, c.priority) : a.style.removeProperty(b)
    }
    var Zs = class extends Gs {
        constructor(a, b) {
            super();
            this.element = b;
            a = a.googTempStyleOverrideInfo = a.googTempStyleOverrideInfo || new Map;
            var c = a.get(b);
            c ? b = c : (c = new Map, a.set(b, c), b = c);
            this.g = b
        }
        j() {
            Xs(this);
            super.j()
        }
    };

    function $s(a) {
        var b = new O(a.getValue());
        a.listen(c => b.g(c));
        return b
    }

    function at(a, b) {
        var c = new O({
            first: a.X,
            second: b.X
        });
        a.listen(() => c.g({
            first: a.X,
            second: b.X
        }));
        b.listen(() => c.g({
            first: a.X,
            second: b.X
        }));
        return c
    }

    function bt(...a) {
        var b = [...a],
            c = () => b.every(f => f.X),
            d = new O(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return ct(d)
    }

    function dt(...a) {
        var b = [...a],
            c = () => b.findIndex(f => f.X) !== -1,
            d = new O(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return ct(d)
    }

    function ct(a, b = et) {
        var c = a.X,
            d = new O(a.X);
        a.listen(e => {
            b(e, c) || (c = e, d.g(e))
        });
        return d
    }

    function ft(a, b, c) {
        return a.j(d => {
            d === b && c()
        })
    }

    function gt(a, b, c) {
        if (a.X === b) return c(), () => {};
        var d = {
            Td: null
        };
        d.Td = ft(a, b, () => {
            d.Td && (d.Td(), d.Td = null);
            c()
        });
        return d.Td
    }

    function ht(a, b, c) {
        ct(a).listen(d => {
            d === b && c()
        })
    }

    function it(a, b) {
        a.A && a.A();
        a.A = b.listen(c => a.g(c), !0)
    }

    function jt(a) {
        return {
            listen: b => a.listen(b),
            getValue: () => a.X
        }
    }
    var O = class {
        constructor(a) {
            this.X = a;
            this.l = new Map;
            this.C = 1;
            this.A = null
        }
        listen(a, b = !1) {
            var c = this.C++;
            this.l.set(c, a);
            b && a(this.X);
            return () => {
                this.l.delete(c)
            }
        }
        j(a) {
            return this.listen(a, !0)
        }
        B() {
            return this.X
        }
        g(a) {
            this.X = a;
            this.l.forEach(b => {
                b(this.X)
            })
        }
        map(a) {
            var b = new O(a(this.X));
            this.listen(c => b.g(a(c)));
            return b
        }
    };

    function et(a, b) {
        return a == b
    };

    function kt(a) {
        return new lt(a)
    }

    function mt(a, b) {
        bb(a.g, c => {
            c(b)
        })
    }
    var nt = class {
        constructor() {
            this.g = []
        }
    };
    class lt {
        constructor(a) {
            this.g = a
        }
        listen(a) {
            this.g.g.push(a)
        }
        map(a) {
            var b = new nt;
            this.listen(c => mt(b, a(c)));
            return kt(b)
        }
        delay(a, b) {
            var c = new nt;
            this.listen(d => {
                a.setTimeout(() => {
                    mt(c, d)
                }, b)
            });
            return kt(c)
        }
    }

    function ot(...a) {
        var b = new nt;
        a.forEach(c => {
            c.listen(d => {
                mt(b, d)
            })
        });
        return kt(b)
    };

    function pt(a) {
        return ct(at(a.g, a.l).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : qt(c, b)
        }))
    }
    var st = class {
        constructor(a) {
            this.j = a;
            this.g = new O(null);
            this.l = new O(null);
            this.A = new nt;
            this.D = b => {
                this.g.X == null && b.touches.length == 1 && this.g.g(b.touches[0])
            };
            this.B = b => {
                var c = this.g.X;
                c != null && (b = rt(c, b.changedTouches), b != null && (this.g.g(null), this.l.g(null), mt(this.A, qt(c, b))))
            };
            this.C = b => {
                var c = this.g.X;
                c != null && (c = rt(c, b.changedTouches), c != null && (this.l.g(c), b.preventDefault()))
            }
        }
    };

    function qt(a, b) {
        return {
            fk: b.pageX - a.pageX,
            gk: b.pageY - a.pageY
        }
    }

    function rt(a, b) {
        if (b == null) return null;
        for (let c = 0; c < b.length; ++c)
            if (b[c].identifier == a.identifier) return b[c];
        return null
    };

    function tt(a) {
        return ct(at(a.g, a.j).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : ut(c, b)
        }))
    }
    var vt = class {
        constructor(a, b) {
            this.A = a;
            this.B = b;
            this.g = new O(null);
            this.j = new O(null);
            this.l = new nt;
            this.O = c => {
                this.g.g(c)
            };
            this.C = c => {
                var d = this.g.X;
                d != null && (this.g.g(null), this.j.g(null), mt(this.l, ut(d, c)))
            };
            this.D = c => {
                this.g.X != null && (this.j.g(c), c.preventDefault())
            }
        }
    };

    function ut(a, b) {
        return {
            fk: b.screenX - a.screenX,
            gk: b.screenY - a.screenY
        }
    };
    var yt = (a, b, c) => {
        var d = new wt(a, b, c);
        return () => xt(d)
    };

    function xt(a) {
        if (a.g) return !1;
        if (a.j == null) return zt(a), !0;
        var b = a.j + a.B - (new Date).getTime();
        if (b < 1) return zt(a), !0;
        At(a, b);
        return !0
    }

    function zt(a) {
        a.j = (new Date).getTime();
        a.A()
    }

    function At(a, b) {
        a.g = !0;
        a.l.setTimeout(() => {
            a.g = !1;
            zt(a)
        }, b)
    }
    class wt {
        constructor(a, b, c) {
            this.l = a;
            this.B = b;
            this.A = c;
            this.j = null;
            this.g = !1
        }
    };

    function Bt(a) {
        return Ct(tt(a.g), pt(a.j))
    }

    function Dt(a) {
        return ot(kt(a.g.l), kt(a.j.A))
    }
    var Et = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
    };

    function Ct(a, b) {
        return at(a, b).map(({
            first: c,
            second: d
        }) => c || d || null)
    };

    function Ft(a, b) {
        return new Gt(a, b)
    }

    function Ht(a) {
        a.win.requestAnimationFrame(() => {
            a.A || a.l.g(new Ei(a.element.offsetWidth, a.element.offsetHeight))
        })
    }

    function It(a) {
        a.g || (a.g = !0, a.B.observe(a.element));
        return ct(a.l, Fi)
    }
    var Gt = class extends Gs {
        constructor(a, b) {
            super();
            this.win = a;
            this.element = b;
            this.g = !1;
            this.l = new O(new Ei(this.element.offsetWidth, this.element.offsetHeight));
            this.B = new ResizeObserver(() => {
                Ht(this)
            })
        }
        j() {
            this.B.disconnect();
            super.j()
        }
    };

    function Jt(a, b) {
        return {
            top: a.g - b,
            right: a.l + a.j,
            bottom: a.g + b,
            left: a.l
        }
    }
    var Kt = class {
        constructor(a, b, c) {
            this.l = a;
            this.g = b;
            this.j = c
        }
    };

    function Lt(a, b) {
        a = a.getBoundingClientRect();
        return new Mt(a.top + qs(b), a.bottom - a.top)
    }

    function Nt(a) {
        return new Mt(Math.round(a.g), Math.round(a.j))
    }
    var Mt = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
        getHeight() {
            return this.j
        }
    };
    var Pt = (a, b) => {
        var c = a.google_pso_loaded_fonts || (a.google_pso_loaded_fonts = []),
            d = new Cs(c);
        b = b.filter(e => !d.contains(e));
        b.length && (Ot(a, b), ob(c, b))
    };

    function Ot(a, b) {
        for (let d of b) {
            let e = hl("LINK", a.document);
            e.type = "text/css";
            b = e;
            var c = ni `//fonts.googleapis.com/css?family=${d}`;
            b.href = ai(c).toString();
            b.rel = "stylesheet";
            (a.document.head ? ? a.document.body).append(e)
        }
    };

    function Qt(a, b) {
        a.G ? b(a.B) : a.l.push(b)
    }

    function Rt(a, b) {
        a.G = !0;
        a.B = b;
        a.l.forEach(c => {
            c(a.B)
        });
        a.l = []
    }
    var St = class extends Gs {
        constructor(a) {
            super();
            this.g = a;
            this.l = [];
            this.G = !1;
            this.D = this.B = null;
            this.J = yt(a, 1E3, () => {
                if (this.D != null) {
                    var b = ls(this.g, !0) - this.D;
                    b > 1E3 && Rt(this, b)
                }
            });
            this.C = null
        }
        init(a, b) {
            a == null ? (this.D = a = ls(this.g, !0), this.g.addEventListener("scroll", this.J), b != null && b(a)) : this.C = this.g.setTimeout(() => {
                this.init(void 0, b)
            }, a)
        }
        j() {
            this.C != null && this.g.clearTimeout(this.C);
            this.g.removeEventListener("scroll", this.J);
            this.l = [];
            this.B = null;
            super.j()
        }
    };
    var Tt = (a, b) => a.reduce((c, d) => c.concat(b(d)), []);
    var Ut = class {
        constructor(a = 1) {
            this.g = a
        }
        next() {
            var a = 48271 * this.g % 2147483647;
            this.g = a * 2147483647 < 0 ? a + 2147483647 : a;
            return this.g / 2147483647
        }
    };

    function Vt(a, b, c) {
        var d = [];
        for (let e of a.g) b(e) ? d.push(e) : c(e);
        return new Wt(d)
    }

    function Xt(a) {
        return a.g.slice(0)
    }

    function Yt(a, b = 1) {
        a = Xt(a);
        var c = new Ut(b);
        rb(a, () => c.next());
        return new Wt(a)
    }
    var Wt = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new Wt(db(this.g, a))
        }
        apply(a) {
            return new Wt(a(Xt(this)))
        }
        sort(a) {
            return new Wt(Xt(this).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            var b = Xt(this);
            b.push(a);
            return new Wt(b)
        }
    };
    var Zt = class {
        constructor(a) {
            this.g = new Cs(a)
        }
        contains(a) {
            return this.g.contains(a)
        }
    };

    function $t(a) {
        return new au({
            value: a
        }, null)
    }

    function bu(a) {
        return new au(null, a)
    }

    function cu(a) {
        try {
            return $t(a())
        } catch (b) {
            return bu(b)
        }
    }

    function du(a) {
        return a.j != null
    }

    function eu(a) {
        return du(a) ? a.getValue() : null
    }

    function fu(a, b) {
        du(a) && b(a.getValue());
        return a
    }

    function gu(a, b) {
        return du(a) ? a : bu(b(a.g))
    }

    function hu(a, b) {
        return gu(a, c => Error(`${b}${c.message}`))
    }

    function iu(a, b) {
        du(a) || b(a.g);
        return a
    }
    var au = class {
        constructor(a, b) {
            this.j = a;
            this.g = b
        }
        getValue() {
            return this.j.value
        }
        map(a) {
            return du(this) ? (a = a(this.getValue()), a instanceof au ? a : $t(a)) : this
        }
    };
    var ju = class {
        constructor() {
            this.g = new Bs
        }
        set(a, b) {
            var c = this.g.get(a);
            c || (c = new Cs, this.g.set(a, c));
            c.add(b)
        }
    };

    function ku(a) {
        return !a
    }

    function lu(a) {
        return b => {
            for (let c of a) c(b)
        }
    };
    var mu = class extends J {
        getId() {
            return pf(this, 3)
        }
    };
    var nu = class {
        constructor(a, {
            Bi: b,
            tk: c,
            Zl: d,
            Mj: e
        }) {
            this.B = a;
            this.l = c;
            this.A = new Wt(b || []);
            this.j = e;
            this.g = d
        }
    };

    function ou(a) {
        var b = a.length;
        if (b === 0) return 0;
        var c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };
    var pu = a => {
            var b = a.split("~").filter(c => c.length > 0);
            a = new Bs;
            for (let c of b) b = c.indexOf("."), b == -1 ? a.set(c, "") : a.set(c.substring(0, b), c.substring(b + 1));
            return a
        },
        ru = a => {
            var b = qu(a);
            a = [];
            for (let c of b) b = String(c.Wd), a.push(c.cd + "." + (b.length <= 20 ? b : b.slice(0, 19) + "_"));
            return a.join("~")
        };
    const qu = a => {
            var b = [],
                c = a.A;
            c && c.g.length && b.push({
                cd: "a",
                Wd: su(c)
            });
            a.l != null && b.push({
                cd: "as",
                Wd: a.l
            });
            a.g != null && b.push({
                cd: "i",
                Wd: String(a.g)
            });
            a.j != null && b.push({
                cd: "rp",
                Wd: String(a.j)
            });
            b.sort(function(d, e) {
                return d.cd.localeCompare(e.cd)
            });
            b.unshift({
                cd: "t",
                Wd: tu(a.B)
            });
            return b
        },
        tu = a => {
            switch (a) {
                case 0:
                    return "aa";
                case 1:
                    return "ma";
                default:
                    throw Error("Invalid slot type" + a);
            }
        },
        su = a => {
            a = Xt(a).map(uu);
            a = JSON.stringify(a);
            return ou(a)
        },
        uu = a => {
            var b = {};
            Lf(a, 7) && (b.q = pf(a, 7));
            ff(a, 2) != null && (b.o =
                ff(a, 2, ue));
            ff(a, 5) != null && (b.p = ff(a, 5, ue));
            return b
        };

    function vu() {
        var a = new wu;
        return Kf(a, 2, 1)
    }
    var wu = class extends J {
        setLocation(a) {
            return Kf(this, 1, a)
        }
        g() {
            return gd(ve(this, 1))
        }
    };

    function xu(a) {
        var b = [].slice.call(arguments).filter(vi(e => e === null));
        if (!b.length) return null;
        var c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Ii || []);
            d = Object.assign(d, e.ke())
        });
        return new yu(c, d)
    }

    function zu(a) {
        switch (a) {
            case 1:
                return new yu(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new yu(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new yu(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new yu(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function Au(a) {
        return a == null ? null : new yu(null, {
            google_ml_rank: a
        })
    }

    function Bu(a) {
        return a == null ? null : new yu(null, {
            google_placement_id: ru(a)
        })
    }

    function Cu({
        kl: a,
        Dl: b = null
    }) {
        if (a == null) return null;
        a = {
            google_daaos_ts: a
        };
        b != null && (a.google_erank = b + 1);
        return new yu(null, a)
    }
    var yu = class {
        constructor(a, b) {
            this.Ii = a;
            this.g = b
        }
        ke() {
            return this.g
        }
    };
    var P = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        R = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Du = class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        },
        Eu = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var Fu = new R(619278254, 10),
        Gu = new R(45696523),
        Hu = new R(1386),
        Iu = new Eu(1385),
        Ju = new P(1397, !0),
        Ku = new R(1359),
        Lu = new R(1358),
        Mu = new P(1360),
        Nu = new R(1357),
        Ou = new P(1345),
        Pu = new Eu(1387),
        Qu = new P(687716473),
        Ru = new P(1377),
        Su = new P(45693370),
        Tu = new P(682658313, !0),
        Uu = new P(745713445),
        Vu = new R(1130, 100),
        Wu = new R(1340, .2),
        Xu = new R(1338, .3),
        Yu = new R(1339, .3),
        Zu = new P(1337),
        $u = new R(1032, 200),
        av = new P(736254284),
        bv = new Du(14),
        cv = new R(1224, .01),
        dv = new R(1346, 6),
        ev = new R(1347, 3),
        fv = new P(1342, !0),
        gv = new P(1344),
        hv = new R(846334470, 1E3),
        iv = new P(1260),
        jv = new P(1393, !0),
        kv = new R(1394, 120),
        lv = new R(1396, 1E3),
        mv = new R(1395, 500),
        nv = new P(316),
        ov = new P(1290),
        pv = new P(1389),
        qv = new P(1390),
        rv = new P(334),
        sv = new P(1383),
        tv = new R(1263, -1),
        uv = new R(1388),
        vv = new R(54),
        wv = new R(1323, -1),
        xv = new R(1265, -1),
        yv = new R(1264, -1),
        zv = new P(1291),
        Av = new P(1267, !0),
        Bv = new P(1266),
        Cv = new P(313),
        Dv = new R(66, -1),
        Ev = new R(65, -1),
        Fv = new P(1256),
        Gv = new P(369),
        Hv = new P(1241, !0),
        Iv = new P(368),
        Jv = new P(1402, !0),
        Kv = new P(1300, !0),
        Lv = new Eu(1273, ["en", "de", "fr", "es", "ja"]),
        Mv = new Eu(1261, ["44786015", "44786016"]),
        Nv = new P(812820063, !0),
        Ov = new P(1361),
        Pv = new P(290),
        Qv = new R(770241922, 1E3),
        Rv = new P(1354),
        Sv = new P(45719801),
        Tv = new P(823552246),
        Uv = new P(1350),
        Vv = new P(1356),
        Wv = new P(566279275),
        Xv = new P(622128248),
        Yv = new P(566279276),
        Zv = new P(903704925),
        $v = new P(933719197),
        aw = new P(842638817, !0),
        bw = new P(858671852),
        cw = new P(861100860),
        dw = new P(829415421, !0),
        ew = new P(45783527, !0),
        fw = new P(767123927, !0),
        gw = new P(917171616),
        hw = new R(799568408, 10),
        iw = new Eu(712458671, " ar bn en es fr hi id ja ko mr pt ru sr te th tr uk vi zh".split(" ")),
        jw = new R(872325350),
        kw = new R(855152761, .6),
        lw = new class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        }(683929765),
        mw = new Du(872996096, "calc(<SW> / 1.2)"),
        nw = new R(868282444, 1200),
        ow = new Du(834418652, "calc(max(<DH> - 150px, 50px))"),
        pw = new Du(874614210),
        qw = new Du(834418651, "calc(max(<DH> - 150px, 50px))"),
        rw = new P(839747468, !0),
        sw = new P(929743681),
        tw = new P(506914611),
        uw = new P(899601681, !0),
        vw = new R(775999093,
            1),
        ww = new P(824550200, !0),
        xw = new R(618163195, 8E3),
        yw = new R(624950166, 3E3),
        zw = new R(623405755, 300),
        Aw = new R(508040914, 622),
        Bw = new R(547455356, 49),
        Cw = new R(9603, 4),
        Dw = new R(650548030, 3),
        Ew = new R(650548032, 300),
        Fw = new R(650548031, 1),
        Gw = new R(469675170, 68040),
        Hw = new R(836239785, .6),
        Iw = new P(45721294),
        Jw = new P(676460084),
        Kw = new P(934276257),
        Lw = new P(932979855),
        Mw = new R(824002820),
        Nw = new P(732272249),
        Ow = new P(803207304),
        Pw = new P(929460549),
        Qw = new P(827615816),
        Rw = new Eu(754933824),
        Sw = new Du(754933823, "1-0-45"),
        Tw = new P(834350237),
        Uw = new R(63, 30),
        Vw = new R(550718588, 250),
        Ww = new R(624290870, 50),
        Xw = new R(815871887, .8),
        Yw = new P(77),
        Zw = new P(78),
        $w = new P(83),
        ax = new P(80),
        bx = new P(76),
        cx = new P(84),
        dx = new P(188);

    function ex(a) {
        return C(a, 1)
    }
    var fx = class extends J {
        Bb() {
            return x(this, Mh, 10)
        }
        setContent(a) {
            return y(this, 10, a)
        }
    };

    function gx(a) {
        return Ve(a, fx, 15, w())
    }
    var hx = class extends J {
            g() {
                return lf(this, 24)
            }
        },
        ix = yh(hx);
    var jx = class extends J {},
        kx = yh(jx);
    var lx = {},
        mx = {},
        nx = {},
        ox = {},
        px = {};

    function qx() {
        throw Error("Do not instantiate directly");
    }
    qx.prototype.Ki = null;
    qx.prototype.Bb = function() {
        return this.content
    };
    qx.prototype.toString = function() {
        return this.content
    };
    qx.prototype.Fb = function() {
        if (this.Li !== lx) throw Error("Sanitized content was not of kind HTML.");
        return Uh(this.toString())
    };

    function rx() {
        qx.call(this)
    }
    Ga(rx, qx);
    rx.prototype.Li = lx;

    function sx(a) {
        if (a != null) switch (a.Ki) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function tx(a) {
        return ux(a, lx) ? a : a instanceof Th ? vx(Vh(a).toString()) : vx(String(String(a)).replace(wx, xx), sx(a))
    }
    var vx = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            d !== void 0 && (c.Ki = d);
            return c
        }
    }(rx);

    function yx(a) {
        return tx(a)
    }

    function zx(a) {
        return Ax(String(a), () => "").replace(Bx, "&lt;")
    }
    const Cx = RegExp.prototype.hasOwnProperty("sticky"),
        Dx = new RegExp((Cx ? "" : "^") + "(?:!|/?([a-zA-Z][a-zA-Z0-9:-]*))", Cx ? "gy" : "g");

    function Ax(a, b) {
        for (var c = [], d = a.length, e = 0, f = [], g, h, k = 0; k < d;) {
            switch (e) {
                case 0:
                    var l = a.indexOf("<", k);
                    if (l < 0) {
                        if (c.length === 0) return a;
                        c.push(a.substring(k));
                        k = d
                    } else c.push(a.substring(k, l)), h = l, k = l + 1, Cx ? (Dx.lastIndex = k, l = Dx.exec(a)) : (Dx.lastIndex = 0, l = Dx.exec(a.substring(k))), l ? (f = ["<", l[0]], g = l[1], e = 1, k += l[0].length) : c.push("<");
                    break;
                case 1:
                    l = a.charAt(k++);
                    switch (l) {
                        case "'":
                        case '"':
                            let m = a.indexOf(l, k);
                            m < 0 ? k = d : (f.push(l, a.substring(k, m + 1)), k = m + 1);
                            break;
                        case ">":
                            f.push(l);
                            c.push(b(f.join(""),
                                g));
                            e = 0;
                            f = [];
                            h = g = null;
                            break;
                        default:
                            f.push(l)
                    }
                    break;
                default:
                    throw Error();
            }
            e === 1 && k >= d && (k = h + 1, c.push("<"), e = 0, f = [], h = g = null)
        }
        return c.join("")
    }

    function Ex(a, b) {
        a = a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>");
        return b ? a.replace(/{/g, " \\{").replace(/}/g, " \\}").replace(/\/\*/g, "/ *").replace(/\\$/, "\\ ") : a
    }

    function S(a) {
        ux(a, lx) ? (a = zx(a.Bb()), a = String(a).replace(Fx, xx)) : a = String(a).replace(wx, xx);
        return a
    }

    function Gx(a) {
        a = String(a);
        for (var b = (d, e, f) => {
                var g = Math.min(e.length - f, d.length);
                for (let k = 0; k < g; k++) {
                    var h = e[f + k];
                    if (d[k] !== ("A" <= h && h <= "Z" ? h.toLowerCase() : h)) return !1
                }
                return !0
            }, c = 0;
            (c = a.indexOf("<", c)) != -1;) {
            if (b("\x3c/script", a, c) || b("\x3c!--", a, c)) return "zSoyz";
            c += 1
        }
        return a
    }

    function Hx(a) {
        if (a == null) return " null ";
        if (ux(a, mx)) return a.Bb();
        switch (typeof a) {
            case "boolean":
            case "number":
                return " " + a + " ";
            default:
                return "'" + String(String(a)).replace(Ix, Jx) + "'"
        }
    }
    const Kx = /['()]/g;

    function Lx(a) {
        return "%" + a.charCodeAt(0).toString(16)
    }

    function Mx(a) {
        a = encodeURIComponent(String(a));
        Kx.lastIndex = 0;
        return Kx.test(a) ? a.replace(Kx, Lx) : a
    }

    function Nx(a) {
        ux(a, nx) || ux(a, ox) ? a = String(a).replace(Ox, Px) : a instanceof Zh ? (a = ai(a).toString(), a = String(a).replace(Ox, Px)) : (a = String(a), a = Qx.test(a) ? a.replace(Ox, Px) : "about:invalid#zSoyz");
        return a
    }

    function T(a) {
        return ux(a, px) ? Ex(a.Bb(), !1) : a == null ? "" : a instanceof Wh ? Ex(Xh(a), !1) : Ex(String(a), !0)
    }

    function ux(a, b) {
        return a != null && a.Li === b
    }

    function Rx(a, b) {
        a.g !== void 0 ? a.g.push(b) : a.content += b;
        return a
    }

    function Sx(a, b) {
        a.g !== void 0 ? a.g.push(b) : b instanceof Tx ? b.content !== void 0 ? a.content += b.Bb() : (a.g = [a.content, b], a.content = void 0) : a.content += b;
        return a
    }
    class Tx extends rx {
        Bb() {
            if (this.content !== void 0) return this.content;
            var a = "";
            for (let b of this.g) a += b;
            return a
        }
        toString() {
            return this.Bb()
        }
    }
    const Ux = (() => {
            function a() {
                this.content = ""
            }
            a.prototype = Tx.prototype;
            return function() {
                return new a
            }
        })(),
        Vx = {
            "\x00": "&#0;",
            "\t": "&#9;",
            "\n": "&#10;",
            "\v": "&#11;",
            "\f": "&#12;",
            "\r": "&#13;",
            " ": "&#32;",
            '"': "&quot;",
            "&": "&amp;",
            "'": "&#39;",
            "-": "&#45;",
            "/": "&#47;",
            "<": "&lt;",
            "=": "&#61;",
            ">": "&gt;",
            "`": "&#96;",
            "\u0085": "&#133;",
            "\u00a0": "&#160;",
            "\u2028": "&#8232;",
            "\u2029": "&#8233;"
        };

    function xx(a) {
        return Vx[a]
    }
    const Wx = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\v": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    };

    function Jx(a) {
        return Wx[a]
    }
    const Xx = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function Px(a) {
        return Xx[a]
    }
    const wx = /[\x00\x22\x26\x27\x3c\x3e]/g,
        Fx = /[\x00\x22\x27\x3c\x3e]/g,
        Ix = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
        Ox = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        Qx = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i,
        Yx = /^[a-zA-Z0-9+\/_-]+={0,2}$/;

    function Zx(a) {
        a = String(a);
        return Yx.test(a) ? a : "zSoyz"
    }
    const Bx = /</g;
    /* 
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    function $x(a) {
        return ra(a) ? a.Fb && (a = a.Fb(), a instanceof Th) ? a : di("zSoyz") : di(String(a))
    }
    const ay = {};

    function by(a, b) {
        return cy(b ? ? {}, a.hd, a.Ua, a.id, a.lj, a.rsToken, a.searchTerm, a.ya, a.za, a.rk, a.sk, a.oe, a.qc, a.sc, a.De)
    }

    function cy(a, b, c, d, e, f, g, h, k, l, m, n, p, q, u) {
        l = l === void 0 ? 0 : l;
        m = m === void 0 ? 0 : m;
        n = n === void 0 ? "" : n;
        p = p === void 0 ? -1 : p;
        q = q === void 0 ? -1 : q;
        u = u === void 0 ? !1 : u;
        a = a && a.rb;
        return vx("<style" + (a ? ' nonce="' + S(Zx(a)) + '"' : "") + ">#" + T(d) + " {display: inline-block; height: " + T(h) + "; width: " + T(k) + ';}</style><ins id="' + S(d) + '" class="adsbygoogle" data-ad-client="' + S(c) + '" data-ad-intent-query="' + S(g) + '"' + (u ? "" : ' data-ad-intent-rs-token="' + S(f) + '"') + ' data-ad-intents-ad-position="' + S(m) + '" data-ad-intents-format="' + S(b) +
            '"' + (n !== "" ? ' data-kw="' + S(n) + '"' : "") + ' data-query-targeted="' + S(e) + '"' + (p !== -1 ? ' data-override-adx="' + S(p) + '"' : "") + (q !== -1 ? ' data-override-ady="' + S(q) + '"' : "") + (l !== 0 ? ' data-ad-intents-in-drawer-format="' + S(l) + '"' : "") + "></ins>")
    };

    function dy(a) {
        return `zdmmCctpVIa${ou(a)}`
    }
    var ey = class {
        constructor() {
            this.g = new Map
        }
        clear() {
            this.g.clear()
        }
    };

    function fy(a, b) {
        return gy(b ? ? {}, a.id, a.searchTerm, a.title)
    }

    function gy(a, b, c, d) {
        a = a && a.rb;
        a = "<style" + (a ? ' nonce="' + S(Zx(a)) + '"' : "") + ">.fallback-title-wrapper {display: flex; flex-direction: column; flex-shrink: 0; height: min-content; bottom: 0; left: 0; right: 0; margin: 16px 25px; padding: 3px 12px; align-items: center; border-radius: 8px; background: #e8f0fe;}.fallback-title {font-size: 14px; font-weight: 400; font-style: normal; color: #3c4043; font-family: 'Google Sans', Roboto, Arial, sans-serif; font-display: optional; text-align: center; line-height: 15px;}</style>";
        d =
            d.split("TERM");
        a += '<div id="' + S(b) + '" class="fallback-title-wrapper" aria-label="' + S(d[0]) + S(c) + S(d[1]) + '"><h1 class="fallback-title" aria-hidden="true">' + tx(d[0]) + "<b>" + tx(c) + "</b>" + tx(d[1]) + "</h1></div>";
        return vx(a)
    };

    function hy(a, b) {
        b = b ? ? {};
        var c = a.Sg,
            d = a.searchTerm;
        a = a.title;
        var e = b && b.rb;
        return Rx(Sx(Rx(Ux(), '<div id="double-no-fill-container" class="container"><style' + (e ? ' nonce="' + S(Zx(e)) + '"' : "") + '>#double-no-fill-container {height: 100%; width: 100%; display: flex; flex-direction: column;}#double-no-fill-icon {flex-grow: 1; margin: 0 auto;}</style><svg width="224px" height="224px" viewBox="0 0 224 224" fill="none" xmlns="http://www.w3.org/2000/svg" id="double-no-fill-icon"><path d="M105.193 168.361H138.469L138.93 149.246L135.445 149.233L105.193 168.361Z" fill="#3C4043" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.7761 168.361H20.3717V100.563L13.7761 168.361Z" fill="#3C4043"/><path d="M47.5502 168.361H53.5608V100.563L47.5502 168.361Z" fill="#3C4043"/><path d="M5.59998 168.361H217.255" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round"/><path d="M91.8401 56.6221H68.0215V168.361H91.8401V56.6221Z" fill="white" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M85.6676 147.666H74.1938V161.778H85.6676V147.666Z" fill="#DADCE0" stroke="#DADCE0" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M83.4153 69.4521H76.434V83.5641H83.4153V69.4521Z" fill="#DADCE0" stroke="#DADCE0" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M76.434 99.8164V139.004" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M83.4279 115.621V139.004" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M44.1904 98.2363H20.3717V168.361H44.1904V98.2363Z" fill="white" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M44.1904 152.668H20.3717V158.928H44.1904V152.668Z" fill="#DADCE0" stroke="#DADCE0" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M44.1904 98.2363H20.3717V168.361H44.1904V98.2363Z" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M68.0089 81.0137H53.5858V168.361H68.0089V81.0137Z" fill="white" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M68.0089 95.0381H53.5858V154.348H68.0089V95.0381Z" fill="#DADCE0"/><path d="M68.0089 81.0137H53.5858V168.361H68.0089V81.0137Z" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M60.8036 114.775V146.932" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M209.057 168.369V149.242H138.933V168.369H209.057Z" fill="white" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M197.571 168.369V149.242H150.406V168.369H197.571Z" fill="#DADCE0" stroke="#DADCE0" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M209.057 168.369V149.242H138.933V168.369H209.057Z" stroke="#3C4043" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M138.93 160.284V149.233H181.315L138.93 160.284Z" fill="#3C4043"/><path d="M180.271 122.351L172.686 109.574L97.5756 154.165L105.161 166.942L180.271 122.351Z" fill="#8AB4F8" stroke="#8AB4F8" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M174.075 126.03L166.49 113.253L103.771 150.487L111.357 163.264L174.075 126.03Z" stroke="#8AB4F8" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M147.454 133.193L119.803 149.608" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M174.074 126.019L166.488 113.242L161.106 116.438L168.691 129.215L174.074 126.019Z" fill="white" stroke="#8AB4F8" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M116.735 160.067L109.149 147.29L103.767 150.486L111.352 163.263L116.735 160.067Z" fill="white" stroke="#8AB4F8" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/></svg>'),
            gy(b, c, d, a)), "</div>")
    };

    function iy(a) {
        a = (a = a ? ? {}) && a.rb;
        return vx("<style" + (a ? ' nonce="' + S(Zx(a)) + '"' : "") + ">#dogtags-container-navigation-wrapper {display: flex; position: relative; height: 82px; bottom: 0; left: 0; right: 0; align-items: center;}#dogtags-container {display: none; flex-grow: 1; position: fixed; width: 100%; bottom: 0; left: 0; right: 0; padding: 23px 25px; box-sizing: border-box; align-items: flex-start; gap: 6px; overflow-x: scroll; scroll-behavior: smooth; scroll-width: none; -ms-overflow-style: none; &::-webkit-scrollbar { display: none; }box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.30), 0 1px 3px 1px rgba(0, 0, 0, 0.15);}#left-arrow-span, #right-arrow-span {display: flex; position: absolute; z-index: 100; height: 100%; width: 70px; align-items: center; opacity: 0; transition: opacity 0.2s ease-in-out;}#left-arrow-span {left: 0; justify-content: left; background: linear-gradient(90deg, #FFF 0.3%, #FFF 72.34%, rgba(243, 248, 255, 0.00) 99.66%); border-bottom-left-radius: 20px;}#right-arrow-span {right: 0; justify-content: right; background: linear-gradient(270deg, #FFF 0.3%, #FFF 72.34%, rgba(243, 248, 255, 0.00) 99.66%); border-bottom-right-radius: 20px;}#left-arrow, #right-arrow {margin-top: 10px; cursor: pointer;}#left-arrow {margin-left: 8px;}#right-arrow {margin-right: 8px;}</style>")
    };

    function jy(a, b, c, d, e, f, g, h, k, l, m, n, p, q, u, A, D, K, I, G) {
        K = K === void 0 ? -1 : K;
        I = I === void 0 ? -1 : I;
        G = G === void 0 ? !1 : G;
        var E = a && a.rb,
            Q = a && a.Dg;
        return Rx(Sx(Rx(Sx(Rx(Ux(), (D ? "" : '<link href="https://fonts.googleapis.com/css?family=Google+Sans:500" rel="stylesheet"' + (E ? ' nonce="' + S(Zx(E)) + '"' : "") + ">") + (g !== -1 ? "<script" + (Q ? ' nonce="' + S(Zx(Q)) + '"' : "") + ">window[" + Gx(Hx("goog_pvsid")) + "] = " + Gx(Hx(g)) + ";\x3c/script>" : "") + (d !== "" ? '<meta name="google-adsense-platform-account" content="' + S(d) + '">' : "") + "<style" + (E ? ' nonce="' +
                S(Zx(E)) + '"' : "") + '>.container {display: none !important;}</style><div id="display-slot-container"><div id="' + S(A) + '">'), cy(a, b, c, "display-slot", !0, n, p, q, u, void 0, void 0, void 0, K, I, G)), "</div></div>"), e ? Rx(Sx(Rx(Ux(), '<div id="dogtags-container">'), iy(a)), "</div>") : Rx(Sx(Rx(Ux(), '<div id="dogtags-container-navigation-wrapper"><span id="left-arrow-span" aria-label="' + S(f) + '"><svg width="50" height="50" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" id="left-arrow" aria-hidden="true"><g filter="url(#filter0-d-1125-2720)"><circle cx="20" cy="16" r="16" transform="rotate(-180 20 16)" fill="white"/></g><path d="M20 24L21.41 22.59L15.83 17L28 17L28 15L15.83 15L21.41 9.41L20 8L12 16L20 24Z" fill="#5F6368"/><defs><filter id="filter0-d-1125-2720" x="0" y="2.79753e-06" width="40" height="40" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset dy="4"/><feGaussianBlur stdDeviation="2"/><feComposite in2="hardAlpha" operator="out"/><feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_1125_2720"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_1125_2720" result="shape"/></filter></defs></svg></span><div id="dogtags-container">'),
                iy(a)), '</div><span id="right-arrow-span" aria-label="' + S(m) + '"><svg width="50" height="50" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" id="right-arrow" aria-hidden="true"><g filter="url(#filter0-d-1125-2701)"><circle cx="20" cy="16" r="16" fill="white"/></g><path d="M20 8L18.59 9.41L24.17 15H12V17H24.17L18.59 22.59L20 24L28 16L20 8Z" fill="#5F6368"/><defs><filter id="filter0-d-1125-2701" x="0" y="0" width="40" height="40" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset dy="4"/><feGaussianBlur stdDeviation="2"/><feComposite in2="hardAlpha" operator="out"/><feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_1125_2701"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_1125_2701" result="shape"/></filter></defs></svg></span></div>')),
            (k ? "<script" + (Q ? ' nonce="' + S(Zx(Q)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;\x3c/script>" : "") + "<script" + (Q ? ' nonce="' + S(Zx(Q)) + '"' : "") + ">parent.postMessage({'action':'sgda-ready'}, parent.location.origin);\x3c/script>" + (D ? "<script" + (Q ? ' nonce="' + S(Zx(Q)) + '"' : "") + ">parent.fakeAdsByGoogle(window);\x3c/script>" : '<script data-ad-intent-query="' + S(p) + '" data-ad-intent-rs-token="' + S(n) + '" data-page-url="' + S(Nx(h)) + '" data-ad-intents-format="' + S(b) + '"' + (l ? ' data-adtest="on"' :
                "") + ' async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + Mx(c) + '" crossorigin="anonymous"' + (Q ? ' nonce="' + S(Zx(Q)) + '"' : "") + ">\x3c/script>"))
    };

    function ky(a, b) {
        b = b ? ? {};
        var c = a.searchTerm,
            d = a.ya,
            e = a.za,
            f = a.title,
            g = a.oe,
            h = a.qc,
            k = a.sc,
            l = a.De,
            m = a.hd,
            n = a.Ua;
        a = a.Sg;
        g = g === void 0 ? "" : g;
        h = h === void 0 ? -1 : h;
        k = k === void 0 ? -1 : k;
        l = l === void 0 ? !1 : l;
        var p = b && b.rb;
        return Rx(Sx(Rx(Sx(Rx(Ux(), '<div id="fallback-container" class="container"><style' + (p ? ' nonce="' + S(Zx(p)) + '"' : "") + '>#fallback-container {height: 100%; display: flex; flex-direction: column;}#ad-slot-wrapper {display: flex; flex-grow: 1; justify-content: center; margin-inline: 16px;}</style><div id="ad-slot-wrapper">'),
            cy(b, m, n, "display-slot", !1, "", "", d, e, void 0, void 0, g, h, k, l)), "</div>"), gy(b, a, c, f)), "</div>")
    };
    const ly = RegExp("(^| )adsbygoogle($| )");
    var my = class {
        constructor() {
            var a = {};
            this.j = (b, c) => a[b] != null ? a[b] : c;
            this.A = (b, c) => a[b] != null ? a[b] : c;
            this.B = (b, c) => a[b] != null ? a[b] : c;
            this.C = (b, c) => a[b] != null ? a[b] : c;
            this.l = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.g = () => {}
        }
    };

    function U(a) {
        return ar(my).j(a.g, a.defaultValue)
    }

    function V(a) {
        return ar(my).A(a.g, a.defaultValue)
    }

    function ny(a) {
        return ar(my).B(a.g, a.defaultValue)
    }

    function oy(a) {
        return ar(my).C(a.g, a.defaultValue)
    };
    const py = ["-webkit-text-fill-color"];

    function qy(a) {
        if (vb) {
            {
                let c = il(a.document.body, a);
                if (c) {
                    a = {};
                    var b = c.length;
                    for (let d = 0; d < b; ++d) a[c[d]] = "initial";
                    a = ry(a)
                } else a = sy()
            }
        } else a = sy();
        return a
    }

    function sy() {
        var a = {
            all: "initial"
        };
        bb(py, b => {
            a[b] = "unset"
        });
        return a
    }

    function ry(a) {
        bb(py, b => {
            delete a[b]
        });
        return a
    };

    function ty(a) {
        var b = a[0] / 255,
            c = a[1] / 255;
        a = a[2] / 255;
        return (b <= .03928 ? b / 12.92 : Math.pow((b + .055) / 1.055, 2.4)) * .2126 + (c <= .03928 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4)) * .7152 + (a <= .03928 ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4)) * .0722
    }
    var uy = (a, b) => {
        a = ty(a);
        b = ty(b);
        return (Math.max(a, b) + .05) / (Math.min(a, b) + .05)
    };
    const vy = [255, 255, 255];

    function wy(a) {
        function b(d) {
            return [Number(d[1]), Number(d[2]), Number(d[3]), d.length > 4 ? Number(d[4]) : 1]
        }
        var c = a.match(/rgb\(([0-9]+),\s*([0-9]+),\s*([0-9]+)\)/);
        if (c || (c = a.match(/rgba\(([0-9]+),\s*([0-9]+),\s*([0-9]+),\s*([0-9\\.]+)\)/))) return b(c);
        if (a === "transparent" || a === "") return [0, 0, 0, 0];
        c = document.createElement("canvas");
        c.width = c.height = 1;
        if (c = c.getContext("2d", {
                willReadFrequently: !0
            })) return c.fillStyle = a, c.fillRect(0, 0, 1, 1), a = c.getImageData(0, 0, 1, 1).data, [a[0], a[1], a[2], a[3] / 255];
        throw Error(`Invalid color: ${a}`);
    }

    function xy(a) {
        return yy(wy(getComputedStyle(a).color))
    }

    function zy(a, b) {
        var c = getComputedStyle(a);
        if (c.backgroundImage !== "none") return null;
        c = wy(c.backgroundColor);
        var d = yy(c);
        if (d) return d;
        b = (a = a.parentElement) ? zy(a, b) : vy;
        if (!b) return null;
        a = c[3];
        return [Math.round(a * c[0] + (1 - a) * b[0]), Math.round(a * c[1] + (1 - a) * b[1]), Math.round(a * c[2] + (1 - a) * b[2])]
    }

    function yy(a) {
        return a[3] === 1 ? [a[0], a[1], a[2]] : null
    };

    function Ay(a, b) {
        b = a.document.createElement(b);
        L(b, qy(a));
        L(b, {
            color: "inherit",
            cursor: "inherit",
            direction: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-weight": "inherit",
            "text-align": "inherit",
            "text-orientation": "inherit",
            visibility: "inherit",
            "writing-mode": "inherit"
        });
        return b
    }

    function By(a, b) {
        a = a.document.createElementNS("http://www.w3.org/2000/svg", b);
        L(a, {
            animation: "initial",
            background: "initial",
            border: "0",
            "box-shadow": "none",
            color: "inherit",
            cursor: "inherit",
            direction: "inherit",
            display: "inline",
            fill: "currentcolor",
            filter: "initial",
            "float": "none",
            margin: "0",
            opacity: "initial",
            outline: "0",
            overflow: "initial",
            padding: "0",
            stroke: "initial",
            transform: "initial",
            "vertical-align": "initial",
            visibility: "inherit"
        });
        return a
    }

    function Cy(a) {
        a.dataset.googleVignette = "false";
        a.dataset.googleInterstitial = "false"
    }

    function Dy(a) {
        return a[0] === 255 && a[1] === 255 && a[2] === 255 || a[0] === 0 && a[1] === 0 && a[2] === 0
    }

    function Ey(a, b) {
        var c = a.document.createElement("div");
        c.style.color = b;
        c.style.display = "none";
        a.document.body.appendChild(c);
        b = a.getComputedStyle(c).color;
        a.document.body.removeChild(c);
        a = wy(b);
        return a[3] > 0 ? a : null
    }

    function Fy(a, b) {
        if (!b) return null;
        var c = a.document.querySelector('meta[name="theme-color"]');
        if (c && (c = c.getAttribute("content")) && (c = Ey(a, c))) return `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${b})`;
        c = a.getComputedStyle(a.document.documentElement);
        var d = ["--primary-color", "--brand-color", "--theme-color"];
        for (var e of d)
            if (d = c.getPropertyValue(e).trim())
                if (d = Ey(a, d)) return `rgba(${d[0]}, ${d[1]}, ${d[2]}, ${b})`;
        if (e = a.document.querySelector("header, nav, .header, #header"))
            if (e = a.getComputedStyle(e).backgroundColor,
                e = wy(e), e[3] > 0 && !Dy(e)) return `rgba(${e[0]}, ${e[1]}, ${e[2]}, ${b})`;
        if (e = a.document.querySelector('button[type="submit"], .btn-primary, button'))
            if (e = a.getComputedStyle(e).backgroundColor, e = wy(e), e[3] > 0 && !Dy(e)) return `rgba(${e[0]}, ${e[1]}, ${e[2]}, ${b})`;
        e = a.document.querySelectorAll("a");
        for (let f of e) {
            if (f.getAttribute("href") ? .startsWith("#")) continue;
            e = a.getComputedStyle(f).color;
            e = wy(e);
            if (e[3] !== 0) return `rgba(${e[0]}, ${e[1]}, ${e[2]}, ${b})`
        }
        return `rgba(26, 115, 232, ${b})`
    };

    function Gy(a, b) {
        return a ? .95 * b.innerHeight - 30 : b.innerHeight - 24 - 20
    };

    function Hy(a, b) {
        a = Iy(a, "20px", b);
        a.classList.add("google-anno-sa-intent-icon");
        return a
    }

    function Jy(a, b, c) {
        a = Ky(a, "0 -960 960 960", "20px", "20px", "m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z");
        L(a, {
            left: "13px",
            right: "",
            "pointer-events": "initial",
            position: "absolute",
            top: "15px",
            transform: "none",
            fill: c
        });
        a.role = "button";
        a.ariaLabel = b;
        a.tabIndex = 0;
        return a
    }

    function Iy(a, b, c) {
        a = Ky(a, "0 -960 960 960", b, b, "M168-144q-29.7 0-50.85-21.15Q96-186.3 96-216v-528q0-29.7 21.15-50.85Q138.3-816 168-816h624q29.7 0 50.85 21.15Q864-773.7 864-744v528q0 29.7-21.15 50.85Q821.7-144 792-144H168Zm0-72h624v-528H168v528Zm72-96h480v-72H240v72Zm0-144h168v-216H240v216Zm240 0h240v-72H480v72Zm0-144h240v-72H480v72ZM168-216v-528 528Z");
        L(a, {
            fill: c,
            cursor: "inherit"
        });
        return a
    }

    function Ky(a, b, c, d, e) {
        var f = By(a, "svg");
        f.setAttribute("viewBox", b);
        f.setAttribute("width", c);
        f.setAttribute("height", d);
        f.appendChild(By(a, "path")).setAttribute("d", e);
        return f
    };

    function W(a) {
        return `${a}px`
    }

    function Ly(a, b, c, d, e) {
        a.g.push(new My(b, c, d, e))
    }

    function Ny(a) {
        for (let c = a.g.length - 1; c >= 0; c--) {
            var b = a.g[c];
            b.j ? (b.element.style.removeProperty(b.g), b.element.style.setProperty(b.g, String(b.l), b.A)) : b.element.style[b.g] = b.l
        }
        a.g.length = 0
    }
    var Oy = class {
            constructor() {
                this.g = []
            }
        },
        My = class {
            constructor(a, b, c, d) {
                this.element = a;
                this.g = b;
                this.g = (this.j = !(d === void 0 || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
                this.l = this.j ? a.style.getPropertyValue(this.g) : a.style[this.g];
                this.A = this.j ? a.style.getPropertyPriority(this.g) : void 0;
                this.j ? (a.style.removeProperty(this.g), a.style.setProperty(this.g, String(c), d)) : a.style[this.g] = String(c)
            }
        };

    function Py(a, b, c) {
        var d = a.g ? a.g.getData() : {};
        a = a.j || pj();
        (b = b(c || ay, d)) && b.j ? a = b.j() : (b = $x(b), a = Kj(a, b));
        return a
    }

    function Qy(a, b, c) {
        var d = a.g ? a.g.getData() : {};
        a = a.j;
        a: {
            b = b(c || ay, d);c = a || pj();b && b.j ? c = b.j() : (c = Jj(c, "DIV"), b = $x(b), c.innerHTML = Vh(b));
            if (c.childNodes.length == 1 && (b = c.firstChild, b.nodeType == 1)) break a;b = c
        }
        return b
    }
    class Ry {
        constructor(a, b) {
            this.j = b || pj();
            this.g = a || null
        }
        render(a, b) {
            a = a(b || {}, this.g ? this.g.getData() : {});
            return String(a)
        }
    };

    function Sy(a, b, c, d, e, f) {
        if (b.data.action === "sgda-ready") {
            var g = c.contentDocument;
            if (g ? .body && c.contentWindow) {
                var h = g.getElementById("display-slot-container");
                h && (a.Sd = new MutationObserver((k, l) => {
                    k = g.getElementById("display-slot");
                    if (k.getAttribute("data-ad-status") === "filled") {
                        if (a.Nb.g.has(dy(a.ma))) return;
                        l.disconnect();
                        Ty(a, !0);
                        d.oc();
                        if (k.getAttribute("data-query-targeted") === "true") a.Nb.g.set(dy(a.ma), 0);
                        else {
                            a.Nb.g.set(dy(a.ma), 1);
                            let m = g.getElementById("fallback-container");
                            Uy(m)
                        }
                        Vy(a, g)
                    }
                    k.getAttribute("data-ad-status") ===
                        "unfilled" && k.getAttribute("data-query-targeted") === "true" ? g.getElementById("fallback-container") ? (l.disconnect(), Ty(a, !0), d.oc(), k.remove(), Wy(a, "fallback-container", a.ma, C(d.R, 25), g), a.Nb.g.set(dy(a.ma), 1)) : (g.getElementById(dy(a.ma)).remove(), l = Qy(a.Yb, ky, {
                            hd: d.format,
                            Ua: a.Ua,
                            Sg: dy(a.ma),
                            oe: a.ma,
                            searchTerm: a.ma,
                            ya: f,
                            za: e,
                            title: C(d.R, 25),
                            qc: a.qc,
                            sc: a.sc,
                            De: U(sw)
                        }), h.appendChild(l), l = c.contentWindow, l.adsbygoogle = l.adsbygoogle || [], l.adsbygoogle.push({})) : k.getAttribute("data-ad-status") === "unfilled" &&
                        k.getAttribute("data-query-targeted") === "false" && (g.getElementById("fallback-container").remove(), l.disconnect(), Ty(a, !0), d.oc(), a.Nb.g.set(dy(a.ma), 2), g.getElementById("double-no-fill-container") ? Wy(a, "double-no-fill-container", a.ma, C(d.R, 26), g) : (l = Qy(a.Yb, hy, {
                            Sg: dy(a.ma),
                            searchTerm: a.ma,
                            title: C(d.R, 26)
                        }), h.appendChild(l), Uy(l)), Xy(a, g), Vy(a, g))
                }), Yy(a, g), d.Xc(() => void a.Sd ? .disconnect()))
            }
        }
    }

    function Zy(a, b, c, d, e, f) {
        if (b.data.action === "sgda-ready") {
            var g = c.contentDocument;
            if (g ? .body && c.contentWindow) {
                var h = g.getElementById("display-slot-container");
                if (h && (L(h, {
                        height: W(d.Kc - 83)
                    }), b = g.getElementById("dogtags-container"))) {
                    var k = d.R,
                        l = gx(k).filter(n => ex(n) === d.searchTerm).map(n => pe(n))[0],
                        m = $y(a, c.contentWindow, ex(l));
                    m.addEventListener("click", () => {
                        az(a, l, d, c, g, h, m, e, f)
                    });
                    Cy(m);
                    b.appendChild(m);
                    bz(m);
                    k = gx(k).filter(n => C(n, 13)).map(n => pe(n));
                    for (let n of k) {
                        if (ex(n) === d.searchTerm) continue;
                        let p = $y(a, c.contentWindow, ex(n));
                        p.addEventListener("click", () => {
                            az(a, n, d, c, g, h, p, e, f)
                        });
                        Cy(p);
                        b.appendChild(p)
                    }
                    d.ka || cz(g, d, b);
                    Ty(a, !1)
                }
            }
        }
    }

    function Ty(a, b) {
        a.Ri = b;
        for (let [c, d] of a.be) c !== a.ma && L(d, {
            cursor: b ? "pointer" : "default"
        })
    }

    function Vy(a, b) {
        a.Vg || (a.Vg = !0, L(b.getElementById("dogtags-container"), {
            display: "flex"
        }))
    }

    function Wy(a, b, c, d, e) {
        if (b = e.getElementById(b)) Uy(b), a = Qy(a.Yb, fy, {
            id: dy(c),
            searchTerm: c,
            title: d
        }), b.appendChild(a)
    }

    function Yy(a, b) {
        (b = b.getElementById("display-slot-container")) && a.Sd && a.Sd.observe(b, {
            subtree: !0,
            childList: !0,
            attributes: !0,
            attributeFilter: ["data-ad-status", "data-query-targeted"]
        })
    }

    function $y(a, b, c) {
        var d = Ay(b, "div"),
            e = Ay(b, "span");
        d.classList.add("google-anno-skip", "google-anno-sc");
        e.appendChild(b.document.createTextNode(c));
        d.appendChild(e);
        L(e, {
            position: "relative",
            "padding-inline": "3px",
            "white-space": "nowrap",
            "font-family": "'Google Sans', Roboto, Arial, sans-serif",
            "font-weight": "500",
            "font-size": "14px",
            color: "#202124"
        });
        L(d, {
            display: "inline-block",
            "flex-shrink": "0",
            padding: "1px 16px 8px 16px",
            border: "1px solid #bdc1c6",
            "border-radius": "100px",
            "white-space": "nowrap",
            cursor: "pointer",
            transition: "background 0.25s linear",
            "-webkit-tap-highlight-color": "transparent"
        });
        a.be.set(c, d);
        a = Iy(b, "22px", "#202124");
        L(a, {
            position: "relative",
            top: "6px",
            "margin-inline": "-5px -22px",
            opacity: "0",
            transition: "margin-inline-end 0.25s ease-out, opacity 0.2s ease-in"
        });
        b = Ay(b, "span");
        L(b, {
            display: "inline-block"
        });
        a.classList.add("intent-icon-dogtag");
        b.classList.add("intent-icon-span-dogtag");
        b.appendChild(a);
        d.insertBefore(b, d.firstChild);
        e.ariaHidden = "true";
        a.ariaHidden = "true";
        b.ariaHidden = "true";
        d.ariaLabel = c;
        return d
    }

    function az(a, b, c, d, e, f, g, h, k) {
        if (ex(b) !== a.ma && a.Ri) {
            dz(e.getElementById(dy(a.ma)));
            dz(e.getElementById("fallback-container"));
            dz(e.getElementById("double-no-fill-container"));
            var l = e.getElementById("display-slot");
            l && (l.id = "");
            a.be.has(a.ma) && (l = a.be.get(a.ma), L(l.querySelector(".intent-icon-dogtag"), {
                "margin-inline-end": "-22px",
                opacity: "0"
            }), L(l, {
                padding: "1px 16px 8px 16px",
                border: "1px solid #bdc1c6",
                background: "#fff",
                cursor: "pointer"
            }));
            bz(g);
            a.ma = ex(b);
            if (a.Nb.g.has(dy(a.ma))) {
                a.Sd.disconnect();
                d =
                    a.ma;
                if (a.Nb.g.has(dy(d))) switch (Uy(e.getElementById(dy(d))), a.Nb.g.get(dy(d))) {
                    case 1:
                        Uy(e.getElementById("fallback-container"));
                        break;
                    case 2:
                        Uy(e.getElementById("double-no-fill-container")), Xy(a, e)
                }
                c.oc()
            } else Yy(a, e), Ty(a, !1), c = Qy(a.Yb, by, {
                    id: "display-slot",
                    Ua: a.Ua,
                    searchTerm: a.ma,
                    hd: c.format,
                    rsToken: C(b, 13),
                    lj: !0,
                    za: h,
                    ya: k,
                    rk: 1,
                    De: U(sw)
                }), e = e.createElement("div"), e.id = dy(a.ma), e.classList.add("container"), e.appendChild(c), f.appendChild(e), Uy(e), a = d.contentWindow, a.adsbygoogle = a.adsbygoogle || [],
                a.adsbygoogle.push({})
        }
    }

    function bz(a) {
        L(a.querySelector(".intent-icon-dogtag"), {
            "margin-inline-end": "0",
            opacity: "1"
        });
        L(a, {
            border: "1px solid #aecbfa",
            background: "#aecbfa",
            cursor: "default"
        })
    }

    function cz(a, b, c) {
        var d = a.getElementById("dogtags-container-navigation-wrapper"),
            e = a.getElementById("left-arrow-span"),
            f = a.getElementById("right-arrow-span");
        d.addEventListener("mouseover", () => {
            (b.V ? -c.scrollLeft < c.scrollWidth - c.clientWidth - 1 : c.scrollLeft > 0) && ez(e);
            (b.V ? c.scrollLeft < 0 : c.scrollLeft < c.scrollWidth - c.clientWidth - 1) && ez(f)
        });
        d.addEventListener("mouseleave", () => {
            fz(e, b);
            fz(f, b)
        });
        c.addEventListener("scroll", () => {
            (b.V ? -c.scrollLeft < c.scrollWidth - c.clientWidth - 1 : c.scrollLeft > 0) ? ez(e): fz(e,
                b);
            (b.V ? c.scrollLeft < 0 : c.scrollLeft < c.scrollWidth - c.clientWidth - 1) ? ez(f): fz(f, b)
        });
        a.getElementById("left-arrow").addEventListener("click", () => {
            c.scrollLeft -= 100
        });
        a.getElementById("right-arrow").addEventListener("click", () => {
            c.scrollLeft += 100
        })
    }

    function Xy(a, b) {
        var c = b.getElementById("double-no-fill-icon");
        b.getElementById(dy(a.ma)).getBoundingClientRect().height > 40 ? L(c, {
            "padding-top": "15px"
        }) : L(c, {
            "padding-top": "0"
        })
    }

    function ez(a) {
        L(a, {
            display: "flex"
        });
        a.offsetHeight;
        L(a, {
            opacity: "1"
        })
    }

    function fz(a, b) {
        L(a, {
            opacity: "0"
        });
        b.Wb(999, b.win, () => {
            L(a, {
                display: "none"
            })
        }, 200)
    }
    var gz = class {
        constructor(a, b, c, d) {
            this.Ua = a;
            this.me = b;
            this.Kh = c;
            this.Qa = d;
            this.Yb = new Ry;
            this.be = new Map;
            this.ma = "";
            this.Sd = null;
            this.Vg = this.Ri = !1;
            this.sc = this.qc = -1;
            this.Nb = new ey
        }
        tg(a) {
            var b = a.Kc - 83 - 16;
            this.qc = a.ka ? 0 : Math.round(a.win.innerWidth - a.pd);
            this.sc = a.ka ? Math.round(a.win.innerHeight - Gy(a.ka, a.win)) : 32;
            var c = {
                    Dg: ej(a.win.document)
                },
                d = a.searchTerm,
                e = this.Ua,
                f = this.me ? ? "",
                g = W(a.pd),
                h = W(b),
                k = dy(a.searchTerm),
                l = !!B(a.R, 13),
                m = B(a.R, 3),
                n = a.Oj ? ? !1,
                p = this.Kh,
                q = this.Qa,
                u = a.format,
                A = a.rsToken,
                D =
                a.ka,
                K = C(a.R, 27),
                I = C(a.R, 28),
                G = a.ka ? -1 : this.qc,
                E = a.ka ? this.sc : -1,
                Q = U(sw);
            c = jy(c ? ? {}, u, e, f, D, K, p, q, n, m, I, A, d, h, g, k, l, G, E, Q);
            c = li("body", {
                dir: a.V ? "rtl" : "ltr",
                lang: C(a.R, 7),
                style: "margin:0;height:100%;padding-top:0;overflow:hidden"
            }, c.Fb());
            var wa = a.win.document.createElement("iframe");
            L(wa, {
                display: "block",
                border: "0",
                width: "100%",
                height: W(a.Kc)
            });
            this.ma = a.searchTerm;
            this.be.clear();
            this.Nb.clear();
            this.Vg = !1;
            var Ca = a.Kc - 83 - 60 - 27,
                ia = a.pd - 32,
                Fa = a.Ne(999, a.win, Sb => {
                    Sy(this, Sb, wa, a, W(ia), W(Ca));
                    Zy(this,
                        Sb, wa, a, W(a.pd), W(b))
                });
            a.Xc(() => {
                a.win.removeEventListener("message", Fa)
            });
            wa.srcdoc = Vh(c);
            return wa
        }
    };

    function Uy(a) {
        a && L(a, {
            display: "flex"
        })
    }

    function dz(a) {
        a && L(a, {
            display: "none"
        })
    };

    function hz(a, b, c, d, e, f, g, h, k, l, m, n, p, q, u, A, D, K, I, G, E, Q, wa) {
        I = I === void 0 ? "" : I;
        G = G === void 0 ? -1 : G;
        var Ca = E === void 0 ? -1 : E,
            ia = Q === void 0 ? !1 : Q;
        Q = a && a.rb;
        E = a && a.Dg;
        e = Sx(Rx(Sx(Rx(Ux(), "<style" + (Q ? ' nonce="' + S(Zx(Q)) + '"' : "") + ">body {font-family: 'Google Sans', Roboto, Arial, sans-serif; margin: 0; padding-block-start: 8px; overflow: hidden;}.display-slot-container {line-height: 0;}#original-content {padding-block-end: 24px; overflow: hidden; background-image: linear-gradient(#e9f1fe 0px, transparent 300px); min-height: 300px;}.header {line-height: 35px; font-size: 25px; font-weight: 400; padding-inline-start: 24px; padding-inline-end: 24px; padding-block-start: 24px;}#gda-search-term {color: #4285f4;}@supports (background-clip: text) {#gda-search-term {background-image: linear-gradient(90deg, #4285f4, #33a1ce); background-clip: text; color: transparent;}}.generated-by {font-size: 14px; font-weight: 500; color: #1f1f1f; padding: 16px 24px 0; display: flex; align-items: center; gap: 8px; height: 24px;}.icon {flex-shrink: 0;}[dir=\"rtl\"] .icon {transform: scaleX(-1);}.generated-by span {margin-bottom: -2px;}#original-content .display-slot-container {float: left; padding-block-start: 16px;}p,ul,h1,h2,h3 {margin: 0 24px; font-size: 16px; font-weight: 400; line-height: 25px; color: #5c5f5e; clear: both;}h1,h2,h3 {font-size: 20px; font-weight: 500; color: #1f1f1f; padding-block-start: 24px;}p, ul {padding-block-start: 16px;}.item-title {font-weight: 500; color: #1f1f1f;}.disclaimer {font-size: 12px; line-height: 16px; color: #5c5f5e; padding: 16px 24px 0;}</style>" +
                (h !== -1 ? "<script" + (E ? ' nonce="' + S(Zx(E)) + '"' : "") + ">window[" + Gx(Hx(g)) + "] = " + Gx(Hx(h)) + ";\x3c/script>" : "") + (e !== "" ? '<meta name="google-adsense-platform-account" content="' + S(e) + '">' : "")), u ? "" : Rx(Sx(Rx(Ux(), '<div id="display-slot-container" class="display-slot-container" style="position:absolute">'), cy(a, b, c, "display-slot", !1, "", "", A, D, void 0, 1, I, G, Ca, ia)), "</div>")), '<div id="original-content"><div class="header" role="heading" aria-level="1"><span id="gda-search-term">' + tx(n) + "</span></div>"), p ===
            "" || u ? "" : Rx(Sx(Rx(Ux(), '<div id="intro-text"></div><div id="display-slot-container-2" class="display-slot-container" style="position:absolute">'), cy(a, b, c, "display-slot-2", !1, "", "", p, q, void 0, 2, I, G, Ca, ia)), "<script" + (E ? ' nonce="' + S(Zx(E)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).push({});\x3c/script></div>"));
        u ? a = iz(d, f, wa) : (a = (a = a ? ? {}) && a.rb, a = vx("<style" + (a ? ' nonce="' + S(Zx(a)) + '"' : "") + '>@keyframes skeleton-enter {0% {opacity: 0;}100% {opacity: 1;}}@keyframes skeleton-stretch-in {0% {transform: scaleX(0);}100% {transform: scaleX(1);}}@keyframes inline-shimmer {0% {background-position: 0% 0%;}100% {background-position: -200% 0%;}}#skeleton-loader {display: flex; flex-direction: column; align-items: flex-start; gap: 8px; padding: 16px; box-sizing: border-box; width: 100%;}.loader {inline-size: var(--line-width, 100%); block-size: 16px; border-radius: 8px; animation: inline-shimmer 2100ms calc(var(--order, 0) * 100ms) linear infinite both; background: linear-gradient( 90deg, #f0f4f9 20%, #f0f4f9, #d3dbe5,  #f0f4f9); background-size: 200% 100%; transform-origin: left; animation-name: skeleton-enter, skeleton-stretch-in, inline-shimmer; animation-duration: 350ms, 600ms, 2100ms; animation-delay: 200ms, 250ms, 50ms; animation-fill-mode: both; animation-timing-function: linear, cubic-bezier(0.2, 0, 0, 1), linear; animation-iteration-count: 1, 1, infinite;}</style><div id="skeleton-loader"><div class="loader" style="--order: 1;"></div><div class="loader" style="--order: 2; --line-width: 85%"></div><div class="loader" style="--order: 3; --line-width: 65%"></div></div>'));
        return Rx(Sx(e, a), "</div>" + (l ? "<script" + (E ? ' nonce="' + S(Zx(E)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;\x3c/script>" : "") + "<script" + (E ? ' nonce="' + S(Zx(E)) + '"' : "") + ">parent.postMessage({'action':'sgda-ready'}, parent.location.origin);\x3c/script>" + (K ? u ? "" : "<script" + (E ? ' nonce="' + S(Zx(E)) + '"' : "") + ">parent.fakeAdsByGoogle(window);\x3c/script>" : (u ? "" : '<script data-ad-intent-query="" data-ad-intent-rs-token="" data-page-url="' + S(Nx(k)) + '" data-ad-intents-format="' + S(b) +
            '"' + (m ? ' data-adtest="on"' : "") + ' async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + Mx(c) + '" crossorigin="anonymous"' + (E ? ' nonce="' + S(Zx(E)) + '"' : "") + ">\x3c/script>") + '<link href="https://fonts.googleapis.com/css?family=Google+Sans:400,500" rel="stylesheet"' + (Q ? ' nonce="' + S(Zx(Q)) + '"' : "") + ">"))
    }

    function jz(a) {
        return iz(a.lf, a.Ub, a.ie)
    }

    function iz(a, b, c) {
        var d = Ux();
        a = vx('<div class="generated-by"><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon"><path d="M14 21L11 18L14 15L17 18L14 21ZM6 18L0 12L6 6L12 12L6 18ZM15.5 11C15.5 9.46667 14.9667 8.16667 13.9 7.1C12.8333 6.03333 11.5333 5.5 10 5.5C11.5333 5.5 12.8333 4.96667 13.9 3.9C14.9667 2.83333 15.5 1.53333 15.5 0C15.5 1.53333 16.0333 2.83333 17.1 3.9C18.1667 4.96667 19.4667 5.5 21 5.5C19.4667 5.5 18.1667 6.03333 17.1 7.1C16.0333 8.16667 15.5 9.46667 15.5 11Z" fill="url(#spark-gradient)"/><defs><linearGradient id="spark-gradient" x1="0" y1="10.5" x2="21" y2="10.5" gradientUnits="userSpaceOnUse"><stop stop-color="#4285f4ff"/><stop offset="1" stop-color="#2daeb8ff"/></linearGradient></defs></svg><span>' + tx(a) +
            "</span></div>");
        return Sx(Sx(d, a), kz(b, c))
    }

    function lz(a) {
        return kz(a.Ub, a.ie)
    }

    function kz(a, b) {
        var c = "";
        a = Ve(a, Ih, 1, w());
        var d = a.length;
        for (let h = 0; h < d; h++) {
            var e = a[h];
            if (nf(e, Bh, 1, Hh)) e = nf(e, Bh, 1, Hh), e = e.getLevel() === 1 ? "<h1>" + yx(C(e, 2)) + "</h1>" : e.getLevel() === 2 ? "<h2>" + yx(C(e, 2)) + "</h2>" : "<h3>" + yx(C(e, 2)) + "</h3>", c += e;
            else if (nf(e, Eh, 2, Hh)) c += "<p>" + yx(Ch(nf(e, Eh, 2, Hh))) + "</p>";
            else if (nf(e, Fh, 3, Hh)) {
                c += "<ul>";
                e = nf(e, Fh, 3, Hh);
                e = Ee(e, 1, Gd, w());
                var f = e.length;
                for (var g = 0; g < f; g++) c += "<li>" + tx(e[g]) + "</li>";
                c += "</ul>"
            } else if (nf(e, Ah, 5, Hh)) {
                c += "<ul>";
                e = nf(e, Ah, 5, Hh);
                e = Ve(e, zh, 1,
                    w());
                f = e.length;
                for (g = 0; g < f; g++) {
                    let k = e[g];
                    c += "<li>" + (C(k, 1) ? '<span class="item-title">' + yx(C(k, 1)) + "</span> " : "") + yx(C(k, 2)) + "</li>"
                }
                c += "</ul>"
            }
        }
        c += b ? '<div class="disclaimer">' + tx(b) + "</div>" : "";
        return vx(c)
    };

    function mz(a, b) {
        var c = Ve(a, Ih, 1, w()),
            d = c.findIndex(e => Be(e, Eh, 2, Hh));
        if (d === -1) return [a, new Kh];
        a = c[d];
        c = c.slice(d + 1);
        d = Ch(nf(a, Eh, 2, Hh));
        b = nz(d, b);
        if (!b || b.length > d.length - 10) return [Jh([a]), Jh(c)];
        a = d.substring(b.length).trimStart();
        return [Jh([Gh(new Ih, Dh(b))]), Jh([Gh(new Ih, Dh(a)), ...c])]
    }

    function nz(a, b) {
        try {
            return (new Intl.Segmenter(b, {
                granularity: "sentence"
            })).segment(a)[Symbol.iterator]().next().value.segment.trimEnd()
        } catch (c) {}
        return (a = a.match(/^.*?[.!?\u3002\u0964\u0589\u1362\uff1f\uff01]+/)) ? a[0] : null
    };

    function oz(a, b) {
        return C(a, 10).replace("TERM", b)
    };
    const pz = ["P", "UL", "DIV"],
        qz = ["DIV"];
    var uz = class {
        constructor(a, b, c, d, e) {
            this.Ua = a;
            this.me = b;
            this.Kh = c;
            this.Qa = d;
            this.g = e
        }
        Ij(a, b) {
            if (b ? .g()) {
                var c = new yp;
                var d = b.aa;
                d = Ae(d, d[t] | 0, Lh, 2);
                c = y(c, 1, d);
                b = rz(b.pf());
                b = H(c, 2, b);
                z(a, 3, Ap, b)
            } else this.g.Ij ? .(a, b)
        }
        tg(a) {
            var b = a.content;
            if (!b ? .g()) return this.g.tg(a);
            var {
                za: c,
                ya: d
            } = sz(a, ny(qw)), {
                za: e,
                ya: f
            } = sz(a, ny(pw)), g = {
                Dg: ej(a.win.document)
            }, h = {
                searchTerm: a.searchTerm,
                Ua: this.Ua,
                me: this.me ? ? "",
                Dn: c,
                Cn: d,
                jn: e,
                hn: f,
                En: !!B(a.R, 13),
                cn: B(a.R, 3),
                bn: a.Oj ? ? !1,
                Gm: "goog_pvsid",
                Hm: this.Kh,
                Jm: this.Qa,
                oe: a.searchTerm,
                hd: a.format,
                qc: a.ka ? -1 : Math.round(a.win.innerWidth - a.pd),
                sc: a.ka ? Math.round(a.win.innerHeight - Gy(a.ka, a.win)) : -1,
                Sf: U(Zv) && !!a.Sf,
                lf: C(a.R, 9),
                ie: C(a.R, 11),
                Ub: Te(b, Kh, 1)
            };
            g = hz(g ? ? {}, h.hd, h.Ua, h.lf, h.me, h.Ub, h.Gm, h.Hm, h.Jm, h.bn, h.cn, h.searchTerm, h.hn, h.jn, h.Sf, h.Cn, h.Dn, h.En, h.oe, h.qc, h.sc, h.De, h.ie);
            g = li("body", {
                dir: a.V ? "rtl" : "ltr",
                lang: C(a.R, 7)
            }, g.Fb());
            var k = a.win.document.createElement("iframe");
            k.title = oz(a.R, a.searchTerm);
            L(k, {
                display: "block",
                border: "0",
                width: "100%",
                height: W(a.Kc)
            });
            var l, m = a.Ne(999,
                a.win, n => {
                    n.data.action === "sgda-ready" && k.contentWindow && n.source === k.contentWindow && !l && (l = new tz(this.Ua, a, k, Te(b, Kh, 1), C(a.R, 7)))
                });
            a.Xc(() => {
                l ? .dispose();
                a.win.removeEventListener("message", m)
            });
            k.srcdoc = Vh(g);
            return k
        }
    };

    function vz(a) {
        var b = () => {
            L(a.L, {
                height: W(a.l.body.scrollHeight)
            })
        };
        b();
        var c = new a.B.ResizeObserver(() => void b());
        c.observe(a.l.body);
        Is(a, () => void c.disconnect())
    }

    function wz(a, b) {
        var c = b.querySelector("ins");
        return new Promise(d => {
            var e = new MutationObserver((f, g) => {
                f = c.getAttribute("data-ad-status");
                f === "filled" && (g.disconnect(), b.style.position = "", d(f));
                f === "unfilled" && (g.disconnect(), b.style.position === "absolute" && b.remove(), d(f))
            });
            e.observe(c, {
                attributeFilter: ["data-ad-status"]
            });
            Is(a, () => void e.disconnect())
        })
    }

    function xz(a, b, c, d, e, f) {
        var {
            za: g,
            ya: h
        } = sz(a.g, d);
        d = Qy(a.Yb, by, {
            id: e,
            Ua: a.Ua,
            searchTerm: "",
            hd: a.g.format,
            rsToken: "",
            lj: !1,
            oe: a.g.searchTerm,
            sk: f,
            za: g,
            ya: h,
            De: U(sw)
        });
        d.classList.add("display-slot-container");
        b.insertBefore(d, c);
        a = a.B;
        a.adsbygoogle = a.adsbygoogle || [];
        a.adsbygoogle.push({})
    }
    class tz extends Gs {
        constructor(a, b, c, d, e) {
            super();
            this.Ua = a;
            this.g = b;
            this.L = c;
            this.Ub = d;
            this.D = e;
            this.B = this.L.contentWindow;
            this.l = this.L.contentDocument;
            this.Yb = new Ry(void 0, new qj(this.l));
            b.va(999, this.init())
        }
        async init() {
            vz(this);
            var a = this.l.getElementById("display-slot-container");
            if (U(Zv) && !a) this.g.oc();
            else {
                var b = this.l.getElementById("display-slot-container-2");
                if (b) {
                    let d = this.g.va(999, wz(this, a));
                    if (await wz(this, b) === "filled") {
                        this.g.oc();
                        if (a.parentNode) {
                            a.style.position = "";
                            let [e,
                                f
                            ] = mz(this.Ub, this.D);
                            this.C = f;
                            if (a = this.l.getElementById("intro-text")) b = C(this.g.R, 9), b = Py(this.Yb, jz, {
                                lf: b,
                                Ub: e
                            }), a.appendChild(b)
                        }
                        await this.delay()
                    } else a = await d, this.g.oc(), a === "filled" && await this.delay()
                } else a = await wz(this, a), this.g.oc(), a === "filled" && await this.delay();
                this.l.getElementById("skeleton-loader") ? .remove();
                if (a = this.l.getElementById("original-content"))
                    if (this.C ? b = Py(this.Yb, lz, {
                            Ub: this.C,
                            ie: C(this.g.R, 11)
                        }) : (b = C(this.g.R, 9), b = Py(this.Yb, jz, {
                            lf: b,
                            Ub: this.Ub,
                            ie: C(this.g.R,
                                11)
                        })), a.appendChild(b), !U(Zv) || !this.g.Sf)
                        if (a = this.l.getElementById("original-content")) {
                            a: {
                                b = a.querySelectorAll("ins");b = (b = b[b.length - 1]) ? b.getBoundingClientRect().bottom : a.getBoundingClientRect().top;
                                for (c of a.children)
                                    if (pz.includes(c.tagName) && !qz.includes(c.nextElementSibling ? .tagName ? ? "") && c.getBoundingClientRect().bottom + 16 - b >= this.g.Kc) {
                                        var c = c.nextElementSibling;
                                        break a
                                    }
                                c = null
                            }
                            xz(this, a, c, ny(ow), "display-slot-3", 3);b = ny(mw);c && b && xz(this, a, null, b, "display-slot-4", 4)
                        }
            }
        }
        delay() {
            return new Promise(a => {
                var b = this.g.Wb(999, this.g.win, a, V(nw));
                Is(this, () => {
                    this.g.win.clearTimeout(b)
                })
            })
        }
    }

    function sz(a, b) {
        if (!b) return {
            za: "",
            ya: ""
        };
        var c = a.pd,
            d = yj(document, "DIV");
        d.style.cssText = "overflow:auto;position:absolute;top:0;width:100px;height:100px";
        var e = yj(document, "DIV"),
            f = "200px";
        if (f instanceof Ei) {
            var g = f.height;
            f = f.width
        } else g = "200px";
        e.style.width = ak(f);
        e.style.height = ak(g);
        d.appendChild(e);
        document.body.appendChild(d);
        e = d.offsetWidth - d.clientWidth;
        zj(d);
        c = W(c - e);
        a = (ba = ka(b, "replaceAll").call(b, "<SW>", c), ka(ba, "replaceAll")).call(ba, "<DH>", W(a.Kc));
        return {
            za: c,
            ya: a
        }
    }

    function rz(a) {
        switch (a) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            default:
                return 0
        }
    };
    var yz = class {
        constructor(a) {
            this.Hd = a.Hd ? ? [];
            this.Mf = a.Mf ? ? !0;
            this.Mg = !!a.Mg;
            this.Za = a.Za ? ? 0;
            this.Fh = a.Fh ? ? 0;
            this.Ze = !!a.Ze;
            this.af = !!a.af;
            this.bg = !!a.bg;
            this.Ha = !!a.Ha;
            this.Ng = !!a.Ng;
            this.Og = !!a.Og;
            this.Nj = !!a.Nj;
            this.Lg = !!a.Lg
        }
    };

    function zz(a) {
        return new yz({
            Hd: a,
            Mf: U(ww),
            Mg: U(aw),
            Za: V(kw),
            Fh: V(jw),
            Ze: U(bw),
            af: U(cw),
            bg: U(uw),
            Ha: U(Zv),
            Ng: U(ew),
            Og: U(gw),
            Nj: U(sw),
            Lg: U($v)
        })
    }

    function Az(a, b, c, d, e, f) {
        return {
            R: Bz(a) ? ? Te(b, hx, 1),
            Qa: c,
            sb: d,
            Lb: 1,
            M: zz(e),
            Lc: f
        }
    }

    function Cz(a, b, c, d, e, f) {
        return {
            R: Bz(a) ? ? Te(b, hx, 1),
            Qa: c,
            sb: d,
            Lb: 1,
            M: zz(e),
            Lc: f
        }
    }

    function Dz() {
        return { ...Ez(),
            om: V(hw)
        }
    }

    function Ez() {
        return {
            tj: new Set(oy(iw))
        }
    }

    function Bz(a) {
        try {
            a = a ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/);
            if (!a) return null;
            let b = decodeURIComponent(a[1]),
                c = ix(b);
            for (let d of gx(c)) xe(d, 10);
            return c
        } catch (b) {
            return null
        }
    };

    function Yp() {
        return "m202606240101"
    };

    function Fz(a, b) {
        Nk(a, (c, d) => {
            b[d] = c
        })
    }

    function Gz(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && Qk(b); b = b.parent) {
            let c = U(Lw) ? b : a;
            if (c.sf_) return 2;
            if (c.$sf) return 3;
            if (c.inGptIF) return 4;
            if (c.inDapIF) return 5
        }
        return 1
    };

    function Hz() {
        if (Iz) return Iz;
        var a = qr() || window,
            b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? Iz = b : a.google_persistent_state_async = Iz = new Jz
    }

    function Kz(a, b, c) {
        b = Lz[b] || `google_ps_${b}`;
        a = a.S;
        var d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function Mz(a, b, c) {
        return Kz(a, b, () => c)
    }

    function Nz(a, b, c) {
        return a.S[Lz[b] || `google_ps_${b}`] = c
    }

    function Oz(a, b) {
        return Nz(a, b, Mz(a, b, 0) + 1)
    }

    function Pz() {
        var a = Hz();
        return Mz(a, 20, {})
    }

    function Qz() {
        var a = Hz(),
            b = Mz(a, 41, !1);
        b || Nz(a, 41, !0);
        return !b
    }

    function Rz(a) {
        return Mz(a, 24)
    }

    function Sz() {
        var a = Hz();
        return Mz(a, 28, [])
    }
    var Jz = class {
            constructor() {
                this.S = {}
            }
        },
        Iz = null;
    const Lz = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function Tz(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };

    function Uz(a, b) {
        var c = Vz(b, ".google-auto-placed"),
            d = Wz(b),
            e = Xz(b),
            f = Yz(b),
            g = Zz(b),
            h = $z(b),
            k = Vz(b, "div.googlepublisherpluginad"),
            l = Vz(b, "html > ins.adsbygoogle"),
            m = [].concat(...Vz(b, "iframe[id^=aswift_],iframe[id^=google_ads_frame]"), ...Vz(b, "body ins.adsbygoogle")),
            n = [];
        a.ep && (n = n.concat(Vz(b, "ins.adsbygoogle[data-ad-hi]")));
        for (let [p, q] of [
                [a.uf, c],
                [a.yd, d],
                [a.Xl, e],
                [a.fh, f],
                [a.gh, g],
                [a.Ul, h],
                [a.Wl, k],
                [a.Yl, l]
            ]) b = q, p === !1 ? n = n.concat(b) : m = m.concat(b);
        m = aA(m);
        n = aA(n);
        m = m.slice(0);
        for (let p of n)
            for (n =
                0; n < m.length; n++)(p.contains(m[n]) || m[n].contains(p)) && m.splice(n, 1);
        return a.Bl ? bA(m) : m
    }

    function cA(a) {
        return !!a.className && a.className.indexOf("google-auto-placed") != -1
    }

    function dA(a) {
        var b = Tz(a);
        return b ? db(eb(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
    }

    function Vz(a, b) {
        return nb(a.document.querySelectorAll(b))
    }

    function Wz(a) {
        return Vz(a, "ins.adsbygoogle[data-anchor-status]")
    }

    function Xz(a) {
        return Vz(a, "ins.adsbygoogle[data-ad-format=autorelaxed]")
    }

    function Yz(a) {
        return (dA(a) || Vz(a, "div[id^=div-gpt-ad]")).concat(Vz(a, "iframe[id^=google_ads_iframe]"))
    }

    function Zz(a) {
        return Vz(a, "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")
    }

    function $z(a) {
        return Vz(a, "ins.adsbygoogle-ablated-ad-slot")
    }

    function bA(a) {
        return a.filter(b => !b.querySelector('[data-google-ad-efd="true"]'))
    }

    function aA(a) {
        var b = [];
        for (let c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                let e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function eA(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function fA(a, b) {
        a = eA(a);
        a.processed_sra_frame_pingbacks = a.processed_sra_frame_pingbacks || {};
        var c = !a.processed_sra_frame_pingbacks[b];
        a.processed_sra_frame_pingbacks[b] = !0;
        return c
    };

    function gA(a) {
        return a.google_ad_client ? String(a.google_ad_client) : eA(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? ""
    };
    var hA = xh(Vp);
    var Xp = xh(Zp);

    function iA(a, b) {
        return b(a) ? a : void 0
    }

    function jA(a, b, c, d, e) {
        c = c instanceof Tl ? c.error : c;
        var f = new bq,
            g = new aq;
        try {
            var h = Cl(window);
            wf(g, 1, h)
        } catch (p) {}
        try {
            var k = Xq();
            Ne(g, 2, k, hd)
        } catch (p) {}
        try {
            Jf(g, 3, window.document.URL)
        } catch (p) {}
        h = y(f, 2, g);
        k = new $p;
        b = H(k, 1, b);
        try {
            var l = v(c ? .name) ? c.name : "Unknown error";
            Jf(b, 2, l)
        } catch (p) {}
        try {
            var m = v(c ? .message) ? c.message : `Caught ${c}`;
            Jf(b, 3, m)
        } catch (p) {}
        try {
            var n = v(c ? .stack) ? c.stack : Error().stack;
            n && Ne(b, 4, n.split(/\n\s*/), Ed)
        } catch (p) {}
        l = z(h, 1, cq, b);
        if (e) {
            m = 0;
            switch (e.errSrc) {
                case "LCC":
                    m = 1;
                    break;
                case "PVC":
                    m = 2
            }
            n = Wp();
            b = iA(e.shv, v);
            n = Jf(n, 2, b);
            m = H(n, 6, m);
            n = wg(hA());
            b = iA(e.es, Bc());
            n = Ne(n, 1, b, hd);
            n = pe(n);
            m = y(m, 4, n);
            n = iA(e.client, v);
            m = If(m, 3, n);
            n = iA(e.slotname, v);
            m = Jf(m, 7, n);
            e = iA(e.tag_origin, v);
            e = Jf(m, 8, e);
            e = pe(e)
        } else e = yg(Wp());
        e = z(l, 6, dq, e);
        d = wf(e, 5, d ? ? 1);
        Oq(a, d)
    };

    function kA(a) {
        var b = (new lA).g();
        return a > 0 && b.Cm * a <= b.ml
    }
    var lA = class {
        constructor() {
            this.g = mA
        }
    };

    function mA() {
        return {
            Cm: el() + (el() & 2 ** 21 - 1) * 2 ** 32,
            ml: Number.MAX_SAFE_INTEGER
        }
    };
    var pA = class {
        constructor(a = !1) {
            var b = nA;
            this.F = oA;
            this.j = a;
            this.A = b;
            this.g = null;
            this.qa = this.Da
        }
        l(a) {
            this.g = a
        }
        B() {}
        uc(a, b, c) {
            try {
                var d = b()
            } catch (e) {
                b = this.j;
                try {
                    b = this.qa(a, Ul(e), void 0, c)
                } catch (f) {
                    this.Da(217, f)
                }
                if (b) window.console ? .error ? .(e);
                else throw e;
            }
            return d
        }
        wc(a, b, c, d) {
            return (...e) => this.uc(a, () => b.apply(c, e), d)
        }
        va(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.Da(a, d instanceof Error ? d : Error(d), void 0, c)
            })
        }
        Da(a, b, c, d) {
            try {
                let f = c === void 0 ? 1 / this.A : c === 0 ? 0 : 1 / c;
                if (kA(f)) {
                    var e = this.F;
                    c = {};
                    if (this.g) try {
                        this.g(c)
                    } catch (g) {}
                    if (d) try {
                        d(c)
                    } catch (g) {}
                    jA(e, a, b, f, c)
                }
            } catch (f) {}
            return this.j
        }
    };
    var qA = class extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, qA) : this.stack = Error().stack || ""
        }
    };
    let oA, rA, sA, tA, nA;
    const uA = new Cm(r);
    (function(a, b, c = !0) {
        ({
            Um: nA,
            Ol: sA
        } = vA());
        rA = a || new gr;
        fr(rA, sA);
        oA = b || new $q(Yp(), 1E3);
        tA = new pA(c);
        r.document.readyState === "complete" ? r.google_measure_js_timing || Bm(uA) : uA.g && gk(r, "load", () => {
            r.google_measure_js_timing || Bm(uA)
        })
    })();

    function wA(a, b, c) {
        return tA.uc(a, b, c)
    }

    function xA(a, b) {
        return tA.wc(a, b)
    }

    function yA(a, b, c) {
        tA.va(a, b, c)
    }

    function zA(a, b, c = .01) {
        var d = Xq();
        !b.eid && d.length && (b.eid = d.toString());
        $m(rA, a, b, !0, c)
    }

    function AA(a, b, c = nA, d) {
        return tA.Da(a, b, c, d, void 0)
    }

    function vA() {
        if (qc(r.google_srt)) {
            var a = r.google_srt;
            var b = r.google_srt === 0 ? 1 : .01
        } else a = Math.random(), b = .01;
        return {
            Um: b,
            Ol: a
        }
    };

    function Yq(a, b) {
        a.g.size > 0 || BA(a);
        var c = a.g.get(0);
        c ? c.push(b) : a.g.set(0, [b])
    }

    function CA(a, b, c, d) {
        gk(b, c, d);
        Is(a, () => hk(b, c, d))
    }

    function DA(a, b) {
        a.state !== 1 && (a.state = 1, a.g.size > 0 && EA(a, b))
    }

    function BA(a) {
        a.win.document.visibilityState ? CA(a, a.win.document, "visibilitychange", b => {
            a.win.document.visibilityState === "hidden" && DA(a, b);
            a.win.document.visibilityState === "visible" && (a.state = 0)
        }) : "onpagehide" in a.win ? (CA(a, a.win, "pagehide", b => {
            DA(a, b)
        }), CA(a, a.win, "pageshow", () => {
            a.state = 0
        })) : CA(a, a.win, "beforeunload", b => {
            DA(a, b)
        })
    }

    function EA(a, b) {
        for (let c = 9; c >= 0; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var FA = class extends Gs {
        constructor(a) {
            super();
            this.win = a;
            this.state = 0;
            this.g = new Map
        }
    };
    async function GA(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} 200`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            var f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function HA() {
        return ar(IA)
    }

    function JA(a) {
        var b = a.state.pc;
        return b !== null && b !== 0 ? b : a.state.pc = Cl(a.win)
    }

    function KA(a) {
        var b = a.state.wpc;
        return b !== null && b !== "" ? b : a.state.wpc = gA(a.win)
    }

    function LA(a, b) {
        var c = new Tp;
        var d = JA(a);
        c = wf(c, 1, d);
        d = KA(a);
        c = Jf(c, 2, d);
        c = Sp(c, a.state.sd);
        return wf(c, 7, Math.round(b || a.win.performance.now()))
    }

    function MA(a, b, c) {
        b(a.F.Tb.Zb.Oe).ua(c)
    }

    function NA(a, b, c) {
        b(a.F.Tb.Zb.Oe).Od(c)
    }
    async function OA(a) {
        try {
            return await GA(a.win, () => !(!JA(a) || !KA(a))), !0
        } catch (b) {
            return !1
        }
    }

    function PA(a) {
        var b = HA();
        if (b.g) {
            var c = b.l;
            a(c);
            b.state.cc = $d(c)
        }
    }
    async function QA(a, b, c) {
        if (a.g && c.length && !a.state.lgdp.includes(Number(b))) {
            a.state.lgdp.push(Number(b));
            var d = a.win.performance.now();
            if (await OA(a)) {
                var e = a.F;
                a = LA(a, d);
                d = new Co;
                b = H(d, 1, b);
                c = Ne(b, 2, c, hd);
                c = z(a, 9, Up, c);
                Pq(e, c)
            }
        }
    }
    async function RA(a, b) {
        if (await OA(a)) {
            var c = LA(a);
            b = z(c, 5, Up, b);
            a.g && !a.state.le.includes(2) && (a.state.le.push(2), Pq(a.F, b))
        }
    }
    async function SA(a, b, c) {
        if (await OA(a)) {
            var d = a.F;
            a = Sp(LA(a, c), 1);
            b = z(a, 6, Up, b);
            Pq(d, b)
        }
    }
    async function TA(a, b, c) {
        await OA(a) && MA(a, d => b(d.Tj), c)
    }
    async function UA(a, b, c) {
        await OA(a) && NA(a, d => b(d.Tj), c)
    }
    async function VA(a, b) {
        if (await OA(a)) {
            var c = a.F;
            a = Sp(LA(a), 1);
            b = z(a, 13, Up, b);
            Pq(c, b)
        }
    }
    async function WA(a, b) {
        if (a.g && await OA(a)) {
            var c = a.F;
            a = LA(a);
            b = z(a, 11, Up, b);
            Pq(c, b)
        }
    }
    async function XA(a, b) {
        if (await OA(a)) {
            var c = a.F;
            a = Sp(LA(a), 1);
            b = z(a, 16, Up, b);
            Pq(c, b)
        }
    }
    async function YA(a, b) {
        if (await OA(a)) {
            var c = a.F;
            a = Sp(LA(a), 1);
            b = z(a, 19, Up, b);
            Pq(c, b)
        }
    }
    async function ZA(a) {
        var b = HA(),
            c = V(Mw);
        if (c > 0 && bl() < 1 / c && await OA(b)) {
            var d = new Bo;
            d = H(d, 1, a);
            a = b.F;
            b = LA(b);
            b = z(b, 23, Up, d);
            Pq(a, Sp(b, c))
        }
    }
    var IA = class {
        constructor(a, b) {
            this.win = qr() || window;
            this.j = b ? ? new FA(this.win);
            this.F = a ? ? new $q(Yp(), 100, 100, !0, this.j);
            this.state = Kz(Hz(), 33, () => {
                var c = V(Vu);
                return {
                    sd: c,
                    ssp: c > 0 && bl() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get g() {
            return this.state.ssp
        }
        get Qa() {
            return this.state.cu
        }
        set Qa(a) {
            this.state.cu = a
        }
        get l() {
            return wA(1227, () => zg(Ho, ae(this.state.cc || []))) || new Ho
        }
    };

    function $A(a) {
        return eA(a) ? .head_tag_slot_vars ? .google_ad_host ? ? a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };
    var aB = class {
        constructor() {
            this.A = this.B = 1;
            this.l = new Map;
            this.j = new Set;
            this.g = new Map;
            this.isDrawerVisible = !1
        }
        takeNextPageEventIndex() {
            return this.B++
        }
        takeNextAnnotationEntryId() {
            return this.A++
        }
        getTermUsageCount(a) {
            return this.l.get(a) ? ? 0
        }
        incrementTermUsageCount(a) {
            var b = this.l.get(a) ? ? 0;
            this.l.set(a, b + 1)
        }
        onDrawerCollapse(a) {
            this.j.add(a)
        }
        removeOnDrawerCollapse(a) {
            this.j.delete(a)
        }
        getClickPageEventIndex(a) {
            return this.g.get(a)
        }
        setClickPageEventIndex(a, b) {
            this.g.set(a, b)
        }
        removeClickPageEventIndex(a) {
            this.g.delete(a)
        }
        notifyDrawerCollapsed() {
            for (let a of this.j) a()
        }
    };

    function bB(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = []), a.google_reactive_ads_global_state.adIntentsPageState == null && (a.google_reactive_ads_global_state.adIntentsPageState = new aB)) : a.google_reactive_ads_global_state = new cB;
        return a.google_reactive_ads_global_state
    }
    var cB = class {
            constructor() {
                this.wasPlaTagProcessed = !1;
                this.wasReactiveAdConfigReceived = {};
                this.adCount = {};
                this.wasReactiveAdVisible = {};
                this.stateForType = {};
                this.reactiveTypeEnabledInAsfe = {};
                this.wasReactiveTagRequestSent = !1;
                this.reactiveTypeDisabledByPublisher = {};
                this.tagSpecificState = {};
                this.messageValidationEnabled = !1;
                this.floatingAdsStacking = new dB;
                this.sideRailProcessedFixedElements = new Set;
                this.sideRailAvailableSpace = new Map;
                this.sideRailPlasParam = new Map;
                this.sideRailMutationCallbacks = [];
                this.g =
                    null;
                this.clickTriggeredInterstitialMayBeDisplayed = !1;
                this.adIntentsPageState = new aB
            }
        },
        dB = class {
            constructor() {
                this.maxZIndexRestrictions = {};
                this.nextRestrictionId = 0;
                this.maxZIndexListeners = []
            }
        };
    var eB = class {
            constructor(a) {
                this.performance = a
            }
            oa() {
                return this.performance.now()
            }
        },
        fB = class {
            oa() {
                return Date.now()
            }
        };

    function gB(a) {
        return a ? pc(b => {
            try {
                if (b instanceof a) return !0;
                let c = b ? .ownerDocument ? .defaultView ? .[a.name];
                return sc(c) && b instanceof c
            } catch {
                return !1
            }
        }) : pc(() => !1)
    }
    gB(Node);
    var hB = gB(globalThis.Element),
        iB = gB(globalThis.HTMLElement);
    gB(globalThis.SVGElement);

    function jB() {
        return pc(a => iB(a) && a.tagName.toLowerCase() === "a")
    };

    function kB({
        di: a,
        Pg: b,
        Hh: c,
        ei: d,
        Qg: e,
        Ih: f
    }) {
        var g = [];
        for (let n = 0; n < f; n++)
            for (let p = 0; p < c; p++) {
                var h = p,
                    k = c - 1,
                    l = n,
                    m = f - 1;
                g.push({
                    x: a + (k === 0 ? 0 : h / k) * (b - a),
                    y: d + (m === 0 ? 0 : l / m) * (e - d)
                })
            }
        return g
    }

    function lB(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };

    function mB(a, b, c) {
        var d = kB({
            di: b.left,
            Pg: b.right,
            Hh: 10,
            ei: b.top,
            Qg: b.bottom,
            Ih: 10
        });
        b = new Set;
        for (let e of d)(d = nB(a, e, c)) && b.add(d);
        return b
    }

    function oB(a, b, c = !1) {
        for (let d of b)
            if (b = pB(a, d, c)) return b;
        return null
    }

    function qB(a, b, c = !1) {
        return oB(a, b, c) != null
    }

    function rB(a, b, c) {
        if (Wj(b, "position") !== "fixed") return null;
        var d = b.getAttribute("class") === "GoogleActiveViewInnerContainer" || bk(b).width <= 1 && bk(b).height <= 1 || a.g.ce && !a.g.ce(b) ? !0 : !1;
        a.g.Xi && a.g.Xi(b, c, d);
        return d ? null : b
    }

    function nB(a, b, c) {
        var d = lB(a.K.document, b);
        if (d) {
            var e;
            if (!(e = rB(a, d, b))) {
                if (c) a: {
                    for (d = sB(d); d && d !== a.K.document.body; d = sB(d))
                        if (c = rB(a, d, b)) {
                            a = c;
                            break a
                        }
                    a = null
                }
                else a: {
                    c = a.K.document;
                    for (d = d.offsetParent; d && d !== c.body; d = d.offsetParent)
                        if (e = rB(a, d, b)) {
                            a = e;
                            break a
                        }
                    a = null
                }
                e = a
            }
            a = e || null
        } else a = null;
        return a
    }

    function pB(a, b, c = !1) {
        b = nB(a, b);
        return !b || b.hasAttribute("google-allow-overlap") || c && (c = b.getBoundingClientRect(), c.width >= a.K.innerWidth && c.height >= a.K.innerHeight) ? null : b
    }
    var tB = class {
        constructor(a, b = {}) {
            this.K = a;
            this.g = b
        }
    };

    function sB(a) {
        return iB(a) ? a.offsetParent : a.parentElement
    };

    function uB({
        K: a,
        xm: b,
        pm: c,
        Vk: d,
        qp: e,
        sp: f,
        F: g,
        Tl: h
    }) {
        var k = 0;
        try {
            k |= gs(a, f);
            let n = Math.min(a.screen.width || 0, a.screen.height || 0);
            k |= n ? n < 320 ? 8192 : 0 : 2048;
            k |= a.navigator && vB(a.navigator.userAgent) ? 1048576 : 0;
            if (b) {
                f = k;
                let p = a.innerHeight;
                var l = Yk(a) * p >= b;
                var m = f | (l ? 0 : 1024)
            } else m = k | (a.innerHeight >= a.innerWidth ? 0 : 8);
            k = m;
            k |= js(a, c, !0, e)
        } catch {
            k |= 32
        }
        switch (d) {
            case 2:
                wB(a, g, h) && (k |= 16777216);
                break;
            case 1:
                xB(a, g, h) && (k |= 16777216)
        }
        return k
    }

    function vB(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    }

    function wB(a, b = null, c = !1) {
        var d = kB({
            di: 0,
            Pg: a.innerWidth,
            Hh: 3,
            ei: 0,
            Qg: Math.min(Math.round(a.innerWidth / 320 * 50), yB) + 15,
            Ih: 3
        });
        return zB(a, d, b, c)
    }

    function xB(a, b = null, c = !1) {
        var d = a.innerWidth,
            e = a.innerHeight,
            f = Math.min(Math.round(a.innerWidth / 320 * 50), yB) + 15,
            g = kB({
                di: 0,
                Pg: d,
                Hh: 3,
                ei: e - f,
                Qg: e,
                Ih: 3
            });
        f > 25 && g.push({
            x: d - 25,
            y: e - 25
        });
        return zB(a, g, b, c)
    }

    function zB(a, b, c, d) {
        return qB(AB(a, c, e => e.getAttribute("google-anchor-overlappable") !== "true"), b, d)
    }

    function AB(a, b = null, c) {
        return new tB(a, {
            Xi: BB(a, b),
            ce: c
        })
    }

    function BB(a, b = null) {
        if (b) return (c, d, e) => {
            $m(b, "ach_evt", {
                tn: c.tagName,
                id: c.getAttribute("id") ? ? "",
                cls: c.getAttribute("class") ? ? "",
                ign: String(e),
                pw: a.innerWidth,
                ph: a.innerHeight,
                x: d.x,
                y: d.y
            }, !0, 1)
        }
    }
    const yB = 90 * 1.38;
    var CB = class {
        constructor(a, b, c) {
            this.position = a;
            this.Ke = b;
            this.g = c
        }
    };

    function DB(a, b) {
        this.start = a < b ? a : b;
        this.end = a < b ? b : a
    };

    function EB(a, b, c, d) {
        var e = is(a);
        e = new CB(b.Nd.wj(b.Gc), b.Ke + 2 * b.Gc, Math.min(e, b.Ef) - b.Nd.mf() + 2 * b.Gc);
        e = e.position.Oi(a, e.Ke, e.g);
        var f = hs(a),
            g = is(a);
        c = FB(a, new Lj(Ai(e.top, g - 1), Ai(e.right, f - 1), Ai(e.bottom, g - 1), Ai(e.left, f - 1)), c, d);
        f = GB(c);
        g = e.top;
        d = [];
        for (let h = 0; h < f.length; h++) f[h].start > g && d.push(new DB(g, f[h].start)), g = f[h].end;
        g < e.bottom && d.push(new DB(g, e.bottom));
        a = is(a);
        e = [];
        for (f = d.length - 1; f >= 0; f--) e.push(new DB(a - d[f].end, a - d[f].start));
        a: {
            for (let h of e) {
                b: {
                    a = h.start + b.Gc;
                    if (a > b.Nd.mf() +
                        b.Ah) {
                        a = null;
                        break b
                    }
                    e = Math.min(h.end - b.Gc, b.Ef) - a;a = e < b.Dh ? null : {
                        position: b.Nd.ek(a),
                        re: e
                    }
                }
                if (a) {
                    b = a;
                    break a
                }
            }
            b = null
        }
        return {
            rg: b,
            Yo: c
        }
    }

    function FB(a, b, c, d) {
        var e = mB(new tB(a), b, d);
        c.forEach(f => void e.delete(f));
        return e
    }

    function GB(a) {
        return [...a].map(HB).sort((b, c) => b.start - c.start)
    }

    function HB(a) {
        a = a.getBoundingClientRect();
        return new DB(a.top, a.bottom)
    };

    function IB({
        sa: a,
        lb: b
    }) {
        return new JB(a, b)
    }
    var JB = class {
        constructor(a, b) {
            this.sa = a;
            this.lb = b
        }
        wj(a) {
            return new JB(this.sa - a, this.lb - a)
        }
        Oi(a, b, c) {
            a = is(a) - this.sa - c;
            return new Lj(a, this.lb + b, a + c, this.lb)
        }
        Ci(a) {
            a.bottom = `${this.sa}px`;
            a.left = `${this.lb}px`;
            a.right = ""
        }
        aj() {
            return 0
        }
        mf() {
            return this.sa
        }
        ek(a) {
            return new JB(a, this.lb)
        }
    };

    function KB({
        sa: a,
        wb: b
    }) {
        return new LB(a, b)
    }
    var LB = class {
        constructor(a, b) {
            this.sa = a;
            this.wb = b
        }
        wj(a) {
            return new LB(this.sa - a, this.wb - a)
        }
        Oi(a, b, c) {
            var d = hs(a);
            a = is(a) - this.sa - c;
            d = d - this.wb - b;
            return new Lj(a, d + b, a + c, d)
        }
        Ci(a) {
            a.bottom = `${this.sa}px`;
            a.right = `${this.wb}px`;
            a.left = ""
        }
        aj() {
            return 1
        }
        mf() {
            return this.sa
        }
        ek(a) {
            return new LB(a, this.wb)
        }
    };

    function MB(a, b) {
        var c;
        a: {
            for (c = a.document.body; c; c = c.parentElement)
                if (c.classList.contains("google-anno-skip")) {
                    c = !1;
                    break a
                }
            c = b.ga >= 400
        }
        if (c)
            if ((c = NB(a, b)) != null) b = c;
            else a: {
                c = b.ba;
                var d = OB(a, b);a = 16;
                for (let e of d) {
                    d = e.start;
                    let f = e.end;
                    if (d > a) {
                        if (d - a - 16 >= 200) {
                            b = PB(b, d, a);
                            break a
                        }
                        a = f + 16
                    } else f >= a && (a = f + 16)
                }
                b = c - a - 16 >= 200 ? PB(b, c, a) : null
            }
        else b = null;
        return b
    }

    function NB(a, b) {
        var c = b.ka === b.V,
            d = QB(a, b, c);
        if (!d) return null;
        d = d.position.mf();
        a = RB(a, d, b, function(f) {
            f = f.getBoundingClientRect();
            return c ? b.ba - f.right : f.left
        });
        if (!a || a - 16 < 200) return null;
        var e = b.ba;
        return {
            lb: c ? e - a : 16,
            wb: c ? 16 : e - a,
            sa: d
        }
    }

    function SB(a, b) {
        var c = hs(a),
            d = is(a);
        return mB(new tB(a, {
            ce: e => e.id !== "google-anno-sa"
        }), new Lj(d - b.sa - 50, c - b.wb, d - b.sa, b.lb), !0).size > 0
    }

    function QB(a, b, c) {
        b = Math.floor(b.ga * .3);
        if (b < 66) return null;
        c = c ? KB({
            sa: 16,
            wb: 16
        }) : IB({
            sa: 16,
            lb: 16
        });
        var d = a.document.getElementById("google-anno-sa");
        return EB(a, {
            Nd: c,
            Ah: b - 66,
            Ke: 200,
            Dh: 50,
            Ef: b,
            Gc: 16
        }, d ? [a.document.body, d] : [a.document.body], !0).rg
    }

    function RB(a, b, c, d) {
        a = c.ka ? TB(a, b, c) : UB(a, b, c);
        b = c.ba;
        var e = c.ka ? b : b * .35;
        a.forEach(f => {
            e = Math.min(e, d(f))
        });
        return e < 16 ? null : e - 16
    }

    function TB(a, b, c) {
        var d = c.ga;
        return mB(new tB(a, {
            ce: e => e.id !== "google-anno-sa"
        }), new Lj(d - b - 50, c.ba - 16, d - b, 16), !0)
    }

    function UB(a, b, c) {
        var d = c.ga,
            e = c.ba;
        c = c.V;
        return mB(new tB(a, {
            ce: f => f.id !== "google-anno-sa"
        }), new Lj(d - b - 50, (c ? e * .35 : e) - 16, d - b, (c ? 16 : e * .65) + 16), !0)
    }

    function PB(a, b, c) {
        var d = a.V;
        return {
            lb: d ? VB(a, b, c) : c,
            wb: d ? c : VB(a, b, c),
            sa: 16
        }
    }

    function VB(a, b, c) {
        var d = a.ba;
        return a.ka ? d - b + 16 : Math.max(d - c - d * .35, d - b + 16)
    }

    function OB(a, b) {
        var c = b.V,
            d = b.ba;
        return [...(b.ka ? TB(a, 16, b) : UB(a, 16, b))].map(e => new DB(c ? d - e.getBoundingClientRect().right : e.getBoundingClientRect().left, c ? d - e.getBoundingClientRect().left : e.getBoundingClientRect().right)).sort((e, f) => e.start - f.start)
    };

    function WB(a) {
        return a.M.bg && F(a.R, 6) === 2 ? .4 : a.M.Fh
    }

    function XB(a, b, c, d, e) {
        var f = Ay(a, "span");
        f.id = "gda";
        f.appendChild(Jy(a, C(b.R, 18), e));
        Cy(f);
        YB(b, 1064, f, g => {
            d ? .();
            zj(c);
            g.preventDefault();
            g.stopImmediatePropagation();
            return !1
        });
        return f
    }

    function ZB(a, b, c, d, e, f, g, h) {
        var k = Ay(a, "span");
        L(k, {
            position: "absolute",
            top: "2.5px",
            bottom: "2.5px",
            left: (b.V(), "50px"),
            right: b.V() ? "24px" : "12px",
            display: "flex",
            "flex-direction": "row",
            color: f,
            cursor: "pointer",
            transition: "width 5s"
        });
        b.ka || L(k, {
            "justify-content": ""
        });
        var l = Hy(a, f),
            m = Ay(a, "span");
        L(m, {
            display: "inline-block",
            cursor: "inherit",
            "margin-left": b.V() ? "6px" : "4px",
            "margin-right": b.V() ? "4px" : "6px",
            "margin-top": "12px",
            "min-width": "initial"
        });
        k.appendChild(m);
        m.appendChild(l);
        c.classList ? .add("google-anno-sa-qtx",
            "google-anno-skip");
        c.tabIndex = 0;
        c.role = "link";
        c.ariaLive = "polite";
        c.ariaLabel = $B(d.g, b);
        L(c, {
            height: "40px",
            "align-items": "center",
            "line-height": "44px",
            "font-weight": "400",
            "font-style": "normal",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
            overflow: "hidden",
            "-webkit-tap-highlight-color": "transparent",
            color: f
        });
        b.M.Ha && g ? k.classList.add("google-anno-oc") : Cy(k);
        b.M.Ha && aC(b, k, () => {
            var n = d.g,
                p = bC(a, b, n),
                q = d.j;
            q && (n = Dp(Bp(n), q), n = vf(n, 3, d.l), p = Ep(H(n, 9, 1), p), h.setClickPageEventIndex(q, b.g.Hc(p)))
        });
        YB(b, 999, k, n => {
            n.preventDefault();
            if (!cC(e, b)) return !1;
            n = n.isTrusted;
            if ((d.B ? ? 0) + 800 <= b.oa(29)) {
                let u = d.g,
                    A = b.B.get(u) || "";
                var p = d.j;
                if (b.M.Ha && !n && p && h.getClickPageEventIndex(p) !== void 0) {
                    var q = h.getClickPageEventIndex(p);
                    h.removeClickPageEventIndex(p)
                } else q = bC(a, b, u), p = Dp(Bp(u), p), p = vf(p, 3, d.l), q = Ep(H(p, 9, 1), q), q = b.g.Hc(q);
                b.va(1401, dC(e, a, b, q, u, A, 2, !1, b.M.Ha && !n && eC(b, u)))
            }
            return !1
        });
        k.appendChild(c);
        return k
    }

    function fC(a, b, c, d, e, f, g) {
        var h = Ay(a, "div");
        h.id = "google-anno-sa";
        h.dir = b.V() ? "rtl" : "ltr";
        h.tabIndex = 0;
        h.setAttribute("google-side-rail-overlap", "true");
        h.setAttribute("google-anchor-overlappable", "true");
        var k = Fy(a, WB(b));
        if (k) a: {
            if (WB(b)) {
                var l = a.document.querySelectorAll("p"),
                    m = [];
                for (var n = 0; n < Math.min(l.length, 2); n++) m.push(l[n]);
                l = wy(k);
                n = [l[0], l[1], l[2]];
                if (l[3] < 1) {
                    n = zy(a.document.body, b.M) || [255, 255, 255];
                    let q = l[3];
                    n = [Math.round(q * l[0] + (1 - q) * n[0]), Math.round(q * l[1] + (1 - q) * n[1]), Math.round(q *
                        l[2] + (1 - q) * n[2])]
                }
                for (p of m)
                    if ((m = xy(p)) && n && uy(m, n) >= 3) {
                        var p = a.getComputedStyle(p).color;
                        break a
                    }
            }
            p = null
        }
        else p = null;
        k = p ? k : null;
        p = p ? ? "#1A73E8";
        m = "#FFFFFF";
        k && (m = zy(a.document.body, b.M), m = `linear-gradient(${k}, ${k}), ${m?`rgb(${m[0]}, ${m[1]}, ${m[2]})`:"#FFFFFF"}`);
        L(h, {
            background: m,
            "border-style": "solid",
            bottom: W(d.sa),
            "border-radius": "16px",
            height: W(50),
            position: "fixed",
            "text-align": "center",
            border: "0px",
            left: W(d.lb),
            right: W(d.wb),
            "box-shadow": "0px 1px 2px rgba(0, 0, 0, 0.3), 0px 1px 3px 1px rgba(0, 0, 0, 0.15)",
            "z-index": "1000"
        });
        L(h, {
            fill: "white"
        });
        L(h, {
            color: p,
            cursor: "auto",
            "font-family": "Roboto",
            "font-size": "16px",
            "font-weight": "400",
            "font-style": "normal",
            overflow: "hidden",
            "text-align": "start",
            "text-orientation": "mixed",
            visibility: "visible",
            "writing-mode": "initial"
        });
        d = Ay(a, "span");
        L(d, {
            cursor: "inherit"
        });
        h.appendChild(ZB(a, b, d, c, f, p, eC(b, c.g), g));
        h.appendChild(XB(a, b, h, e, p));
        return h
    }

    function gC(a, b, c, d) {
        var e = c.getElementsByClassName("google-anno-sa-qtx")[0];
        iB(e) && (d.M.Lg ? hC(a, e, d, b) : (e.innerText = a.g, e.ariaLabel = $B(a.g, d)), b = c.getElementsByTagName("span")[0], d.M.Ha && eC(d, a.g) ? (b.classList.add("google-anno-oc"), b.removeAttribute("data-google-vignette"), b.removeAttribute("data-google-interstitial")) : (b.classList.remove("google-anno-oc"), Cy(b)));
        d = d.g;
        b = d.ng;
        c = new $o;
        e = a.j;
        c = xe(c, 2, e == null ? e : Ad(e, void 0));
        a = Jf(c, 4, a.g);
        return b.call(d, a)
    }

    function iC(a, b, c, d, e, f) {
        if (SB(b, d)) return null;
        a.B = c.oa(28);
        d = fC(b, c, a, d, () => {
            a.A = !0;
            var g = c.g,
                h = g.lg;
            var k = new Yo;
            k = yf(k, 3, a.j);
            k = Jf(k, 2, a.g);
            h.call(g, k)
        }, e, f);
        e = gC(a, b, d, c);
        b.document.body.appendChild(d);
        return e
    }

    function jC(a, b, c, d, e, f, g, h) {
        if (!(a.A || a.g === e && a.j === d)) {
            if (a.l !== null) {
                var k = a.l,
                    l = c.g,
                    m = l.mg,
                    n = new Zo;
                k = wf(n, 1, k);
                m.call(l, k)
            }
            a.g = e;
            a.j = d;
            B(c.R, 17) || (d = b.document.getElementById("google-anno-sa"), a.l = d ? gC(a, b, d, c) : iC(a, b, c, f, g, h))
        }
    }
    async function hC(a, b, c, d) {
        if (b.textContent !== a.g)
            if (b.innerText) {
                var e = b.parentElement;
                e && L(e, {
                    perspective: "1000px",
                    "transform-style": "preserve-3d"
                });
                try {
                    L(b, {
                        display: "inline-block",
                        transition: "transform 350ms ease-in, opacity 350ms ease-in",
                        transform: "rotateX(-90deg)",
                        opacity: "0"
                    }), c.Wb(898, d, () => {
                        b.innerText = a.g;
                        b.ariaLabel = $B(a.g, c);
                        L(b, {
                            transition: "none",
                            transform: "rotateX(90deg)",
                            opacity: "0"
                        });
                        b.getBoundingClientRect();
                        c.Wb(898, d, () => {
                            L(b, {
                                transition: "transform 350ms ease-out, opacity 350ms ease-out",
                                transform: "rotateX(0deg)",
                                opacity: "1"
                            })
                        }, 0)
                    }, 350)
                } catch (f) {
                    b.textContent = a.g, L(b, {
                        transition: "none",
                        transform: "rotateX(0deg)",
                        opacity: "1"
                    })
                }
            } else b.innerText = a.g, b.ariaLabel = $B(a.g, c)
    }

    function kC(a, b, c, d) {
        if (!a.A) {
            var e = b.document.getElementById("google-anno-sa");
            e && lC(d, b, () => {
                L(e, {
                    transition: "all 200ms ease-in-out",
                    bottom: W(c.sa),
                    left: W(c.lb),
                    right: W(c.wb)
                })
            })
        }
    }
    var mC = class {
        constructor() {
            this.g = "";
            this.l = this.j = null;
            this.A = !1;
            this.B = null
        }
    };

    function $B(a, b) {
        return C(b.R, 19).replace("TERM", a)
    };

    function nC(a, b, c = null) {
        a.l >= a.A.length && (a.l = 0, a.C++);
        a.C >= 3 || (c ? ? a.g.isDrawerVisible() ? a.g.Xc(() => void nC(a, b, !1)) : (c = a.A[a.l++], a.B = !1, jC(a.D, a.win, a.config, c.Dk, c.searchTerm, a.j, a.g, a.pageState), a.config.Wb(898, a.win, () => {
            nC(a, b)
        }, a.hi)))
    }
    var oC = class {
        constructor(a, b, c, d, e, f) {
            var g = new mC;
            this.win = a;
            this.config = b;
            this.D = g;
            this.j = d;
            this.g = e;
            this.pageState = f;
            this.A = [];
            this.B = !0;
            this.C = this.l = 0;
            this.hi = c.hi
        }
    };

    function pC(a) {
        return a.maximumAnnotationsPerPage > 0 && a.g.A >= a.maximumAnnotationsPerPage
    }
    var rC = class {
        constructor(a, b, c, d, e) {
            this.A = b;
            this.annotationsPerWindow = c;
            this.maximumAnnotationsPerPage = d;
            this.l = e;
            this.j = 0;
            this.g = new qC(a)
        }
    };

    function sC(a, b) {
        b -= a.B;
        for (let c of a.g.keys()) {
            let d = a.g.get(c),
                e = 0;
            for (; e < d.length && d[e] < b;) e++;
            a.j -= e;
            e > 0 && a.g.set(c, d.slice(e))
        }
    }
    class qC {
        constructor(a) {
            this.B = a;
            this.g = new Map;
            this.l = new Map;
            this.j = 0
        }
        get A() {
            return this.j
        }
    };

    function tC(a) {
        return a.M.bg && F(a.R, 6) === 2
    }

    function uC(a, b, c, d, e, f, g, h, k) {
        var l = Ay(a, "div");
        l.classList.add("google-anno-skip", "google-anno-sc");
        !k && b.M.Ha && eC(b, c) && l.classList.add("google-anno-oc");
        d = a.getComputedStyle(d).fontSize || "16px";
        if (h = tC(b) && !h) {
            var m = c.indexOf(" "),
                n = (k = m > 0) ? c.substring(0, m) : c;
            m = k ? c.substring(m + 1) : "";
            let p = Ay(a, "span");
            L(p, {
                "white-space": "nowrap",
                display: "inline-block",
                "padding-left": b.M.Za ? b.V() ? "0" : "6px" : "",
                "padding-right": b.M.Za ? b.V() ? "6px" : "0" : ""
            });
            p.appendChild(vC(a, d, b, f, h));
            p.appendChild(wC(a, b, n, !k));
            b.M.Za ||
                l.appendChild(a.document.createTextNode(" "));
            l.appendChild(p);
            m && l.appendChild(wC(a, b, m, !0))
        } else l.appendChild(vC(a, d, b, f, h)), k = l.appendChild, n = Ay(a, "span"), n.appendChild(a.document.createTextNode(c)), L(n, {
            position: "relative",
            left: b.V() ? "" : "3px",
            right: b.V() ? "3px" : "",
            "padding-left": b.V() ? "6px" : "",
            "padding-right": b.V() ? "" : "6px"
        }), k.call(l, n);
        if (h) {
            f = b.M.Za ? f : "inherit";
            g = "";
            if (b.M.af || b.M.Za)
                if (d = a.document.querySelector("a")) g = a.getComputedStyle(d).color;
            b.M.af && g && (f = g);
            L(l, {
                display: "inline",
                color: f,
                "font-family": "inherit",
                "font-weight": "inherit",
                "font-size": "inherit",
                "font-style": "inherit",
                background: "transparent",
                border: "none",
                "padding-left": "0",
                "padding-right": "0",
                "margin-top": "0",
                "margin-bottom": "0",
                "margin-inline-start": b.M.Za ? "0px" : "6px",
                "margin-inline-end": "0",
                cursor: "pointer"
            });
            b.M.Za && L(l, {
                "background-image": `linear-gradient(${e}, ${e})`,
                "border-radius": "20px",
                "padding-top": W(2),
                "padding-bottom": W(2),
                "padding-left": "",
                "padding-right": "",
                "box-shadow": `${b.V()?"-3px":"3px"} 0 0 0 ${e}`
            })
        } else L(l, {
            display: "inline-block",
            "border-radius": "20px",
            "padding-left": b.V() ? "7px" : "6px",
            "padding-right": b.V() ? "6px" : "7px",
            "padding-top": "3px",
            "padding-bottom": "3px",
            "border-width": "1px",
            "border-style": "solid",
            color: f,
            "font-family": "Roboto",
            "font-weight": "500",
            "font-size": d,
            "border-color": "#D7D7D7",
            background: e,
            cursor: "pointer",
            "margin-top": "-3px",
            height: "min-content"
        }), g && L(l, {
            margin: `${W(-3)} 0`,
            "padding-top": W(2),
            "padding-bottom": W(2)
        });
        l.tabIndex = 0;
        l.role = "link";
        l.ariaLabel = c;
        return l
    }

    function vC(a, b, c, d, e) {
        b = Iy(a, b, d);
        e ? L(b, {
            "vertical-align": "middle"
        }) : L(b, {
            position: "relative",
            top: "3px"
        });
        a = Ay(a, "span");
        L(a, {
            display: e ? "inline" : "inline-block",
            "padding-left": c.V() ? "" : e ? "0" : "3px",
            "padding-right": c.V() ? e ? "0" : "3px" : "",
            "white-space": e ? "nowrap" : ""
        });
        a.appendChild(b);
        return a
    }

    function wC(a, b, c, d) {
        var e = Ay(a, "span");
        e.appendChild(a.document.createTextNode(c));
        L(e, {
            "margin-left": b.V() ? "" : "3px",
            "margin-right": b.V() ? "3px" : "",
            "text-decoration": b.M.Za ? "" : "underline dotted",
            "-webkit-text-decoration": b.M.Za ? "" : "underline dotted",
            "padding-left": d && b.V() ? "6px" : "",
            "padding-right": d && !b.V() ? "6px" : ""
        });
        return e
    }

    function xC(a, b, c, d) {
        c = wy(c);
        d = xy(d);
        var e;
        if (e = d !== null) {
            e = c[0];
            var f = c[1],
                g = c[2];
            c = c[3];
            c === 1 ? a = [e, f, g] : (a = zy(a.document.body, b.M) ? ? [255, 255, 255], a = [Math.round(c * e + (1 - c) * a[0]), Math.round(c * f + (1 - c) * a[1]), Math.round(c * g + (1 - c) * a[2])]);
            e = uy(d, a) >= 3
        }
        return e
    };
    var yC = class {
        constructor() {
            this.g = []
        }
    };

    function zC(a, b) {
        return new AC(a, b)
    }

    function BC(a) {
        var b = CC(a);
        bb(a.floatingAdsStacking.maxZIndexListeners, c => c(b))
    }

    function CC(a) {
        a = Ok(a.floatingAdsStacking.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }

    function DC(a, b) {
        kb(a.floatingAdsStacking.maxZIndexListeners, c => c === b)
    }
    var EC = class {
        constructor(a) {
            this.floatingAdsStacking = bB(a).floatingAdsStacking
        }
    };

    function FC(a) {
        if (a.g == null) {
            var b = a.controller,
                c = a.Uc;
            let d = b.floatingAdsStacking.nextRestrictionId++;
            b.floatingAdsStacking.maxZIndexRestrictions[d] = c;
            BC(b);
            a.g = d
        }
    }

    function GC(a) {
        if (a.g != null) {
            var b = a.controller;
            delete b.floatingAdsStacking.maxZIndexRestrictions[a.g];
            BC(b);
            a.g = null
        }
    }
    var AC = class {
        constructor(a, b) {
            this.controller = a;
            this.Uc = b;
            this.g = null
        }
    };

    function HC(a) {
        a = a.activeElement;
        var b = a ? .shadowRoot;
        return b ? HC(b) || a : a
    }

    function IC(a, b) {
        return JC(b, a.document.body).flatMap(c => KC(c))
    }

    function JC(a, b) {
        var c = a;
        for (a = []; c && c !== b;) {
            a.push(c);
            let e;
            var d;
            (d = c.parentElement) || (c = c.getRootNode(), d = ((e = c.mode && c.host ? c : null) == null ? void 0 : e.host) || null);
            c = d
        }
        return c !== b ? [] : a
    }

    function KC(a) {
        var b = a.parentElement;
        return b ? Array.from(b.children).filter(c => c !== a) : []
    };

    function LC(a) {
        a.state !== null && (a.state.xl.forEach(b => {
            b.inert = !1
        }), a.state.Qm ? .focus(), a.state = null)
    }

    function MC(a, b) {
        LC(a);
        var c = HC(a.win.document);
        b = IC(a.win, b).filter(d => !d.inert);
        b.forEach(d => {
            d.inert = !0
        });
        a.state = {
            Qm: c,
            xl: b
        }
    }
    var NC = class {
        constructor(a) {
            this.win = a;
            this.state = null
        }
    };

    function OC(a) {
        return new PC(a, new Zs(a, a.document.body), new Zs(a, a.document.documentElement), new Zs(a, a.document.documentElement))
    }

    function QC(a) {
        Ys(a.l, "scroll-behavior", "auto");
        var b = RC(a.win);
        b.activePageScrollPreventers.add(a);
        b.previousWindowScroll === null && (b.previousWindowScroll = a.win.scrollY);
        Ys(a.g, "position", "fixed");
        Ys(a.g, "top", `${-b.previousWindowScroll}px`);
        Ys(a.g, "width", "100%");
        Ys(a.g, "overflow-x", "hidden");
        Ys(a.g, "overflow-y", "hidden");
        b = getComputedStyle(a.win.document.documentElement);
        SC(b.overflowX) && Ys(a.j, "overflow-x", "unset");
        SC(b.overflowY) && Ys(a.j, "overflow-y", "unset")
    }

    function SC(a) {
        return a === "scroll" || a === "auto"
    }

    function TC(a) {
        Xs(a.g);
        Xs(a.j);
        var b = RC(a.win);
        b.activePageScrollPreventers.delete(a);
        b.activePageScrollPreventers.size === 0 && (a.win.scrollTo(0, b.previousWindowScroll || 0), b.previousWindowScroll = null);
        Xs(a.l)
    }
    var PC = class {
        constructor(a, b, c, d) {
            this.win = a;
            this.g = b;
            this.j = c;
            this.l = d
        }
    };

    function RC(a) {
        return a.googPageScrollPreventerInfo = a.googPageScrollPreventerInfo || {
            previousWindowScroll: null,
            activePageScrollPreventers: new Set
        }
    }

    function UC(a) {
        return a.googPageScrollPreventerInfo && a.googPageScrollPreventerInfo.activePageScrollPreventers.size > 0 ? !0 : !1
    };

    function VC(a, b) {
        return WC(`#${a}`, b)
    }

    function XC(a, b) {
        return WC(`.${a}`, b)
    }

    function WC(a, b) {
        b = b.querySelector(a);
        if (!b) throw Error(`Element (${a}) does not exist`);
        return b
    };

    function YC(a, b) {
        var c = a.document.createElement("div");
        L(c, qy(a));
        a = c.attachShadow({
            mode: "open"
        });
        b && c.classList.add(b);
        return {
            xc: c,
            shadowRoot: a
        }
    };

    function ZC(a, b) {
        b = YC(a, b);
        a.document.body.appendChild(b.xc);
        return b
    }

    function $C(a, b) {
        var c = new O(b.X);
        ht(b, !0, () => void c.g(!0));
        ht(b, !1, () => {
            a.setTimeout(() => {
                b.X || c.g(!1)
            }, 700)
        });
        return ct(c)
    };

    function aD(a, b, c, d) {
        a = a && a.rb;
        return vx("<style" + (a ? ' nonce="' + S(Zx(a)) + '"' : "") + ">.drawer-close-button {float: " + T(d ? "left" : "right") + '; border: none; background: none; cursor: pointer;}</style><button id="' + S(b) + '" class="drawer-close-button" aria-label="' + S(c) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="#5f6368"><path d="M6.4 19 5 17.6 10.6 12 5 6.4 6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4Z"/></svg></button>')
    };

    function bD(a) {
        var b = {},
            c = a.kf,
            d = a.Vh,
            e = a.ff,
            f = a.Ic,
            g = a.Ei,
            h = a.zIndex;
        a = a.og;
        var k = b && b.rb;
        c = Rx(Ux(), "<style" + (k ? ' nonce="' + S(Zx(k)) + '"' : "") + ">#hd-drawer-container {position: fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + T(h) + "; pointer-events: none;}#hd-drawer-container.hd-revealed {pointer-events: auto;}#hd-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.hd-revealed > #hd-modal-background {opacity: 0.5;}#hd-drawer {position: absolute; top: 0; height: 100%; width: " +
            T(c) + "; background-color: white; display: flex; flex-direction: column; box-sizing: border-box; padding-bottom: ");
        d = d ? 20 : 0;
        Rx(Sx(Rx(c, T(d) + "px; transition: transform " + T(a) + "s ease-in-out;" + (e ? "left: 0; border-top-right-radius: " + T(d) + "px; border-bottom-right-radius: " + T(d) + "px; transform: translateX(-100%);" : "right: 0; border-top-left-radius: " + T(d) + "px; border-bottom-left-radius: " + T(d) + "px; transform: translateX(100%);") + "}.hd-revealed > #hd-drawer {transform: translateY(0);}#hd-control-bar {height: 24px;}.hd-control-button {border: none; background: none; cursor: pointer;}#hd-back-arrow-button {" +
            (e ? "float: right;" : "float: left;") + '}#hd-content-container {flex-grow: 1; overflow: auto;}#hd-content-container::-webkit-scrollbar * {background: transparent;}.hd-hidden {visibility: hidden;}</style><div id="hd-drawer-container" class="hd-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="hd-modal-background"></div><div id="hd-drawer"><div id="hd-control-bar"><button id="hd-back-arrow-button" class="hd-control-button hd-hidden" aria-label="' + S(g) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' +
            S("#5f6368") + '"><path d="m12 20-8-8 8-8 1.425 1.4-5.6 5.6H20v2H7.825l5.6 5.6Z"/></svg></button>'), aD(b, "hd-close-button", f, e)), '</div><div id="hd-content-container"></div></div></div>');
        return c
    };

    function cD(a) {
        a = a.top;
        if (!a) return null;
        try {
            var b = a.history
        } catch (c) {
            b = null
        }
        b = b && sc(b.pushState) ? b : null;
        if (!b) return null;
        if (a.googNavStack) return a.googNavStack;
        b = new dD(a, b);
        b.init();
        return b ? a.googNavStack = b : null
    }

    function eD(a, b) {
        return b ? b.googNavStackId === a.g ? b : null : null
    }

    function fD(a, b) {
        for (let c = b.length - 1; c >= 0; --c) {
            let d = c === 0;
            a.K.requestAnimationFrame(() => void b[c].en({
                isFinal: d
            }))
        }
    }

    function gD(a, b) {
        b = pb(a.stack, b, (c, d) => c - d.gj.googNavStackStateId);
        if (b >= 0) return a.stack.splice(b, a.stack.length - b);
        b = -b - 1;
        return a.stack.splice(b, a.stack.length - b)
    }
    class dD extends Gs {
        constructor(a, b) {
            super();
            this.K = a;
            this.history = b;
            this.stack = [];
            this.g = Math.random() * 1E9 >>> 0;
            this.B = 0;
            this.l = c => {
                (c = eD(this, c.state)) ? fD(this, gD(this, c.googNavStackStateId + .5)): fD(this, this.stack.splice(0, this.stack.length))
            }
        }
        pushEvent() {
            var a = {
                    googNavStackId: this.g,
                    googNavStackStateId: this.B++
                },
                b = new Promise(c => {
                    this.stack.push({
                        en: c,
                        gj: a
                    })
                });
            this.history.pushState(a, "");
            return {
                navigatedBack: b,
                triggerNavigateBack: () => {
                    var c = gD(this, a.googNavStackStateId),
                        d;
                    if (d = c.length > 0) {
                        d = c[0].gj;
                        let e = eD(this, this.history.state);
                        d = e && e.googNavStackId === d.googNavStackId && e.googNavStackStateId === d.googNavStackStateId
                    }
                    d && this.history.go(-c.length);
                    fD(this, c)
                }
            }
        }
        init() {
            this.K.addEventListener("popstate", this.l)
        }
        j() {
            this.K.removeEventListener("popstate", this.l);
            super.j()
        }
    };

    function hD(a) {
        return (a = cD(a)) ? new iD(a) : null
    }

    function jD(a) {
        if (!a.g) {
            var {
                navigatedBack: b,
                triggerNavigateBack: c
            } = a.B.pushEvent();
            a.g = c;
            b.then(() => {
                a.g && !a.A && (a.g = null, mt(a.l))
            })
        }
    }
    var iD = class extends Gs {
        constructor(a) {
            super();
            this.B = a;
            this.l = new nt;
            this.g = null
        }
    };

    function kD(a, b, c) {
        var d = new NC(a),
            e = zC(new EC(a), c.zIndex - 1);
        b = lD(a, b, c);
        d = new mD(a, b, d, OC(a), e);
        d.init();
        (c.Ti || c.Ti === void 0) && nD(d);
        c.de && ((a = hD(a)) ? oD(d, a, c.Gh) : c.Gh ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function nD(a) {
        a.C = b => {
            b.key === "Escape" && a.g.X && a.collapse()
        };
        a.win.document.body.addEventListener("keydown", a.C)
    }

    function oD(a, b, c) {
        ht(a.g, !0, () => {
            try {
                jD(b)
            } catch (d) {
                c ? .(d)
            }
        });
        ht(a.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        kt(b.l).listen(() => void a.collapse());
        Hs(a, b)
    }

    function pD(a) {
        if (a.A) throw Error("Accessing domItems after disposal");
        return a.D
    }

    function qD(a) {
        a.win.setTimeout(() => {
            a.g.X && pD(a).yb.focus()
        }, 500)
    }

    function rD(a) {
        var {
            Eh: b,
            Zk: c
        } = pD(a);
        b.addEventListener("click", () => void a.collapse());
        c.addEventListener("click", () => void a.collapse())
    }

    function sD(a) {
        ht(a.l, !1, () => {
            pD(a).yb.classList.add("hd-hidden")
        })
    }
    var mD = class extends Gs {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.D = b;
            this.B = c;
            this.g = new O(!1);
            this.l = $C(a, this.g);
            ht(this.l, !0, () => {
                QC(d);
                FC(e)
            });
            ht(this.l, !1, () => {
                TC(d);
                GC(e)
            })
        }
        show({
            Qi: a = !1
        } = {}) {
            if (this.A) throw Error("Cannot show drawer after disposal");
            pD(this).yb.classList.remove("hd-hidden");
            Es(this.win);
            pD(this).yb.classList.add("hd-revealed");
            this.g.g(!0);
            MC(this.B, pD(this).yc.xc);
            qD(this);
            a && ht(this.l, !1, () => {
                this.dispose()
            })
        }
        collapse() {
            pD(this).yb.classList.remove("hd-revealed");
            this.g.g(!1);
            LC(this.B)
        }
        isVisible() {
            return this.l
        }
        init() {
            rD(this);
            sD(this)
        }
        j() {
            this.C && this.win.document.body.removeEventListener("keydown", this.C);
            var a = this.D.yc.xc,
                b = a.parentNode;
            b && b.removeChild(a);
            LC(this.B);
            super.j()
        }
    };

    function lD(a, b, c) {
        var d = ZC(a, c.Ig),
            e = d.shadowRoot;
        e.appendChild(Kj(new qj(a.document), bD({
            kf: c.kf,
            Vh: c.Vh ? ? !0,
            ff: c.ff || !1,
            Ic: c.Ic,
            Ei: c.Ei || "",
            zIndex: c.zIndex,
            og: .5
        }).Fb()));
        var f = VC("hd-drawer-container", e);
        c.Kg ? .j(g => {
            f.setAttribute("aria-label", g)
        });
        c = VC("hd-content-container", e);
        c.appendChild(b);
        Es(a);
        return {
            yb: f,
            Eh: VC("hd-modal-background", e),
            yg: c,
            content: b,
            Zk: VC("hd-close-button", e),
            Zo: VC("hd-back-arrow-button", e),
            yc: d
        }
    };

    function tD(a) {
        var b = {},
            c = a.Lm,
            d = a.Ml,
            e = a.zIndex,
            f = a.og,
            g = a.Ye,
            h = a.V;
        a = a.Ic;
        var k = b && b.rb;
        return Rx(Sx(Sx(Rx(Sx(Sx(Rx(Ux(), "<style" + (k ? ' nonce="' + S(Zx(k)) + '"' : "") + ">#ved-drawer-container {position:  fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + T(e) + "; pointer-events: none;}#ved-drawer-container.ved-revealed {pointer-events: auto;}#ved-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.ved-revealed > #ved-modal-background {opacity: 0.5;}#ved-ui-revealer {position: absolute; left: 0; bottom: 0; width: 100%; height: " +
                T(d) + "%; transition: transform " + T(f) + "s ease-in-out; transform: translateY(100%);}#ved-ui-revealer.ved-no-animation {transition-property: none;}.ved-revealed > #ved-ui-revealer {transform: translateY(0);}#ved-scroller-container {position: absolute; left: 0; bottom: 0; width: 100%; height: 100%; clip-path: inset(0 0 -50px 0 round " + T(20) + "px);}#ved-scroller {position: relative; width: 100%; height: 100%; overflow-y: scroll; -ms-overflow-style: none; scrollbar-width: none; overflow-y: scroll; overscroll-behavior: none; scroll-snap-type: y mandatory;}#ved-scroller.ved-scrolling-paused {overflow: hidden;}#ved-scroller.ved-no-snap {scroll-snap-type: none;}#ved-scroller::-webkit-scrollbar {display: none;}#ved-scrolled-stack {width: 100%; height: 100%; overflow: visible;}#ved-scrolled-stack.ved-with-background {background-color: white;}.ved-snap-point-top {scroll-snap-align: start;}.ved-snap-point-bottom {scroll-snap-align: end;}#ved-fully-closed-anchor {height: " +
                T(c / d * 100) + "%;}.ved-with-background #ved-fully-closed-anchor {background-color: white;}#ved-partially-extended-anchor {height: " + T((d - c) / d * 100) + "%;}.ved-with-background #ved-partially-extended-anchor {background-color: white;}#ved-moving-handle-holder {scroll-snap-stop: always;}.ved-with-background #ved-moving-handle-holder {background-color: white;}#ved-fixed-handle-holder {position: absolute; left: 0; top: 0; width: 100%;}#ved-visible-scrolled-items {display: flex; flex-direction: column; min-height: " +
                T(c / d * 100) + "%;}#ved-content-background {width: 100%; flex-grow: 1; padding-top: 1px; margin-top: -1px; background-color: white;}#ved-content-sizer {overflow: hidden; width: 100%; height: 100%;}#ved-content-container {width: 100%;}#ved-over-scroll-block {display: flex; flex-direction: column; position: absolute; bottom: 0; left: 0; width: 100%; height: " + T(c / d * 100) + "%; pointer-events: none;}#ved-over-scroll-handle-spacer {height: " + T(80) + "px;}#ved-over-scroll-background {flex-grow: 1; background-color: white;}.ved-handle {align-items: flex-end; border-radius: " +
                T(20) + "px " + T(20) + "px 0 0; background: white; display: flex; height: " + T(30) + 'px; justify-content: center; cursor: grab;}.ved-handle-icon {background: #dadce0; width: 50px; border-radius: 2px; height: 4px; margin-bottom: 8px;}.ved-hidden {visibility: hidden;}#ved-moving-close-button, #ved-fixed-close-button {margin-top: -29px;}</style><div id="ved-drawer-container" class="ved-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="ved-modal-background"></div><div id="ved-ui-revealer"><div id="ved-over-scroll-block" class="ved-hidden"><div id=\'ved-over-scroll-handle-spacer\'></div><div id=\'ved-over-scroll-background\'></div></div><div id="ved-scroller-container"><div id="ved-scroller"><div id="ved-scrolled-stack"><div id="ved-fully-closed-anchor" class="ved-snap-point-top"></div><div id="ved-partially-extended-anchor" class="ved-snap-point-top"></div><div id="ved-visible-scrolled-items"><div id="ved-moving-handle-holder" class="ved-snap-point-top">'),
            uD("ved-moving-handle")), g ? aD(b, "ved-moving-close-button", a, h) : ""), '</div><div id="ved-content-background"><div id="ved-content-sizer" class="ved-snap-point-bottom"><div id="ved-content-container"></div></div></div></div></div></div></div><div id="ved-fixed-handle-holder" class="ved-hidden">'), uD("ved-fixed-handle")), g ? aD(b, "ved-fixed-close-button", a, h) : ""), "</div></div></div>")
    }

    function uD(a) {
        return vx('<div class="ved-handle" id="' + S(a) + '"><div class="ved-handle-icon"></div></div>')
    };

    function vD(a) {
        return Bt(a.g).map(b => b ? wD(a, b) : 0)
    }

    function wD(a, b) {
        switch (a.direction) {
            case 0:
                return xD(-b.gk);
            case 1:
                return xD(-b.fk);
            default:
                throw Error(`Unhandled direction: ${a.direction}`);
        }
    }

    function yD(a) {
        return Dt(a.g).map(b => wD(a, b))
    }
    var zD = class {
        constructor(a) {
            this.g = a;
            this.direction = 0
        }
    };

    function xD(a) {
        return a === 0 ? 0 : a
    };

    function AD(a) {
        if (a.A) throw Error("Accessing domItems after disposal");
        return a.D
    }

    function BD(a) {
        a.win.setTimeout(() => {
            a.g.X && AD(a).yb.focus()
        }, 500)
    }

    function CD(a) {
        AD(a).yb.classList.remove("ved-hidden");
        Es(a.win);
        var {
            Sa: b,
            tc: c
        } = AD(a);
        c.getBoundingClientRect().top <= b.getBoundingClientRect().top || DD(a);
        AD(a).yb.classList.add("ved-revealed");
        a.g.g(!0);
        MC(a.B, AD(a).yc.xc);
        BD(a)
    }

    function ED(a, b) {
        var c = new O(b());
        kt(a.J).listen(() => void c.g(b()));
        return ct(c)
    }

    function FD(a) {
        var {
            Sa: b,
            Gf: c
        } = AD(a);
        return ED(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function GD(a) {
        var {
            Sa: b,
            Gf: c
        } = AD(a);
        return ED(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top - 1)
    }

    function HD(a) {
        var {
            Sa: b
        } = AD(a);
        return ED(a, () => b.scrollTop === b.scrollHeight - b.clientHeight)
    }

    function ID(a) {
        return dt(FD(a), HD(a))
    }

    function JD(a) {
        var {
            Sa: b,
            tc: c
        } = AD(a);
        return ED(a, () => c.getBoundingClientRect().top < b.getBoundingClientRect().top - 1)
    }

    function DD(a) {
        AD(a).tc.classList.add("ved-snap-point-top");
        var b = KD(a, AD(a).tc);
        AD(a).Sa.scrollTop = b;
        LD(a)
    }

    function MD(a) {
        ft(FD(a), !0, () => {
            var {
                Yi: b,
                Be: c
            } = AD(a);
            b.classList.remove("ved-hidden");
            c.classList.add("ved-with-background")
        });
        ft(FD(a), !1, () => {
            var {
                Yi: b,
                Be: c
            } = AD(a);
            b.classList.add("ved-hidden");
            c.classList.remove("ved-with-background")
        })
    }

    function ND(a) {
        var b = Ft(a.win, AD(a).yg);
        It(b).j(() => void OD(a));
        Hs(a, b)
    }

    function PD(a) {
        ft(QD(a), !0, () => {
            AD(a).Cj.classList.remove("ved-hidden")
        });
        ft(QD(a), !1, () => {
            AD(a).Cj.classList.add("ved-hidden")
        })
    }

    function RD(a) {
        var b = () => void mt(a.G),
            {
                Eh: c,
                tc: d,
                Ll: e,
                ym: f,
                Il: g
            } = AD(a);
        c.addEventListener("click", b);
        d.addEventListener("click", b);
        e.addEventListener("click", b);
        f && f.addEventListener("click", b);
        g && g.addEventListener("click", b);
        ht(SD(a), !0, b)
    }

    function TD(a) {
        ht(a.isDrawerVisible(), !1, () => {
            DD(a);
            AD(a).yb.classList.add("ved-hidden")
        })
    }

    function LD(a) {
        gt(a.l, !1, () => void mt(a.J))
    }

    function OD(a) {
        if (!a.l.X) {
            var {
                Mi: b,
                yg: c
            } = AD(a), d = c.getBoundingClientRect().height;
            d = Math.max(UD(a), d);
            a.l.g(!0);
            var e = VD(a);
            b.style.setProperty("height", `${d}px`);
            e();
            a.win.requestAnimationFrame(() => {
                a.win.requestAnimationFrame(() => {
                    a.l.g(!1)
                })
            })
        }
    }

    function QD(a) {
        var {
            Sa: b,
            tc: c
        } = AD(a);
        return ED(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function SD(a) {
        return bt(a.C.map(ku), WD(a))
    }

    function WD(a) {
        return ED(a, () => AD(a).Sa.scrollTop === 0)
    }

    function KD(a, b) {
        ({
            Be: a
        } = AD(a));
        a = a.getBoundingClientRect().top;
        return b.getBoundingClientRect().top - a
    }

    function XD(a, b) {
        a.C.g(!0);
        var {
            Be: c,
            Sa: d
        } = AD(a);
        d.scrollTop = 0;
        d.classList.add("ved-scrolling-paused");
        c.style.setProperty("margin-top", `-${b}px`);
        return () => void YD(a, b)
    }

    function YD(a, b) {
        var {
            Be: c,
            Sa: d
        } = AD(a);
        c.style.removeProperty("margin-top");
        d.classList.remove("ved-scrolling-paused");
        AD(a).Sa.scrollTop = b;
        LD(a);
        a.C.g(!1)
    }

    function VD(a) {
        var b = AD(a).Sa.scrollTop;
        XD(a, b);
        return () => void YD(a, b)
    }

    function UD(a) {
        var {
            Sa: b,
            Gf: c,
            Mi: d,
            tc: e
        } = AD(a);
        a = b.getBoundingClientRect();
        var f = c.getBoundingClientRect(),
            g = d.getBoundingClientRect(),
            h = e.getBoundingClientRect();
        g = g.top - f.top;
        return Math.max(a.height - h.height - g, Math.min(a.height, a.bottom - f.top) - g)
    }
    var ZD = class extends Gs {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.D = b;
            this.T = c;
            this.B = d;
            this.G = new nt;
            this.J = new nt;
            this.g = new O(!1);
            this.C = new O(!1);
            this.l = new O(!1)
        }
        isDrawerVisible() {
            return $C(this.win, this.g)
        }
        init() {
            DD(this);
            MD(this);
            ND(this);
            PD(this);
            RD(this);
            TD(this);
            AD(this).Sa.addEventListener("scroll", () => void LD(this))
        }
        j() {
            var a = this.D.yc.xc,
                b = a.parentNode;
            b && b.removeChild(a);
            LC(this.B);
            super.j()
        }
    };

    function $D(a, b, c) {
        var d = ZC(a, c.Ig),
            e = d.shadowRoot;
        e.appendChild(Kj(new qj(a.document), tD({
            Lm: c.Fj * 100,
            Ml: c.Zi * 100,
            zIndex: c.zIndex,
            og: .5,
            Ye: c.Ye ? ? !1,
            V: c.V || !1,
            Ic: c.Ic || ""
        }).Fb()));
        var f = VC("ved-drawer-container", e);
        c.Kg ? .j(h => {
            f.setAttribute("aria-label", h)
        });
        var g = VC("ved-content-container", e);
        g.appendChild(b);
        Es(a);
        return {
            yb: f,
            Eh: VC("ved-modal-background", e),
            bk: VC("ved-ui-revealer", e),
            Sa: VC("ved-scroller", e),
            Be: VC("ved-scrolled-stack", e),
            Ll: VC("ved-fully-closed-anchor", e),
            tc: VC("ved-partially-extended-anchor",
                e),
            Mi: VC("ved-content-sizer", e),
            yg: g,
            ym: c.Ye ? VC("ved-moving-close-button", e) : void 0,
            ip: VC("ved-moving-handle", e),
            Gf: VC("ved-moving-handle-holder", e),
            Il: c.Ye ? VC("ved-fixed-close-button", e) : void 0,
            Jl: VC("ved-fixed-handle", e),
            Yi: VC("ved-fixed-handle-holder", e),
            Cj: VC("ved-over-scroll-block", e),
            yc: d
        }
    };

    function aE(a, b, c) {
        var d = zC(new EC(a), c.zIndex - 1);
        b = $D(a, b, c);
        var e = new NC(a);
        var f = b.Jl;
        f = new Et(new vt(a, f), new st(f));
        var g = f.g;
        g.B.addEventListener("mousedown", g.O);
        g.A.addEventListener("mouseup", g.C);
        g.A.addEventListener("mousemove", g.D, {
            passive: !1
        });
        g = f.j;
        g.j.addEventListener("touchstart", g.D);
        g.j.addEventListener("touchend", g.B);
        g.j.addEventListener("touchmove", g.C, {
            passive: !1
        });
        b = new ZD(a, b, new zD(f), e);
        b.init();
        d = new bE(a, b, OC(a), d);
        Hs(d, b);
        d.init();
        c.de && ((a = hD(a)) ? cE(d, a, c.Gh) : c.Gh ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function cE(a, b, c) {
        ht(a.g.g, !0, () => {
            try {
                jD(b)
            } catch (d) {
                c ? .(d)
            }
        });
        ht(a.g.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        kt(b.l).listen(() => void a.collapse());
        Hs(a, b)
    }

    function dE(a) {
        ht(bt(ID(a.g), JD(a.g)), !0, () => {
            AD(a.g).tc.classList.remove("ved-snap-point-top")
        });
        ft(GD(a.g), !0, () => {
            AD(a.g).Sa.classList.add("ved-no-snap")
        });
        ft(GD(a.g), !1, () => {
            AD(a.g).Sa.classList.remove("ved-no-snap")
        });
        ht(GD(a.g), !1, () => {
            var b = a.g;
            var c = AD(b).Gf;
            c = XD(b, KD(b, c));
            b.win.setTimeout(c, 100)
        })
    }

    function eE(a) {
        var b = a.g.T;
        vD(b).listen(c => {
            c = -c;
            if (c > 0) {
                let {
                    bk: d
                } = AD(a.g);
                d.classList.add("ved-no-animation");
                d.style.setProperty("transform", `translateY(${c}px)`)
            } else({
                bk: c
            } = AD(a.g)), c.classList.remove("ved-no-animation"), c.style.removeProperty("transform")
        });
        yD(b).listen(c => {
            -c > 30 && a.collapse()
        })
    }
    var bE = class extends Gs {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.g = b;
            ht(b.isDrawerVisible(), !0, () => {
                QC(c);
                FC(d)
            });
            ht(b.isDrawerVisible(), !1, () => {
                TC(c);
                GC(d)
            })
        }
        show({
            Qi: a = !1
        } = {}) {
            if (this.A) throw Error("Cannot show drawer after disposal");
            CD(this.g);
            a && ht(this.g.isDrawerVisible(), !1, () => {
                this.dispose()
            })
        }
        collapse() {
            var a = this.g;
            AD(a).yb.classList.remove("ved-revealed");
            a.g.g(!1);
            LC(a.B)
        }
        isVisible() {
            return this.g.isDrawerVisible()
        }
        init() {
            kt(this.g.G).listen(() => {
                this.collapse()
            });
            dE(this);
            eE(this);
            Es(this.win)
        }
    };

    function fE(a) {
        a.config.Wb(1065, a.win, () => {
            if (!a.g) {
                var b = (new Mp).setClickPageEventIndex(a.j);
                var c = new Kp;
                b = z(b, 2, Np, c);
                a.config.g.ve(b)
            }
        }, 1E4)
    }
    class gE {
        constructor(a, b, c) {
            this.win = a;
            this.config = b;
            this.j = c;
            this.g = !1
        }
        dismiss() {
            this.g = !0
        }
        cancel(a) {
            this.win.clearTimeout(a)
        }
    }

    function bC(a, b, c) {
        var d = b.ka ? a.innerWidth : Math.min(a.document.body.clientWidth, 670);
        a = Gy(b.ka, a);
        var e = new zp;
        d = uf(e, 1, d);
        d = uf(d, 2, a);
        b.Lc.Ij ? .(d, b.l.get(c));
        return d
    }

    function cC(a, b) {
        b = b.oa(14);
        if (b < a.j + 1500 && a.j !== 0) return !1;
        a.j = b;
        return !0
    }

    function dC(a, b, c, d, e, f, g, h = !1, k = !1) {
        a.l();
        return new Promise(l => {
            var m = gt(a.g, !1, () => void l(hE(a, b, c, d, e, f, g, h, k)));
            a.l = () => {
                m();
                l(null)
            }
        })
    }

    function hE(a, b, c, d, e, f, g, h, k = !1) {
        var l = ka(Promise, "withResolvers").call(Promise);
        l.promise.then(() => {
            var p = c.g,
                q = p.ve;
            var u = (new Mp).setClickPageEventIndex(d);
            var A = new Lp;
            u = z(u, 4, Np, A);
            q.call(p, u)
        });
        var m = c.ka ? b.innerWidth : Math.min(b.document.body.clientWidth, 670);
        f = c.Lc.tg({
            win: b,
            searchTerm: e,
            rsToken: f,
            M: c.M,
            ka: c.ka,
            V: c.V(),
            R: c.R,
            pd: m,
            Kc: Gy(c.ka, b),
            Ne: c.Ne.bind(c),
            Wb: c.Wb.bind(c),
            Xh: c.Xh.bind(c),
            va: c.va.bind(c),
            Xc: p => void a.Xc(p),
            format: g,
            Oj: h,
            content: c.l.get(e),
            oc: l.resolve,
            Sf: k
        });
        m = c.ka ? aE(b,
            f, {
                Fj: .95,
                Zi: .95,
                zIndex: 2147483647,
                de: !0,
                Ig: "adpub-drawer-root",
                Kg: new O(oz(c.R, e))
            }) : iE(b, c, e, m, f);
        ht(m.isVisible(), !1, () => {
            var p = a.A;
            for (let q of p.g) q();
            p.g.length = 0;
            a.g.g(!1);
            p = bB(b).adIntentsPageState;
            p.isDrawerVisible = !1;
            c.M.Og && eC(c, e) && p.notifyDrawerCollapsed()
        });
        m.show({
            Qi: !0
        });
        a.g.g(!0);
        bB(b).adIntentsPageState.isDrawerVisible = !0;
        var n = new gE(b, c, d);
        fE(n);
        a.Xc(() => {
            var p = c.g,
                q = p.ve;
            var u = (new Mp).setClickPageEventIndex(d);
            var A = new Jp;
            u = z(u, 3, Np, A);
            q.call(p, u);
            n.dismiss()
        });
        return m
    }

    function iE(a, b, c, d, e) {
        return kD(a, e, {
            kf: `${d}px`,
            ff: b.V(),
            Ic: C(b.R, 14),
            zIndex: 2147483647,
            de: !0,
            Ti: !0,
            Ig: "adpub-drawer-root",
            Kg: new O(oz(b.R, c))
        })
    }
    var jE = class {
        constructor() {
            this.g = new O(!1);
            this.A = new yC;
            this.l = () => {};
            this.j = 0
        }
        isDrawerVisible() {
            return this.g.X
        }
        Xc(a) {
            this.A.g.push(a)
        }
    };
    const kE = ["BTN", "BUTTON", "LINK"],
        mE = lE("banner cc cookie dialog gdpr modal notice notification pop-up popup privacy prompt slidedown-container sticky stky".split(" ")),
        nE = lE("accept acknowledge allow close consent deny dismiss ok opt-in opt-out reject".split(" "));

    function lE(a) {
        return new RegExp(`(?:^|[_-\\s])${a.join("|(?:^|[_-\\s])")}`, "i")
    }

    function oE(a, b) {
        if (a.classList ? .contains("google-anno-skip")) return !1;
        switch (a.tagName ? .toUpperCase ? .()) {
            case "IFRAME":
            case "A":
            case "AUDIO":
            case "BUTTON":
            case "CANVAS":
            case "CITE":
            case "CODE":
            case "EMBED":
            case "FOOTER":
            case "FORM":
            case "IMG":
            case "KBD":
            case "LABEL":
            case "MENU":
            case "OBJECT":
            case "PRE":
            case "SAMP":
            case "SCRIPT":
            case "SELECT":
            case "STYLE":
            case "SUB":
            case "SUPER":
            case "SVG":
            case "TEXTAREA":
            case "TIME":
            case "VAR":
            case "VIDEO":
            case null:
            case void 0:
                return !1;
            case "BODY":
                return !0
        }
        return !(pE(a).includes("CRUMB") &&
            a.offsetHeight <= 50) && !qE(a, b) && !rE(a) && !pE(a).includes("MENU") && !(a.tabIndex >= 0) && b.getComputedStyle(a).transform === "none" && !a.classList ? .contains("adsbygoogle")
    }

    function qE(a, b) {
        return a.role ? .toUpperCase ? .() === "BUTTON" || a.tagName ? .toUpperCase ? .() === "INPUT" && a.getAttribute("type") ? .toUpperCase ? .() === "BUTTON" || kE.some(c => pE(a).includes(c)) || b.getComputedStyle(a).cursor === "pointer" || a.childNodes.length === 1 && jB()(a.firstElementChild)
    }

    function sE(a, b, c) {
        var d = a.getBoundingClientRect();
        d = c.document.elementsFromPoint(d.x + d.width / 2, d.y + d.height / 2);
        for (let e of d)
            if (a.contains(e)) break;
            else if (tE(e, b, c)) return !0;
        return !1
    }

    function uE(a, b, c) {
        var d = a.getClientRects();
        if (!d.length) return !1;
        var e = !1;
        for (let f of d) {
            d = c.document.elementsFromPoint(f.x + f.width / 2, f.y + f.height / 2);
            let g = !1;
            for (let h of d)
                if (a.contains(h)) {
                    g = !0;
                    break
                } else if (tE(h, b, c)) {
                e = !0;
                g = !1;
                break
            }
            if (g) return !1
        }
        return e
    }

    function tE(a, b, c) {
        return !(a.closest(".adsbygoogle") || a.closest("#google-anno-sa") || vE(a, b, c))
    }

    function vE(a, b, c) {
        return rE(a) || c.getComputedStyle(a).position === "fixed" ? !0 : !!a.parentElement && a.parentElement.tagName !== "BODY" && vE(a.parentElement, b, c)
    }

    function rE(a) {
        var b = a.getAttribute("id") ? ? "";
        return b.match ? .(mE) || a.className ? .match ? .(mE) || a.ariaLabel ? .match ? .(mE) || a.role ? .toUpperCase ? .() === "DIALOG" || (a.tagName === "A" || a.tagName === "BUTTON") && (b.match ? .(nE) || a.className ? .match ? .(nE) || a.ariaLabel ? .match ? .(nE)) ? !0 : !1
    }

    function wE(a) {
        var b = a.textContent;
        if (!b) return !1;
        switch (a.tagName ? .toUpperCase ? .()) {
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "HEADER":
            case "HGROUP":
            case "TH":
            case "THEAD":
                return !0;
            case "LI":
            case "OL":
            case "TD":
            case "TR":
            case "UL":
                return !1
        }
        a: {
            for (a = 0; a < b.length; a++) {
                let c = b.charAt(a);
                if ((a === 0 || b.charAt(a - 1) === " ") && c.toLowerCase() === c) {
                    b = !1;
                    break a
                }
            }
            b = !0
        }
        return b
    }

    function pE(a) {
        return (a.id ? .toUpperCase ? .() ? ? "") + "," + (a.className ? .toUpperCase ? .() ? ? "")
    };

    function xE(a, b, c, d) {
        b = b.getBoundingClientRect();
        a = rp(qp(pp(new af, a), 3), c);
        a = uf(a, 6, Math.round(b.x));
        b = uf(a, 7, Math.round(b.y));
        return sp(b, d)
    }

    function yE(a, b, c) {
        return sp(rp(qp(pp(new af, a), 4), b), c)
    }

    function zE(a, b, c) {
        return sp(rp(qp(pp(new af, a), 5), b), c)
    }

    function AE(a) {
        a = wy(a);
        var b = new np;
        b = uf(b, 1, a[0]);
        b = uf(b, 2, a[1]);
        b = uf(b, 3, a[2]);
        return Oe(b, 4, Xc(a[3]), 0)
    };
    const BE = /[\s!'",:;\\(\\)\\?\\.\u00bf\u00a1\u30a0\uff1d\u037e\u061f\u3002\uff1f\uff1b\uff1a\u2014\u2014\uff5e\u300a\u300b\u3008\u3009\uff08\uff09\u300c\u300d\u3001\u00b7\u2026\u2025\uff01\uff0c\u00b7\u2019\u060c\u061b\u060d\u06d4\u0648]/;

    function CE(a, b) {
        switch (b) {
            case 1:
                return !0;
            default:
                return a === "" || BE.test(a)
        }
    };

    function DE(a, b) {
        var c = new EE(b);
        for (let d of a) C(d, 5) && Ee(d, 3, Gd, w()).forEach(e => {
            FE(c, e, ex(d))
        });
        GE(c);
        return new HE(c)
    }

    function IE(a, b) {
        b = a.match(b);
        a = new Map;
        for (let c of b)
            if (b = c.g, a.has(b)) {
                let d = a.get(b);
                c.length > d.length && a.set(b, c)
            } else a.set(b, c);
        return [...a.values()]
    }
    var HE = class {
        constructor(a) {
            this.g = a
        }
        isEmpty() {
            return this.g.isEmpty()
        }
        match(a) {
            return this.g.match(a)
        }
    };

    function FE(a, b, c) {
        var d = a.j.has(c) ? a.j.get(c) : a.A++;
        a.j.set(c, d);
        a.B.set(d, c);
        c = 0;
        for (let e = 0; e < b.length; e++) {
            let f = b.charCodeAt(e);
            a.g[c].contains(f) || (a.g.push(new JE), a.g[a.size].B = c, a.g[a.size].D = f, a.g[c].l.set(f, a.size), a.size++);
            c = a.g[c].l.get(f)
        }
        a.g[c].A = !0;
        a.g[c].C = d;
        a.g[c].O = a.l.length;
        a.l.push(b.length)
    }

    function GE(a) {
        var b = [];
        for (b.push(0); b.length > 0;) {
            let f = b.shift();
            var c = a,
                d = c.g[f];
            if (f === 0) d.g = 0, d.j = 0;
            else if (d.B === 0) d.g = 0, d.j = d.A ? f : c.g[c.g[f].g].j;
            else {
                d = c.g[c.g[f].B].g;
                for (var e = c.g[f].D;;) {
                    if (c.g[d].contains(e)) {
                        c.g[f].g = c.g[d].l.get(e);
                        break
                    }
                    if (d === 0) {
                        c.g[f].g = 0;
                        break
                    }
                    d = c.g[d].g
                }
                c.g[f].j = c.g[f].A ? f : c.g[c.g[f].g].j
            }
            for (let g of a.g[f].Gb) b.push(g)
        }
    }
    class EE {
        constructor(a) {
            this.C = a;
            this.size = 1;
            this.g = [new JE];
            this.l = [];
            this.j = new Map;
            this.B = new Map;
            this.A = 0
        }
        isEmpty() {
            return this.A === 0
        }
        match(a) {
            var b = 0,
                c = [];
            for (let g = 0; g < a.length; g++) {
                for (;;) {
                    var d = a.charCodeAt(g),
                        e = this.g[b];
                    if (e.contains(d)) {
                        b = e.l.get(d);
                        break
                    }
                    if (b === 0) break;
                    b = e.g
                }
                let h = b;
                for (;;) {
                    h = this.g[h].j;
                    if (h === 0) break;
                    let k = g + 1 - this.l[this.g[h].O],
                        l = g;
                    d = a;
                    e = l;
                    var f = this.C;
                    CE(d.charAt(k - 1), f) && CE(d.charAt(e + 1), f) && c.push(new KE(k, l, this.B.get(this.g[h].C)));
                    h = this.g[h].g
                }
            }
            return c
        }
    }
    class JE {
        constructor() {
            this.l = new Map;
            this.T = !1;
            this.Aa = this.J = this.G = this.pa = this.W = this.Z = -1
        }
        contains(a) {
            return this.l.has(a)
        }
        set B(a) {
            this.Z = a
        }
        get B() {
            return this.Z
        }
        set D(a) {
            this.W = a
        }
        get D() {
            return this.W
        }
        set A(a) {
            this.T = a
        }
        get A() {
            return this.T
        }
        set C(a) {
            this.J = a
        }
        get C() {
            return this.J
        }
        set g(a) {
            this.pa = a
        }
        get g() {
            return this.pa
        }
        set j(a) {
            this.G = a
        }
        get j() {
            return this.G
        }
        set O(a) {
            this.Aa = a
        }
        get O() {
            return this.Aa
        }
        get Gb() {
            return this.l.values()
        }
    }
    var KE = class {
        constructor(a, b, c) {
            this.g = a;
            this.j = b;
            this.searchTerm = c
        }
        get length() {
            return this.j - this.g
        }
    };
    const LE = "A B EM I LI S SPAN STRONG U".split(" ");
    async function ME(a, b, c, d, e, f, g) {
        var h = DE(gx(b.R), b.j);
        h.isEmpty() || await NE(a, a.document.body, b, h, new Set, c, d, e, new rC(0, 0, 0, 100, 2 * a.innerHeight), new OE(a.innerHeight * .6), f, g)
    }
    async function NE(a, b, c, d, e, f, g, h, k, l, m, n) {
        f.g.oa(9) >= f.j && await PE(f, 10);
        if (b.nodeType === Node.TEXT_NODE) IE(d, b.textContent ? ? "").forEach(p => void e.add(p.searchTerm));
        else if (iB(b))
            if (PF(b, a)) {
                for (let p of b.childNodes) await NE(a, p, c, d, e, f, g, h, k, l, m, n);
                QF(a, b, e, l) && RF(a, e, c, g, h, b, k, l, n)
            } else b.classList ? .contains("adsbygoogle") && b.dataset.adStatus === "filled" && (l.j = SF(a, b))
    }

    function PF(a, b) {
        return oE(a, b) && a.tagName !== "TABLE" && b.getComputedStyle(a).display !== "none"
    }

    function QF(a, b, c, d) {
        if (c = c.size && ["block", "table-cell"].includes(a.getComputedStyle(b).display)) c = ml(a.getComputedStyle(b).fontSize), c = !(c !== null && c > 22) && !(c !== null && c < 8);
        c && (a = SF(a, b), c = (d.g === void 0 || a - d.g > d.l) && (d.j === void 0 || a - d.j > 639));
        if (d = c && !wE(b)) {
            for (b = b.lastChild; b ? .nodeType !== Node.TEXT_NODE;)
                if (iB(b) && LE.includes(b.tagName)) b = b.lastChild;
                else break;
            d = b ? .nodeType === Node.TEXT_NODE && !!b ? .textContent && b.textContent.trim().length > 3
        }
        return !!d
    }

    function RF(a, b, c, d, e, f, g, h, k) {
        b.size && Pt(a, ["Roboto:500"]);
        var l = "#0B57D0",
            m = "#FFFFFF";
        tC(c) && (l = (m = (l = Fy(a, c.M.Za)) && xC(a, c, l, f)) ? l : "#FFFFFF", m = m ? "inherit" : "#1A73E8");
        var n = [...b];
        for (let K = 0; K < n.length; ++K) {
            let I = n[K];
            if (pC(g) || K === 1) break;
            b.delete(I);
            var p = g,
                q = I,
                u = f.getBoundingClientRect().bottom;
            q = p.g.l.get(q);
            if (!(q === void 0 || u - q > p.l)) {
                b.delete(I);
                continue
            }
            p = xE(c.g.ec(), f, I, eC(c, I));
            TF(d, p);
            e.incrementTermUsageCount(I);
            var A = g;
            q = I;
            var D = f.getBoundingClientRect().bottom;
            u = A.g;
            A = A.j;
            u.j++;
            let G =
                u.g.get(q) ? ? [];
            G.push(A);
            u.g.set(q, G);
            A = u.l.get(q) ? ? 0;
            u.l.set(q, Math.max(A, D));
            if (B(c.R, 17)) continue;
            u = uC(a, c, I, f, l, m, !0, !1, !1);
            q = UF(u, c, kf(p), a);
            c.M.Ha && eC(c, I) || Cy(u);
            VF(u, c, I, kf(p), q, k, a, e);
            tC(c) && c.M.Za > 0 && f.appendChild(a.document.createTextNode(" "));
            f.appendChild(u);
            (tC(c) ? uE(u, c.M, a) : sE(u, c.M, a)) ? u.remove(): h.g = SF(a, u)
        }
    }
    async function WF(a, b, c, d, e, f, g, h, k) {
        d.size && Pt(a, ["Roboto:500"]);
        var l = new jE;
        d = [...d];
        sc(g.getTermUsageCount) && d.sort((m, n) => g.getTermUsageCount(m) - g.getTermUsageCount(n));
        for (let m = 0; m < d.length && !(m >= c.om); ++m) {
            let n = d[m],
                p = yE(e.g.ec(), n, eC(e, n));
            TF(f, p);
            let q = uC(a, e, n, h, "#FFFFFF", "#1A73E8", !1, !0, k === 4),
                u = XF(q, e, kf(p));
            e.M.Ha && eC(e, n) || Cy(q);
            YB(e, 999, q, A => {
                try {
                    if (!cC(l, e)) return !1;
                    let I = b ? .document ? .body ? .tagName === "BODY" ? b : a,
                        G = bC(I, e, n);
                    var D = Dp(Bp(n), kf(p));
                    var K = vf(D, 8, u.B);
                    let E = Ep(H(K, 9, 4),
                            G),
                        Q = e.g.Tf(E);
                    dC(l, I, e, Q, n, e.A.get(n) || "", 4, e.M.Mf);
                    return !1
                } finally {
                    A.preventDefault(), A.stopImmediatePropagation()
                }
            });
            h.appendChild(q);
            if (h.scrollHeight > h.clientHeight) {
                h.removeChild(q);
                break
            }
            g.incrementTermUsageCount(n)
        }
    }
    var YF = class {
        constructor() {
            this.A = this.l = null
        }
        get B() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.xg,
                    d = new To;
                b = yf(d, 1, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.A) {
                var b = a.wg;
                var c = new So;
                c = wf(c, 1, this.l);
                this.A = b.call(a, c)
            }
        }
    };

    function UF(a, b, c, d) {
        var e = new YF;
        ZF(b, 1065, f => {
            for (let g of f) g.isIntersecting ? e.B === null && (tC(b) ? uE(a, b.M, d) : sE(a, b.M, d)) ? a.remove() : e.j(b.g, c) : e.g(b.g)
        }).observe(a);
        return e
    }

    function VF(a, b, c, d, e, f, g, h) {
        function k() {
            var l = bC(g, b, c);
            var m = Dp(Bp(c), d);
            m = vf(m, 7, e.B);
            l = Ep(H(m, 9, 3), l);
            return b.g.Hc(l)
        }
        b.M.Ha && aC(b, a, () => {
            h.setClickPageEventIndex(d, k())
        });
        YB(b, 999, a, l => {
            try {
                if (!cC(f, b)) return !1;
                let m;
                b.M.Ha && !l.isTrusted && h.getClickPageEventIndex(d) !== void 0 ? (m = h.getClickPageEventIndex(d), h.removeClickPageEventIndex(d)) : m = k();
                b.va(1401, dC(f, g, b, m, c, b.C.get(c) ? ? "", 3, !1, b.M.Ha && !l.isTrusted && eC(b, c)));
                return !1
            } finally {
                l.preventDefault(), l.stopImmediatePropagation()
            }
        })
    }
    class OE {
        constructor(a) {
            this.l = a;
            this.j = this.g = void 0
        }
    }

    function SF(a, b) {
        return b.getBoundingClientRect().bottom + a.scrollY
    }
    class $F {
        constructor() {
            this.A = this.l = null
        }
        get B() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.ag,
                    d = new Xo;
                b = yf(d, 1, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.A) {
                var b = a.Zf;
                var c = new Wo;
                c = wf(c, 1, this.l);
                this.A = b.call(a, c)
            }
        }
    }

    function XF(a, b, c) {
        var d = new $F;
        ZF(b, 1065, e => {
            for (let f of e) f.isIntersecting ? d.j(b.g, c) : d.g(b.g)
        }).observe(a);
        return d
    };
    async function aG(a, b, c, d, e, f, g, h) {
        a = uC(a, b, c, d, f, g, !0, !1, !1);
        b.M.Ze ? (a.style.position = "absolute", a.style.visibility = "hidden", d.appendChild(a), e = a.getBoundingClientRect().width, d.removeChild(a), d = h >= e ? 1 : 0) : (d.appendChild(a), h = d.getBoundingClientRect().height, d.removeChild(a), d = h === e ? 1 : 0);
        return d
    }
    async function bG(a, b, c, d, e, f) {
        var g = c.textContent || "",
            h = IE(d, g);
        d = c.getBoundingClientRect();
        if (g.length === 0 || h.length === 0) return null;
        if (b.M.Ze) {
            var k = a.document.createRange();
            k.selectNodeContents(c);
            k = k.getClientRects();
            if (k.length === 0) k = 0;
            else {
                k = k[k.length - 1];
                g = c.getBoundingClientRect();
                var l = a.getComputedStyle(c);
                if (b.V()) {
                    var m = Number(l.paddingLeft.replace("px", "")) || 0;
                    l = Number(l.borderLeftWidth.replace("px", "")) || 0;
                    k = k.left - (g.left + m + l)
                } else m = Number(l.paddingRight.replace("px", "")) || 0, l = Number(l.borderRightWidth.replace("px",
                    "")) || 0, k = g.right - m - l - k.right
            }
        }
        g = -1;
        l = "";
        for (let n of h)
            if (h = n.searchTerm, m = await aG(a, b, h, c, d.height, e, f, k), m > g && (g = m, l = h), g === 1) break;
        return g < 0 ? null : {
            Pf: (g + Math.max(0, 1 - Math.max(d.top + a.scrollY, 0) / (a.innerHeight * 5))) / 2,
            vg: [l]
        }
    }
    async function cG(a, b, c, d, e) {
        var f = DE(gx(b.R), b.j);
        if (!f.isEmpty()) {
            var g = Array.from(a.document.body.getElementsByTagName("p")),
                h = Fy(a, b.M.Za),
                k = new dG(a.innerHeight),
                l = [],
                m = !1,
                n = async () => {
                    if (!m) {
                        m = !0;
                        var q = b.oa(12);
                        try {
                            for (; l.length > 0;) {
                                var u = [...l];
                                l.length = 0;
                                let A = [];
                                for (let D of u) {
                                    u = "#0B57D0";
                                    let K = "#FFFFFF";
                                    tC(b) && h && xC(a, b, h, D) ? (u = h, K = "inherit") : tC(b) && (u = "#FFFFFF", K = "#1A73E8");
                                    let I = await bG(a, b, D, f, u, K);
                                    I && A.push({
                                        element: D,
                                        Pf: I.Pf,
                                        vg: I.vg,
                                        Wk: u,
                                        Xk: K
                                    })
                                }
                                if (A.length > 0) {
                                    A.sort((D, K) => K.Pf - D.Pf);
                                    for (let D of A)
                                        if (eG(k, D.element.getBoundingClientRect().bottom + a.scrollY))
                                            for (let K of D.vg) fG(a, K, b, c, D.element, e, k, D.Wk, D.Xk, d)
                                }
                            }
                        } finally {
                            m = !1, q = gG(c, b.oa(13) - q), q.l() && tp(q.l()).length > 0 && b.g.Af(q), l.length > 0 && n()
                        }
                    }
                },
                p = ZF(b, 898, q => {
                    var u = !1;
                    for (let A of q) A.isIntersecting && A.target instanceof HTMLParagraphElement && (p.unobserve(A.target), l.push(A.target), u = !0);
                    u && n()
                }, {
                    root: null,
                    rootMargin: "0px 0px 300% 0px",
                    threshold: 0
                });
            for (let q of g) p.observe(q)
        }
    }

    function fG(a, b, c, d, e, f, g, h, k, l) {
        var m = xE(c.g.ec(), e, b, eC(c, b));
        TF(d, m);
        B(c.R, 17) || (d = uC(a, c, b, e, h, k, !0, !1, !1), h = UF(d, c, kf(m), a), c.M.Ha && eC(c, b) || Cy(d), VF(d, c, b, kf(m), h, f, a, l), tC(c) && c.M.Za > 0 && e.appendChild(a.document.createTextNode(" ")), e.appendChild(d), a = d.getBoundingClientRect().bottom + window.scrollY, g.g.push(a))
    }

    function eG(a, b) {
        for (let c of a.g)
            if (Math.abs(b - c) < a.j) return !1;
        return !0
    }
    class dG {
        constructor(a) {
            this.j = a;
            this.g = []
        }
    };

    function hG(a) {
        var b = new nt,
            c = yt(a, 2500, () => void mt(b));
        return new iG(a, () => void jG(a, () => void c()), kt(b))
    }

    function kG(a) {
        a.l || (lG(a), mG(a), a.l = !0);
        return a.B
    }

    function lG(a) {
        var b = new MutationObserver(() => {
            a.g()
        });
        b.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class", "style"]
        });
        Is(a, () => void b.disconnect())
    }

    function mG(a) {
        a.win.addEventListener("resize", a.g);
        Is(a, () => void a.win.removeEventListener("resize", a.g))
    }
    var iG = class extends Gs {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.g = b;
            this.B = c;
            this.l = !1
        }
    };

    function jG(a, b) {
        b();
        a.setTimeout(b, 1500)
    };
    const nG = ["block", "inline", "inline-block", "list-item", "table-cell"];
    async function oG(a, b, c, d, e, f, g) {
        e.g.oa(5) >= e.j && await PE(e, 6);
        var h = new jE;
        d.ql || pG(a, b, c, d, f, gx(c.R), h, g);
        d.rl || (c.M.Mg && B(c.R, 5) ? await c.va(898, cG(a, c, f, g, h)) : await c.va(898, ME(a, c, e, f, g, b, h)));
        d.tl || await qG(a, c, d, e, f, g, h)
    }
    async function qG(a, b, c, d, e, f, g) {
        var h = gx(b.R);
        var k = new EE(b.j);
        for (let l of h) C(l, 6) !== "" && (h = ex(l), FE(k, h, h));
        GE(k);
        k = new HE(k);
        k.isEmpty() || await b.va(898, rG(a, b, d, e, f, k, new rC(c.wordWindowSize, c.sameSearchTermPerWindow, c.annotationsPerWindow, c.maximumAnnotationsPerPage, 0), g))
    }
    async function rG(a, b, c, d, e, f, g, h) {
        for (var k = a.document.body; k;) {
            c.g.oa(7) >= c.j && await PE(c, 8);
            if (k.nodeType === Node.TEXT_NODE && k.textContent !== "" && k.parentElement) {
                let uc = k.parentElement;
                a: {
                    var l = a,
                        m = b,
                        n = uc,
                        p = k.textContent,
                        q = d,
                        u = e,
                        A = f,
                        D = g,
                        K = h;
                    let Va = [];b: {
                        var I = p;
                        switch (m.j) {
                            case 1:
                                var G = I;
                                let vc = Array(G.length),
                                    cc = 0;
                                for (let wc = 0; wc < G.length; wc++) BE.test(G[wc]) || cc++, vc[wc] = cc;
                                var E = vc;
                                break b;
                            default:
                                var Q = I;
                                let Zc = Array(Q.length),
                                    md = 0,
                                    Gb = 0;
                                for (; Gb < Q.length;) {
                                    for (;
                                        /\s/.test(Q[Gb]);) Zc[Gb] = md, Gb++;
                                    let wc = !1;
                                    for (; Gb < Q.length && !/\s/.test(Q[Gb]);) wc = !0, Zc[Gb] = md, Gb++;
                                    wc && (md++, Zc[Gb - 1] = md)
                                }
                                E = Zc
                        }
                    }
                    let Vb = E,
                        Pg = p.includes("\u00bb") ? [] : IE(A, p),
                        Ge = -1;
                    for (let vc of Pg) {
                        let cc = vc.g,
                            Zc = vc.j;
                        if (cc < Ge) continue;
                        var wa = D,
                            Ca = vc.searchTerm;
                        sC(wa.g, wa.j + Vb[cc]);
                        var ia = wa;
                        if (!((ia.g.g.get(Ca) ? .length ? ? 0) < ia.A && wa.g.A < wa.annotationsPerWindow)) continue;
                        let md = l.getComputedStyle(n),
                            Gb = md.fontSize.match(/\d+/);
                        if (!(Gb && Number(Gb[0]) >= 12 && Number(Gb[0]) <= 22 && ib(nG, md.display))) {
                            D.j += Vb[Vb.length - 1];
                            var Fa = [];
                            break a
                        }
                        let wc =
                            Ge + 1;
                        wc < cc && Va.push(l.document.createTextNode(p.substring(wc, cc)));
                        let zf = p.substring(cc, Zc + 1);
                        var Sb = p,
                            $c = cc,
                            Lc = Zc + 1;
                        let Mi = Sb.substring(Math.max($c - 30, 0), $c) + "~~" + Sb.substring(Lc, Math.min(Lc + 30, Sb.length));
                        var ee = l,
                            ya = m.g.ec(),
                            Mc = n,
                            Qg = zf,
                            Rg = Mi,
                            Sg = vc.searchTerm,
                            Tg = Vb[cc],
                            Ug = eC(m, vc.searchTerm);
                        let Vg = Mc.getBoundingClientRect();
                        var Wg = qp(pp(new af, ya), 2);
                        var Xg = Jf(Wg, 2, Qg);
                        var Yg = Jf(Xg, 3, Rg);
                        var Zg = rp(Yg, Sg);
                        var $g = uf(Zg, 5, Tg);
                        var ah = uf($g, 6, Math.round(Vg.x));
                        var bh = uf(ah, 7, Math.round(Vg.y));
                        let nd =
                            ee.getComputedStyle(Mc);
                        var Ni = new op;
                        var Oi = Jf(Ni, 1, nd.fontFamily);
                        var Pi = AE(nd.color);
                        var Qi = y(Oi, 7, Pi);
                        var Ri = AE(nd.backgroundColor);
                        var Si = y(Qi, 8, Ri);
                        let ch = nd.fontSize.match(/^(\d+(\.\d+)?)px$/);
                        var Af = uf(Si, 4, ch ? Math.round(Number(ch[1])) : 0);
                        let Bf = Math.round(Number(nd.fontWeight));
                        isNaN(Bf) || Bf === 400 || uf(Af, 5, Bf);
                        nd.textDecorationLine !== "none" && Jf(Af, 6, nd.textDecorationLine);
                        var Ti = y(bh, 8, Af);
                        let Cf = [],
                            fe = Mc;
                        for (; fe && Cf.length < 20;) {
                            var dh = Cf,
                                Ui = dh.push,
                                Df = fe,
                                Vi = new mp;
                            let eh = Jf(Vi, 1, Df.tagName);
                            Df.className !== "" && Ne(eh, 2, Df.className.split(" "), Ed);
                            Ui.call(dh, eh);
                            if (fe.tagName === "BODY") break;
                            fe = fe.parentElement
                        }
                        var Wi = Cf.reverse();
                        var Xi = Xe(Ti, 9, Wi);
                        let fh = sp(Xi, Ug);
                        TF(q, fh);
                        u.incrementTermUsageCount(zf);
                        Va.push(sG(l, m, kf(fh), vc.searchTerm, zf, n, K, u));
                        var Ef = D.g,
                            gh = vc.searchTerm,
                            Yi = D.j + Vb[cc];
                        Ef.j++;
                        let hh = Ef.g.get(gh) ? ? [];
                        hh.push(Yi);
                        Ef.g.set(gh, hh);
                        Ge = Zc;
                        if (pC(D)) break
                    }
                    let Ff = Ge + 1;Ff !== 0 && Ff < p.length && Va.push(l.document.createTextNode(p.substring(Ff)));D.j += Vb[Vb.length - 1];Fa = Va
                }
                let ad =
                    Fa;
                if (ad.length && !B(b.R, 17)) {
                    for (let Va of ad) uc.insertBefore(Va, k), tG(Va, b.M);
                    uc.removeChild(k);
                    for (let Va of uc.children) Va.classList ? .contains("google-anno") && Va.firstElementChild && sE(Va.firstElementChild, b.M, a) && Va.replaceWith(a.document.createTextNode(Va.textContent ? .trimStart() ? ? ""));
                    for (k = ad[ad.length - 1]; k.lastChild;) k = k.lastChild;
                    if (pC(g)) break
                }
            }
            a: {
                var ih = a,
                    xc = k,
                    jh = g,
                    Zi = b.j;
                if (xc.firstChild && iB(xc) && !xc.classList ? .contains("google-anno-skip") && (xc.offsetHeight || ih.getComputedStyle(xc).display ===
                        "contents")) {
                    if (oE(xc, ih)) {
                        k = xc.firstChild;
                        break a
                    }
                    if (xc.textContent ? .length) {
                        b: {
                            var Gf = xc.textContent;
                            switch (Zi) {
                                case 1:
                                    var kh = Gf;
                                    let ad = 0;
                                    for (let Vb = kh.length - 1; Vb >= 0; Vb--) BE.test(kh[Vb]) || ad++;
                                    var Hf = ad;
                                    break b;
                                default:
                                    let Va = Gf.trim();
                                    Hf = Va === "" ? 0 : Va.split(/\s+/).length
                            }
                        }
                        sC(jh.g, jh.j + Hf)
                    }
                }
                let uc = xc;
                for (;;) {
                    if (uc.nextSibling) {
                        k = uc.nextSibling;
                        break a
                    }
                    if (!uc.parentNode) {
                        k = null;
                        break a
                    }
                    uc = uc.parentNode
                }
                k = void 0
            }
        }
    }

    function uG(a, b) {
        return MB(a, {
            V: b.V(),
            ka: b.ka,
            ba: hs(a),
            ga: is(a)
        })
    }

    function pG(a, b, c, d, e, f, g, h) {
        function k() {
            return m ? ? (m = c.Xh(898, a, () => {
                if (!l) {
                    var p = c.oa(12),
                        q = uG(a, c);
                    q && (a.clearInterval(m), l = !0, vG(a, b, c, d, e, p, f, q, g, h))
                }
            }, d.yk ? ? 3E3))
        }
        if (f.filter(p => C(p, 7).length).length) {
            var l = !1,
                m = void 0,
                n = wG(c, a, () => {
                    if (!(a.scrollY <= (d.zk ? ? 300) || l)) {
                        var p = c.oa(12),
                            q = uG(a, c);
                        q ? (l = !0, a.removeEventListener("scroll", n), vG(a, b, c, d, e, p, f, q, g, h)) : m = k()
                    }
                });
            c.Wb(898, a, () => {
                if (!l) {
                    var p = c.oa(12),
                        q = uG(a, c);
                    q ? (l = !0, vG(a, b, c, d, e, p, f, q, g, h)) : m = k()
                }
            }, d.xk ? ? 15E3)
        }
    }

    function vG(a, b, c, d, e, f, g, h, k, l) {
        var m = new oC(a, c, d, h, k, l);
        g.filter(n => C(n, 7).length).forEach(n => {
            var p = c.g.ec();
            var q = ex(n),
                u = eC(c, ex(n));
            p = sp(rp(qp(pp(new af, p), 1), q), u);
            TF(e, p);
            p = kf(p);
            n = ex(n);
            m.A.push({
                Dk: p,
                searchTerm: n
            });
            m.B && nC(m, b)
        });
        a = hG(a);
        kG(a).listen(() => {
            if (!m.g.isDrawerVisible() && SB(m.win, m.j)) {
                var n = MB(m.win, {
                    V: m.config.V(),
                    ka: m.config.ka,
                    ba: hs(m.win),
                    ga: is(m.win)
                });
                n && (m.j = n, kC(m.D, m.win, n, m.config))
            }
        });
        c.g.Af(gG(e, c.oa(13) - f))
    }

    function tG(a, b) {
        if (hB(a)) {
            if (a.tagName === "A") {
                var c = xy(a.parentElement),
                    d = xy(a);
                var e = zy(a, b);
                if (e = c && d && e ? uy(d, e) < Math.min(uy(c, e), 2.5) ? c : null : c) {
                    c = e[0];
                    d = e[1];
                    e = e[2];
                    c = Number(c);
                    d = Number(d);
                    e = Number(e);
                    if (c != (c & 255) || d != (d & 255) || e != (e & 255)) throw Error('"(' + c + "," + d + "," + e + '") is not a valid RGB color');
                    d = c << 16 | d << 8 | e;
                    L(a, {
                        color: c < 16 ? "#" + (16777216 | d).toString(16).slice(1) : "#" + d.toString(16)
                    })
                }
            }
            for (c = 0; c < a.childElementCount; c++) tG(a.children[c], b)
        }
    }
    class xG {
        constructor() {
            this.A = this.l = null
        }
        get B() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.yh,
                    d = new Ip;
                b = yf(d, 2, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.A) {
                var b = a.xh;
                var c = new Hp;
                c = wf(c, 1, this.l);
                this.A = b.call(a, c)
            }
        }
    }

    function sG(a, b, c, d, e, f, g, h) {
        function k() {
            var m = bC(a, b, d);
            var n = Dp(Bp(d), c);
            n = vf(n, 2, l.B);
            m = Ep(H(n, 9, 2), m);
            return b.g.Hc(m)
        }
        e = yG(a, e, f);
        e.className = "google-anno";
        b.M.Ha && eC(b, d) ? e.classList.add("google-anno-oc") : Cy(e);
        var l = zG(b, c, e, a);
        b.M.Ha && aC(b, e, () => {
            h.setClickPageEventIndex(c, k())
        });
        YB(b, 999, e, m => {
            try {
                if (!cC(g, b)) return !1;
                let n;
                b.M.Ha && !m.isTrusted && h.getClickPageEventIndex(c) !== void 0 ? (n = h.getClickPageEventIndex(c), h.removeClickPageEventIndex(c)) : n = k();
                b.va(1401, dC(g, a, b, n, d, b.D.get(d) || "",
                    1, !1, b.M.Ha && !m.isTrusted && eC(b, d)));
                return !1
            } finally {
                m.preventDefault(), m.stopImmediatePropagation()
            }
        });
        return e
    }

    function yG(a, b, c) {
        var d = Ay(a, "span");
        d.className = "google-anno-t";
        L(d, {
            "text-decoration": "underline"
        });
        L(d, {
            "text-decoration-style": "dotted"
        });
        L(d, {
            "-webkit-text-decoration-line": "underline",
            "-webkit-text-decoration-style": "dotted"
        });
        L(d, {
            color: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-style": "inherit",
            "font-weight": "inherit"
        });
        d.appendChild(a.document.createTextNode(b));
        b = Ay(a, "a");
        L(b, {
            color: "revert-layer",
            cursor: "pointer",
            fill: "currentColor",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-style": "inherit",
            "font-weight": "inherit",
            "line-height": "inherit",
            "text-decoration": "none"
        });
        cj(b, "#");
        var e = b.appendChild;
        c = a.getComputedStyle(c).fontSize;
        c = Ky(a, "100 -1000 840 840", `calc(${c} - 2px)`, c, "M168-144q-29.7 0-50.85-21.15Q96-186.3 96-216v-528q0-29.7 21.15-50.85Q138.3-816 168-816h624q29.7 0 50.85 21.15Q864-773.7 864-744v528q0 29.7-21.15 50.85Q821.7-144 792-144H168Zm0-72h624v-528H168v528Zm72-96h480v-72H240v72Zm0-144h168v-216H240v216Zm240 0h240v-72H480v72Zm0-144h240v-72H480v72ZM168-216v-528 528Z");
        L(c, {
            color: "inherit",
            cursor: "inherit",
            fill: "currentcolor"
        });
        e.call(b, c);
        b.appendChild(a.document.createTextNode("\u00a0"));
        b.appendChild(d);
        return b
    }

    function zG(a, b, c, d) {
        var e = new xG;
        ZF(a, 1065, f => {
            for (let g of f) g.isIntersecting ? c.classList ? .contains("google-anno") && e.B === null && c.firstElementChild && sE(c.firstElementChild, a.M, d) ? c.replaceWith(d.document.createTextNode(c.textContent ? .trimStart() ? ? "")) : e.j(a.g, b) : e.g(a.g)
        }).observe(c);
        return e
    };

    function TF(a, b) {
        a.entries.push(oe(b))
    }

    function gG(a, b) {
        var c = a.g;
        a.g = a.entries.length;
        var d = new Gp,
            e = new up;
        a = Xe(e, 2, a.entries.slice(c));
        d = y(d, 1, a);
        b !== 0 && wf(d, 2, Math.round(b));
        return d
    }

    function AG(a, b) {
        var c = new bp;
        a = Jf(c, 2, a.language);
        return Jf(a, 3, b)
    }

    function BG(a) {
        var b = gx(a),
            c = 0,
            d = 0,
            e = 0,
            f = 0,
            g = 0,
            h = 0;
        a = 0;
        for (var k of b) c += CG(C(k, 6) !== "") + CG(C(k, 7) !== "") + CG(C(k, 5) !== "") + CG(C(k, 12) !== "") + CG(C(k, 9) !== ""), d += CG(C(k, 6) !== "") + CG(C(k, 7) !== "") + CG(C(k, 5) !== "") + CG(C(k, 12) !== "") + CG(C(k, 9) !== ""), e += CG(C(k, 6) !== ""), f += CG(C(k, 7) !== ""), g += CG(C(k, 5) !== ""), h += CG(C(k, 12) !== ""), a += CG(C(k, 9) !== "");
        k = new vp;
        b = tf(k, 1, b.length);
        c = tf(b, 2, c);
        d = xe(c, 3, d == null ? d : jd(d));
        e = xe(d, 4, e == null ? e : jd(e));
        f = xe(e, 5, f == null ? f : jd(f));
        g = tf(f, 6, g);
        h = tf(g, 7, h);
        return tf(h, 8, a)
    }

    function DG(a, b, c, d, e, f, g, h) {
        var k = new xp;
        var l = new ap;
        c = Jf(l, 1, c);
        d = Jf(c, 2, d);
        b = sf(d, 3, b);
        b = sf(b, 5, !1);
        k = y(k, 1, b);
        e = AG(a, e);
        e = y(k, 2, e);
        g = wf(e, 3, Math.round(g));
        e = BG(f);
        g = y(g, 6, e);
        for (let m of mf(f, 8)) Ye(g, 7, fd, EG(m), gd);
        h.length ? (a = new lp, a = Xe(a, 1, h), z(g, 5, wp, a)) : (a.g = a.entries.length, h = new up, a = $e(h, a.entries), z(g, 4, wp, a));
        return g
    }
    var FG = class {
        constructor() {
            this.entries = [];
            this.language = null;
            this.g = 0
        }
    };

    function CG(a) {
        return a ? 1 : 0
    }

    function EG(a) {
        switch (a) {
            case 1:
                return 2;
            case 3:
                return 3;
            case 2:
                return 1;
            case 4:
                return 4;
            case 5:
                return 5;
            case 0:
                return 0;
            default:
                return 0
        }
    };

    function GG(a) {
        if (a != null) return HG(a)
    }

    function IG(a) {
        return a == null ? null : HG(a)
    }

    function HG(a) {
        return Fc(a) ? Number(a) : String(a)
    };

    function JG(a, b, c) {
        KG(a);
        b = LG(b);
        for (let [d, e] of b) b = d, MG(a, e, b, c), NG(a, b)
    }

    function OG(a, b, c) {
        a.j.forEach(d => {
            PG(d, { ...a.g,
                outcome: b,
                nc: !1,
                Oc: c
            })
        })
    }

    function QG(a, b, c, d) {
        a.j.forEach(e => {
            e.Zh(b, { ...a.g,
                outcome: c,
                nc: !1,
                Oc: d
            })
        })
    }

    function RG(a, b, c, d) {
        a.j.forEach(e => {
            SG(e, { ...a.g,
                outcome: b,
                nc: c,
                Oc: d
            })
        })
    }

    function TG(a, b, c, d, e) {
        a.j.forEach(f => {
            f.pg(b, { ...a.g,
                outcome: c,
                nc: d,
                Oc: e
            })
        })
    }

    function KG(a) {
        a.A || (a.A = !0, a.j.forEach(b => {
            UG(b, a.g)
        }))
    }

    function MG(a, b, c, d) {
        a.j.forEach(e => {
            e.qg(b, { ...a.g,
                format: c,
                nc: d
            })
        })
    }

    function NG(a, b) {
        a.B.has(b) || (a.B.add(b), a.j.forEach(c => {
            VG(c, { ...a.g,
                Lb: a.Lb,
                format: b
            })
        }))
    }

    function WG(a) {
        a.C || (a.C = !0, a.j.forEach(b => {
            XG(b, a.g)
        }))
    }

    function YG(a, b) {
        a.j.forEach(c => {
            c.bi(b, { ...a.g,
                format: 4,
                nc: !1
            })
        })
    }

    function ZG(a, b) {
        a.j.forEach(c => {
            $G(c, { ...a.g,
                reason: aH(b)
            })
        })
    }
    var hH = class {
        constructor(a, b, c, d) {
            this.D = this.l = 1;
            this.C = this.A = !1;
            this.g = {
                language: a.has(b) ? b : "other",
                Pa: $a() ? 2 : Ya() ? 4 : Za() ? 7 : 10
            };
            a: switch (d) {
                case 1:
                    a = 1;
                    break a;
                case 2:
                    a = 2;
                    break a;
                default:
                    a = 0
            }
            this.Lb = a;
            this.B = new Set;
            this.j = [...c]
        }
        ec() {
            return this.D++
        }
        Qe(a) {
            a: switch (Se(a, wp)) {
                case 4:
                    var b = 1;
                    break a;
                case 5:
                    b = 2;
                    break a;
                default:
                    b = 0
            }
            var c = bH(a),
                d = hf(a, 3),
                e = c.length > 0;RG(this, b, !1, e);TG(this, d, b, !1, e);a.g() && c.length > 0 && JG(this, c, !1);
            if (Be(a, lp, 5, wp)) {
                a = nf(a, lp, 5, wp);
                for (let f of Ve(a, gp, 1, w())) ZG(this,
                    f)
            }
            this.l++
        }
        Af(a) {
            var b = a.g() ? 1 : 0,
                c = bH(a),
                d = hf(a, 2),
                e = c.length > 0;
            RG(this, b, !0, e);
            TG(this, d, b, !0, e);
            a.g() && c.length > 0 && JG(this, c, !0);
            this.l++
        }
        ai(a) {
            var b = bH(a),
                c = a.g() ? 1 : 2,
                d = hf(a, 5),
                e = b.length > 0;
            OG(this, c, e);
            QG(this, d, c, e);
            if (a.g() && b.length > 0) {
                WG(this);
                a = LG(b);
                for (let [, f] of a) YG(this, f)
            }
            this.l++
        }
        yh() {
            this.j.forEach(a => {
                cH(a, { ...this.g,
                    format: 2
                })
            });
            return this.l++
        }
        xh() {
            this.j.forEach(a => {
                dH(a, { ...this.g,
                    format: 2
                })
            });
            return this.l++
        }
        ng() {
            this.j.forEach(a => {
                cH(a, { ...this.g,
                    format: 1
                })
            });
            return this.l++
        }
        mg() {
            this.j.forEach(a => {
                dH(a, { ...this.g,
                    format: 1
                })
            });
            this.l++
        }
        xg() {
            this.j.forEach(a => {
                cH(a, { ...this.g,
                    format: 3
                })
            });
            return this.l++
        }
        wg() {
            this.j.forEach(a => {
                dH(a, { ...this.g,
                    format: 3
                })
            });
            return this.l++
        }
        ag() {
            this.j.forEach(a => {
                cH(a, { ...this.g,
                    format: 4
                })
            });
            return this.l++
        }
        Zf() {
            this.j.forEach(a => {
                dH(a, { ...this.g,
                    format: 4
                })
            });
            return this.l++
        }
        Sh() {
            this.j.forEach(a => {
                cH(a, { ...this.g,
                    format: 5
                })
            });
            return this.l++
        }
        Rh() {
            this.j.forEach(a => {
                dH(a, { ...this.g,
                    format: 5
                })
            });
            return this.l++
        }
        Hc(a) {
            var b = 0;
            bf(a, 2) != null ? b = 2 : bf(a, 3) != null ? b =
                1 : bf(a, 7) != null && (b = 3);
            this.j.forEach(c => {
                c.click({ ...this.g,
                    format: b
                })
            });
            return this.l++
        }
        Tf() {
            this.j.forEach(a => {
                eH(a, { ...this.g,
                    format: 4
                })
            });
            return this.l++
        }
        ve(a) {
            var b = 0;
            Be(a, Kp, 2, Np) ? b = 1 : Be(a, Jp, 3, Np) && (b = 2);
            this.j.forEach(c => {
                fH(c, { ...this.g,
                    type: b
                })
            });
            this.l++
        }
        lg() {
            this.j.forEach(a => {
                gH(a, this.g)
            });
            this.l++
        }
    };

    function bH(a) {
        return a.g() ? [...tp(a.l())] : []
    }

    function aH(a) {
        switch (Se(a, hp)) {
            case 1:
                return 1;
            case 9:
                return 4;
            case 13:
                return 7;
            default:
                return 0
        }
    }

    function LG(a) {
        var b = new Map;
        for (let c of a) a = iH(c), b.set(a, (b.get(a) ? ? 0) + 1);
        return b
    }

    function iH(a) {
        switch (F(a, 1)) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            case 4:
                return 4;
            case 5:
                return 5;
            default:
                return 0
        }
    };

    function jH(a, b) {
        var c = new Qp;
        var d = a.adIntentsPageState.takeNextPageEventIndex();
        c = wf(c, 1, d);
        b = wf(c, 2, Math.round(a.j.oa(b) - a.A));
        b = y(b, 10, a.B);
        b = rf(b, 15, a.C ? !0 : void 0);
        return H(b, 18, a.Lb)
    }
    var kH = class {
        constructor(a, b, c, d, e, f, g, h, k, l) {
            this.j = b;
            this.A = c;
            this.B = d;
            this.C = f;
            this.Lb = k;
            this.adIntentsPageState = l;
            this.l = [...g];
            this.g = h.length ? new hH(e, a, h, k) : null
        }
        ec() {
            return this.adIntentsPageState.takeNextAnnotationEntryId()
        }
        Qe(a) {
            this.g ? .Qe(a);
            var b = this.handle,
                c = jH(this, 11);
            a = z(c, 3, Rp, a);
            b.call(this, a)
        }
        Af(a) {
            this.g ? .Af(a);
            var b = this.handle,
                c = jH(this, 11);
            a = z(c, 14, Rp, a);
            b.call(this, a)
        }
        ai(a) {
            this.g ? .ai(a);
            var b = this.handle,
                c = jH(this, 11);
            a = z(c, 22, Rp, a);
            b.call(this, a)
        }
        yh(a) {
            this.g ? .yh(a);
            var b =
                this.handle,
                c = jH(this, 15);
            a = z(c, 4, Rp, a);
            return b.call(this, a)
        }
        xh(a) {
            this.g ? .xh(a);
            var b = this.handle,
                c = jH(this, 16);
            a = z(c, 5, Rp, a);
            return b.call(this, a)
        }
        ng(a) {
            this.g ? .ng(a);
            var b = this.handle,
                c = jH(this, 17);
            a = z(c, 6, Rp, a);
            return b.call(this, a)
        }
        mg(a) {
            this.g ? .mg(a);
            var b = this.handle,
                c = jH(this, 18);
            a = z(c, 7, Rp, a);
            b.call(this, a)
        }
        xg(a) {
            this.g ? .xg(a);
            var b = this.handle,
                c = jH(this, 19);
            a = z(c, 16, Rp, a);
            return b.call(this, a)
        }
        wg(a) {
            this.g ? .wg(a);
            var b = this.handle,
                c = jH(this, 20);
            a = z(c, 17, Rp, a);
            return b.call(this, a)
        }
        ag(a) {
            this.g ? .ag(a);
            var b = this.handle,
                c = jH(this, 21);
            a = z(c, 20, Rp, a);
            return b.call(this, a)
        }
        Zf(a) {
            this.g ? .Zf(a);
            var b = this.handle,
                c = jH(this, 22);
            a = z(c, 21, Rp, a);
            return b.call(this, a)
        }
        Sh(a) {
            this.g ? .Sh(a);
            var b = this.handle,
                c = jH(this, 23);
            a = z(c, 23, Rp, a);
            return b.call(this, a)
        }
        Rh(a) {
            this.g ? .Rh(a);
            var b = this.handle,
                c = jH(this, 24);
            a = z(c, 24, Rp, a);
            return b.call(this, a)
        }
        Hc(a) {
            this.g ? .Hc(a);
            var b = this.handle,
                c = jH(this, 14);
            a = z(c, 8, Rp, a);
            return b.call(this, a)
        }
        Tf(a) {
            this.g ? .Tf(a);
            var b = this.handle,
                c = jH(this, 14);
            a = z(c, 8, Rp, a);
            return b.call(this,
                a)
        }
        ve(a) {
            this.g ? .ve(a);
            var b = this.handle,
                c = jH(this, 25);
            a = z(c, 9, Rp, a);
            b.call(this, a)
        }
        lg(a) {
            this.g ? .lg(a);
            var b = this.handle,
                c = jH(this, 27);
            a = z(c, 12, Rp, a);
            b.call(this, a)
        }
        handle(a) {
            for (let b of this.l) b(a);
            return HG(hf(a, 1))
        }
    };

    function lH(a) {
        this.g = a || {
            cookie: ""
        }
    }

    function mH() {
        var a = nH;
        if (!r.navigator.cookieEnabled) return !1;
        if (!a.isEmpty()) return !0;
        a.set("TESTCOOKIESENABLED", "1", {
            Df: 60
        });
        if (a.get("TESTCOOKIESENABLED") !== "1") return !1;
        oH(a, "TESTCOOKIESENABLED");
        return !0
    }
    aa = lH.prototype;
    aa.set = function(a, b, c) {
        var d = !1;
        if (typeof c === "object") {
            var e = c.sameSite;
            d = c.secure || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.Df
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        h === void 0 && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (h < 0 ? "" : h == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + h * 1E3)).toUTCString()) + (d ? ";secure" : "") + (e != null ? ";samesite=" +
            e : "")
    };
    aa.get = function(a, b) {
        var c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = La(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };

    function oH(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            Df: 0,
            path: c,
            domain: d
        })
    }
    aa.isEmpty = function() {
        return !this.g.cookie
    };
    aa.je = function() {
        return this.g.cookie ? (this.g.cookie || "").split(";").length : 0
    };
    aa.clear = function() {
        var a = (this.g.cookie || "").split(";"),
            b = [],
            c = [];
        for (let f = 0; f < a.length; f++) {
            var d = La(a[f]);
            var e = d.indexOf("=");
            e == -1 ? (b.push(""), c.push(d)) : (b.push(d.substring(0, e)), c.push(d.substring(e + 1)))
        }
        for (a = b.length - 1; a >= 0; a--) oH(this, b[a])
    };
    var nH = new lH(typeof document == "undefined" ? null : document);

    function pH(a, b = window) {
        if (a.ha()) try {
            return b.localStorage
        } catch {}
        return null
    }

    function qH(a) {
        return a.origin !== "null"
    }
    let rH;

    function sH(a) {
        return rH ? rH : qH(a) ? rH = tH(a) : rH = !1
    }

    function tH(a) {
        if (!a.navigator.cookieEnabled) return !1;
        var b = new lH(a.document);
        if (!b.isEmpty()) return !0;
        b.set("TESTCOOKIESENABLED", "1", {
            Df: 60,
            sameSite: a.isSecureContext ? "none" : void 0,
            secure: a.isSecureContext || void 0
        });
        if (b.get("TESTCOOKIESENABLED") !== "1") return !1;
        oH(b, "TESTCOOKIESENABLED");
        return !0
    }

    function uH(a, b) {
        b = qH(b) ? b.document.cookie : null;
        return b === null ? null : (new lH({
            cookie: b
        })).get(a) || ""
    }

    function vH(a, b, c, d) {
        qH(d) && (d.isSecureContext && (c = { ...c,
            sameSite: "none",
            secure: !0
        }), (new lH(d.document)).set(a, b, c))
    }

    function wH(a, b, c) {
        qH(b) && oH(new lH(b.document), a, "/", c)
    };
    const xH = {
        gfpCookie: null,
        parsedGfpCookie: {
            id: null,
            creationTimeSeconds: null
        }
    };
    var yH = class {
        constructor(a) {
            this.win = a;
            this.Va = void 0
        }
    };

    function zH(a) {
        var b = a.split(":");
        a = b.find(c => c.indexOf("ID") === 0) || null;
        b = b.find(c => c.indexOf("T=") === 0) ? .substring(2) || null;
        return {
            id: a,
            creationTimeSeconds: b
        }
    }

    function AH(a, b) {
        a = a.get("__gads", b);
        if (!a) return xH;
        b = zH(a);
        return {
            gfpCookie: a,
            parsedGfpCookie: b
        }
    };

    function BH(a, b) {
        if (!a) return null;
        a = new yH(a);
        b ? a.Va ? b = a.Va.get("__gads", b) : (a = a.win, b = b.ha() ? uH("__gads", a) : null) : b = null;
        return b ? ou(b + "t2Z7mVic") % 20 : null
    };

    function CH(a) {
        return (a = a.match(/^[a-z]{2,3}/i)) ? a[0].toLowerCase() : ""
    };

    function YB(a, b, c, d) {
        c.addEventListener("click", DH(a, b, d))
    }

    function aC(a, b, c) {
        b.addEventListener("adIntentsVignetteIntercepted", DH(a, 999, c))
    }

    function eC(a, b) {
        return a.l.has(b)
    }

    function lC(a, b, c) {
        b.requestAnimationFrame(DH(a, 898, c))
    }

    function ZF(a, b, c, d) {
        return new IntersectionObserver(DH(a, b, c), d || {
            threshold: .98
        })
    }

    function wG(a, b, c) {
        a = DH(a, 898, c);
        b.addEventListener("scroll", a, {
            passive: !0
        });
        return a
    }

    function DH(a, b, c) {
        return a.ob.wc(b, c, void 0, d => {
            d.es = a.M.Hd.join(",")
        })
    }
    var FH = class {
        constructor(a, b, c, d, e, f, g) {
            this.ka = a;
            this.R = b;
            this.ob = c;
            this.g = d;
            this.G = e;
            this.M = f;
            this.Lc = g;
            this.D = new Map;
            this.B = new Map;
            this.C = new Map;
            this.A = new Map;
            this.O = new Map;
            this.l = new Map;
            this.j = ib(EH, C(b, 7)) ? 1 : 0;
            for (let h of gx(this.R)) Lf(h, 6) && this.D.set(ex(h), C(h, 6)), Lf(h, 7) && this.B.set(ex(h), C(h, 7)), Lf(h, 5) && this.C.set(ex(h), C(h, 5)), Lf(h, 12) && this.A.set(ex(h), C(h, 12)), Lf(h, 9) && this.O.set(ex(h), C(h, 9)), ze(h, Mh, 10) && this.l.set(ex(h), Te(h, Mh, 10))
        }
        Ne(a, b, c) {
            a = DH(this, a, c);
            b.addEventListener("message",
                a);
            return a
        }
        Wb(a, b, c, d) {
            return b.setTimeout(DH(this, a, c), d)
        }
        Xh(a, b, c, d) {
            return b.setInterval(DH(this, a, c), d)
        }
        va(a, b) {
            this.ob.va(a, b, c => {
                c.es = this.M.Hd.join(",")
            });
            return b
        }
        oa(a) {
            return this.G.oa(a)
        }
        V() {
            return F(this.R, 12) === 2
        }
    };
    const EH = ["ja", "zh_CN", "zh_TW"];

    function GH(a, b, c, d) {
        var e = Ay(a, "div");
        e.classList.add("google-anno-skip", "goog-rentry");
        var f = HH(a, c);
        e.appendChild(f);
        L(e, {
            display: "flex",
            "flex-direction": "row",
            "justify-content": "flex-start",
            "padding-inline": W(16),
            "align-items": "center",
            "margin-bottom": W(0),
            "box-sizing": "border-box",
            height: W(58),
            width: "100%",
            "min-width": "0",
            color: "#3c4043",
            "font-family": "Google Sans, Roboto, Arial, sans-serif",
            "font-weight": "400",
            "font-size": W(18),
            "font-style": "normal",
            background: "#fff",
            cursor: "pointer"
        });
        a.getComputedStyle(d);
        e.appendChild(IH(a, b));
        e.tabIndex = 0;
        e.role = "link";
        e.ariaLabel = c;
        e.addEventListener("mouseenter", () => {
            L(f, {
                "text-decoration": "underline",
                "-webkit-text-decoration-line": "underline"
            })
        });
        e.addEventListener("mouseleave", () => {
            L(f, {
                "text-decoration": "none",
                "-webkit-text-decoration-line": "none"
            })
        });
        return e
    }

    function IH(a, b) {
        var c = Ky(a, "0 0 24 24", "24px", "24px", "M7.59009 18.59L9.00009 20L17.0001 12L9.00009 4L7.59009 5.41L14.1701 12");
        L(c, {
            fill: "#9aa0a6",
            color: "#9aa0a6",
            cursor: "inherit"
        });
        a = Ay(a, "span");
        L(a, {
            "margin-inline-start": "auto",
            "margin-inline-end": W(10),
            "font-weight": "bold",
            "align-items": "center",
            "justify-content": "center",
            "font-size": W(16)
        });
        b.V() && L(a, {
            transform: "scaleX(-1)"
        });
        a.appendChild(c);
        a.ariaHidden = "true";
        a.tabIndex = -1;
        return a
    }

    function HH(a, b) {
        var c = Ay(a, "span");
        c.appendChild(a.document.createTextNode(b));
        c.title = b;
        L(c, {
            "font-size": W(18),
            "padding-bottom": W(14),
            "padding-inline-start": W(5),
            "padding-inline-end": W(10),
            "padding-top": W(14),
            color: "#3c4043",
            width: "auto",
            "white-space": "nowrap",
            overflow: "hidden",
            "text-overflow": "ellipsis",
            "flex-shrink": "1",
            "min-width": "0"
        });
        return c
    };

    function JH(a) {
        a = Ay(a, "div");
        a.className = "goog-rentries";
        L(a, {
            display: "flex",
            "flex-direction": "row",
            width: "100%",
            "align-self": "stretch",
            "justify-content": "flex-start",
            "align-items": "center",
            "flex-shrink": "1",
            "flex-wrap": "wrap",
            "padding-bottom": W(5),
            margin: W(5),
            gap: W(2),
            "background-color": "#f8f9fa",
            "border-radius": W(4),
            border: "1px solid #dadce0",
            "box-sizing": "border-box"
        });
        return a
    }

    function KH(a, b, c) {
        var d = Ay(a, "span");
        d.innerText = C(b.R, 2);
        d.ariaLabel = C(b.R, 4);
        d.tabIndex = 0;
        d.role = "heading";
        d.ariaLevel = "2";
        L(d, {
            "font-weight": "700",
            "border-radius": W(2),
            "font-size": W(18),
            "padding-inline-start": W(16),
            "margin-bottom": W(0),
            "padding-bottom": W(14),
            "padding-top": W(14),
            color: "#4a4a4a"
        });
        a = Ay(a, "div");
        a.appendChild(d);
        L(a, {
            cursor: "inherit",
            direction: "inherit",
            "text-orientation": "inherit",
            visibility: "inherit",
            "writing-mode": "inherit",
            "font-size": W(18),
            "padding-inline-start": W(5),
            color: "#4a4a4a",
            "font-family": "Google Sans, Roboto, Arial, sans-serif",
            height: W(48),
            display: "flex",
            "flex-direction": "row",
            "justify-content": "flex-start",
            "align-items": "center"
        });
        b.M.Ng && c === 4 && L(a, {
            "background-color": "#E8F0FE",
            "border-bottom": "1px solid #DADCE0",
            "border-top-left-radius": W(4),
            "border-top-right-radius": W(4),
            width: "100%"
        });
        return a
    }

    function LH(a, b) {
        var c = b.clientHeight;
        c === 0 && (a = a.getComputedStyle(b), a = Number(a.maxHeight.replace("px", "")), isNaN(a) || (c = a));
        c = Math.max(Math.floor((c - 48 - 10) / 58), 0);
        return c === 0 ? 0 : Math.min(8, c)
    }
    async function MH(a, b, c, d, e, f, g, h = 4) {
        var k = LH(a, g);
        if (!(k < 2 || c.size < 2)) {
            Pt(a, ["Google Sans:400", "Google Sans:700"]);
            c = [...c];
            sc(f.getTermUsageCount) && c.sort((n, p) => f.getTermUsageCount(n) - f.getTermUsageCount(p));
            var l = JH(a),
                m = KH(a, d, h);
            l.appendChild(m);
            m = new jE;
            for (let n = 0; n < c.length; n++) {
                let p = c[n];
                if (n >= k) break;
                let q = h === 4 ? NH(a, b, g, d, e, m, p) : OH(a, b, g, d, e, m, p);
                l.appendChild(q);
                f.incrementTermUsageCount(p)
            }
            g.appendChild(l);
            l.appendChild(PH(a))
        }
    }

    function OH(a, b, c, d, e, f, g) {
        var h = zE(d.g.ec(), g, eC(d, g));
        TF(e, h);
        c = GH(a, d, g, c);
        var k = QH(c, d, kf(h));
        Cy(c);
        YB(d, 999, c, l => {
            try {
                if (!cC(f, d)) return !1;
                let p = b ? .document ? .body ? .tagName === "BODY" ? b : a,
                    q = bC(p, d, g);
                var m = Dp(Bp(g), kf(h));
                var n = vf(m, 11, k.wh);
                let u = Ep(H(n, 9, 5), q),
                    A = d.g.Hc(u);
                dC(f, p, d, A, g, d.O.get(g) || "", 5, !1);
                return !1
            } finally {
                l.preventDefault(), l.stopImmediatePropagation()
            }
        });
        return c
    }

    function NH(a, b, c, d, e, f, g) {
        var h = yE(d.g.ec(), g, eC(d, g));
        TF(e, h);
        c = GH(a, d, g, c);
        var k = RH(c, d, kf(h));
        Cy(c);
        YB(d, 999, c, l => {
            try {
                if (!cC(f, d)) return !1;
                let p = b ? .document ? .body ? .tagName === "BODY" ? b : a,
                    q = bC(p, d, g);
                var m = Dp(Bp(g), kf(h));
                var n = vf(m, 8, k.wh);
                let u = Ep(H(n, 9, 4), q),
                    A = d.g.Tf(u);
                dC(f, p, d, A, g, d.A.get(g) || "", 4, d.M.Mf);
                return !1
            } finally {
                l.preventDefault(), l.stopImmediatePropagation()
            }
        });
        return c
    }
    class SH {
        constructor() {
            this.A = this.l = null
        }
        get wh() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.ag,
                    d = new Xo;
                b = yf(d, 1, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.A) {
                var b = a.Zf;
                var c = new Wo;
                c = wf(c, 1, this.l);
                this.A = b.call(a, c)
            }
        }
    }
    class TH {
        constructor() {
            this.A = this.l = null
        }
        get wh() {
            return this.l
        }
        j(a, b) {
            if (!this.l) {
                var c = a.Sh,
                    d = new Vo;
                b = yf(d, 1, b);
                this.l = c.call(a, b)
            }
        }
        g(a) {
            if (this.l && !this.A) {
                var b = a.Rh;
                var c = new Uo;
                c = wf(c, 1, this.l);
                this.A = b.call(a, c)
            }
        }
    }

    function PH(a) {
        a = Ay(a, "div");
        L(a, {
            "align-self": "stretch",
            width: "100%",
            "background-color": "#dadce0",
            margin: "0",
            padding: "0"
        });
        return a
    }

    function RH(a, b, c) {
        var d = new SH;
        ZF(b, 1065, e => {
            for (let f of e) f.isIntersecting ? d.j(b.g, c) : d.g(b.g)
        }).observe(a);
        return d
    }

    function QH(a, b, c) {
        var d = new TH;
        ZF(b, 1065, e => {
            for (let f of e) f.isIntersecting ? d.j(b.g, c) : d.g(b.g)
        }).observe(a);
        return d
    };
    const UH = new Map([
        [1, 1],
        [2, 2]
    ]);
    async function VH(a, b, c, d, e, f, g, h, k) {
        var l = tA,
            m = BH(a, k) ? ? Math.floor(bl() * 20);
        k = g.oa(0);
        var n = !!a && hs(a) < 488,
            p = c.R,
            q = CH(C(p, 7)),
            u = a ? bB(a).adIntentsPageState : new aB,
            A = new Fp;
        m = uf(A, 2, m);
        m = Ye(m, 3, ld, c.M.Hd, yd, void 0, void 0, !0);
        e = new kH(q, g, k, m, d.tj ? ? new Set, B(p, 17), e, f, c.Lb, u);
        f = new FH(n, p, l, e, g, c.M, c.Lc);
        l = new FG;
        l.language = q;
        b = await WH(a, b, f, d, h, l, u);
        e.Qe(DG(l, n, c.Qa, a ? .location ? .hostname || "", c.sb, p, g.oa(11) - k, b))
    }
    async function XH(a, b, c, d, e, f, g, h, k, l, m, n = 4) {
        var p = tA,
            q = CH(C(c.R, 7)),
            u = g.oa(0),
            A = b ? bB(b).adIntentsPageState : new aB,
            D = BH(b, h) ? ? Math.floor(bl() * 20);
        h = c.R;
        var K = new Fp;
        D = uf(K, 2, D);
        D = Ye(D, 3, ld, c.M.Hd, yd, void 0, void 0, !0);
        e = new kH(q, g, u, D, d.tj ? ? new Set, B(h, 17), e, f, c.Lb, A);
        f = !!b && hs(b) < 488;
        h = new FH(f, c.R, p, e, g, c.M, c.Lc);
        p = new FG;
        p.language = q;
        q = [];
        a ? .document ? .body && YH(a.document.body) || q.push(fp());
        m || q.length || (ZH(l, a) ? await h.va(898, WF(a, b, d, k, h, p, A, l, n)) : await h.va(898, MH(a, b, k, h, p, A, l, n)));
        d = g.oa(11) -
            u;
        n === 4 ? (n = e.ai, a = a !== b, k = c.Qa, l = b ? .location ? .hostname || "", b = c.sb, c = c.R, g = new Pp, m = new ap, k = Jf(m, 1, k), k = Jf(k, 2, l), f = sf(k, 3, f), f = sf(f, 5, a), f = y(g, 1, f), b = AG(p, b), b = y(f, 3, b), b = wf(b, 5, Math.round(d)), c = BG(c), c = y(b, 2, c), q.length ? (p = new lp, p = Xe(p, 1, q), z(c, 6, Op, p)) : (q = new up, p = $e(q, p.entries), z(c, 4, Op, p)), n.call(e, c)) : e.Qe(DG(p, f, c.Qa, b ? .location ? .hostname || "", c.sb, c.R, d, q))
    }

    function ZH(a, b) {
        var c = a.clientHeight;
        c === 0 && (a = b.getComputedStyle(a), a = Number(a.maxHeight.replace("px", "")), isNaN(a) || (c = a));
        return c < 184
    }
    async function WH(a, b, c, d, e, f, g) {
        if (!a) return [ip()];
        var h = a.document.body;
        if (!h || !YH(h)) return [fp()];
        e.g.oa(3) >= e.j && await PE(e, 4);
        h = [];
        (hs(a) < 250 || is(a) < 300) && h.push(fp());
        if (mf(c.R, 1).length) {
            let k = mf(c.R, 1).map(l => UH.get(l) ? ? 0);
            h.push(kp(new gp, cp(k)))
        }
        al() && h.push(jp());
        h.length || await oG(a, b, c, d, e, f, g);
        return h
    }

    function YH(a) {
        try {
            (new ResizeObserver(() => {})).disconnect(), (new IntersectionObserver(() => {})).disconnect(), (new MutationObserver(() => {})).disconnect()
        } catch {
            return !1
        }
        return a.classList && a.classList.contains !== void 0 && a.attachShadow !== void 0
    };
    async function PE(a, b) {
        await new Promise(c => void a.win.setTimeout(c, 0));
        a.j = a.g.oa(b) + a.l
    }
    var $H = class {
        constructor(a, b) {
            var c = V(Bw);
            this.win = a;
            this.g = b;
            this.l = c;
            this.j = b.oa(2) + c
        }
    };
    async function aI(a, b, c, d, e, f, g) {
        var h = a.performance ? .now ? new eB(a.performance) : new fB,
            k = new $H(a, h);
        if (!v(e)) throw Error(`Invalid config string ${e}`);
        e = kx(e);
        var l = Te(e, hx, 1),
            m = c.google_ad_client;
        if (!v(m)) throw new qA(`Invalid property code ${m}`);
        C(e, 5) && m !== C(e, 5) || (c = bI(c), m = cI(a, m, c), a = HA(), l = dI(l), g = {
            R: Bz(b) || Te(e, hx, 1),
            Qa: c,
            sb: g,
            Lb: 1,
            M: zz(l),
            Lc: m
        }, await eI(b, d, a, g, { ...Ez(),
            ql: U(Wv),
            tl: U(Yv),
            rl: U(Xv),
            wordWindowSize: V(Aw),
            sameSearchTermPerWindow: V(Fw),
            annotationsPerWindow: V(Dw),
            maximumAnnotationsPerPage: V(Ew),
            hi: V(Gw),
            yk: V(yw),
            xk: V(xw),
            zk: V(zw)
        }, h, k, f))
    }
    async function fI(a, b, c, d, e, f, g, h = !1) {
        var k = a.performance ? .now ? new eB(a.performance) : new fB,
            l = c.google_ad_client;
        if (!v(l)) throw new qA(`Invalid property code ${l}`);
        l === C(d, 2) && (c = bI(c), l = cI(a, l, c, Te(d, hx, 1)), d = Az(b, d, c, f, dI(Te(d, hx, 1)), l), f = d.R, l = new Set(gx(f).filter(m => C(m, 12)).map(m => ex(m))), c = HA(), !h && ZH(g, a) && gI(a, g, f), await XH(a, b, d, Dz(), hI(c, k, f), [new iI(c, f)], k, e, l, g, h))
    }
    async function jI(a, b, c, d, e, f, g) {
        var h = a.performance ? .now ? new eB(a.performance) : new fB,
            k = Te(f, hx, 1);
        c = cI(a, c, d);
        d = Cz(b, f, d, e, dI(k), c);
        e = HA();
        f = new Set(gx(k).filter(l => C(l, 9)).map(l => ex(l)));
        await XH(a, b, d, Dz(), hI(e, h, k), [new iI(e, k)], h, null, f, g, !1, 5)
    }

    function gI(a, b, c) {
        Pt(a, ["Google Sans Text:500"]);
        var d = a.document.createElement("div");
        L(d, qy(a));
        d.className = "goog-rtopics";
        d.innerText = C(c, 2);
        d.ariaLabel = C(c, 4);
        d.tabIndex = 0;
        L(d, {
            cursor: "inherit",
            direction: "inherit",
            "text-orientation": "inherit",
            visibility: "inherit",
            "writing-mode": "inherit",
            "font-family": "Google Sans Text",
            "font-size": "16px",
            "font-weight": "500",
            "line-height": "24px",
            "letter-spacing": "0%",
            color: "#5F6368",
            "text-align": "center",
            "border-radius": "5px",
            "padding-left": "5px",
            "padding-right": "5px",
            "padding-top": "2px",
            "padding-bottom": "2px",
            background: "#FFFFFF"
        });
        b.appendChild(d)
    }

    function hI(a, b, c) {
        return [d => {
            tA.va(1214, SA(a, d, b.oa(26)), e => {
                e.es = dI(c)
            })
        }]
    }

    function dI(a) {
        a = [42, ...Xq(), ...(a ? .g() ? ? [])].filter(b => b > 0);
        return [...(new Set(a))].sort((b, c) => b - c)
    }

    function cI(a, b, c) {
        var d = new gz(b, $A(a), kI(a), c);
        return U(dw) ? new uz(b, $A(a), kI(a), c, d) : d
    }
    async function eI(a, b, c, d, e, f, g, h) {
        if (a) {
            let k = bB(a);
            if (k.wasReactiveAdConfigReceived[42]) return;
            k.wasReactiveAdConfigReceived[42] = !0
        }
        await VH(a, b, d, e, hI(c, f, d.R), [new iI(c, d.R)], f, g, h)
    }

    function UG(a, b) {
        lI(a, c => c.Ak, {
            ca: 1,
            ...b
        })
    }

    function XG(a, b) {
        lI(a, c => c.nn, {
            ca: 1,
            ...b
        })
    }

    function VG(a, b) {
        lI(a, c => c.Kl, {
            ca: 1,
            ...b
        })
    }

    function SG(a, b) {
        lI(a, c => c.Bk, {
            ca: 1,
            ...b
        })
    }

    function PG(a, b) {
        lI(a, c => c.on, {
            ca: 1,
            ...b
        })
    }

    function $G(a, b) {
        lI(a, c => c.Ck, {
            ca: 1,
            ...b
        })
    }

    function cH(a, b) {
        lI(a, c => c.Fk, {
            ca: 1,
            ...b
        })
    }

    function dH(a, b) {
        lI(a, c => c.Ek, {
            ca: 1,
            ...b
        })
    }

    function eH(a, b) {
        lI(a, c => c.qn, {
            ca: 1,
            ...b
        })
    }

    function fH(a, b) {
        lI(a, c => c.Rm, {
            ca: 1,
            ...b
        })
    }

    function gH(a, b) {
        lI(a, c => c.wk, {
            ca: 1,
            ...b
        })
    }

    function lI(a, b, c) {
        a.ea && a.ob.va(1214, TA(a.ea, b, c), d => {
            d.es = dI(a.g)
        })
    }

    function mI(a, b, c) {
        a.ea && a.ob.va(1214, UA(a.ea, b, c), d => {
            d.es = dI(a.g)
        })
    }
    class iI {
        constructor(a, b) {
            var c = tA;
            this.ea = a;
            this.ob = c;
            this.g = b
        }
        pg(a, b) {
            mI(this, c => c.pg, {
                Yc: a != null && Fc(a) ? Number(a) : 0,
                ...b
            })
        }
        Zh(a, b) {
            mI(this, c => c.Zh, {
                Yc: a != null && Fc(a) ? Number(a) : 0,
                ...b
            })
        }
        qg(a, b) {
            lI(this, c => c.qg, {
                ca: a,
                ...b
            })
        }
        bi(a, b) {
            lI(this, c => c.bi, {
                ca: a,
                ...b
            })
        }
        click(a) {
            lI(this, b => b.Yk, {
                ca: 1,
                ...a
            })
        }
    }

    function bI(a) {
        a = a.google_page_url;
        return v(a) ? a : ""
    }

    function kI(a) {
        return fl(a, {
            Ka: () => {}
        })
    };
    var nI = class extends Gs {
        constructor({
            pubWin: a,
            K: b,
            Ph: c,
            Qa: d,
            sb: e
        }) {
            super();
            this.g = [];
            this.pubWin = a;
            this.K = b;
            this.Ph = c;
            this.Qa = d;
            this.sb = e
        }
        j() {
            for (let a of this.g) a();
            this.g.length = 0;
            super.j()
        }
    };
    var oI = {
            Nc: "ama_success",
            Vb: .1,
            mc: !0,
            Qc: !0
        },
        pI = {
            Nc: "ama_failure",
            Vb: .1,
            mc: !0,
            Qc: !0
        },
        qI = {
            Nc: "ama_coverage",
            Vb: .1,
            mc: !0,
            Qc: !0
        },
        rI = {
            Nc: "ama_opt",
            Vb: .1,
            mc: !0,
            Qc: !1
        },
        sI = {
            Nc: "ama_auto_rs",
            Vb: 1,
            mc: !0,
            Qc: !1
        },
        tI = {
            Nc: "ama_reltops",
            Vb: 1,
            mc: !0,
            Qc: !1
        },
        uI = {
            Nc: "ama_constraints",
            Vb: 0,
            mc: !0,
            Qc: !0
        };

    function vI(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && Wl(c.stack, "") || "");
        wI(a.ea, tI, { ...b,
            evt: "place",
            vh: is(a.win),
            eid: GG(a.g.l() ? .g()) || 0,
            hl: x(a.g, xI, 5) ? .g() || ""
        })
    }
    var yI = class {
        constructor(a, b, c) {
            this.win = a;
            this.ea = b;
            this.g = c
        }
    };
    var zI = class extends J {
        setProperty(a) {
            return If(this, 1, a)
        }
        getValue() {
            return pf(this, 2)
        }
    };
    var AI = class extends J {};
    var BI = class extends J {
        xa() {
            return x(this, mu, 1)
        }
        g() {
            return qf(this, 2)
        }
    };
    var CI = class extends J {};
    var DI = class extends J {
        xa() {
            return x(this, mu, 1)
        }
        g() {
            return qf(this, 2)
        }
    };
    var EI = class extends J {};
    var FI = class extends J {
        g() {
            return Ve(this, EI, 1, w())
        }
    };

    function GI(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];
            var c = a.className ? a.className.split(/\s+/) : [];a = {};
            for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
            for (c = 0; c < b.length; ++c)
                if (!a[b[c]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    }

    function HI(a) {
        return ws(a.querySelectorAll("ins.adsbygoogle-ablated-ad-slot"))
    };

    function II(a, b) {
        a = Jj(new qj(a), "DIV");
        var c = a.style;
        c.width = "100%";
        c.height = "auto";
        c.clear = b ? "both" : "none";
        return a
    }

    function JI(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    let d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        GI(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    }

    function KI(a) {
        if (a && a.parentNode) {
            let b = a.parentNode;
            b.removeChild(a);
            GI(b) && (b.style.display = b.getAttribute("data-init-display") || "none")
        }
    };
    var MI = (a, b, c, d = 0) => {
            var e = LI(b, c, d);
            if (e.init) {
                for (c = b = e.init; c = e.nf(c);) b = c;
                e = {
                    anchor: b,
                    position: e.If
                }
            } else e = {
                anchor: b,
                position: c
            };
            a["google-ama-order-assurance"] = d;
            JI(a, e.anchor, e.position)
        },
        NI = (a, b, c, d = 0) => {
            U(Cv) ? MI(a, b, c, d) : JI(a, b, c)
        };

    function LI(a, b, c) {
        var d = f => {
                f = OI(f);
                return f == null ? !1 : c < f
            },
            e = f => {
                f = OI(f);
                return f == null ? !1 : c > f
            };
        switch (b) {
            case 0:
                return {
                    init: PI(a.previousSibling, d),
                    nf: f => PI(f.previousSibling, d),
                    If: 0
                };
            case 2:
                return {
                    init: PI(a.lastChild, d),
                    nf: f => PI(f.previousSibling, d),
                    If: 0
                };
            case 3:
                return {
                    init: PI(a.nextSibling, e),
                    nf: f => PI(f.nextSibling, e),
                    If: 3
                };
            case 1:
                return {
                    init: PI(a.firstChild, e),
                    nf: f => PI(f.nextSibling, e),
                    If: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function OI(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function PI(a, b) {
        return a && b(a) ? a : null
    };

    function QI(a, b) {
        do {
            let c = il(a, b);
            if (c && c.position === "fixed") return !1
        } while (a = a.parentElement);
        return !0
    }

    function RI(a, b, c) {
        var d;
        return a.style && !!a.style[c] && ml(a.style[c]) || (d = il(a, b)) && !!d[c] && ml(d[c]) || null
    }

    function SI(a, b) {
        try {
            let c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function TI(a, b) {
        return (a = SI(a, b)) ? a.y : 0
    }

    function UI(a, b) {
        a = TI(a, b);
        b = is(b);
        return a < b - 100
    }

    function VI(a, b) {
        var c = RI(b, a, "height");
        if (c) return c;
        var d = b.style.height;
        b.style.height = "inherit";
        c = RI(b, a, "height");
        b.style.height = d;
        if (c) return c;
        c = Infinity;
        do(d = b.style && ml(b.style.height)) && (c = Math.min(c, d)), (d = RI(b, a, "maxHeight")) && (c = Math.min(c, d)); while (b.parentElement && (b = b.parentElement) && b.tagName !== "HTML");
        return c
    };

    function WI(a, b) {
        var c;
        return a.style && a.style.zIndex || (c = il(a, b)) && c.zIndex || null
    };

    function XI(a, b) {
        for (let c = 0; c < b.length; c++) {
            let d = b[c],
                e = nj(d.property);
            a[e] = d.value
        }
    }

    function YI(a, b, c, d, e, f) {
        a = ZI(a, e);
        a.Hb.setAttribute("data-ad-format", d ? d : "auto");
        $I(a, b, c, f);
        return a
    }

    function aJ(a, b, c = null) {
        a = ZI(a, {});
        $I(a, b, null, c);
        return a
    }

    function $I(a, b, c, d) {
        var e = [];
        if (d = d && d.Ii) a.qd.className = d.join(" ");
        a = a.Hb;
        a.className = "adsbygoogle";
        a.setAttribute("data-ad-client", b);
        c && a.setAttribute("data-ad-slot", c);
        e.length && a.setAttribute("data-ad-channel", e.join("+"))
    }

    function ZI(a, b) {
        var c = II(a, b.clearBoth || !1),
            d = c.style;
        d.textAlign = "center";
        b.Hf && XI(d, b.Hf);
        a = Jj(new qj(a), "INS");
        d = a.style;
        d.display = "block";
        d.margin = "auto";
        d.backgroundColor = "transparent";
        b.ji && (d.marginTop = b.ji);
        b.sg && (d.marginBottom = b.sg);
        b.Rd && XI(d, b.Rd);
        c.appendChild(a);
        return {
            qd: c,
            Hb: a
        }
    }

    function bJ(a, b, c, d = null) {
        b.dataset.adsbygoogleStatus = "reserved";
        b.className += " adsbygoogle-noablate";
        var e = {
            element: b
        };
        c = c && c.ke();
        if (d) c = d.LmpfC ? ? c, e.ofxVI = {
            recYb: d
        };
        else if (b.hasAttribute("data-pub-vars")) {
            try {
                c = JSON.parse(b.getAttribute("data-pub-vars"))
            } catch (f) {
                return
            }
            b.removeAttribute("data-pub-vars")
        }
        c && (e.params = c);
        (a.adsbygoogle = a.adsbygoogle || []).push(e)
    }

    function cJ(a) {
        var b = a.fqjyf;
        if (b != null)
            for (let e of HI(a.document)) {
                var c = a,
                    d = TI(e, c);
                c = is(c);
                if (d < c) continue;
                if (d = dJ(e, b)) e.removeAttribute("height"), e.style.removeProperty("height"), e.removeAttribute("width"), e.style.removeProperty("width"), bJ(a, e, null, d)
            }
    }

    function dJ(a, b) {
        return (a = a.getAttribute("google_element_uid")) ? b && b[a] || null : null
    };
    var fJ = (a, b, c) => {
        if (!b || !c) return !1;
        var d = b.parentElement,
            e = c.parentElement;
        if (!d || !e || d != e) return !1;
        d = 0;
        for (b = b.nextSibling; d < 10 && b;) {
            if (b == c) return !0;
            if (eJ(a, b)) break;
            b = b.nextSibling;
            d++
        }
        return !1
    };
    const eJ = (a, b) => {
        if (b.nodeType == 3) return b.nodeType == 3 ? (b = b.data, a = b.indexOf("&") != -1 ? jj(b, a.document) : b, a = /\S/.test(a)) : a = !1, a;
        if (b.nodeType == 1) {
            var c = a.getComputedStyle(b);
            if (c.opacity == "0" || c.display == "none" || c.visibility == "hidden") return !1;
            if ((c = b.tagName) && Ds.contains(c.toUpperCase())) return !0;
            b = b.childNodes;
            for (c = 0; c < b.length; c++)
                if (eJ(a, b[c])) return !0
        }
        return !1
    };
    var gJ = a => {
        if (a >= 460) return a = Math.min(a, 1200), Math.ceil(a < 800 ? a / 4 : 200);
        a = Math.min(a, 600);
        return a <= 420 ? Math.ceil(a / 1.2) : Math.ceil(a / 1.91) + 130
    };
    var hJ = class {
        constructor() {
            this.g = {
                clearBoth: !0
            }
        }
        j(a, b, c, d) {
            return YI(d.document, a, null, null, this.g, b)
        }
        l(a) {
            return gJ(Math.min(a.screen.width || 0, a.screen.height || 0))
        }
    };
    var iJ = class extends J {};
    var jJ = class extends J {};
    var kJ = class extends J {
        l() {
            return pf(this, 2)
        }
        g() {
            return pf(this, 5)
        }
        A() {
            return Ve(this, jJ, 3, w())
        }
        B() {
            return ff(this, 4)
        }
        C() {
            return De(this, 6)
        }
        O() {
            return ze(this, iJ, 7)
        }
    };
    var lJ = class extends J {};
    var mJ = class extends J {
        A() {
            return B(this, 12)
        }
        l() {
            return cf(this, 13)
        }
        g() {
            return ef(this, 23)
        }
    };
    var nJ = class extends J {};

    function oJ(a) {
        return De(a, 1, ue)
    }
    var pJ = class extends J {
        g() {
            return qf(this, 3)
        }
        l() {
            return of(this, 6)
        }
    };
    var qJ = class extends J {};
    var rJ = class extends J {};
    var sJ = class extends J {};
    var tJ = class extends J {};
    var uJ = class extends J {
            getName() {
                return pf(this, 4)
            }
        },
        vJ = [1, 2, 3];
    var wJ = class extends J {
        g() {
            return x(this, pJ, 10)
        }
    };

    function xJ(a) {
        return of(a, 1)
    }
    var yJ = class extends J {
        g() {
            return of(this, 2)
        }
        l() {
            return ef(this, 2)
        }
        A() {
            return of(this, 3)
        }
    };
    var zJ = class extends J {
        g() {
            return cf(this, 1, ue)
        }
    };
    var AJ = class extends J {
        g() {
            return hf(this, 1)
        }
    };
    var xI = class extends J {
        g() {
            return C(this, 1)
        }
        l() {
            return C(this, 2)
        }
    };
    var BJ = class extends J {
        A() {
            return B(this, 1)
        }
        B() {
            return B(this, 3)
        }
        C() {
            return B(this, 7)
        }
        g() {
            return B(this, 4)
        }
        l() {
            return B(this, 5)
        }
    };
    var CJ = class extends J {
        l() {
            return x(this, AJ, 6)
        }
        A() {
            return B(this, 14)
        }
        g() {
            return x(this, BJ, 12)
        }
    };
    var DJ = class extends J {};
    var EJ = class extends J {};
    var FJ = class extends J {},
        GJ = yh(FJ);
    var HJ = class extends J {
        g() {
            return hf(this, 1)
        }
    };
    var IJ = class extends J {};
    var KJ = class extends J {
            g() {
                return nf(this, IJ, 2, JJ)
            }
        },
        JJ = [1, 2];
    var LJ = class extends J {
        g() {
            return x(this, KJ, 3)
        }
    };
    var MJ = class extends J {};
    var NJ = class extends J {
        g() {
            return Ve(this, MJ, 1, w())
        }
    };
    var OJ = class extends J {
        g() {
            return Ee(this, 1, Gd, w())
        }
        l() {
            return x(this, LJ, 3)
        }
    };
    var PJ = class extends J {};
    var QJ = class extends J {};

    function RJ(a) {
        return Ve(a, DI, 1, w())
    }

    function SJ(a) {
        return x(a, CJ, 28)
    }
    var TJ = yh(class extends J {
        g() {
            return x(this, mJ, 15)
        }
    });

    function UJ(a) {
        var b = [];
        vs(a.getElementsByTagName("p"), function(c) {
            VJ(c) >= 100 && b.push(c)
        });
        return b
    }

    function VJ(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        var b = 0;
        vs(a.childNodes, function(c) {
            b += VJ(c)
        });
        return b
    }

    function WJ(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function XJ(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function YJ(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.A)
        } catch (d) {}
        if (!c.length) return [];
        b = nb(c);
        b = XJ(a, b);
        typeof a.j === "number" && (c = a.j, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.l === "number") {
            c = [];
            for (let d = 0; d < b.length; d++) {
                let e = UJ(b[d]),
                    f = a.l;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    var ZJ = class {
        constructor(a, b, c, d) {
            this.A = a;
            this.j = b;
            this.l = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.A,
                occurrenceIndex: this.j,
                paragraphIndex: this.l,
                ignoreMode: this.g
            })
        }
    };
    var $J = class {
        constructor() {
            this.g = ni `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        Da(a, b, c = .01, d = "jserror") {
            if (Math.random() > c) return !1;
            b.error && b.meta && b.id || (b = new Tl(b, {
                context: a,
                id: d
            }));
            r.google_js_errors = r.google_js_errors || [];
            r.google_js_errors.push(b);
            r.error_rep_loaded || (gl(r.document, this.g), r.error_rep_loaded = !0);
            return !1
        }
        uc(a, b) {
            try {
                return b()
            } catch (c) {
                if (!this.Da(a, c, .01, "jserror")) throw c;
            }
        }
        wc(a, b, c) {
            return (...d) => this.uc(a, () => b.apply(c, d))
        }
        va(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.Da(a, c instanceof Error ? c : Error(c), void 0)
            })
        }
    };

    function aK(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function bK(a, b, c, d, e = !1) {
        var f = d || window,
            g = typeof queueMicrotask !== "undefined";
        return function(...h) {
            e && g && queueMicrotask(() => {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var k = vm(),
                l = 3;
            try {
                var m = b.apply(this, h)
            } catch (n) {
                l = 13;
                if (!c) throw n;
                c(a, n)
            } finally {
                f.google_measure_js_timing && k && aK({
                    label: a.toString(),
                    value: k,
                    duration: (vm() || 0) - k,
                    type: l,
                    ...(e && g && {
                        taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                    })
                }, f)
            }
            return m
        }
    }

    function cK(a, b) {
        return bK(754, a, (c, d) => {
            (new $J).Da(c, d)
        }, b, !0)
    };

    function dK(a, b, c) {
        return bK(a, b, void 0, c, !0).apply()
    }

    function eK(a, b) {
        return cK(a, b).apply()
    }

    function fK(a) {
        if (!a) return null;
        var b = pf(a, 7);
        if (pf(a, 1) || a.getId() || Ee(a, 4, Gd, w()).length > 0) {
            var c = a.getId(),
                d = pf(a, 1),
                e = Ee(a, 4, Gd, w());
            b = ff(a, 2, ue);
            var f = ff(a, 5, ue);
            a = gK(qf(a, 6));
            let g = "";
            d && (g += d);
            c && (g += "#" + WJ(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + WJ(e[c]);
            b = (e = g) ? new ZJ(e, b, f, a) : null
        } else b = b ? new ZJ(b, ff(a, 2, ue), ff(a, 5, ue), gK(qf(a, 6))) : null;
        return b
    }
    const hK = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function gK(a) {
        return a == null ? a : hK[a]
    }

    function iK(a) {
        var b = [];
        for (let c = 0; c < a.length; c++) {
            let d = pf(a[c], 1),
                e = a[c].getValue();
            d && e != null && b.push({
                property: d,
                value: e
            })
        }
        return b
    }

    function jK(a, b) {
        var c = {};
        a && (c.ji = pf(a, 1), c.sg = pf(a, 2), c.clearBoth = !! of (a, 3));
        b && (c.Hf = iK(Ve(b, zI, 3, w()).map(d => Td(d))), c.Rd = iK(Ve(b, zI, 4, w()).map(d => Td(d))));
        return c
    }
    const kK = {
            1: 0,
            2: 1,
            3: 2,
            4: 3
        },
        lK = {
            0: 1,
            1: 2,
            2: 3,
            3: 4
        };
    var mK = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            return YI(d.document, a, null, null, this.g, b)
        }
        l() {
            return null
        }
    };
    var nK = class {
        constructor(a) {
            this.j = a
        }
        g(a) {
            a = Math.floor(a.j);
            var b = gJ(a);
            return new yu(["ap_container"], {
                google_reactive_ad_format: 27,
                google_responsive_auto_format: 16,
                google_max_num_ads: 1,
                google_ad_type: this.j,
                google_ad_format: a + "x" + b,
                google_ad_width: a,
                google_ad_height: b
            })
        }
    };
    var oK = class {
        constructor(a, b) {
            this.A = a;
            this.l = b
        }
        j() {
            return this.A
        }
        g() {
            return this.l
        }
    };
    var pK = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            var e = Ve(this.g, AI, 9, w()).length > 0 ? Ve(this.g, AI, 9, w())[0] : null,
                f = jK(Te(this.g, CI, 3), e);
            if (!e) return null;
            if (e = pf(e, 1)) {
                d = d.document;
                var g = c.tagName;
                c = Jj(new qj(d), g);
                c.style.clear = f.clearBoth ? "both" : "none";
                g == "A" && (c.style.display = "block");
                c.style.padding = "0px";
                c.style.margin = "0px";
                f.Hf && XI(c.style, f.Hf);
                d = Jj(new qj(d), "INS");
                f.Rd && XI(d.style, f.Rd);
                c.appendChild(d);
                f = {
                    qd: c,
                    Hb: d
                };
                f.Hb.setAttribute("data-ad-type", "text");
                f.Hb.setAttribute("data-native-settings-key",
                    e);
                $I(f, a, null, b);
                a = f
            } else a = null;
            return a
        }
        l() {
            var a = Ve(this.g, AI, 9, w()).length > 0 ? Ve(this.g, AI, 9, w())[0] : null;
            if (!a) return null;
            a = Ve(a, zI, 3, w());
            for (let b = 0; b < a.length; b++) {
                let c = a[b];
                if (pf(c, 1) == "height" && parseInt(c.getValue(), 10) > 0) return parseInt(c.getValue(), 10)
            }
            return null
        }
    };
    var qK = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            if (!this.g) return null;
            var e = this.g.google_ad_format || null,
                f = this.g.google_ad_slot || null;
            if (c = c.style) {
                var g = [];
                for (let h = 0; h < c.length; h++) {
                    let k = c.item(h);
                    k !== "width" && k !== "height" && g.push({
                        property: k,
                        value: c.getPropertyValue(k)
                    })
                }
                c = {
                    Rd: g
                }
            } else c = {};
            a = YI(d.document, a, f, e, c, b);
            a.Hb.setAttribute("data-pub-vars", JSON.stringify(this.g));
            return a
        }
        l() {
            return this.g ? parseInt(this.g.google_ad_height, 10) || null : null
        }
        ke() {
            return this.g
        }
    };
    var rK = class {
        constructor(a) {
            this.j = a
        }
        g() {
            return new yu([], {
                google_ad_type: this.j,
                google_reactive_ad_format: 26,
                google_ad_format: "fluid"
            })
        }
    };
    var sK = class {
        constructor(a, b) {
            this.A = a;
            this.l = b
        }
        g() {
            return this.l
        }
        j(a) {
            a = YJ(this.A, a.document);
            return a.length > 0 ? a[0] : null
        }
    };

    function tK(a, b, c) {
        var d = [];
        for (let p = 0; p < a.length; p++) {
            a: {
                var e = a[p];
                var f = p,
                    g = b,
                    h = c,
                    k = e.xa();
                if (!k) {
                    e = null;
                    break a
                }
                var l = fK(k);
                if (!l) {
                    e = null;
                    break a
                }
                var m = e.g();m = kK[m];
                var n = m === void 0 ? null : m;
                if (n === null) {
                    e = null;
                    break a
                }
                m = (m = x(e, CI, 3)) ? of (m, 3) : null;l = new sK(l, n);n = mf(e, 10).slice(0);ff(k, 5) != null && n.push(1);k = ff(e, 12, ue);
                let q = ze(e, wu, 4) ? x(e, wu, 4) : null;gd(ve(e, 8)) == 1 ? (h = h && h.Ok || null, e = new uK(l, new mK(jK(x(e, CI, 3), null)), h, m, 0, n, q, g, f, k, e)) : e = gd(ve(e, 8)) == 2 ? new uK(l, new pK(e), h && h.am || new rK("text"),
                    m, 1, n, q, g, f, k, e) : null
            }
            e !== null && d.push(e)
        }
        return d
    }

    function vK(a) {
        return a.A
    }

    function wK(a) {
        return a.Aa
    }

    function xK(a) {
        return a.D instanceof qK ? a.D.ke() : null
    }

    function yK(a, b, c) {
        xs(a.T, b) || a.T.set(b, []);
        a.T.get(b).push(c)
    }

    function zK(a) {
        return II(a.j.document, a.G || !1)
    }

    function AK(a) {
        return a.D.l(a.j)
    }

    function BK(a, b = null) {
        return new uK(a.O, new CK, b || a.W, a.G, a.Dd, a.Cd, a.Rf, a.j, a.pa, a.C, a.l, a.B, a.Z)
    }
    var uK = class {
        constructor(a, b, c, d, e, f, g, h, k, l = null, m = null, n = null, p = null) {
            this.O = a;
            this.D = b;
            this.W = c;
            this.G = d;
            this.Dd = e;
            this.Cd = f;
            this.Rf = g ? g : new wu;
            this.j = h;
            this.pa = k;
            this.C = l;
            this.l = m;
            (a = !m) || ((a = !m.xa()) || (m = m.xa(), a = ff(m, 5) == null), a = !!a);
            this.Aa = !a;
            this.B = n;
            this.Z = p;
            this.J = [];
            this.A = !1;
            this.T = new Bs
        }
        Ba() {
            return this.j
        }
        g() {
            return this.O.g()
        }
    };

    function DK(a, b, c, d, e, f) {
        var g = vu();
        return new uK(new oK(c, e), new hJ, new nK(a), !0, 2, [], g, d, null, null, null, b, f)
    }

    function EK(a, b, c, d, e) {
        var f = vu();
        return new uK(new oK(b, d), new mK({
            clearBoth: !0
        }), null, !0, 2, [], f, c, null, null, null, a, e)
    };
    var FK = class {
        constructor(a, b, c) {
            this.articleStructure = a;
            this.element = b;
            this.win = c
        }
        Ba() {
            return this.win
        }
        B(a) {
            return DK(a, this.articleStructure, this.element, this.win, 3, null)
        }
        j() {
            return EK(this.articleStructure, this.element, this.win, 3, null)
        }
    };
    const GK = {
        TABLE: {
            ae: new Zt([1, 2])
        },
        THEAD: {
            ae: new Zt([0, 3, 1, 2])
        },
        TBODY: {
            ae: new Zt([0, 3, 1, 2])
        },
        TR: {
            ae: new Zt([0, 3, 1, 2])
        },
        TD: {
            ae: new Zt([0, 3])
        }
    };

    function HK(a, b, c, d) {
        var e = c.childNodes;
        c = c.querySelectorAll(b);
        b = [];
        for (let f of c) c = ab(e, f), c < 0 || b.push(new IK(a, [f], c, f, 3, Cj(f).trim(), d));
        return b
    }

    function JK(a, b, c) {
        var d = [],
            e = [],
            f = b.childNodes,
            g = f.length,
            h = 0,
            k = "";
        for (let n = 0; n < g; n++) {
            var l = f[n];
            if (l.nodeType != 1 && l.nodeType != 3) continue;
            a: {
                if (l.nodeType != 1) {
                    var m = null;
                    break a
                }
                if (l.tagName == "BR") {
                    m = l;
                    break a
                }
                m = c.getComputedStyle(l).getPropertyValue("display");m = m == "inline" || m == "inline-block" ? null : l
            }
            if (m) {
                d.length && k && e.push(new IK(a, d, n - 1, m, 0, k, c));
                d = [];
                h = n + 1;
                k = "";
                continue
            }
            d.push(l);
            l = Cj(l).trim();
            k += l && k ? " " + l : l
        }
        d.length && k && e.push(new IK(a, d, h, b, 2, k, c));
        return e
    }

    function KK(a, b) {
        return a.g - b.g
    }
    var IK = class {
        constructor(a, b, c, d, e, f, g) {
            this.A = a;
            this.Ve = b.slice(0);
            this.g = c;
            this.dg = d;
            this.eg = e;
            this.C = f;
            this.l = g
        }
        Ba() {
            return this.l
        }
        B(a) {
            return DK(a, this.A, this.dg, this.l, this.eg, this.g)
        }
        j() {
            return EK(this.A, this.dg, this.l, this.eg, this.g)
        }
    };

    function LK(a) {
        return mb(a.C ? JK(a.g, a.l, a.j) : [], a.B ? HK(a.g, a.B, a.l, a.j) : []).filter(b => {
            var c = b.dg.tagName;
            c ? (c = GK[c.toUpperCase()], b = c != null && c.ae.contains(b.eg)) : b = !1;
            return !b
        })
    }
    var MK = class {
        constructor(a, b, c) {
            this.l = a;
            this.B = b.Te;
            this.C = b.Wi;
            this.g = b.articleStructure;
            this.j = c;
            this.A = b.Ai
        }
    };

    function NK(a, b) {
        if (!b) return !1;
        var c = sa(b),
            d = a.g.get(c);
        if (d != null) return d;
        if (b.nodeType == 1 && (b.tagName == "UL" || b.tagName == "OL") && a.j.getComputedStyle(b).getPropertyValue("list-style-type") != "none") return a.g.set(c, !0), !0;
        b = NK(a, b.parentNode);
        a.g.set(c, b);
        return b
    }

    function OK(a, b) {
        return hb(b.Ve, c => NK(a, c))
    }
    var PK = class {
        constructor(a) {
            this.g = new Bs;
            this.j = a
        }
    };
    var QK = class {
        constructor(a, b) {
            this.A = a;
            this.g = [];
            this.j = [];
            this.l = b
        }
    };
    var SK = (a, {
            jj: b = !1,
            Yh: c = !1,
            uj: d = c ? 2 : 3,
            Wh: e = null
        } = {}) => {
            a = LK(a);
            return RK(a, {
                jj: b,
                Yh: c,
                uj: d,
                Wh: e
            })
        },
        RK = (a, {
            jj: b = !1,
            Yh: c = !1,
            uj: d = c ? 2 : 3,
            Wh: e = null
        } = {}) => {
            if (d < 2) throw Error("minGroupSize should be at least 2, found " + d);
            var f = a.slice(0);
            f.sort(KK);
            a = [];
            b = new QK(b, e);
            for (let g of f) {
                e = {
                    Jf: g,
                    vf: g.C.length < 51 ? !1 : b.l != null ? !OK(b.l, g) : !0
                };
                if (b.A || e.vf) {
                    a: {
                        if (!b.g.length) {
                            f = !0;
                            break a
                        }
                        f = b.g[b.g.length - 1].Jf;f = fJ(f.Ba(), f.Ve[f.Ve.length - 1], e.Jf.Ve[0])
                    }
                    f ? (b.g.push(e), e.vf && b.j.push(e.Jf)) : (b.g = [e], b.j = e.vf ? [e.Jf] : [])
                }
                if (b.j.length >= d) {
                    a: {
                        e = b;f = c ? 0 : 1;
                        if (f < 0 || f >= e.j.length) {
                            e = null;
                            break a
                        }
                        for (f = e.j[f]; e.g.length && !e.g[0].vf;) e.g.shift();e.g.shift();e.j.shift();e = f
                    }
                    e && a.push(e)
                }
            }
            return a
        };
    var UK = (a, b, c = !1) => {
            a = TK(a, b);
            var d = new PK(b);
            return Tt(a, e => SK(e, {
                Yh: c,
                Wh: d
            }))
        },
        VK = (a, b) => {
            a = TK(a, b);
            var c = new PK(b);
            return Tt(a, d => {
                if (d.A) {
                    var e = d.g;
                    var f = d.j;
                    d = d.l.querySelectorAll(d.A);
                    var g = [];
                    for (var h of d) g.push(new FK(e, h, f));
                    e = g
                } else e = [];
                d = e.slice(0);
                if (d.length) {
                    e = [];
                    f = d[0];
                    for (g = 1; g < d.length; g++) {
                        let m = d[g];
                        h = f;
                        b: {
                            if (h.element.hasAttributes())
                                for (l of h.element.attributes)
                                    if (l.name.toLowerCase() === "style" && l.value.toLowerCase().includes("background-image")) {
                                        var k = !0;
                                        break b
                                    }
                            k = h.element.tagName;
                            k = k === "IMG" || k === "SVG"
                        }(k || h.element.textContent.length > 1) && !NK(c, f.element) && fJ(m.Ba(), f.element, m.element) && e.push(f);
                        f = m
                    }
                    var l = e
                } else l = [];
                return l
            })
        },
        TK = (a, b) => {
            var c = new Bs;
            a.forEach(d => {
                var e = fK(Te(d, mu, 1));
                if (e) {
                    var f = e.toString();
                    xs(c, f) || c.set(f, {
                        articleStructure: d,
                        Ik: e,
                        Te: null,
                        Wi: !1,
                        Ai: null
                    });
                    e = c.get(f);
                    (f = (f = x(d, mu, 2)) ? pf(f, 7) : null) ? e.Te = e.Te ? e.Te + "," + f : f: e.Wi = !0;
                    d = x(d, mu, 4);
                    e.Ai = d ? pf(d, 7) : null
                }
            });
            return As(c).map(d => {
                var e = YJ(d.Ik, b.document);
                return e.length ? new MK(e[0], d, b) : null
            }).filter(d =>
                d != null)
        };
    var WK = a => a ? .google_ad_slot ? $t(new nu(1, {
            tk: a.google_ad_slot
        })) : bu(Error("Missing dimension when creating placement id")),
        YK = a => {
            switch (a.Dd) {
                case 0:
                case 1:
                    var b = a.l;
                    b == null ? a = null : (a = b.xa(), a == null ? a = null : (b = b.g(), a = b == null ? null : new nu(0, {
                        Bi: [a],
                        Mj: b
                    })));
                    return a != null ? $t(a) : bu(Error("Missing dimension when creating placement id"));
                case 2:
                    return a = XK(a), a != null ? $t(a) : bu(Error("Missing dimension when creating placement id"));
                default:
                    return bu(Error("Invalid type: " + a.Dd))
            }
        };
    const XK = a => {
        if (a == null || a.B == null) return null;
        var b = x(a.B, mu, 1),
            c = x(a.B, mu, 2);
        if (b == null || c == null) return null;
        var d = a.Z;
        if (d == null) return null;
        a = a.g();
        return a == null ? null : new nu(0, {
            Bi: [b, c],
            Zl: d,
            Mj: lK[a]
        })
    };

    function ZK(a) {
        var b = xK(a.ta);
        return (b ? WK(b) : YK(a.ta)).map(c => ru(c))
    }

    function $K(a) {
        a.g = a.g || ZK(a);
        return a.g
    }

    function aL(a, b) {
        if (a.ta.A) throw Error("AMA:AP:AP");
        NI(b, a.xa(), a.ta.g());
        a = a.ta;
        a.A = !0;
        b != null && a.J.push(b)
    }
    const bL = class {
        constructor(a, b, c) {
            this.ta = a;
            this.j = b;
            this.Fa = c;
            this.g = null
        }
        xa() {
            return this.j
        }
        fill(a, b) {
            var c = this.ta;
            (a = c.D.j(a, b, this.j, c.j)) && aL(this, a.qd);
            return a
        }
    };

    function cL(a, b) {
        return eK(() => {
            var c = [],
                d = [];
            try {
                var e = [];
                for (var f = 0; f < a.length; f++) {
                    var g = a[f],
                        h = g.O.j(g.j);
                    h && e.push({
                        Hj: g,
                        anchorElement: h
                    })
                }
                for (g = 0; g < e.length; g++) {
                    f = d;
                    var k = f.push; {
                        var l = e[g];
                        let u = l.anchorElement,
                            A = l.Hj;
                        var m = A.G;
                        let D = A.j.document.createElement("div");
                        D.className = "google-auto-placed";
                        let K = D.style;
                        K.textAlign = "center";
                        K.width = "100%";
                        K.height = "0px";
                        K.clear = m ? "both" : "none";
                        h = D;
                        try {
                            NI(h, u, A.g());
                            var n = h
                        } catch (I) {
                            throw KI(h), I;
                        }
                    }
                    k.call(f, n)
                }
                let p = qs(b),
                    q = rs(b);
                for (k = 0; k < d.length; k++) {
                    let u =
                        d[k].getBoundingClientRect(),
                        A = e[k];
                    c.push(new bL(A.Hj, A.anchorElement, new Kt(u.left + q, u.top + p, u.right - u.left)))
                }
            } finally {
                for (e = 0; e < d.length; e++) KI(d[e])
            }
            return c
        }, b)
    };
    const dL = {
            1: "0.5vp",
            2: "300px"
        },
        eL = [1E3, 930, 880, 830, 780, 730, 680, 630, 580, 530, 480, 430, 380, 350, 330, 310, 290, 270, 250, 230, 220, 210, 200, 190, 180, 170, 160, 150, 140, 130, 125, 120, 115, 110, 105, 100, 95, 90, 85, 80, 78, 76, 74, 72, 70, 68, 66, 64, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50],
        fL = {
            1: 700,
            2: 1200
        },
        gL = {
            [1]: {
                Yj: "3vp",
                ci: "1vp",
                Xj: "0.3vp"
            },
            [2]: {
                Yj: "900px",
                ci: "300px",
                Xj: "90px"
            }
        };

    function hL(a) {
        return eL.reduce((b, c) => {
            var d = Math.abs(b - a),
                e = Math.abs(c - a);
            return e === d ? c < b ? c : b : e < d ? c : b
        }, 530)
    }

    function iL(a, b, c) {
        var d = jL(a),
            e = is(a) || fL[d];
        if (U(jv)) {
            var f = V(lv),
                g = V(mv);
            let h = V(kv);
            if (f && g && h) return b = b ? ? .5, b = b < .5 ? g + (1 - 2 * b) * (f - g) : h + (2 - 2 * b) * (g - h), U(Jv) && (b = hL(b)), a = new pJ, a = vf(a, 4, 8), b = xe(a, 5, Xc(b)), kL(b, lL(d, e))
        }
        f = void 0;
        c && (f = (c = (c = mL(Ve(c, kJ, 2, w()), d)) ? x(c, iJ, 7) : void 0) ? nL(c, e) : void 0);
        c = f;
        f = jL(a);
        a = is(a) || fL[f];
        g = oL(gL[f].ci, a);
        a = g === null ? lL(f, a) : new pL(g, g, qL(g, 8), 8, .3, c);
        c = oL(gL[d].Yj, e);
        f = oL(gL[d].ci, e);
        d = oL(gL[d].Xj, e);
        e = a.l;
        c && d && f && b !== void 0 && (e = b <= .5 ? f + (1 - 2 * b) * (c - f) : d + (2 - 2 * b) *
            (f - d));
        d = new pL(e, e, qL(e, a.j), a.j, a.C, a.g);
        return rL(d, null, b ? ? null)
    }

    function kL(a, b) {
        var c = GG(cf(a, 4, ue)),
            d = De(a, 5, ue);
        return c == null || d == null ? b : rL(new pL(d, 0, [], c, 1), a, null)
    }

    function sL(a, b) {
        var c = jL(a),
            d = is(a) || fL[c];
        if (U(ov)) return iL(a, .5);
        if (!b) return lL(c, d);
        if (a = mL(Ve(b, kJ, 2, w()), c))
            if (a = tL(a, d)) return a;
        return lL(c, d)
    }

    function uL(a) {
        var b = jL(a);
        a = is(a) || fL[b];
        return lL(b, a)
    }

    function rL(a, b, c) {
        b = vL(b, c);
        return b == null ? a : new pL(a.l, a.B, a.A, a.j, b, a.g)
    }

    function wL(a, b) {
        var c = {
            te: a.l,
            Vc: a.B
        };
        for (let d of a.A) d.adCount <= b && (c = d.He);
        return c
    }

    function vL(a, b) {
        var c = V(uv);
        if (c <= 0) return null;
        if (U(pv)) return c;
        if (!U(qv) || !a && !b) return null;
        if (a && a.g() === 2) a = String(cf(a, 4, ue)) === "8" && De(a, 5, ue) === 530;
        else {
            if (!b) return null;
            a = b === .5
        }
        return a ? c : null
    }

    function xL(a, b, c) {
        var d = of (b, 2);
        b = x(b, kJ, 1);
        var e = jL(c);
        var f = is(c) || fL[e];
        c = oL(b ? .l(), f) ? ? a.l;
        e = oL(b ? .g(), f) ? ? a.B;
        d = d ? [] : yL(b ? .A(), f) ? ? a.A;
        var g = b ? .B() ? ? a.j,
            h = b ? .C() ? ? a.C;
        a = (b ? .O() ? nL(x(b, iJ, 7), f) : null) ? ? a.g;
        return new pL(c, e, d, g, h, a)
    }

    function zL(a, b) {
        var c = jL(b),
            d = new lJ,
            e = new kJ,
            f = !1,
            g = V(tv);
        g >= 0 && (tf(e, 4, g), f = !0);
        g = null;
        c === 1 ? (c = V(yv), c >= 0 && (g = c + "vp")) : (c = V(xv), c >= 0 && (g = c + "px"));
        c = V(wv);
        c >= 0 && (g = c + "px");
        g !== null && (If(e, 2, g), f = !0);
        c = U(Av) ? "0px" : null;
        c !== null && (If(e, 5, c), f = !0);
        if (U(Bv)) rf(d, 2, !0), f = !0;
        else if (c !== null || g !== null) {
            let m = [];
            for (let n of a.A) {
                var h = m,
                    k = h.push;
                var l = new jJ;
                l = tf(l, 1, n.adCount);
                l = If(l, 3, c ? ? n.He.Vc + "px");
                l = If(l, 2, g ? ? n.He.te + "px");
                k.call(h, l)
            }
            Xe(e, 3, m)
        }
        return f ? (y(d, 1, e), xL(a, d, b)) : a
    }
    var pL = class {
        constructor(a, b, c, d, e, f) {
            this.l = a;
            this.B = b;
            this.A = c.sort((g, h) => g.adCount - h.adCount);
            this.j = d;
            this.C = e;
            this.g = f
        }
    };

    function mL(a, b) {
        for (let c of a)
            if (gd(ve(c, 1)) == b) return c;
        return null
    }

    function yL(a, b) {
        if (a === void 0) return null;
        var c = [];
        for (let d of a) {
            a = ff(d, 1, ue);
            let e = oL(pf(d, 2), b),
                f = oL(pf(d, 3), b);
            if (typeof a !== "number" || e === null) return null;
            c.push({
                adCount: a,
                He: {
                    te: e,
                    Vc: f
                }
            })
        }
        return c
    }

    function tL(a, b) {
        var c = oL(a.l(), b),
            d = oL(a.g(), b);
        if (c === null) return null;
        var e = ff(a, 4, ue);
        if (e == null) return null;
        var f = a.A();
        f = yL(f, b);
        if (f === null) return null;
        var g = x(a, iJ, 7);
        b = g ? nL(g, b) : void 0;
        return new pL(c, d, f, e, De(a, 6, ue), b)
    }

    function lL(a, b) {
        a = oL(dL[a], b);
        return U(ov) ? new pL(a === null ? Infinity : a, null, [], 8, .3) : new pL(a === null ? Infinity : a, null, [], 3, null)
    }

    function oL(a, b) {
        if (!a) return null;
        var c = parseFloat(a);
        return isNaN(c) ? null : a.endsWith("px") ? c : a.endsWith("vp") ? c * b : null
    }

    function jL(a) {
        a = hs(a) >= 900;
        return Vk() && !a ? 1 : 2
    }

    function qL(a, b) {
        if (b < 4) return [];
        var c = Math.ceil(b / 2);
        return [{
            adCount: c,
            He: {
                te: a * 2,
                Vc: a * 2
            }
        }, {
            adCount: c + Math.ceil((b - c) / 2),
            He: {
                te: a * 3,
                Vc: a * 3
            }
        }]
    }

    function nL(a, b) {
        var c = oL(pf(a, 2), b) || 0,
            d = ff(a, 3, ue) || 1;
        a = oL(pf(a, 1), b) || 0;
        return {
            vj: c,
            qj: d,
            Ud: a
        }
    };

    function AL(a, b, c) {
        return as({
            top: a.g.top - (c + 1),
            right: a.g.right + (c + 1),
            bottom: a.g.bottom + (c + 1),
            left: a.g.left - (c + 1)
        }, b.g)
    }

    function BL(a) {
        if (!a.length) return null;
        var b = bs(a.map(c => c.g));
        a = a.reduce((c, d) => c + d.j, 0);
        return new CL(b, a)
    }
    var CL = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
    };
    var DL = xA(453, Uz),
        EL = xA(454, function(a, b) {
            var c = Vz(b, ".google-auto-placed"),
                d = Wz(b),
                e = Xz(b),
                f = Yz(b),
                g = Zz(b),
                h = $z(b),
                k = Vz(b, "div.googlepublisherpluginad");
            b = Vz(b, "html > ins.adsbygoogle");
            return aA([...(a.uf === !0 ? c : []), ...(a.yd === !0 ? d : []), ...(a.Xl === !0 ? e : []), ...(a.fh === !0 ? f : []), ...(a.gh === !0 ? g : []), ...(a.Ul === !0 ? h : []), ...(a.Wl === !0 ? k : []), ...(a.Yl === !0 ? b : [])])
        });

    function FL(a, b, c, d = !1) {
        d = GL(a, d);
        b = HL(d, b, c);
        return new IL(a, d, b)
    }

    function JL(a) {
        return (a.bottom - a.top) * (a.right - a.left) > 1
    }

    function KL(a) {
        return a.g.map(b => b.box)
    }

    function LL(a) {
        return a.g.reduce((b, c) => b + c.box.bottom - c.box.top, 0)
    }
    var IL = class {
        constructor(a, b, c) {
            this.l = a;
            this.g = b.slice(0);
            this.A = c.slice(0);
            this.j = null
        }
    };

    function GL(a, b = !1) {
        b = DL({
            yd: !1,
            Bl: b
        }, a);
        var c = rs(a),
            d = qs(a);
        return b.map(e => {
            var f = e.getBoundingClientRect();
            return (e = cA(e)) || JL(f) ? {
                box: {
                    top: f.top + d,
                    right: f.right + c,
                    bottom: f.bottom + d,
                    left: f.left + c
                },
                Wo: e ? 1 : 0
            } : null
        }).filter(vi(e => e === null))
    }

    function HL(a, b, c) {
        return b != void 0 && a.length <= (c != void 0 ? c : 8) ? ML(a, b) : eb(a, d => new CL(d.box, 1))
    }

    function ML(a, b) {
        a = eb(a, d => new CL(d.box, 1));
        for (var c = []; a.length > 0;) {
            let d = a.pop(),
                e = !0;
            for (; e;) {
                e = !1;
                for (let f = 0; f < a.length; f++)
                    if (AL(d, a[f], b)) {
                        d = BL([d, a[f]]);
                        Array.prototype.splice.call(a, f, 1);
                        e = !0;
                        break
                    }
            }
            c.push(d)
        }
        return c
    };

    function NL(a, b, c) {
        var d = Jt(c, b);
        return !hb(a, e => as(e, d))
    }

    function OL(a, b, c, d, e) {
        e = e.Fa;
        var f = Jt(e, b),
            g = Jt(e, c),
            h = Jt(e, d);
        return !hb(a, k => as(k, g) || as(k, f) && !as(k, h))
    }

    function PL(a, b, c, d) {
        var e = KL(a);
        if (NL(e, b, d.Fa)) return !0;
        if (!OL(e, b, c.vj, c.Ud, d)) return !1;
        var f = new CL(Jt(d.Fa, 0), 1);
        a = db(a.A, g => AL(g, f, c.Ud));
        b = gb(a, (g, h) => g + h.j);
        return a.length === 0 || b > c.qj ? !1 : !0
    };
    var QL = (a, b) => {
        var c = [],
            d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function RL(a, b) {
        var c = new ju,
            d = new Cs;
        b.forEach(e => {
            if (nf(e, sJ, 1, vJ)) {
                e = nf(e, sJ, 1, vJ);
                if (x(e, BI, 1) && x(e, BI, 1).xa() && x(e, BI, 2) && x(e, BI, 2).xa()) {
                    let g = SL(a, x(e, BI, 1).xa()),
                        h = SL(a, x(e, BI, 2).xa());
                    if (g && h)
                        for (var f of QL({
                                anchor: g,
                                position: x(e, BI, 1).g()
                            }, {
                                anchor: h,
                                position: x(e, BI, 2).g()
                            })) c.set(sa(f.anchor), f.position)
                }
                x(e, BI, 3) && x(e, BI, 3).xa() && (f = SL(a, x(e, BI, 3).xa())) && c.set(sa(f), x(e, BI, 3).g())
            } else nf(e, tJ, 2, vJ) ? TL(a, nf(e, tJ, 2, vJ), c) : nf(e, rJ, 3, vJ) && UL(a, nf(e, rJ, 3, vJ), d)
        });
        return new VL(c, d)
    }
    var VL = class {
        constructor(a, b) {
            this.j = a;
            this.g = b
        }
    };
    const TL = (a, b, c) => {
            x(b, BI, 2) ? (b = x(b, BI, 2), (a = SL(a, b.xa())) && c.set(sa(a), b.g())) : x(b, mu, 1) && (a = WL(a, x(b, mu, 1))) && a.forEach(d => {
                d = sa(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        UL = (a, b, c) => {
            x(b, mu, 1) && (a = WL(a, x(b, mu, 1))) && a.forEach(d => {
                c.add(sa(d))
            })
        },
        SL = (a, b) => (a = WL(a, b)) && a.length > 0 ? a[0] : null,
        WL = (a, b) => (b = fK(b)) ? YJ(b, a) : null;
    var XL = class {
        constructor() {
            var a = Math.random;
            this.g = Math.floor(a() * 2 ** 52);
            this.j = 0
        }
    };

    function YL(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (ZL(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function $L(a) {
        a = aM(a);
        return a.has("all") || a.has("after")
    }

    function bM(a) {
        a = aM(a);
        return a.has("all") || a.has("before")
    }

    function aM(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function ZL(a) {
        var b = aM(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var cM = class {
        constructor() {
            this.g = new Set;
            this.j = new XL
        }
    };

    function dM(a) {
        return function(b) {
            return cL(b, a)
        }
    }

    function eM(a) {
        var b = is(a);
        return b ? Ba(fM, b + qs(a)) : si
    }

    function gM(a, b, c) {
        if (a < 0) throw Error("ama::ead:nd");
        if (a === Infinity) return si;
        var d = KL(c || FL(b));
        return e => NL(d, a, e.Fa)
    }

    function hM(a, b, c, d) {
        if (a < 0 || b.vj < 0 || b.qj < 0 || b.Ud < 0) throw Error("ama::ead:nd");
        return a === Infinity ? si : e => PL(d || FL(c, b.Ud), a, b, e)
    }

    function iM(a) {
        if (!a.length) return si;
        var b = new Zt(a);
        return c => b.contains(c.Dd)
    }

    function jM(a) {
        return function(b) {
            for (let c of b.Cd)
                if (a.indexOf(c) > -1) return !1;
            return !0
        }
    }

    function kM(a) {
        return a.length ? function(b) {
            var c = b.Cd;
            return a.some(d => c.indexOf(d) > -1)
        } : ti
    }

    function lM(a, b) {
        if (a <= 0) return ti;
        var c = ms(b).scrollHeight - a;
        return function(d) {
            return d.Fa.g <= c
        }
    }

    function mM(a) {
        var b = {};
        a && a.forEach(c => {
            b[c] = !0
        });
        return function(c) {
            return !b[qf(c.Rf, 2) || 0]
        }
    }

    function nM(a) {
        return a.length ? b => a.includes(qf(b.Rf, 1) || 0) : ti
    }

    function oM(a, b) {
        var c = RL(a, b);
        return function(d) {
            var e = d.xa();
            d = d.ta.g();
            d = lK[d];
            var f = c.j,
                g = sa(e);
            f = f.g.get(g);
            if (!(f = f ? f.contains(d) : !1)) a: {
                if (c.g.contains(sa(e))) switch (d) {
                    case 2:
                    case 3:
                        f = !0;
                        break a;
                    default:
                        f = !1;
                        break a
                }
                for (e = e.parentElement; e;) {
                    if (c.g.contains(sa(e))) {
                        f = !0;
                        break a
                    }
                    e = e.parentElement
                }
                f = !1
            }
            return !f
        }
    }

    function pM() {
        var a = new cM;
        return function(b) {
            var c = b.xa();
            b = b.ta.g();
            var d = lK[b];
            a: switch (d) {
                case 1:
                    b = $L(c.previousElementSibling) || bM(c);
                    break a;
                case 4:
                    b = $L(c) || bM(c.nextElementSibling);
                    break a;
                case 2:
                    b = bM(c.firstElementChild);
                    break a;
                case 3:
                    b = $L(c.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + d);
            }
            c = YL(a, c, d);
            d = a.j;
            zA("ama_exclusion_zone", {
                typ: b ? c ? "siuex" : "siex" : c ? "suex" : "noex",
                cor: d.g,
                num: d.j++,
                dvc: $k()
            }, .1);
            return !(b || c)
        }
    }
    const fM = (a, b) => b.Fa.g >= a,
        qM = (a, b, c) => {
            c = c.Fa.j;
            return a <= c && c <= b
        };

    function rM(a, b, c, d, e) {
        var f = sM(tM(a, b), a);
        if (f.length === 0) {
            var g = !!x(b, FI, 6) ? .g() ? .length;
            f = SJ(b) ? .g() ? .l() && g ? sM(uM(a, b), a) : f
        }
        if (f.length === 0) return vI(d, "pfno"), [];
        b = f;
        a = e.td ? vM(a, b, c) : {
            qb: b,
            Rb: null
        };
        var {
            qb: h,
            Rb: k
        } = a;
        f = h;
        return f.length === 0 && k ? (vI(d, k), []) : [f[e.mi ? 0 : e.li ? Math.floor(f.length / 4) : Math.floor(f.length / 2)]]
    }

    function vM(a, b, c) {
        c = c ? Ve(c, uJ, 5, w()) : [];
        var d = oM(a.document, c),
            e = pM();
        b = b.filter(f => d(f));
        if (b.length === 0) return {
            qb: [],
            Rb: "pfaz"
        };
        b = b.filter(f => e(f));
        return b.length === 0 ? {
            qb: [],
            Rb: "pfet"
        } : {
            qb: b,
            Rb: null
        }
    }

    function wM(a, b) {
        return a.Fa.g - b.Fa.g
    }

    function tM(a, b) {
        var c = x(b, FI, 6);
        if (!c) return [];
        b = SJ(b) ? .g();
        return (b ? .g() ? VK(c.g(), a) : UK(c.g(), a, !!b ? .A())).map(d => d.j())
    }

    function uM(a, b) {
        b = RJ(b) || [];
        return tK(b, a, {}).filter(c => !c.Cd.includes(6))
    }

    function sM(a, b) {
        a = cL(a, b);
        var c = eM(b);
        a = a.filter(d => c(d));
        return a.sort(wM)
    };

    function xM(a) {
        var b = zK(a.j.ta),
            c = a.C.Bb(a.B, () => yM(a));
        b.appendChild(c);
        a.A && (b.className = a.A);
        return {
            wl: b,
            fl: c
        }
    }

    function yM(a) {
        a.g && a.g.parentNode && a.g.parentNode.removeChild(a.g);
        a.g = null;
        a.l.g(null)
    }
    var zM = class {
        constructor(a, b, c, d) {
            this.B = a;
            this.j = b;
            this.C = c;
            this.A = d || null;
            this.g = null;
            this.l = new O(null)
        }
        init() {
            var a = xM(this);
            this.g = a.wl;
            aL(this.j, this.g);
            this.l.g(a.fl)
        }
    };
    async function AM(a) {
        await new Promise(b => {
            setTimeout(() => {
                try {
                    BM(a)
                } catch (c) {
                    vI(a.Ra, "pfere", c)
                }
                b()
            })
        })
    }

    function BM(a) {
        if (!CM({
                ja: a.ja,
                Ra: a.Ra
            })) {
            var b = a.g.g();
            b = rM(a.win, a.config, a.ja, a.Ra, {
                mi: !!b ? .B(),
                td: !0,
                Am: !!b ? .g(),
                li: !!b ? .C()
            });
            var c = DM(b.slice(0, 1), a.win),
                d = Object.keys(c),
                e = Object.values(c).map(({
                    Hn: g
                }) => g);
            if (!x(a.config, yJ, 25) ? .l() && d.length !== 0) {
                var f = async () => {
                    e.forEach(g => {
                        yM(g)
                    })
                };
                dK(1661, () => {
                    var g = new nI({
                        pubWin: a.win,
                        K: a.win.top,
                        Ph: a.webPropertyCode,
                        Qa: a.win.location.href,
                        sb: a.win.location.href
                    });
                    Is(g, f);
                    jI(g.pubWin, g.K, g.Ph, g.Qa, g.sb, a.j, c[d[0]].Ym)
                }, a.win)
            }
        }
    }
    var EM = class {
        constructor(a, b, c, d, e) {
            this.win = a;
            this.config = c;
            this.webPropertyCode = d;
            this.ja = e;
            this.g = SJ(this.config);
            this.j = x(this.config, QJ, 37);
            this.Ra = new yI(a, b, this.g)
        }
    };

    function CM({
        ja: a,
        Ra: b
    }) {
        return (a ? mf(a, 2) : []).length === 0 ? (vI(b, "pfeu"), !0) : !1
    }

    function DM(a, b) {
        var c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            let f = "reltops-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            L(g, qy(b));
            L(g, {
                "max-height": "1000px"
            });
            d = new zM(b, d, {
                Bb: () => g
            }, "reltops-widget");
            d.init();
            c[f] = {
                Hn: d,
                Ym: g
            }
        }
        return c
    };
    var FM = class extends J {},
        GM = yh(FM);

    function HM(a) {
        try {
            let b = a.localStorage.getItem("google_ama_settings");
            return b ? GM(b) : null
        } catch (b) {
            return null
        }
    }

    function IM(a, b) {
        if (a.Jg !== void 0) {
            var c = HM(b);
            c || (c = new FM);
            a.Jg !== void 0 && rf(c, 2, a.Jg);
            a = Date.now() + 864E5;
            Number.isFinite(a) && vf(c, 1, Math.round(a));
            c = xg(c);
            try {
                b.localStorage.setItem("google_ama_settings", c)
            } catch (d) {}
        } else {
            if (c = a = HM(b)) c = hf(a, 1), c = BigInt(c) < Date.now();
            if (c) try {
                b.localStorage.removeItem("google_ama_settings")
            } catch (d) {}
        }
    };

    function JM(a, b) {
        wI(a.ea, sI, { ...b,
            evt: "place",
            vh: is(a.win),
            eid: GG(a.g.l() ? .g()) || 0,
            hl: x(a.g, xI, 5) ? .g() || ""
        })
    }

    function KM(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && Wl(c.stack, "") || "");
        JM(a, b)
    }
    var LM = class {
        constructor(a, b, c) {
            this.win = a;
            this.ea = b;
            this.g = c
        }
    };
    var MM = class {
        constructor(a) {
            this.g = a
        }
        Bb(a) {
            var b = a.document.createElement("div");
            L(b, qy(a));
            L(b, {
                width: "100%",
                "max-width": "1000px",
                margin: "auto"
            });
            b.appendChild(this.g);
            var c = a.document.createElement("div");
            L(c, qy(a));
            L(c, {
                width: "100%",
                "text-align": "center",
                display: "block",
                padding: "5px 5px 2px",
                "box-sizing": "border-box",
                "background-color": "#FFF"
            });
            c.appendChild(b);
            return c
        }
    };

    function NM(a, b, c, d, e) {
        var f = OM(PM(a, b), a);
        if (f.length === 0) {
            var g = !!x(b, FI, 6) ? .g() ? .length;
            f = SJ(b) ? .g() ? .l() && g ? OM(QM(a, b), a) : f
        }
        if (f.length === 0) return KM(d, "pfno"), [];
        b = f;
        a = e.td ? RM(a, b, c) : {
            qb: b,
            Rb: null
        };
        var {
            qb: h,
            Rb: k
        } = a;
        f = h;
        return f.length === 0 && k ? (KM(d, k), []) : [f[e.mi ? 0 : e.li ? Math.floor(f.length / 4) : Math.floor(f.length / 2)]]
    }

    function RM(a, b, c) {
        c = c ? Ve(c, uJ, 5, w()) : [];
        var d = oM(a.document, c),
            e = pM();
        b = b.filter(f => d(f));
        if (b.length === 0) return {
            qb: [],
            Rb: "pfaz"
        };
        b = b.filter(f => e(f));
        return b.length === 0 ? {
            qb: [],
            Rb: "pfet"
        } : {
            qb: b,
            Rb: null
        }
    }

    function SM(a, b) {
        return a.Fa.g - b.Fa.g
    }

    function PM(a, b) {
        var c = x(b, FI, 6);
        if (!c) return [];
        b = SJ(b) ? .g();
        return (b ? .g() ? VK(c.g(), a) : UK(c.g(), a, !!b ? .A())).map(d => d.j())
    }

    function QM(a, b) {
        b = RJ(b) || [];
        return tK(b, a, {}).filter(c => !c.Cd.includes(6))
    }

    function OM(a, b) {
        a = cL(a, b);
        var c = eM(b);
        a = a.filter(d => c(d));
        return a.sort(SM)
    };
    var TM = class {
        constructor(a) {
            this.L = a.L;
            this.jc = a.jc;
            this.jd = a.jd;
            this.host = a.location.host;
            this.origin = a.location.origin;
            this.language = a.language;
            this.zh = a.zh;
            this.Tg = a.Tg;
            this.we = a.we;
            this.Uj = !!a.Uj;
            this.alwaysSetAdSafeHigh = !!a.alwaysSetAdSafeHigh
        }
        postMessage(a, b) {
            a ? .postMessage(b, "https://www.gstatic.com")
        }
        init() {
            this.L.setAttribute("id", "prose-iframe");
            this.L.setAttribute("width", "100%");
            this.L.setAttribute("height", "100%");
            this.L.style.cssText = "box-sizing:border-box;border:unset;";
            var a = this.L;
            var b = ni `https://www.gstatic.com/prose/protected/${this.we||"558153351"}/iframe.html?cx=${this.jc}&host=${this.host}&hl=${this.language}&lrh=${this.zh}&client=${this.jd}&origin=${this.origin}`;
            b = this.Uj ? oi(b, {
                soo: 1
            }) : b;
            dj(a, b)
        }
    };

    function UM(a, b) {
        return $k() === 2 ? aE(a.win, b, {
            Fj: .95,
            Zi: .95,
            zIndex: 2147483645,
            de: !0
        }) : kD(a.win, b, {
            kf: "min(65vw, 768px)",
            Ic: "",
            ff: !1,
            zIndex: 2147483645,
            de: !0,
            Vh: !1
        })
    }

    function VM(a) {
        ((d, e) => {
            d[e] = d[e] || function() {
                (d[e].q = d[e].q || []).push(arguments)
            };
            d[e].t = (new Date).getTime()
        })(a.win, "_googCsa");
        var b = a.We.map(d => ({
                container: d,
                relatedSearches: 5
            })),
            c = {
                pubId: a.jd,
                styleId: "5134551505",
                hl: a.language,
                fexp: a.B.join(","),
                channel: "AutoRsVariant",
                resultsPageBaseUrl: "http://google.com",
                resultsPageQueryParam: "q",
                relatedSearchTargeting: "content",
                relatedSearchResultClickedCallback: a.T.bind(a),
                relatedSearchUseResultCallback: !0,
                cx: a.jc
            };
        a.G && (c.adLoadedCallback = a.J.bind(a));
        a.win._googCsa("relatedsearch", c, b)
    }

    function WM(a) {
        a.win.addEventListener("message", b => {
            b.origin === "https://www.gstatic.com" && b.data.action === "resize" && (a.g.style.height = `${Math.ceil(b.data.height)+1}px`)
        })
    }
    var XM = class extends Gs {
        constructor(a) {
            super();
            this.win = a.win;
            this.We = a.We;
            this.Ra = a.Ra;
            this.Mh = a.Mh ? ? (() => {});
            this.language = a.oj ? .g() || "en";
            this.G = U(Hv);
            this.jd = a.webPropertyCode.replace("ca", "partner");
            this.C = new qj(this.win.document);
            this.g = Jj(this.C, "IFRAME");
            this.jc = a.hk.g ? a.hk.jc : "9d449ff4a772956c6";
            this.B = Xq().concat(a.experimentId ? a.experimentId : []);
            var b = a.oj ? .l() || "Search results from ${website}";
            this.l = new TM({
                L: this.g,
                jc: this.jc,
                jd: this.jd,
                location: this.win.location,
                language: this.language,
                zh: b,
                Tg: this.B,
                we: a.we,
                alwaysSetAdSafeHigh: a.alwaysSetAdSafeHigh
            });
            this.D = UM(this, this.g);
            Hs(this, this.D)
        }
        init() {
            this.We.length !== 0 && (this.G || dK(1075, () => {
                this.l.init()
            }, this.win), dK(1076, () => {
                var a = Jj(this.C, "SCRIPT");
                fj(a, ni `https://www.google.com/adsense/search/async-ads.js`);
                this.win.document.head.appendChild(a)
            }, this.win), VM(this), JM(this.Ra, {
                sts: "ok"
            }), WM(this))
        }
        J(a, b) {
            b ? dK(1075, () => {
                this.l.init()
            }, this.win) : (this.Mh(), KM(this.Ra, "pfns"))
        }
        T(a, b) {
            var c = this.l,
                d = c.L.contentWindow;
            a = {
                action: "search",
                searchTerm: a,
                rsToken: b
            };
            a.experimentId = c.Tg;
            c.alwaysSetAdSafeHigh && (a.alwaysSetAdSafeHigh = "1");
            c.postMessage(d, a);
            this.D.show()
        }
    };
    var YM = class {
        constructor(a, b) {
            this.g = a;
            this.jc = b
        }
    };
    async function ZM(a) {
        await new Promise(b => {
            setTimeout(() => {
                try {
                    $M(a)
                } catch (c) {
                    KM(a.Ra, "pfere", c)
                }
                b()
            })
        })
    }

    function $M(a) {
        if ((!a.td || !aN(a.config, a.ja, a.Ra)) && bN(x(a.g, xI, 5), a.Ra)) {
            var b = a.g.g();
            b = NM(a.win, a.config, a.ja, a.Ra, {
                mi: !!b ? .B(),
                td: a.td,
                Am: !!b ? .g(),
                li: !!b ? .C()
            });
            b = cN(b, a.win);
            var c = Object.keys(b),
                d = Object.values(b),
                e = GG(a.g.l() ? .g()),
                f = dN(a.g),
                g = String(C(a.g, 13));
            b = x(a.config, yJ, 25) ? .g() || !1;
            var h = a.g ? .A() || !1;
            if (!b) {
                var k = () => {
                    d.forEach(l => {
                        yM(l)
                    })
                };
                dK(1074, () => {
                    var l = {
                        win: a.win,
                        We: c,
                        webPropertyCode: a.webPropertyCode,
                        oj: x(a.g, xI, 5),
                        Ra: a.Ra,
                        experimentId: e,
                        hk: f,
                        we: g,
                        Mh: k,
                        alwaysSetAdSafeHigh: h
                    };
                    (new XM(l)).init()
                }, a.win)
            }
        }
    }
    var eN = class {
        constructor(a, b, c, d, e) {
            this.win = a;
            this.config = c;
            this.webPropertyCode = d;
            this.ja = e;
            this.td = !0;
            this.g = SJ(this.config);
            this.Ra = new LM(a, b, this.g)
        }
    };

    function aN(a, b, c) {
        a = GG(SJ(a) ? .l() ? .g());
        var d = oy(Mv);
        return d && a && d.includes(a.toString()) ? !1 : (b ? mf(b, 2) : []).length === 0 ? (KM(c, "pfeu"), !0) : !1
    }

    function bN(a, b) {
        var c = oy(Lv);
        a = a ? .g() || "";
        return c && c.length !== 0 && !c.includes(a.toString()) ? (KM(b, "pflna"), !1) : !0
    }

    function cN(a, b) {
        var c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            let f = "autors-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            d = new zM(b, d, new MM(g), "autors-widget");
            d.init();
            c[f] = d
        }
        return c
    }

    function dN(a) {
        var b = B(a, 11) || !1;
        a = C(a, 8) || "";
        return new YM(b, a)
    };
    var fN = (a, b) => {
        var c = [];
        x(a, FJ, 18) && c.push(2);
        b.ja && c.push(0);
        if (b = SJ(a)) b = SJ(a), b = F(b, 1) == 1;
        b && (x(a, QJ, 37) ? c.push(3) : c.push(1));
        x(a, PJ, 38) && c.push(4);
        return c
    };
    var gN = a => a.googlefc = a.googlefc || {},
        hN = a => {
            a = a.googlefc = a.googlefc || {};
            return a.__fcusi = a.__fcusi || {}
        },
        iN = a => {
            a = a.googlefc = a.googlefc || {};
            if (!a.getFloatingToolbarTranslatedMessages) return null;
            if (a = a.getFloatingToolbarTranslatedMessages()) {
                var b = new DJ;
                b = If(b, 1, a.defaultFloatingToolbarToggleExpansionText);
                b = If(b, 2, a.defaultFloatingToolbarTogglePrivacySettings);
                a = If(b, 3, a.defaultFloatingToolbarDismissPrivacySettings);
                a = pe(a)
            } else a = null;
            return a
        };

    function jN(a, b) {
        b = b.filter(c => x(c, wu, 4) ? .g() === 5 && gd(ve(c, 8)) === 1);
        b = tK(b, a);
        a = cL(b, a);
        a.sort((c, d) => d.Fa.g - c.Fa.g);
        return a[0] || null
    };

    function kN(a) {
        var b = {},
            c = a.Cl,
            d = a.bl,
            e = a.Sk,
            f = a.ln,
            g = a.Tk;
        a = a.Rk;
        b = b && b.rb;
        return vx('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"' + (b ? ' nonce="' + S(Zx(b)) + '"' : "") + '/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500,700" rel="stylesheet"' + (b ? ' nonce="' + S(Zx(b)) + '"' : "") + "><style" + (b ? ' nonce="' + S(Zx(b)) + '"' : "") + ">.ft-styless-button {border: none; background: none; user-select: none; cursor: pointer; border-radius: " +
            T(16) + "px;}.ft-container {position: fixed;}.ft-menu {position: absolute; bottom: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); min-height: " + T(e) + "px;}.ft-menu:not(.ft-multiple-buttons *) {transition: padding 0.25s 0.25s, margin 0.25s 0.25s, border-radius 0.25s 0.25s, background-color 0s 0.5s; padding: 0; margin: " + T(a) + "px; border-radius: " + T(16) + "px; background-color: rgba(255, 255, 255, 0);}.ft-multiple-buttons .ft-menu {transition: margin 0.25s, padding 0.25s, border-radius 0.25s 0.25s, background-color 0s; padding: " +
            T(a) + "px; margin: 0; border-radius: " + T(16 + a) + "px; background-color: rgba(255, 255, 255, 1);}.ft-left-pos .ft-menu {left: 0;}.ft-right-pos .ft-menu {right: 0;}.ft-container.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}.ft-container:not(.ft-hidden) {transition: opacity 0.25s, bottom 0.5s ease; opacity: 1;}.google-symbols {font-size: 26px; color: #3c4043;}.ft-button-holder {display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 0;}.ft-flip-vertically {transform: scaleY(-1);}.ft-expand-toggle {width: " +
            T(e) + "px; height: " + T(e) + "px;}.ft-collapsed .ft-expand-icon {transition: transform 0.25s; transform: rotate(180deg);}.ft-expand-icon:not(.ft-collapsed *) {transition: transform 0.25s; transform: rotate(0deg);}.ft-button {position: relative; height: " + T(e) + "px; margin-bottom: " + T(g) + "px; transform: margin 0.25s 0.25s;}.ft-button.ft-last-button {margin-bottom: 0;}.ft-button > button {position: relative; height: " + T(e) + "px; width: " + T(e) + "px; margin: 0; padding: 0; border: none;}.ft-button > button > * {position: relative;}.ft-button .ft-highlighter {position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); height: " +
            T(e - 6) + "px; width: " + T(e - 6) + "px; border-radius: " + T(e / 2) + "px; background-color: #d2e3fc; opacity: 0; transition: opacity 0.25s;}.ft-button.ft-highlighted .ft-highlighter {opacity: 1;}.ft-button-corner-info {display: none;}.ft-button.ft-show-corner-info .ft-button-corner-info {position: absolute; left: -5px; top: 4px; background: #b3261e; border: 1.5px solid #ffffff; box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3), 0 1px 3px 1px rgba(60, 64, 67, 0.15); border-radius: 100px; color: ffffff; font-family: 'Google Sans Text'; font-style: normal; font-weight: 700; font-size: 11px; line-height: 14px; min-width: 16px; height: 16px; display: flex; flex-direction: row; justify-content: center; align-items: center;}.ft-separator {display: block; width: 100%; height: " +
            T(f) + "px;}.ft-separator > span {display: block; width: 28px; margin: 0 auto 10px auto; height: 0; border-bottom: 1px solid #dadce0;}.ft-expand-toggle-container {height: " + T(e) + "px;}.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}:not(.ft-hidden) {transition: opacity 0.25s; opacity: 1;}.ft-collapsed .ft-collapsible, .ft-collapsible.ft-collapsed, .ft-expand-toggle-container.ft-collapsed {transition: opacity 0.25s, margin 0.25s 0.25s, height 0.25s 0.25s, overflow 0.25s 0s, visibility 1s 0s; height: 0; opacity: 0; overflow: hidden; visibility: hidden; margin: 0;}.ft-collapsible:not(.ft-collapsed *):not(.ft-collapsed), .ft-expand-toggle-container:not(.ft-collapsed) {transition: margin 0.25s, height 0.25s, opacity 0.25s 0.25s; opacity: 1;}.ft-symbol-font-load-test {position: fixed; left: -1000px; top: -1000px; font-size: 26px; visibility: hidden;}.ft-reg-bubble {position: absolute; bottom: 0; padding: 10px 10px 0 10px; background: #fff; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); border-radius: " +
            T(16) + "px; max-width: calc(90vw - " + T(e * 2) + "px); width: 300px; height: 200px;}.ft-left-pos .ft-reg-bubble {left: " + T(e + 10 + a) + "px;}.ft-right-pos .ft-reg-bubble {right: " + T(e + 10 + a) + "px;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-collapsed {transition: width 0.25s ease-in 0.25s, height 0.25s ease-in 0.25s, opacity 0.05s linear 0.45s, overflow 0s 0.25s, visibility 0s 0.5s; width: 0; overflow: hidden; opacity: 0; visibility: hidden;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-no-messages {height: 0 !important;}.ft-reg-bubble:not(.ft-collapsed *):not(.ft-collapsed) {transition: width 0.25s ease-out, height 0.25s ease-out, opacity 0.05s linear;}.ft-reg-bubble-content {display: flex; flex-direction: row; max-width: calc(90vw - " +
            T(e * 2) + 'px); width: 300px;}.ft-collapsed .ft-reg-bubble-content {transition: opacity 0.25s; opacity: 0;}.ft-reg-bubble-content:not(.ft-collapsed *) {transition: opacity 0.25s 0.25s; opacity: 1;}.ft-reg-message-holder {flex-grow: 1; display: flex; flex-direction: column; height: auto;}.ft-reg-controls {flex-grow: 0; padding-left: 5px;}.ft-reg-bubble-close-icon {font-size: 16px;}.ft-reg-message {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; padding-bottom: 5px; margin-bottom: 5px; border-bottom: 1px solid #dadce0;}.ft-reg-message-custom h1 {display: flex; align-items: center; gap: 5px; font-weight: 500; font-size: 14px; line-height: 14px; margin: 0 0 10px 0; padding: 0;}.ft-reg-message-custom p {margin: 10px 0 0 0; padding: 0;}.ft-reg-message-custom a, .ft-reg-message-custom a:link, .ft-reg-message-custom a:visited, .ft-reg-message-custom a:hover, .ft-reg-message-custom a:active {color: #0b57d0; text-decoration: none;}.ft-reg-message:last-of-type {border-bottom: none;}.ft-reg-message-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0; text-align: start;}.ft-display-none {display: none;}</style><toolbar id="ft-floating-toolbar" class="ft-container ft-hidden"><div class="ft-menu"><div class="ft-button-holder"></div><div class="ft-separator ft-collapsible ft-collapsed"><span></span></div><div class="ft-bottom-button-holder"></div><div class="ft-expand-toggle-container"><button class="ft-expand-toggle ft-styless-button" aria-controls="ft-floating-toolbar" aria-label="' +
            S(c) + '"><span class="google-symbols ft-expand-icon" aria-hidden="true">expand_more</span></button></div></div><div id="ft-reg-bubble" class="ft-reg-bubble ft-collapsed ft-no-messages"><div class="ft-reg-bubble-content"><div class="ft-reg-message-holder"></div><div class="ft-reg-controls"><button class="ft-reg-bubble-close ft-styless-button" aria-controls="ft-reg-bubble" aria-label="' + S(d) + '"><span class="google-symbols ft-reg-bubble-close-icon" aria-hidden="true">close</span></button></div></div></div></toolbar><span inert class="ft-symbol-font-load-test"><span class="ft-symbol-reference google-symbols" aria-hidden="true">keyboard_double_arrow_right</span><span class="ft-text-reference" aria-hidden="true">keyboard_double_arrow_right</span></span>')
    }

    function lN(a) {
        var b = a.googleIconName,
            c = a.backgroundColorCss,
            d = a.iconColorCss;
        return vx('<div class="ft-button ft-collapsible ft-collapsed ft-last-button"><button class="ft-styless-button" aria-label="' + S(a.ariaLabel) + '" style="background-color: ' + S(T(c)) + '"><span class="ft-highlighter"></span><span class="google-symbols" style="color: ' + S(T(d)) + '" aria-hidden="true">' + tx(b) + '</span></button><span class="ft-button-corner-info"></span></div>')
    };
    const mN = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500,700"];

    function nN(a, b) {
        a = new oN(a, b, pN(a, b));
        a.init();
        return a
    }

    function qN() {
        ({
            Vd: a
        } = {
            Vd: 2
        });
        var a;
        return a > 1 ? 50 : 120
    }

    function rN(a, b, c) {
        sN(a) === 0 && b.classList.remove("ft-collapsed");
        tN(b, c);
        Es(a.win);
        b.classList.remove("ft-collapsed");
        uN(a);
        return () => void vN(a, b, c)
    }

    function wN(a) {
        xN(a.g.wa.se).length === 0 ? (a.B.X ? .Zm(), a.B.g(null), a.g.wa.ej.g(!1), a.g.wa.oh.g(!1), a.g.wa.ih.g(!1)) : (a.g.wa.ej.g(!0), yN(a))
    }

    function zN(a, {
        uk: b = 0,
        Xo: c = 0
    }) {
        b = Math.max(xN(a.g.nd).length + b, 0);
        c = Math.max(xN(a.g.Fc).length + c, 0);
        var d = b + c,
            e = d * 50;
        b > 0 && c > 0 && (e += 11);
        e += Math.max(0, d - 1) * 10;
        d >= a.l.Vd && (e += 60);
        d > 1 && (e += 10);
        return e
    }

    function sN(a) {
        var b = a.g.Fc;
        return xN(a.g.nd).length + xN(b).length
    }

    function uN(a) {
        var b = a.g.Fc,
            c = a.g.separator;
        xN(a.g.nd).length > 0 && xN(b).length > 0 ? c.classList.remove("ft-collapsed") : c.classList.add("ft-collapsed");
        sN(a) >= a.l.Vd ? a.g.kj.g(!0) : a.g.kj.g(!1);
        sN(a) > 1 ? a.g.fj.g(!0) : a.g.fj.g(!1);
        sN(a) > 0 ? a.g.isVisible.g(!0) : a.g.isVisible.g(!1);
        AN(a);
        BN(a)
    }

    function vN(a, b, c) {
        b.classList.contains("ft-removing") || (b.classList.add("ft-removing"), b.classList.add("ft-collapsed"), uN(a), a.win.setTimeout(() => {
            c.removeChild(b)
        }, 750))
    }

    function AN(a) {
        var b = xN(a.g.nd).concat(xN(a.g.Fc));
        b.forEach(c => {
            c.classList.remove("ft-last-button")
        });
        sN(a) >= a.l.Vd || b[b.length - 1] ? .classList.add("ft-last-button")
    }

    function BN(a) {
        var b = xN(a.g.nd).concat(xN(a.g.Fc)).filter(c => !c.classList.contains("ft-reg-button"));
        a.G.g(b.length > 0)
    }

    function CN(a) {
        vs(a.g.wa.se.children, b => {
            var c = a.g.wa.xe;
            vN(a, b, a.g.wa.se);
            var d = c.get(b);
            c.delete(b);
            d ? .isDismissed.g(!0)
        });
        wN(a)
    }

    function yN(a) {
        if (!a.B.X) {
            var b = DN(a.win, {
                googleIconName: "verified_user",
                ariaLabel: C(a.l.Ch, 2),
                orderingIndex: 0,
                onClick: () => {
                    a.g.wa.oh.g(!a.g.wa.isVisible.X);
                    for (let [, c] of a.g.wa.xe) c.th = !0;
                    a.g.wa.ih.g(!1)
                },
                backgroundColorCss: "#fff"
            });
            b.Se.classList.add("ft-reg-button");
            rN(a, b.Se, a.g.Fc);
            it(b.hm, a.g.wa.isVisible);
            a.B.g({
                cp: b,
                Zm: () => void vN(a, b.Se, a.g.Fc)
            })
        }
    }

    function EN(a) {
        var b = a.g.wa.ih,
            c = b.g;
        a: {
            for ([, d] of a.g.wa.xe)
                if (a = d, a.showUnlessUserInControl && !a.th) {
                    var d = !0;
                    break a
                }
            d = !1
        }
        c.call(b, d)
    }

    function FN(a) {
        a.g.wa.al.listen(() => {
            CN(a)
        })
    }
    var oN = class extends Gs {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.l = b;
            this.g = c;
            this.B = new O(null);
            this.G = new O(!1)
        }
        addButton(a) {
            a = DN(this.win, a);
            return rN(this, a.Se, this.g.nd)
        }
        addRegulatoryMessage(a) {
            var b = this.g.wa.se,
                c = GN(this.win, a);
            tN(c.Bh, b);
            this.g.wa.xe.set(c.Bh, c);
            wN(this);
            return {
                showUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !0;
                    EN(this)
                },
                hideUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !1;
                    EN(this)
                },
                showAndGiveUserControl: () => void this.showAndGiveUserControl(c),
                isDismissed: jt(c.isDismissed),
                removeCallback: () => {
                    var d = c.Bh,
                        e = this.g.wa.se;
                    d.parentNode === e && e.removeChild(d);
                    this.g.wa.xe.delete(d);
                    wN(this)
                }
            }
        }
        J() {
            return ct(this.B.map(a => a != null))
        }
        D() {
            return ct(this.G)
        }
        C() {
            return [this.g.container]
        }
        j() {
            var a = this.g.yc.xc;
            a.parentNode ? .removeChild(a);
            super.j()
        }
        showAndGiveUserControl(a) {
            a.th = !0;
            this.g.wa.oh.g(!0);
            EN(this)
        }
        init() {
            Pt(this.win, mN);
            it(this.g.Jn, this.l.Uc);
            this.win.document.body.appendChild(this.g.yc.xc);
            FN(this)
        }
    };

    function pN(a, b) {
        var c = YC(a),
            d = c.shadowRoot;
        d.appendChild(Kj(new qj(a.document), kN({
            Cl: C(b.Ch, 1),
            bl: C(b.Ch, 3),
            Sk: 50,
            ln: 11,
            Tk: 10,
            Rk: 5
        }).Fb()));
        var e = XC("ft-container", d),
            f = XC("ft-expand-toggle", d),
            g = XC("ft-expand-toggle-container", d),
            h = new O(null);
        h.j(p => {
            e.style.zIndex = String(p ? ? 2147483647)
        });
        var k = new O(!0);
        ft(k, !0, () => {
            e.classList.remove("ft-collapsed");
            f.setAttribute("aria-expanded", "true")
        });
        ft(k, !1, () => {
            e.classList.add("ft-collapsed");
            f.setAttribute("aria-expanded", "false")
        });
        f.addEventListener("click",
            () => {
                k.g(!k.X)
            });
        var l = new O(!1);
        ft(l, !0, () => {
            g.classList.remove("ft-collapsed");
            e.classList.add("ft-toolbar-collapsible")
        });
        ft(l, !1, () => {
            g.classList.add("ft-collapsed");
            e.classList.remove("ft-toolbar-collapsible");
            k.g(!0)
        });
        var m = new O(!1);
        ft(m, !0, () => {
            e.classList.add("ft-multiple-buttons")
        });
        ft(m, !1, () => {
            e.classList.remove("ft-multiple-buttons")
        });
        b.position.j(p => {
            if (p) {
                p.Ci(e.style);
                p = p.aj();
                switch (p) {
                    case 0:
                        e.classList.add("ft-left-pos");
                        e.classList.remove("ft-right-pos");
                        break;
                    case 1:
                        e.classList.add("ft-right-pos");
                        e.classList.remove("ft-left-pos");
                        break;
                    default:
                        throw Error(`Unknown HorizontalAnchoring: ${p}`);
                }
                Es(a)
            }
        });
        var n = new O(!1);
        b = bt(HN(a, d), n, b.position.map(p => p !== null));
        ft(b, !0, () => {
            e.classList.remove("ft-hidden")
        });
        ft(b, !1, () => {
            e.classList.add("ft-hidden")
        });
        b = IN(a, XC("ft-reg-bubble", d));
        return {
            container: e,
            nd: XC("ft-button-holder", d),
            Fc: XC("ft-bottom-button-holder", d),
            separator: XC("ft-separator", d),
            yc: c,
            Jn: h,
            jh: k,
            kj: l,
            fj: m,
            isVisible: n,
            wa: b
        }
    }

    function IN(a, b) {
        var c = new O(!1),
            d = new O(!1),
            e = dt(c, d);
        ft(e, !0, () => {
            b.classList.remove("ft-collapsed")
        });
        ft(e, !1, () => {
            b.classList.add("ft-collapsed")
        });
        var f = new O(!1);
        ft(f, !0, () => {
            b.classList.remove("ft-no-messages")
        });
        ft(f, !1, () => {
            b.classList.add("ft-no-messages")
        });
        var g = XC("ft-reg-bubble-close", b),
            h = new nt;
        g.addEventListener("click", () => {
            mt(h)
        });
        var k = XC("ft-reg-message-holder", b);
        It(Ft(a, k)).j(() => {
            b.style.height = `${k.offsetHeight}px`
        });
        return {
            se: k,
            oh: c,
            ih: d,
            isVisible: e,
            ej: f,
            xe: new Map,
            al: kt(h)
        }
    }

    function DN(a, b) {
        var c = Kj(new qj(a.document), lN({
            googleIconName: b.googleIconName,
            ariaLabel: b.ariaLabel,
            backgroundColorCss: b.backgroundColorCss || "#e2eaf6",
            iconColorCss: b.iconColorCss || "#3c4043"
        }).Fb());
        b.buttonExtension ? .styleSheet && c.appendChild(b.buttonExtension.styleSheet);
        if (b.cornerNumber !== void 0) {
            let d = Ai(Math.round(b.cornerNumber), 99);
            XC("ft-button-corner-info", c).appendChild(a.document.createTextNode(String(d)));
            c.classList.add("ft-show-corner-info")
        }
        c.orderingIndex = b.orderingIndex;
        b.onClick &&
            WC("BUTTON", c).addEventListener("click", b.onClick);
        a = new O(!1);
        ft(a, !0, () => {
            c.classList.add("ft-highlighted")
        });
        ft(a, !1, () => {
            c.classList.remove("ft-highlighted")
        });
        return {
            Se: c,
            hm: a
        }
    }

    function GN(a, b) {
        a: {
            var c = b.regulatoryMessage;
            var d = c.kind;
            if (d) switch (d) {
                case "standard":
                    c = JN(a, c);
                    break a;
                case "custom":
                    a = new qj(a.document);
                    d = vx('<div class="ft-reg-message ft-reg-message-custom"></div>');
                    a = Kj(a, d.Fb());
                    a.appendChild(c.content);
                    c = a;
                    break a;
                default:
                    throw Error(`Unknown regulatory message kind: ${d}`);
            } else c = JN(a, c)
        }
        c.orderingIndex = b.orderingIndex;
        return {
            Bh: c,
            showUnlessUserInControl: !1,
            th: !1,
            isDismissed: new O(!1)
        }
    }

    function JN(a, b) {
        a = new qj(a.document);
        var c = vx('<div class="ft-reg-message"><button class="ft-reg-message-button"></button><div class="ft-reg-message-info"></div></div>');
        a = Kj(a, c.Fb());
        c = XC("ft-reg-message-button", a);
        b.actionButton ? (c.appendChild(b.actionButton.buttonText), c.addEventListener("click", b.actionButton.onClick)) : c.classList.add("ft-display-none");
        c = XC("ft-reg-message-info", a);
        b.informationText ? c.appendChild(b.informationText) : c.classList.add("ft-display-none");
        return a
    }

    function tN(a, b) {
        a: {
            var c = Array.from(b.children);
            for (let d = 0; d < c.length; ++d)
                if (c[d].orderingIndex >= a.orderingIndex) {
                    c = d;
                    break a
                }
            c = c.length
        }
        b.insertBefore(a, b.childNodes[c] || null)
    }

    function xN(a) {
        return Array.from(a.children).filter(b => !b.classList.contains("ft-removing"))
    }

    function HN(a, b) {
        var c = new O(!1),
            d = XC("ft-symbol-font-load-test", b);
        b = XC("ft-symbol-reference", d);
        var e = XC("ft-text-reference", d),
            f = Ft(a, b);
        gt(It(f).map(g => g.width > 0 && g.width < e.offsetWidth / 2), !0, () => {
            c.g(!0);
            d.parentNode ? .removeChild(d);
            f.dispose()
        });
        return c
    };

    function KN(a) {
        return a.g[a.g.length - 1]
    }
    var MN = class {
        constructor() {
            this.l = LN;
            this.g = [];
            this.j = new Set
        }
        add(a) {
            if (this.j.has(a)) return !1;
            var b = pb(this.g, a, this.l);
            this.g.splice(b >= 0 ? b : -b - 1, 0, a);
            this.j.add(a);
            return !0
        }
        first() {
            return this.g[0]
        }
        has(a) {
            return this.j.has(a)
        }
        delete(a) {
            kb(this.g, b => b === a);
            return this.j.delete(a)
        }
        clear() {
            this.j.clear();
            return this.g.splice(0, this.g.length)
        }
        size() {
            return this.g.length
        }
    };

    function NN(a) {
        for (var b = a.re.X, c; a.l.jl() > b && (c = a.j.first());) {
            var d = a,
                e = c;
            ON(d, e);
            d.g.add(e)
        }
        for (;
            (d = KN(a.g)) && a.l.Rl() <= b;) PN(a, d);
        for (;
            (d = KN(a.g)) && (c = a.j.first()) && d.priority > c.priority;) b = a, e = c, ON(b, e), b.g.add(e), PN(a, d)
    }

    function PN(a, b) {
        a.g.delete(b);
        a.j.add(b) && (b.ki = a.l.addButton(b.buttonSpec));
        b.isInToolbar.g(!0)
    }

    function ON(a, b) {
        b.ki && b.ki();
        b.ki = void 0;
        a.j.delete(b);
        b.isInToolbar.g(!1)
    }
    var QN = class {
        constructor(a, b) {
            this.re = a;
            this.l = b;
            this.g = new MN;
            this.j = new MN;
            this.A = 0;
            this.re.listen(() => void NN(this))
        }
        addButton(a) {
            var b = {
                buttonSpec: a.buttonSpec,
                priority: a.priority,
                ti: this.A++,
                isInToolbar: new O(!1)
            };
            this.g.add(b);
            NN(this);
            return {
                isInToolbar: jt(ct(b.isInToolbar)),
                removeCallback: () => {
                    ON(this, b);
                    this.g.delete(b);
                    NN(this)
                }
            }
        }
    };

    function LN(a, b) {
        return a.priority === b.priority ? b.ti - a.ti : a.priority - b.priority
    };

    function RN(a) {
        if (!UC(a.win)) {
            if (a.l.X) {
                let b = qs(a.win);
                if (b > a.g + 100 || b < a.g - 100) a.l.g(!1), a.g = ks(a.win)
            }
            a.B && a.win.clearTimeout(a.B);
            a.B = a.win.setTimeout(() => void SN(a), 200)
        }
    }

    function SN(a) {
        if (!UC(a.win)) {
            var b = ks(a.win);
            a.g && a.g > b && (a.g = b);
            b = qs(a.win);
            b >= a.g - 100 && (a.g = Math.max(a.g, b), a.l.g(!0))
        }
    }
    var TN = class extends Gs {
        constructor(a) {
            super();
            this.win = a;
            this.l = new O(!1);
            this.g = 0;
            this.B = null;
            this.C = () => void RN(this)
        }
        init() {
            this.win.addEventListener("scroll", this.C);
            this.g = ks(this.win);
            SN(this)
        }
        j() {
            this.win.removeEventListener("scroll", this.C);
            this.l.g(!1);
            super.j()
        }
    };

    function UN(a, b) {
        var c = a.l.addRegulatoryMessage(b);
        c.showAndGiveUserControl();
        return {
            removeCallback: () => void c.removeCallback(),
            isDismissed: c.isDismissed
        }
    }

    function VN(a, b) {
        var c = new O(!1),
            d = new O(!1),
            e = gt(WN(a), !0, () => {
                XN(a, b, c, d)
            });
        return {
            removeCallback: () => {
                c.g(!0);
                e()
            },
            isDismissed: jt(ct(d))
        }
    }

    function WN(a) {
        if (!a.g) {
            var b = new TN(a.win);
            b.init();
            a.g = ct(b.l);
            Hs(a, b)
        }
        return a.g
    }

    function XN(a, b, c, d) {
        var e = a.l.addRegulatoryMessage(b);
        YN(a, e, c);
        gt(c, !0, () => {
            e.removeCallback()
        });
        it(d, $s(e.isDismissed))
    }

    function YN(a, b, c) {
        a = WN(a);
        var d = ft(a, !0, () => void b.showUnlessUserInControl()),
            e = ft(a, !1, () => void b.hideUnlessUserInControl());
        ft($s(b.isDismissed), !0, () => {
            d();
            e()
        });
        gt(c, !0, () => {
            d();
            e()
        })
    }
    var ZN = class extends Gs {
        constructor(a, b) {
            super();
            this.win = a;
            this.l = b;
            this.g = null
        }
        addRegulatoryMessage(a) {
            return a.displayImmediately ? UN(this, a.messageSpec) : VN(this, a.messageSpec)
        }
    };

    function $N(a, b) {
        a.googFloatingToolbarManager || (a.googFloatingToolbarManager = new aO(a, b));
        return a.googFloatingToolbarManager
    }

    function bO(a) {
        a.g || (a.g = cO(a.win, a.l, a.Uc), Hs(a, a.g.ud), Hs(a, a.g.Lj), dO(a), eO(a, a.g.ud));
        return a.g
    }

    function fO(a) {
        a.Uc.X === null && a.g ? .position.g(gO(a))
    }

    function hO(a) {
        a.win.requestAnimationFrame(() => void fO(a))
    }

    function gO(a) {
        var b = [];
        a.g ? .ud ? .D().B() ? (b.push(() => iO(a)), b.push(() => jO(a))) : (b.push(() => jO(a)), b.push(() => iO(a)));
        a.g ? .ud ? .J() ? .B() && b.push(() => {
            var c = is(a.win);
            return {
                position: IB({
                    sa: Math.floor(c / 3),
                    lb: 10
                }),
                re: 0
            }
        });
        for (let c of b)
            if (b = c()) return b;
        return null
    }

    function dO(a) {
        a.win.googFloatingToolbarManagerAsyncPositionUpdate ? hO(a) : fO(a)
    }

    function eO(a, b) {
        var c = hG(a.win);
        kG(c).listen(() => void dO(a));
        Hs(a, c);
        b.J().listen(() => void dO(a));
        b.D().listen(() => void dO(a));
        a.Uc.listen(() => void dO(a))
    }

    function iO(a) {
        var b = a.win,
            c = is(a.win);
        return EB(b, {
            Nd: KB({
                sa: 50,
                wb: 10
            }),
            Ah: Math.floor(c / 3),
            Ke: 60,
            Dh: qN(),
            Ef: Math.floor(c / 2),
            Gc: 20
        }, [...(a.g ? .ud.C() ? ? []), a.win.document.body]).rg
    }

    function jO(a) {
        var b = a.win,
            c = is(a.win);
        return EB(b, {
            Nd: IB({
                sa: 50,
                lb: 10
            }),
            Ah: Math.floor(c / 3),
            Ke: 60,
            Dh: qN(),
            Ef: Math.floor(c / 2),
            Gc: 40
        }, [...(a.g ? .ud.C() ? ? []), a.win.document.body]).rg
    }
    class aO extends Gs {
        constructor(a, b) {
            super();
            this.win = a;
            this.l = b;
            this.g = null;
            this.Uc = kO(this.win, this)
        }
        addButton(a) {
            return bO(this).Bm.addButton(a)
        }
        addRegulatoryMessage(a) {
            return bO(this).Lj.addRegulatoryMessage(a)
        }
    }

    function cO(a, b, c) {
        var d = new O(null),
            e = nN(a, {
                Vd: 2,
                position: d.map(f => f ? .position ? ? null),
                Ch: b,
                Uc: c
            });
        b = new QN(d.map(f => f ? .re || 0), {
            addButton: f => e.addButton(f),
            jl: () => zN(e, {}),
            Rl: () => zN(e, {
                uk: 1
            })
        });
        a = new ZN(a, {
            addRegulatoryMessage: f => e.addRegulatoryMessage(f)
        });
        return {
            ud: e,
            position: d,
            Bm: b,
            Lj: a
        }
    }

    function kO(a, b) {
        var c = new EC(a),
            d = new O(null),
            e = f => void d.g(f);
        Is(b, () => {
            DC(c, e)
        });
        c.floatingAdsStacking.maxZIndexListeners.push(e);
        e(CC(c));
        return d
    };
    const lO = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500"];

    function mO(a, b, c, d) {
        a = new nO(a, b, c, d);
        if (a.l) {
            Pt(a.win, lO);
            var e = a.win;
            b = a.message;
            c = YC(e);
            var f = c.shadowRoot;
            d = f.appendChild;
            e = new qj(e.document);
            var g = (g = {}, g.rb);
            g = vx('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"' + (g ? ' nonce="' + S(Zx(g)) + '"' : "") + '/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500" rel="stylesheet"' + (g ? ' nonce="' + S(Zx(g)) + '"' : "") + "><style" + (g ? ' nonce="' + S(Zx(g)) +
                '"' : "") + '>.ipr-container {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; color: #000; border-top: 2px solid rgb(236, 237, 237); border-bottom: 2px solid rgb(236, 237, 237); background-color: #fff; padding: 5px; margin: 5px 0; text-align: center;}.ipr-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ipr-display-none {display: none;}</style><div class="ipr-container"><button class="ipr-button"></button><div class="ipr-info"></div></div>');
            d.call(f, Kj(e, g.Fb()));
            d = XC("ipr-container", f);
            f = XC("ipr-button", d);
            b.actionButton ? (f.appendChild(b.actionButton.buttonText), f.addEventListener("click", b.actionButton.onClick)) : f.classList.add("ipr-display-none");
            d = XC("ipr-info", d);
            b.informationText ? d.appendChild(b.informationText) : d.classList.add("ipr-display-none");
            a.g = c.xc;
            aL(a.l, a.g);
            oO(a)
        } else pO(a);
        return a
    }

    function oO(a) {
        var b = new St(a.win);
        b.init(2E3);
        Hs(a, b);
        Qt(b, () => {
            qO(a);
            pO(a);
            b.dispose()
        })
    }

    function pO(a) {
        var b = $N(a.win, a.B).addRegulatoryMessage({
            messageSpec: {
                regulatoryMessage: a.message,
                orderingIndex: 0
            }
        });
        Is(a, () => void b.removeCallback())
    }

    function qO(a) {
        a.g && (a.g.parentNode ? .removeChild(a.g), a.g = null)
    }
    var nO = class extends Gs {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.l = b;
            this.message = c;
            this.B = d;
            this.g = null
        }
        j() {
            qO(this);
            super.j()
        }
    };
    var sO = (a, b, c, d) => rO(a, b, c, d);

    function rO(a, b, c, d) {
        var e = mO(a, jN(a, d), {
            kind: "standard",
            actionButton: {
                buttonText: a.document.createTextNode(b),
                onClick: c
            }
        }, tO(a));
        return () => e.dispose()
    }

    function tO(a) {
        if (a = iN(a)) return a;
        AA(1234, Error("No messages"));
        return yg(new DJ)
    };

    function uO(a, b) {
        b && (a.g = sO(a.j, b.localizedDnsText, () => vO(a, b), a.A))
    }

    function wO(a) {
        var b = gN(a.j);
        b.callbackQueue = b.callbackQueue || [];
        hN(a.j).overrideDnsLink = !0;
        b.callbackQueue.push({
            INITIAL_US_STATES_DATA_READY: c => uO(a, c)
        })
    }

    function vO(a, b) {
        FC(a.l);
        b.openConfirmationDialog(c => {
            c && a.g && (a.g(), a.g = null);
            GC(a.l)
        })
    }
    var xO = class {
        constructor(a, b, c) {
            this.j = a;
            this.l = zC(b, 2147483643);
            this.A = c;
            this.g = null
        }
    };

    function yO(a) {
        zO(a.l, b => {
            var c = a.j,
                d = b.revocationText,
                e = b.attestationText,
                f = b.showRevocationMessage;
            b = jN(c, a.A);
            d = {
                kind: "standard",
                actionButton: {
                    buttonText: c.document.createTextNode(d),
                    onClick: f
                },
                informationText: c.document.createTextNode(e)
            };
            e = iN(c);
            e || (AA(1233, Error("No messages")), e = yg(new DJ));
            mO(c, b, d, e)
        }, () => {
            GC(a.g);
            AO(a)
        })
    }

    function BO(a) {
        FC(a.g);
        yO(a)
    }

    function AO(a) {
        a.j.__tcfapi ? a.j.__tcfapi("addEventListener", 2, (b, c) => {
            c && b.eventStatus == "cmpuishown" ? FC(a.g) : GC(a.g)
        }) : AA(1250, Error("No TCF API function"))
    }
    var CO = class {
        constructor(a, b, c, d) {
            this.j = a;
            this.g = zC(b, 2147483643);
            this.A = c;
            this.l = d
        }
    };
    var DO = a => {
            if (!a || gd(ve(a, 1)) == null) return !1;
            a = F(a, 1);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoConsentUiStatus: " + a);
            }
        },
        EO = a => {
            if (!a || gd(ve(a, 3)) == null) return !1;
            a = F(a, 3);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoCcpaUiStatus: " + a);
            }
        },
        FO = a => a ? B(a, 5) === !0 : !1;

    function GO(a) {
        if (a.j.adsbygoogle_ama_fc_has_run !== !0) {
            var b = DO(a.g),
                c = EO(a.g),
                d = !1;
            b && (BO(new CO(a.j, a.B, a.A || Ve(a.g, DI, 4, w()), a.l)), d = !0);
            c && (wO(new xO(a.j, a.B, a.A || Ve(a.g, DI, 4, w()))), d = !0);
            PA(e => {
                e = sf(e, 9, !0);
                e = sf(e, 10, b);
                sf(e, 11, c)
            });
            FO(a.g) && (d = !0);
            d && (a.l.start(!0), a.j.adsbygoogle_ama_fc_has_run = !0)
        }
    }
    var HO = class {
        constructor(a, b, c, d, e) {
            this.j = a;
            this.l = b;
            this.g = c;
            this.B = d;
            this.A = e || null
        }
    };

    function IO(a, b, c, d, e, f) {
        try {
            let g = a.g,
                h = hl("SCRIPT", g);
            h.async = !0;
            fj(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", () => {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", () => {
                c > 0 ? IO(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (g) {
            f()
        }
    }

    function JO(a, b, c = () => {}, d = () => {}) {
        IO(pj(a), b, 0, !1, c, d)
    };

    function KO(a = null) {
        a = a || r;
        return a.googlefc || (a.googlefc = {})
    };
    Li(Zr).map(a => Number(a));
    Li($r).map(a => Number(a));
    const LO = r.URL;

    function MO(a) {
        var b = c => encodeURIComponent(c).replace(/[!()~']|(%20)/g, d => ({
            "!": "%21",
            "(": "%28",
            ")": "%29",
            "%20": "+",
            "'": "%27",
            "~": "%7E"
        })[d]);
        return Array.from(a, c => b(c[0]) + "=" + b(c[1])).join("&")
    };

    function NO(a) {
        var b = (new LO(a.location.href)).searchParams;
        a = b.get("fcconsent");
        b = b.get("fc");
        return b === "alwaysshow" ? b : a === "alwaysshow" ? a : null
    }

    function OO(a) {
        var b = "ab gdpr consent gdpr_transparency soft_cmp_bottom_pinned soft_cmp_floating_toolbar ccpa monetization usnat usfl".split(" ");
        return (a = (new LO(a.location.href)).searchParams.get("fctype")) && b.indexOf(a) !== -1 ? a : null
    }

    function PO(a) {
        return (a = (new LO(a.location.href)).searchParams.get("hl")) ? a : null
    }

    function QO(a) {
        var b = new LO(a),
            c = {
                search: "",
                hash: ""
            };
        a = {};
        b && (a.protocol = b.protocol, a.username = b.username, a.password = b.password, a.hostname = b.hostname, a.port = b.port, a.pathname = b.pathname, a.search = b.search, a.hash = b.hash);
        Object.assign(a, c);
        if (a.port && a.port[0] === ":") throw Error("port should not start with ':'");
        a.hash && a.hash[0] != "#" && (a.hash = "#" + a.hash);
        c.search ? c.search[0] != "?" && (a.search = "?" + c.search) : c.searchParams && (a.search = "?" + MO(c.searchParams), a.searchParams = void 0);
        b = "";
        a.protocol && (b += a.protocol +
            "//");
        c = a.username;
        var d = a.password;
        b = b + (c && d ? c + ":" + d + "@" : c ? c + "@" : d ? ":" + d + "@" : "") + (a.hostname || "");
        a.port && (b += ":" + a.port);
        b += a.pathname || "";
        b += a.search || "";
        b += a.hash || "";
        a = (new LO(b)).toString();
        a.charAt(a.length - 1) === "/" && (a = a.substring(0, a.length - 1));
        return a.toString().length <= 1E3 ? a : null
    };

    function RO(a, b) {
        var c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        let e = hl("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var SO = yh(class extends J {});

    function TO(a) {
        if (a.g) return a.g;
        a.T && a.T(a.l) ? a.g = a.l : a.g = tl(a.l, a.W);
        return a.g ? ? null
    }

    function UO(a) {
        a.B || (a.B = b => {
            if (b.source === a.g) try {
                var c = a.J ? a.J(b) : void 0;
                if (c) {
                    var d = c.Nh,
                        e = a.G.get(d);
                    e && (e.Om || a.G.delete(d), e.Jd ? .(e.nl, c.payload))
                }
            } catch (f) {}
        }, gk(a.l, "message", a.B))
    }

    function VO(a, b, c) {
        if (TO(a))
            if (a.g === a.l)(b = a.D.get(b)) && b(a.g, c);
            else {
                var d = a.C.get(b);
                if (d && d.qe) {
                    UO(a);
                    var e = ++a.Z;
                    a.G.set(e, {
                        Jd: d.Jd,
                        nl: d.Bf(c),
                        Om: b === "addEventListener"
                    });
                    a.g.postMessage(d.qe(c, e), "*")
                }
            }
    }
    var WO = class extends Gs {
        constructor(a, b, c, d) {
            super();
            this.W = b;
            this.T = c;
            this.J = d;
            this.D = new Map;
            this.Z = 0;
            this.C = new Map;
            this.G = new Map;
            this.B = void 0;
            this.l = a
        }
        j() {
            delete this.g;
            this.D.clear();
            this.C.clear();
            this.G.clear();
            this.B && (hk(this.l, "message", this.B), delete this.B);
            delete this.l;
            delete this.J;
            super.j()
        }
    };
    const XO = (a, b) => {
            var c = {
                cb: d => {
                    d = SO(d);
                    b.Jb({
                        Xd: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        YO = {
            Bf: a => a.Jb,
            qe: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            Jd: (a, b) => {
                a({
                    Xd: b
                })
            }
        };

    function ZO(a) {
        a = SO(a.data.__fciReturn);
        return {
            payload: a,
            Nh: HG(hf(a, 1))
        }
    }

    function $O(a, b = !1) {
        if (b) return !1;
        a.l || (a.g = !!TO(a.caller), a.l = !0);
        return a.g
    }

    function aP(a) {
        return new Promise(b => {
            $O(a) && VO(a.caller, "getDataWithCallback", {
                command: "loaded",
                Jb: c => {
                    b(c.Xd)
                }
            })
        })
    }

    function bP(a, b) {
        $O(a) && VO(a.caller, "getDataWithCallback", {
            command: "prov",
            spsp: xg(b),
            Jb: () => {}
        })
    }
    var cP = class extends Gs {
        constructor(a) {
            super();
            this.g = this.l = !1;
            this.caller = new WO(a, "googlefcPresent", void 0, ZO);
            this.caller.D.set("getDataWithCallback", XO);
            this.caller.C.set("getDataWithCallback", YO)
        }
        j() {
            this.caller.dispose();
            super.j()
        }
    };
    var dP = class extends J {};

    function eP(a) {
        a.addtlConsent === void 0 || v(a.addtlConsent) || (a.addtlConsent = void 0);
        a.gdprApplies === void 0 || rc(a.gdprApplies) || (a.gdprApplies = void 0);
        return a.tcString !== void 0 && !v(a.tcString) || a.listenerId !== void 0 && !qc(a.listenerId) ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }

    function fP(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = eP(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (Hl({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function gP(a, b = {}) {
        return fP(a) ? a.gdprApplies === !1 ? !0 : a.tcString === "tcunavailable" ? !b.idpcApplies : (b.idpcApplies || a.gdprApplies !== void 0 || b.fp) && (b.idpcApplies || v(a.tcString) && a.tcString.length) ? hP(a, "1") : !0 : !1
    }

    function hP(a, b) {
        a: {
            if (a.publisher && a.publisher.restrictions) {
                var c = a.publisher.restrictions[b];
                if (c !== void 0) {
                    c = c["755"];
                    break a
                }
            }
            c = void 0
        }
        if (c === 0) return !1;a = a.purpose && a.vendor ? (c = iP(a.vendor.consents, "755")) && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : c && iP(a.purpose.consents, b) : !0;
        return a
    }

    function iP(a, b) {
        return !(!a || !a[b])
    }

    function jP(a) {
        var b = ["3", "4"];
        return a.gdprApplies === !1 ? !0 : b.every(c => hP(a, c))
    }

    function kP(a) {
        if (a.g) return a.g;
        a.g = tl(a.l, "__tcfapiLocator");
        return a.g
    }

    function lP(a) {
        return typeof a.l.__tcfapi === "function" || kP(a) != null
    }

    function mP(a, b, c, d) {
        c || (c = () => {});
        var e = a.l;
        typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : kP(a) ? (nP(a), e = ++a.D, a.C[e] = c, a.g && a.g.postMessage({
            __tcfapiCall: {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }
        }, "*")) : c({}, !1)
    }

    function oP(a, b) {
        var c = {
                internalErrorState: 0,
                internalBlockOnErrors: a.md
            },
            d = xi(() => {
                b(c)
            }),
            e = 0;
        a.timeoutMs !== -1 && (e = setTimeout(() => {
            e = 0;
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, a.timeoutMs));
        mP(a, "addEventListener", f => {
            f && (c = f, c.internalErrorState = eP(c), c.internalBlockOnErrors = a.md, fP(c) ? (c.internalErrorState !== 0 && (c.tcString = "tcunavailable"), mP(a, "removeEventListener", null, c.listenerId), (f = e) && clearTimeout(f), d()) : (c.cmpStatus === "error" || c.internalErrorState !== 0) && (f = e) && clearTimeout(f))
        })
    }

    function nP(a) {
        if (!a.B) {
            var b = c => {
                if (c.source === a.g) try {
                    var d = (v(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                    a.C[d.callId](d.returnValue, d.success)
                } catch (e) {}
            };
            a.B = b;
            gk(a.l, "message", b)
        }
    }
    var pP = class extends Gs {
        constructor(a, b = {}) {
            super();
            this.g = null;
            this.C = {};
            this.D = 0;
            this.B = null;
            this.l = a;
            this.timeoutMs = b.timeoutMs ? ? 500;
            this.md = b.md ? ? !1
        }
        j() {
            this.C = {};
            this.B && (hk(this.l, "message", this.B), delete this.B);
            delete this.C;
            delete this.l;
            delete this.g;
            super.j()
        }
        addEventListener(a) {
            var b = {
                    internalBlockOnErrors: this.md
                },
                c = xi(() => {
                    a(b)
                }),
                d = 0;
            this.timeoutMs !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.timeoutMs));
            var e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState =
                    eP(b), b.internalBlockOnErrors = this.md, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                mP(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && mP(this, "removeEventListener", null, a.listenerId)
        }
    };

    function zO(a, b, c) {
        var d = KO(a.win);
        d.callbackQueue = d.callbackQueue || [];
        d.callbackQueue.push({
            CONSENT_DATA_READY: () => {
                var e = KO(a.win),
                    f = new pP(a.win);
                lP(f) && oP(f, g => {
                    g.cmpId === 300 && g.tcString && g.tcString !== "tcunavailable" && g.gdprApplies && b({
                        revocationText: (0, e.getDefaultConsentRevocationText)(),
                        closeText: (0, e.getDefaultConsentRevocationCloseText)(),
                        attestationText: (0, e.getDefaultConsentRevocationAttestationText)(),
                        showRevocationMessage: () => {
                            (0, e.showRevocationMessage)()
                        }
                    })
                });
                c()
            }
        })
    }

    function qP(a, b = !1, c) {
        c || (c = new dP);
        vf(c, 2, Math.round(performance.now()));
        var d = {};
        try {
            let f = NO(a.win),
                g = OO(a.win);
            d.fc = f;
            d.fctype = g;
            let h = PO(a.win);
            h && (d.hl = h)
        } catch (f) {}
        try {
            var e = QO(a.win.location.href)
        } catch (f) {}
        b && e && (d.href = e);
        b = rP(a.g, d);
        JO(a.win, b, () => {}, () => {});
        c && bP(new cP(a.win), c)
    }
    var sP = class {
        constructor(a, b) {
            this.win = a;
            this.g = b;
            this.ea = null
        }
        start(a = !1, b) {
            if (this.win === this.win.top) try {
                RO(this.win, "googlefcPresent"), qP(this, a, b)
            } catch (c) {}
        }
    };

    function rP(a, b) {
        a = ni `https://fundingchoicesmessages.google.com/i/${a}`;
        return oi(a, { ...b,
            ers: 2
        })
    };

    function tP(a, b, c) {
        return (a = a.g()) && of (a, 11) ? c.map(d => d.j()) : c.map(d => d.B(b))
    };
    var uP = class {
        constructor() {
            this.map = new Map
        }
        clear() {
            this.map.clear()
        }
        delete(a, b) {
            var c = this.map.get(a);
            return c ? (b = c.delete(b), c.size === 0 && this.map.delete(a), b) : !1
        }
        get(a) {
            return [...(this.map.get(a) ? ? [])]
        }
        keys() {
            return this.map.keys()
        }
        add(a, b) {
            var c = this.map.get(a);
            c || this.map.set(a, c = new Set);
            c.add(b)
        }
        get size() {
            var a = 0;
            for (let b of this.map.values()) a += b.size;
            return a
        }
        values() {
            var a = this.map;
            return function() {
                return function*() {
                    for (let b of a.values()) yield* b
                }()
            }()
        }[Symbol.iterator]() {
            var a = this.map;
            return function() {
                return function*() {
                    for (let [b, c] of a) {
                        let d = b,
                            e = c;
                        for (let f of e) yield [d, f]
                    }
                }()
            }()
        }
    };

    function vP(a) {
        return [a[0],
            [...a[1]]
        ]
    };
    const wP = new Set([7, 1]);
    var xP = class {
        constructor() {
            this.l = new uP;
            this.A = []
        }
        g(a, b) {
            wP.has(b) || iu(fu($K(a), c => void this.l.add(c, b)), c => void this.A.push(c))
        }
        j(a, b) {
            for (let c of a) this.g(c, b)
        }
    };

    function yP(a) {
        return new yu(["pedestal_container"], {
            google_reactive_ad_format: 30,
            google_ad_width: Math.floor(a),
            google_ad_format: "autorelaxed",
            google_full_width_responsive: !0,
            google_enable_content_recommendations: !0,
            google_content_recommendation_ui_type: "pedestal"
        })
    }
    var zP = class {
        g(a) {
            return yP(Math.floor(a.j))
        }
    };
    var AP = class extends J {};

    function BP(a, b) {
        var c = b.adClient;
        if (!v(c) || !c) return !1;
        a.gg = c;
        a.j = !!b.adTest;
        c = b.pubVars;
        ra(c) && (a.I = c);
        if (Array.isArray(b.fillMessage) && b.fillMessage.length > 0) {
            a.A = {};
            for (let d of b.fillMessage) a.A[d.key] = d.value
        }
        a.Ec = b.adWidth;
        a.Dc = b.adHeight;
        qc(a.Ec) && a.Ec > 0 && qc(a.Dc) && a.Dc > 0 || zA("rctnosize", b);
        return !0
    }
    var CP = class {
        constructor() {
            this.A = this.I = this.j = this.gg = null;
            this.Dc = this.Ec = 0
        }
        B() {
            return !0
        }
    };

    function DP(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            let b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return b === "__storage_test__"
        } catch (b) {
            return !1
        }
    }

    function EP(a, b = []) {
        var c = Date.now();
        return db(b, d => c - d < a * 1E3)
    }

    function FP(a, b, c) {
        try {
            let d = a.getItem(c);
            if (!d) return [];
            let e;
            try {
                e = JSON.parse(d)
            } catch (f) {}
            if (!Array.isArray(e) || hb(e, f => !Number.isInteger(f))) return a.removeItem(c), [];
            e = EP(b, e);
            e.length || a ? .removeItem(c);
            return e
        } catch (d) {
            return null
        }
    }

    function GP(a, b, c) {
        return b <= 0 || a == null || !DP(a) ? null : FP(a, b, c)
    };

    function HP(a, b, c) {
        var d = 0;
        try {
            var e = d |= gs(a);
            let h = hs(a),
                k = a.innerWidth;
            var f = h && k ? h / k : 0;
            d = e | (f ? f > 1.05 ? 262144 : f < .95 ? 524288 : 0 : 131072);
            d |= js(a);
            d |= a.innerHeight >= a.innerWidth ? 0 : 8;
            d |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            var g;
            if (g = b) g = GP(c, 3600, "__lsv__") ? .length !== 0;
            g && (d |= 134217728)
        } catch (h) {
            d |= 32
        }
        return d
    };
    var IP = class extends CP {
        constructor() {
            super(...arguments);
            this.l = !1;
            this.g = null
        }
        B(a) {
            this.l = !!a.enableAma;
            if (a = a.amaConfig) try {
                var b = TJ(a)
            } catch (c) {
                b = null
            } else b = null;
            this.g = b;
            return !0
        }
    };
    var JP = {};

    function KP(a, b, c) {
        var d = LP(a, c, b);
        if (!d) return !0;
        for (var e = c.D.j; d.Ld && d.Ld.length;) {
            let f = d.Ld.shift(),
                g = AK(f.ta);
            if (g && !(typeof d.ld === "number" && g <= d.ld)) c.C ? .g(f, 18);
            else if (MP(c, f, {
                    Cf: d.ld
                })) {
                if (d.Me.g.length + 1 >= e) return c.C ? .j(d.Ld, 19), !0;
                d = LP(a, c, b);
                if (!d) return !0
            }
        }
        return c.l
    }
    const LP = (a, b, c) => {
        var d = b.D.j,
            e = b.D.C,
            f = b.D;
        f = FL(b.Ba(), f.g ? f.g.Ud : void 0, d, !0);
        if (f.g.length >= d) return b.C ? .j(NP(b, f, {
            types: a
        }, c), 19), null;
        e ? (d = f.j || (f.j = ms(f.l).scrollHeight || null), e = !d || d < 0 ? -1 : d * e - LL(f)) : e = void 0;
        var g = (d = e == null || e >= 50) ? NP(b, f, {
            types: a
        }, c) : null;
        d || b.C ? .j(NP(b, f, {
            types: a
        }, c), 18);
        return {
            Me: f,
            ld: e,
            Ld: g
        }
    };
    JP[2] = Ba(function(a, b) {
        a = NP(b, FL(b.Ba()), {
            types: a,
            Cc: uL(b.Ba())
        }, 2);
        if (a.length == 0) return !0;
        for (let c = 0; c < a.length; c++)
            if (MP(b, a[c])) return !0;
        return b.l ? (b.A.push(11), !0) : !1
    }, [0]);
    JP[5] = Ba(KP, [0], 5);
    JP[10] = Ba(function(a, b) {
        a = [];
        var c = b.Le;
        c.includes(3) && a.push(2);
        c.includes(1) && a.push(0);
        c.includes(2) && a.push(1);
        return KP(a, 10, b)
    }, 10);
    JP[3] = function(a) {
        if (!a.l) return !1;
        var b = NP(a, FL(a.Ba()), {
            types: [0],
            Cc: uL(a.Ba())
        }, 3);
        if (b.length == 0) return !0;
        for (let c = b.length - 1; c >= 0; c--)
            if (MP(a, b[c])) return !0;
        a.A.push(11);
        return !0
    };
    const PP = a => {
            var b = a.Ba().document.body.getBoundingClientRect().width;
            OP(a, yP(b))
        },
        RP = (a, b) => {
            var c = {
                types: [0],
                Cc: new pL(0, null, [], 3, null),
                dn: [5]
            };
            c = NP(a, FL(a.Ba()), c, 8);
            QP(a, c.reverse(), b)
        },
        QP = (a, b, c) => {
            for (let d of b)
                if (b = c.g(d.Fa), MP(a, d, {
                        hg: b
                    })) return !0;
            return !1
        };
    JP[8] = function(a) {
        var b = a.Ba().document;
        if (b.readyState != "complete") return b.addEventListener("readystatechange", () => JP[8](a), {
            once: !0
        }), !0;
        if (!a.l) return !1;
        if (!a.xf()) return !0;
        b = {
            types: [0],
            Cc: new pL(0, null, [], 3, null),
            Th: [2, 4, 5]
        };
        b = NP(a, FL(a.Ba()), b, 8);
        var c = new zP;
        if (QP(a, b, c)) return !0;
        if (a.B.Ui) switch (a.B.Gj || 0) {
            case 1:
                RP(a, c);
                break;
            default:
                PP(a)
        }
        return !0
    };
    JP[6] = Ba(KP, [2], 6);
    JP[7] = Ba(KP, [1], 7);
    JP[9] = function(a) {
        var b = LP([0, 2], a, 9);
        if (!b || !b.Ld) return a.A.push(17), a.l;
        for (var c of b.Ld) {
            a: {
                var d = a.B.Wg || null;
                if (d == null) {
                    d = null;
                    break a
                }
                d = BK(c.ta, new SP(d, a.Ba()));d = new bL(d, c.xa(), c.Fa)
            }
            if (!d) continue;
            let e = AK(d.ta);
            if (e === null) continue;
            if (typeof b.ld === "number" && e > b.ld) continue;
            if (!MP(a, d, {
                    Cf: b.ld,
                    ug: !0
                })) continue;a = d.ta.J;c = c.ta;a = a.length > 0 ? a[0] : null;c.A = !0;a != null && c.J.push(a);
            return !0
        }
        a.A.push(17);
        return a.l
    };
    var CK = class {
        j(a, b, c, d) {
            return aJ(d.document, a, b)
        }
        l(a) {
            return is(a) || 0
        }
    };
    var TP = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.Me = c
        }
        pb(a) {
            return this.g ? hM(this.j, this.g, a, this.Me) : gM(this.j, a, this.Me)
        }
        kb() {
            return this.g ? 16 : 9
        }
    };
    var UP = class {
        constructor(a) {
            this.ig = a
        }
        pb(a) {
            return oM(a.document, this.ig)
        }
        kb() {
            return 11
        }
    };
    var VP = class {
        constructor(a) {
            this.Vc = a
        }
        pb(a) {
            return lM(this.Vc, a)
        }
        kb() {
            return 13
        }
    };
    var WP = class {
        pb(a) {
            return eM(a)
        }
        kb() {
            return 12
        }
    };
    var XP = class {
        constructor(a) {
            this.ee = a
        }
        pb() {
            return jM(this.ee)
        }
        kb() {
            return 2
        }
    };
    var YP = class {
        constructor(a) {
            this.g = a
        }
        pb() {
            return mM(this.g)
        }
        kb() {
            return 3
        }
    };
    var ZP = class {
        pb() {
            return pM()
        }
        kb() {
            return 17
        }
    };
    var $P = class {
        constructor(a) {
            this.g = a
        }
        pb() {
            return iM(this.g)
        }
        kb() {
            return 1
        }
    };
    var aQ = class {
        pb() {
            return vi(vK)
        }
        kb() {
            return 7
        }
    };
    var bQ = class {
        constructor(a) {
            this.Th = a
        }
        pb() {
            return kM(this.Th)
        }
        kb() {
            return 6
        }
    };
    var cQ = class {
        constructor(a) {
            this.g = a
        }
        pb() {
            return nM(this.g)
        }
        kb() {
            return 5
        }
    };
    var dQ = class {
        constructor(a, b) {
            this.minWidth = a;
            this.maxWidth = b
        }
        pb() {
            return Ba(qM, this.minWidth, this.maxWidth)
        }
        kb() {
            return 10
        }
    };
    var eQ = class {
        constructor(a) {
            this.A = a.j.slice(0);
            this.j = a.g.slice(0);
            this.l = a.l;
            this.B = a.A;
            this.g = a.B
        }
    };

    function fQ(a) {
        var b = new gQ;
        b.B = a;
        b.j.push(new $P(a));
        return b
    }

    function hQ(a, b) {
        a.j.push(new bQ(b));
        return a
    }

    function iQ(a, b) {
        a.j.push(new XP(b));
        return a
    }

    function jQ(a, b) {
        a.j.push(new cQ(b));
        return a
    }

    function kQ(a, b) {
        a.j.push(new YP(b));
        return a
    }

    function lQ(a) {
        a.j.push(new aQ);
        return a
    }

    function mQ(a) {
        a.g.push(new WP);
        return a
    }

    function nQ(a, b = 0, c, d) {
        a.g.push(new TP(b, c, d));
        return a
    }

    function oQ(a, b = 0, c = Infinity) {
        a.g.push(new dQ(b, c));
        return a
    }

    function pQ(a) {
        a.g.push(new ZP);
        return a
    }

    function qQ(a, b = 0) {
        a.g.push(new VP(b));
        return a
    }

    function rQ(a, b) {
        a.l = b;
        return a
    }
    var gQ = class {
        constructor() {
            this.l = 0;
            this.A = !1;
            this.j = [].slice(0);
            this.g = [].slice(0)
        }
        build() {
            return new eQ(this)
        }
    };
    var SP = class {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
        g() {
            var a = this.j,
                b = this.l,
                c = a.I || {};
            c.google_ad_client = a.gg;
            c.google_ad_height = is(b) || 0;
            c.google_ad_width = hs(b) || 0;
            c.google_reactive_ad_format = 9;
            b = new AP;
            b = rf(b, 1, a.l);
            a.g && y(b, 2, a.g);
            c.google_rasc = xg(b);
            a.j && (c.google_adtest = "on");
            return new yu(["fsi_container"], c)
        }
    };
    var sQ = ru(new nu(0, {})),
        tQ = ru(new nu(1, {})),
        uQ = a => a === sQ || a === tQ;

    function vQ(a, b, c) {
        xs(a.g, b) || a.g.set(b, []);
        a.g.get(b).push(c)
    }
    var wQ = class {
        constructor() {
            this.g = new Bs
        }
    };

    function xQ(a, b) {
        a.C.wpc = b;
        return a
    }

    function yQ(a, b) {
        for (let c = 0; c < a.A.length; c++)
            if (a.A[c] == b) return a;
        a.A.push(b);
        return a
    }

    function zQ(a, b) {
        for (let c = 0; c < b.length; c++) yQ(a, b[c]);
        return a
    }

    function AQ(a, b) {
        a.l = a.l ? a.l : b;
        return a
    }
    var BQ = class {
        constructor(a) {
            this.C = {};
            this.C.c = a;
            this.A = [];
            this.l = null;
            this.B = [];
            this.D = 0
        }
        getData(a) {
            var b = $i(this.C);
            this.D > 0 && (b.t = this.D);
            b.err = this.A.join();
            b.warn = this.B.join();
            this.l && (b.excp_n = this.l.name, b.excp_m = this.l.message && this.l.message.substring(0, 512), b.excp_s = this.l.stack && Wl(this.l.stack, ""));
            b.w = 0 < a.innerWidth ? a.innerWidth : null;
            b.h = 0 < a.innerHeight ? a.innerHeight : null;
            return b
        }
    };

    function CQ(a, b) {
        b && (a.g.apv = pf(b, 4), ze(b, zJ, 23) && (a.g.sat = "" + x(b, zJ, 23).g()));
        return a
    }

    function DQ(a, b) {
        a.g.afm = b.join(",");
        return a
    }
    var EQ = class extends BQ {
        constructor(a) {
            super(a);
            this.g = {}
        }
        getData(a) {
            try {
                this.g.su = a.location.hostname
            } catch (b) {
                this.g.su = "_ex"
            }
            a = super.getData(a);
            bj(a, this.g);
            return a
        }
    };

    function FQ(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function GQ(a, b, c, d = 30) {
        c.length <= d ? a[b] = HQ(c) : (a[b] = HQ(c.slice(0, d)), a[b + "_c"] = c.length.toString())
    }

    function HQ(a) {
        var b = a.length > 0 && typeof a[0] === "string";
        a = a.map(c => c ? .toString() ? ? "null");
        b && (a = a.map(c => ka(c, "replaceAll").call(c, "~", "")));
        return a.join("~")
    }

    function IQ(a) {
        return a == null ? "null" : typeof a === "string" ? a : typeof a === "boolean" ? a ? "1" : "0" : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function JQ(a, b) {
        a.j.op = IQ(b)
    }

    function KQ(a, b, c) {
        GQ(a.j, "fap", b);
        a.j.fad = IQ(c)
    }

    function LQ(a, b, c) {
        GQ(a.j, "fmp", b);
        a.j.fmd = IQ(c)
    }

    function MQ(a, b, c) {
        GQ(a.j, "vap", b);
        a.j.vad = IQ(c)
    }

    function NQ(a, b, c) {
        GQ(a.j, "vmp", b);
        a.j.vmd = IQ(c)
    }

    function OQ(a, b, c) {
        GQ(a.j, "pap", b);
        a.j.pad = IQ(c)
    }

    function PQ(a, b, c) {
        GQ(a.j, "pmp", b);
        a.j.pmd = IQ(c)
    }

    function QQ(a, b) {
        GQ(a.j, "psq", b)
    }
    var RQ = class extends EQ {
        constructor(a) {
            super(0);
            Object.assign(this, a);
            this.j = {};
            this.errors = []
        }
        getData(a) {
            a = super.getData(a);
            Object.assign(a, this.j);
            this.errors.length > 0 && (a.e = HQ(this.errors));
            return a
        }
    };

    function SQ(a, b, c) {
        var d = b.ta;
        xs(a.g, d) || a.g.set(d, new TQ(eu($K(b)) ? ? ""));
        c(a.g.get(d))
    }

    function UQ(a, b) {
        SQ(a, b, c => {
            c.g = !0
        })
    }

    function VQ(a, b) {
        SQ(a, b, c => {
            c.j = !0
        })
    }

    function WQ(a, b) {
        SQ(a, b, c => {
            c.l = !0
        });
        a.T.push(b.ta)
    }

    function XQ(a, b, c) {
        SQ(a, b, d => {
            d.Ed = c
        })
    }

    function YQ(a, b, c) {
        var d = [],
            e = 0;
        for (let f of c.filter(b)) uQ(f.Ed ? ? "") ? ++e : (b = a.j.get(f.Ed ? ? "", null), d.push(b));
        return {
            list: d.sort((f, g) => (f ? ? -1) - (g ? ? -1)),
            Fd: e
        }
    }

    function ZQ(a, b) {
        JQ(b, a.j.je());
        var c = As(a.g).filter(f => (f.bd.startsWith(sQ) ? 0 : 1) === 0),
            d = As(a.g).filter(f => (f.bd.startsWith(sQ) ? 0 : 1) === 1),
            e = YQ(a, f => f.g, c);
        KQ(b, e.list, e.Fd);
        e = YQ(a, f => f.g, d);
        LQ(b, e.list, e.Fd);
        e = YQ(a, f => f.j, c);
        MQ(b, e.list, e.Fd);
        e = YQ(a, f => f.j, d);
        NQ(b, e.list, e.Fd);
        c = YQ(a, f => f.l, c);
        OQ(b, c.list, c.Fd);
        d = YQ(a, f => f.l, d);
        PQ(b, d.list, d.Fd);
        QQ(b, a.T.map(f => a.g.get(f) ? .Ed).map(f => a.j.get(f) ? ? null))
    }

    function no() {
        var a = ar($Q);
        if (!a.B) return bo();
        var b = lo(ko(jo(io(ho(go(fo(eo(ao($n(new co, a.B ? ? []), a.J ? ? []), a.C), a.O), a.G), a.W), a.Z), a.D ? ? 0), As(a.g).map(c => {
            var d = new Zn;
            d = Jf(d, 1, c.bd);
            var e = a.j.get(c.Ed ? ? "", -1);
            d = wf(d, 2, e);
            d = sf(d, 3, c.g);
            return sf(d, 4, c.j)
        })), a.T.map(c => a.g.get(c) ? .Ed).map(c => a.j.get(c) ? ? -1));
        a.l != null && sf(b, 6, a.l);
        a.A != null && yf(b, 13, a.A);
        return b
    }
    var $Q = class {
        constructor() {
            this.A = this.J = this.B = null;
            this.G = this.O = !1;
            this.l = null;
            this.Z = this.C = this.W = !1;
            this.D = null;
            this.j = new Bs;
            this.g = new Bs;
            this.T = []
        }
    };
    class TQ {
        constructor(a) {
            this.l = this.j = this.g = !1;
            this.Ed = null;
            this.bd = a
        }
    };
    var aR = class {
        constructor(a) {
            this.j = a;
            this.g = -1
        }
    };

    function bR(a) {
        for (var b = 0; a;)(!b || a.previousElementSibling || a.nextElementSibling) && b++, a = a.parentElement;
        return b
    };

    function cR(a, b) {
        var c = a.J.filter(d => zs(d.Xe).every(e => d.Xe.get(e) === b.get(e)));
        return c.length === 0 ? (a.j.push(19), null) : c.reduce((d, e) => d.Xe.je() > e.Xe.je() ? d : e, c[0])
    }

    function dR(a, b) {
        b = $K(b);
        if (!du(b)) return a.j.push(18), null;
        b = b.getValue();
        if (xs(a.l, b)) return a.l.get(b);
        var c = pu(b);
        c = cR(a, c);
        a.l.set(b, c);
        return c
    }
    var eR = class {
        constructor(a) {
            this.g = a;
            this.l = new Bs;
            this.J = (x(a, NJ, 2) ? .g() || []).map(b => {
                var c = pu(C(b, 1)),
                    d = HG(hf(b, 2));
                return {
                    Xe: c,
                    Jj: d,
                    bd: C(b, 1)
                }
            });
            this.j = []
        }
        G() {
            var a = ar($Q),
                b = this.A();
            a.B = b;
            b = this.C();
            a.J = b;
            b = this.B();
            b != null && (a.A = b);
            b = !!this.g.l() ? .g() ? .g();
            a.G = b;
            b = new Bs;
            for (let c of x(this.g, NJ, 2) ? .g() ? ? []) b.set(C(c, 1), HG(hf(c, 2)));
            a.j = b
        }
        D() {
            return [...this.j]
        }
        A() {
            return [...this.g.g()]
        }
        C() {
            return [...df(this.g, 4).map(HG)]
        }
        B() {
            return GG(x(this.g, HJ, 5) ? .g()) ? ? null
        }
        O(a) {
            var b = dR(this, a);
            b ? .bd != null &&
                XQ(ar($Q), a, b.bd)
        }
        T(a) {
            return a.length == 0 ? !0 : .75 <= (new Wt(a)).filter(b => {
                b = dR(this, b) ? .bd || "";
                return b != "" && !(b === sQ || b === tQ)
            }).g.length / a.length
        }
    };

    function fR(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => (dR(a.g, c) ? .Jj ? ? Number.MAX_VALUE) - (dR(a.g, d) ? .Jj ? ? Number.MAX_VALUE))
    }

    function gR(a, b) {
        var c = b.Fa.g,
            d = Math,
            e = d.min,
            f = b.xa(),
            g = b.ta.g();
        c += 200 * e.call(d, 20, g == 0 || g == 3 ? bR(f.parentElement) : bR(f));
        a = a.j;
        a.g < 0 && (a.g = ms(a.j).scrollHeight || 0);
        a = a.g - b.Fa.g;
        a = c + (a > 1E3 ? 0 : 2 * (1E3 - a));
        b.xa();
        return a
    }

    function hR(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => gR(a, c) - gR(a, d))
    }

    function iR(a, b) {
        return b.sort((c, d) => {
            var e = c.ta.C,
                f = d.ta.C,
                g;
            e == null || f == null ? g = e == null && f == null ? gR(a, c) - gR(a, d) : e == null ? 1 : -1 : g = e - f;
            return g
        })
    }
    var jR = class {
        constructor(a, b = null) {
            this.j = new aR(a);
            this.g = b && new eR(b)
        }
    };

    function kR(a, b, c = 0, d) {
        var e = a.j;
        for (var f of b.A) e = Vt(e, f.pb(a.l), lR(f.kb(), c));
        f = e = e.apply(dM(a.l));
        for (let g of b.j) f = Vt(f, g.pb(a.l), lu([mR(g.kb(), c), h => {
            d ? .g(h, g.kb())
        }]));
        switch (b.l) {
            case 1:
                f = hR(a.g, f);
                break;
            case 2:
                f = iR(a.g, f);
                break;
            case 3:
                let g = ar($Q);
                f = fR(a.g, f);
                e.forEach(h => {
                    UQ(g, h);
                    a.g.g ? .O(h)
                });
                f.forEach(h => VQ(g, h))
        }
        b.B && (f = Yt(f, mj(a.l.location.href + a.l.localStorage.google_experiment_mod)));
        b.g ? .length === 1 && vQ(a.A, b.g[0], {
            qb: e.g.length,
            ck: f.g.length
        });
        return Xt(f)
    }
    var nR = class {
        constructor(a, b, c = null) {
            this.j = new Wt(a);
            this.g = new jR(b, c);
            this.l = b;
            this.A = new wQ
        }
    };
    const lR = (a, b) => c => yK(c, b, a),
        mR = (a, b) => c => yK(c.ta, b, a);

    function oR(a, b, c, d) {
        a: {
            switch (b) {
                case 0:
                    a = pR(qR(c), a);
                    break a;
                case 3:
                    a = pR(c, a);
                    break a;
                case 2:
                    let e = c.lastChild;
                    a = pR(e ? e.nodeType == 1 ? e : qR(e) : null, a);
                    break a
            }
            a = !1
        }
        if (d = !a && !(!d && b == 2 && !rR(c))) b = b == 1 || b == 2 ? c : c.parentNode,
        d = !(b && !GI(b) && b.offsetWidth <= 0);
        return d
    }

    function pR(a, b) {
        if (!a) return !1;
        a = il(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function qR(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function rR(a) {
        return !!a.nextSibling || !!a.parentNode && rR(a.parentNode)
    };
    var sR = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };

    function tR(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            let f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = ml(a[c[e]]);
                d = d === null ? null : Math.round(d);
                d != null && (b[f] = d)
            }
        }
    }

    function uR(a, b) {
        return !((kl.test(b.google_ad_width) || jl.test(a.style.width)) && (kl.test(b.google_ad_height) || jl.test(a.style.height)))
    }

    function vR(a, b) {
        var c = a.google_reactive_ad_format === 40,
            d = a.google_reactive_ad_format === 16;
        return !!a.google_ad_resizable && (!a.google_reactive_ad_format || c) && !d && !!b.navigator && /iPhone|iPod|iPad|Android|BlackBerry/.test(b.navigator.userAgent) && b === b.top
    }

    function wR(a, b, c, d, e) {
        if (a !== a.top) return Tk(a) ? 3 : 16;
        if (!(hs(a) < 488)) return 4;
        if (!(a.innerHeight >= a.innerWidth)) return 5;
        var f = hs(a);
        if (!f || (f - c) / f > d) a = 6;
        else {
            if (c = e.google_full_width_responsive !== "true") a: {
                c = b.parentElement;
                for (b = hs(a); c; c = c.parentElement) {
                    d = il(c, a);
                    if (!d) continue;
                    if ((e = ml(d.width)) && !(e >= b) && d.overflow !== "visible") {
                        c = !0;
                        break a
                    }
                }
                c = !1
            }
            a = c ? 7 : !0
        }
        return a
    }

    function xR(a, b, c, d) {
        var e = wR(b, c, a, V(Yu), d);
        e !== !0 ? a = e : d.google_full_width_responsive === "true" || QI(c, b) ? (b = hs(b), a = b - a, a = b && a >= 0 ? !0 : b ? a < -10 ? 11 : a < 0 ? 14 : 12 : 10) : a = 9;
        return a
    }

    function yR(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function zR(a, b) {
        if (b.nodeType === 3) return /\S/.test(b.data);
        if (b.nodeType === 1) {
            if (/^(script|style)$/i.test(b.nodeName)) return !1;
            let c;
            try {
                c = il(b, a)
            } catch (d) {}
            return !c || c.display !== "none" && !(c.position === "absolute" && (c.visibility === "hidden" || c.visibility === "collapse"))
        }
        return !1
    }

    function AR(a, b, c) {
        a = SI(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function BR(a, b) {
        b = b.parentElement;
        return b ? (a = il(b, a)) ? a.direction : "" : ""
    }

    function CR(a, b, c) {
        if (AR(a, b, c) !== 0) {
            yR(b, c, "0px");
            var d = AR(a, b, c);
            yR(b, c, `${-1*d}px`);
            a = AR(a, b, c);
            a !== 0 && a !== d && yR(b, c, `${d/(a-d)*d}px`)
        }
    }

    function DR(a, b) {
        var c = BR(a, b);
        if (c) {
            var d = b.style;
            d.border = d.borderStyle = d.outline = d.outlineStyle = d.transition = "none";
            d.borderSpacing = d.padding = "0";
            yR(b, c, "0px");
            d.width = `${hs(a)}px`;
            CR(a, b, c);
            d.zIndex = "30"
        }
    };
    const ER = !ub && !Za();

    function FR(a) {
        if (/-[a-z]/.test("adFormat")) return null;
        if (ER && a.dataset) {
            if (!(!Sa("Android") || $a() || Ya() || Ua() || Sa("Silk") || "adFormat" in a.dataset)) return null;
            a = a.dataset.adFormat;
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + "adFormat".replace(/([A-Z])/g, "-$1").toLowerCase())
    };

    function GR(a, b, c) {
        if (!b) return null;
        var d = hl("INS");
        d.id = "google_pedestal_container";
        d.style.width = "100%";
        d.style.zIndex = "-1";
        if (c) {
            var e = a.getComputedStyle(c),
                f = "";
            if (e && e.position !== "static") {
                var g = c.parentNode.lastElementChild;
                for (f = e.position; g && g !== c;) {
                    if (a.getComputedStyle(g).display !== "none") {
                        f = a.getComputedStyle(g).position;
                        break
                    }
                    g = g.previousElementSibling
                }
            }
            if (c = f) d.style.position = c
        }
        b.appendChild(d);
        if (d) {
            var h = a.document;
            f = h.createElement("div");
            f.style.width = "100%";
            f.style.height = "2000px";
            c = is(a);
            e = h.body.scrollHeight;
            a = a.innerHeight;
            g = h.body.getBoundingClientRect().bottom;
            d.appendChild(f);
            var k = f.getBoundingClientRect().top;
            h = h.body.getBoundingClientRect().top;
            d.removeChild(f);
            f = e;
            e <= a && c > 0 && g > 0 && (f = g - h);
            a = k - h >= .8 * f
        } else a = !1;
        return a ? d : (b.removeChild(d), null)
    }

    function HR(a) {
        var b = a.document.body,
            c = GR(a, b, null);
        if (c) return c;
        if (a.document.body) {
            c = Math.floor(a.document.body.getBoundingClientRect().width);
            for (var d = [{
                    element: a.document.body,
                    depth: 0,
                    height: 0
                }], e = -1, f = null; d.length > 0;) {
                let h = d.pop(),
                    k = h.element;
                var g = h.height;
                h.depth > 0 && g > e && (e = g, f = k);
                if (h.depth < 5)
                    for (g = 0; g < k.children.length; g++) {
                        let l = k.children[g],
                            m = l.getBoundingClientRect().width;
                        (m == null || c == null ? 0 : m >= c * .9 && m <= c * 1.01) && d.push({
                            element: l,
                            depth: h.depth + 1,
                            height: l.getBoundingClientRect().height
                        })
                    }
            }
            c =
                f
        } else c = null;
        return c ? GR(a, c.parentNode || b, c) : null
    }

    function IR(a) {
        var b = 0;
        try {
            b |= gs(a), Vk() || (b |= 1048576), Math.floor(a.document.body.getBoundingClientRect().width) <= 1200 || (b |= 32768), JR(a) && (b |= 33554432)
        } catch (c) {
            b |= 32
        }
        return b
    }

    function JR(a) {
        a = a.document.getElementsByClassName("adsbygoogle");
        for (let b = 0; b < a.length; b++)
            if (FR(a[b]) === "autorelaxed") return !0;
        return !1
    };

    function KR(a) {
        var b = ls(a, !0),
            c = ms(a).scrollWidth,
            d = ms(a).scrollHeight,
            e = "unknown";
        a && a.document && a.document.readyState && (e = a.document.readyState);
        var f = qs(a),
            g = [],
            h = [],
            k = [],
            l = [],
            m = [],
            n = [],
            p = [],
            q = 0,
            u = 0,
            A = Infinity,
            D = Infinity,
            K = null,
            I = Uz({
                yd: !1
            }, a);
        for (var G of I) {
            I = G.getBoundingClientRect();
            let wa = b - (I.bottom + f);
            var E = void 0,
                Q = void 0;
            if (G.className && G.className.indexOf("adsbygoogle-ablated-ad-slot") != -1) {
                E = G.getAttribute("google_element_uid");
                let Ca;
                if (Q = a.fqjyf) {
                    if (E && Q[E] && (Ca = Q[E].LmpfC), !Ca) continue
                } else continue;
                E = (Q = Wr(Ca)) ? Q.height : 0;
                Q = Q ? Q.width : 0
            } else if (E = I.bottom - I.top, Q = I.right - I.left, E <= 1 || Q <= 1) continue;
            g.push(E);
            k.push(Q);
            l.push(E * Q);
            cA(G) ? (u += 1, G.className && G.className.indexOf("pedestal_container") != -1 && (K = E)) : (A = Math.min(A, wa), n.push(I), q += 1, h.push(E), m.push(E * Q));
            D = Math.min(D, wa);
            p.push(I)
        }
        A = A === Infinity ? null : A;
        D = D === Infinity ? null : D;
        f = LR(n);
        p = LR(p);
        h = MR(b, h);
        n = MR(b, g);
        m = MR(b * c, m);
        G = MR(b * c, l);
        return new NR(a, {
            vl: e,
            Lh: b,
            Km: c,
            Im: d,
            nm: q,
            Jk: u,
            Mk: OR(g),
            Nk: OR(k),
            Lk: OR(l),
            wm: f,
            vm: p,
            um: A,
            tm: D,
            Gg: h,
            Fg: n,
            Hk: m,
            Gk: G,
            Mm: K
        })
    }

    function PR(a, b, c, d) {
        var e = Vk() && !(hs(a.win) >= 900);
        d = db(d, f => ib(a.j, f)).join(",");
        b = {
            wpc: b,
            su: c,
            eid: d,
            doc: a.g.vl ? ? null,
            pg_h: QR(a.g.Lh),
            pg_w: QR(a.g.Km),
            pg_hs: QR(a.g.Im),
            c: QR(a.g.nm),
            aa_c: QR(a.g.Jk),
            av_h: QR(a.g.Mk),
            av_w: QR(a.g.Nk),
            av_a: QR(a.g.Lk),
            s: QR(a.g.wm),
            all_s: QR(a.g.vm),
            b: QR(a.g.um),
            all_b: QR(a.g.tm),
            d: QR(a.g.Gg),
            all_d: QR(a.g.Fg),
            ard: QR(a.g.Hk),
            all_ard: QR(a.g.Gk),
            pd_h: QR(a.g.Mm),
            dt: e ? "m" : "d"
        };
        c = {};
        for (let f of Object.keys(b)) b[f] !== null && (c[f] = b[f]);
        return c
    }
    var NR = class {
        constructor(a, b) {
            this.j = [];
            this.win = a;
            this.g = b
        }
    };

    function OR(a) {
        return Ci.apply(null, db(a, b => b > 0)) || null
    }

    function MR(a, b) {
        return a <= 0 ? null : Bi.apply(null, b) / a
    }

    function LR(a) {
        var b = Infinity;
        for (let e = 0; e < a.length - 1; e++)
            for (let f = e + 1; f < a.length; f++) {
                var c = a[e],
                    d = a[f];
                c = Math.max(Math.max(0, c.left - d.right, d.left - c.right), Math.max(0, c.top - d.bottom, d.top - c.bottom));
                c > 0 && (b = Math.min(c, b))
            }
        return b !== Infinity ? b : null
    }

    function QR(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function RR(a) {
        var b = DL({
            yd: !1,
            uf: !1
        }, a);
        a = (is(a) || 0) - qs(a);
        var c = 0;
        for (let d = 0; d < b.length; d++) {
            let e = b[d].getBoundingClientRect();
            JL(e) && e.top <= a && (c += 1)
        }
        return c > 0
    }

    function SR(a) {
        var b = {},
            c = DL({
                yd: !1,
                uf: !1,
                fh: !1,
                gh: !1
            }, a).map(d => d.getBoundingClientRect()).filter(JL);
        b.ui = c.length;
        c = EL({
            fh: !0
        }, a).map(d => d.getBoundingClientRect()).filter(JL);
        b.Si = c.length;
        c = EL({
            gh: !0
        }, a).map(d => d.getBoundingClientRect()).filter(JL);
        b.xj = c.length;
        c = EL({
            uf: !0
        }, a).map(d => d.getBoundingClientRect()).filter(JL);
        b.zi = c.length;
        c = (is(a) || 0) - qs(a);
        c = DL({
            yd: !1
        }, a).map(d => d.getBoundingClientRect()).filter(JL).filter(Aa(TR, null, c));
        b.wi = c.length;
        a = KR(a);
        c = a.g.Gg != null ? a.g.Gg : null;
        c != null &&
            (b.pj = c);
        a = a.g.Fg != null ? a.g.Fg : null;
        a != null && (b.xi = a);
        return b
    }

    function MP(a, b, {
        Cf: c,
        hg: d,
        ug: e
    } = {}) {
        return dK(997, () => UR(a, b, {
            Cf: c,
            hg: d,
            ug: e
        }), a.g)
    }

    function NP(a, b, c, d) {
        var e = c.Cc ? c.Cc : a.D,
            f = wL(e, b.g.length);
        e = a.B.yi ? e.g : void 0;
        var g = pQ(qQ(mQ(oQ(nQ(lQ(jQ(kQ(hQ(iQ(fQ(c.types), a.Aa), c.Th || []), a.pa), c.dn || [])), f.te || void 0, e, b), c.minWidth, c.maxWidth)), f.Vc || void 0));
        a.Z && g.g.push(new UP(a.Z));
        b = 1;
        a.Rc() && (b = 3);
        rQ(g, b);
        a.B.Vj && (g.A = !0);
        return dK(995, () => kR(a.j, g.build(), d, a.C || void 0), a.g)
    }

    function OP(a, b) {
        var c = HR(a.g);
        if (c) {
            let d = xu(a.W, b),
                e = YI(a.g.document, a.G, null, null, {}, d);
            e && (NI(e.qd, c, 2, 256), dK(996, () => VR(a, e, d), a.g))
        }
    }

    function WR(a) {
        return a.J ? a.J : a.J = a.g.google_ama_state
    }

    function UR(a, b, {
        Cf: c,
        hg: d,
        ug: e
    } = {}) {
        var f = b.ta;
        if (f.A) return !1;
        var g = b.xa(),
            h = f.g();
        if (!oR(a.g, h, g, a.l)) return !1;
        h = null;
        f.Cd ? .includes(6) ? (h = Math.round(g.getBoundingClientRect().height), h = new yu(null, {
            google_max_responsive_height: c == null ? h : Math.min(c, h),
            google_full_width_responsive: "false"
        })) : h = c == null ? null : new yu(null, {
            google_max_responsive_height: c
        });
        c = zu(qf(f.Rf, 2) || 0);
        g = Au(f.C);
        var k = YR(a, f),
            l = ZR(a),
            m = xu(a.W, f.W ? f.W.g(b.Fa) : null, h, d || null, c, g, k, l),
            n = b.fill(a.G, m);
        if (e && !$R(a, n, m) || !dK(996, () =>
                VR(a, n, m), a.g)) return !1;
        Sl(9, [f.C, f.Dd]);
        a.Rc() && WQ(ar($Q), b);
        return !0
    }

    function YR(a, b) {
        return eu(iu(YK(b).map(Bu), () => {
            a.A.push(18)
        }))
    }

    function ZR(a) {
        if (!a.Rc()) return null;
        var b = a.j.g.g ? .C();
        if (b == null) return null;
        b = b.join("~");
        a = a.j.g.g ? .B() ? ? null;
        return Cu({
            kl: b,
            Dl: a
        })
    }

    function $R(a, b, c) {
        if (!b) return !1;
        var d = b.Hb,
            e = d.style.width;
        d.style.width = "100%";
        var f = d.offsetWidth;
        d.style.width = e;
        if (xR(f, a.g, b.Hb, c && c.ke() || {})) return DR(a.g, b.Hb), !0;
        KI(b.qd);
        return !1
    }

    function VR(a, b, c) {
        if (!b) return !1;
        try {
            bJ(a.g, b.Hb, c)
        } catch (d) {
            return KI(b.qd), a.A.push(6), !1
        }
        return !0
    }
    var aS = class {
        constructor(a, b, c, d, e = {}, f = [], g = !1) {
            this.j = a;
            this.G = b;
            this.g = c;
            this.D = d.Cc;
            this.Aa = d.ee || [];
            this.W = d.Fl || null;
            this.pa = d.ul || [];
            this.Z = d.ig || [];
            this.B = e;
            this.l = !1;
            this.O = [];
            this.A = [];
            this.T = this.J = void 0;
            this.Le = f;
            this.C = g ? new xP : null
        }
        Ba() {
            return this.g
        }
        Rc() {
            if ((this.j.g.g ? .A().length ? ? 0) == 0) return !1;
            if (this.T === void 0) {
                let a = rQ(mQ(lQ(fQ([0, 1, 2]))), 1).build(),
                    b = dK(995, () => kR(this.j, a), this.g);
                this.T = this.j.g.g ? .T(b) || !1
            }
            return this.T
        }
        qh() {
            return !!this.B.Qj
        }
        xf() {
            return !JR(this.g)
        }
        Gb() {
            return this.C
        }
    };
    const TR = (a, b) => b.top <= a;

    function bS(a, b, c, d, e, f = 0, g = 0) {
        this.dc = a;
        this.Lf = f;
        this.Kf = g;
        this.errors = b;
        this.ed = c;
        this.g = d;
        this.j = e
    };
    var cS = (a, {
        xf: b = !1,
        qh: c = !1,
        fn: d = !1,
        Rc: e = !1
    } = {}) => {
        var f = [];
        d && f.push(9);
        if (e) {
            a.includes(4) && !c && b && f.push(8);
            a.includes(1) && f.push(1);
            d = a.includes(3);
            e = a.includes(2);
            let g = a.includes(1);
            (d || e || g) && f.push(10)
        } else a.includes(3) && f.push(6), a.includes(4) && !c && b && f.push(8), a.includes(1) && f.push(1, 5), a.includes(2) && f.push(7);
        a.includes(4) && c && b && f.push(8);
        return f
    };

    function dS(a, b, c) {
        a = cS(a, {
            xf: b.xf(),
            qh: b.qh(),
            fn: !!b.B.Wg,
            Rc: b.Rc()
        });
        return new eS(a, b, c)
    }

    function fS(a, b) {
        var c = JP[b];
        return c ? dK(998, () => c(a.g), a.B) : (a.g.O.push(12), !0)
    }

    function gS(a, b) {
        return new Promise(c => {
            setTimeout(() => {
                c(fS(a, b))
            })
        })
    }

    function hS(a) {
        a.g.l = !0;
        return Promise.all(a.j.map(b => gS(a, b))).then(b => {
            b.includes(!1) && a.g.O.push(5);
            a.j.splice(0, a.j.length)
        })
    }
    var eS = class {
        constructor(a, b, c) {
            this.A = a.slice(0);
            this.j = a.slice(0);
            this.l = jb(this.j, 1);
            this.g = b;
            this.B = c
        }
    };
    var iS = class {
        constructor(a) {
            this.g = a;
            this.exception = void 0
        }
    };

    function jS(a) {
        return hS(a).then(() => {
            var b = a.g.j.j.filter(vK).g.length;
            var c = a.g.O.slice(0);
            var d = a.g;
            d = [...d.A, ...(d.j.g.g ? .D() || [])];
            b = new bS(b, c, d, a.g.j.j.g.length, a.g.j.A.g, a.g.j.j.filter(vK).filter(wK).g.length, a.g.j.j.filter(wK).g.length);
            return new iS(b)
        })
    };
    var kS = class {
        g() {
            return new yu([], {
                google_reactive_ad_format: 40,
                google_tag_origin: "qs"
            })
        }
    };
    var lS = class {
        g() {
            return new yu(["adsbygoogle-resurrected-ad-slot"], {})
        }
    };

    function mS(a) {
        return HI(a.g.document).map(b => {
            var c = new oK(b, 3);
            b = dJ(b, a.g.fqjyf ? ? {}) ? .LmpfC;
            return new uK(c, new qK(b), a.j, !1, 0, [], null, a.g, null)
        })
    }
    var nS = class {
        constructor(a) {
            var b = new lS;
            this.g = a;
            this.j = b || null
        }
    };
    const oS = {
        ji: "10px",
        sg: "10px"
    };

    function pS(a) {
        return ws(a.g.document.querySelectorAll("INS.adsbygoogle-placeholder")).map(b => new uK(new oK(b, 1), new mK(oS), a.j, !1, 0, [], null, a.g, null))
    }
    var qS = class {
        constructor(a, b) {
            this.g = a;
            this.j = b || null
        }
    };

    function rS(a, b) {
        var c = [];
        b.forEach((d, e) => {
            c.push(ka(e, "replaceAll").call(e, "~", "_") + "--" + d.map(f => Number(f)).join("_"))
        });
        GQ(a.g, "cnstr", c, 80)
    }
    var sS = class extends BQ {
        constructor() {
            super(-1);
            this.g = {}
        }
        getData(a) {
            a = super.getData(a);
            Object.assign(a, this.g);
            return a
        }
    };
    var tS = class extends Error {
        constructor(a, b, c) {
            super(a);
            this.g = b;
            this.field = c
        }
    };

    function uS(a, b, c) {
        return a == null ? new tS(b + "ShouldNotBeNull", 2, c) : a == 0 ? new tS(b + "ShouldNotBeZero", 3, c) : a < -1 ? new tS(b + "ShouldNotBeLessMinusOne", 4, c) : null
    }

    function vS(a, b, c) {
        var d = uS(c.he, "gapsMeasurementWindow", 1) || uS(c.vd, "gapsPerMeasurementWindow", 2) || uS(c.Gd, "maxGapsToReport", 3);
        return d != null ? bu(d) : c.kg || c.vd != -1 || c.Gd != -1 ? $t(new wS(a, b, c)) : bu(new tS("ShouldHaveLimits", 1, 0))
    }

    function xS(a) {
        return WR(a.l) && WR(a.l).placed || []
    }

    function yS(a) {
        return xS(a).map(b => Nt(Lt(b.element, a.g)))
    }

    function zS(a) {
        return xS(a).map(b => b.index)
    }

    function AS(a, b) {
        var c = b.ta;
        return !a.C && c.l && gd(ve(c.l, 8)) != null && qf(c.l, 8) == 1 ? [] : c.A ? (c.J || []).map(d => Nt(Lt(d, a.g))) : [Nt(new Mt(b.Fa.g, 0))]
    }

    function BS(a) {
        a.sort((e, f) => e.g - f.g);
        var b = [],
            c = 0;
        for (let e = 0; e < a.length; ++e) {
            var d = a[e];
            let f = d.g;
            d = d.g + d.j;
            f <= c ? c = Math.max(c, d) : (b.push(new Mt(c, f - c)), c = d)
        }
        return b
    }

    function CS(a, b) {
        b = b.map(c => {
            var d = new En;
            d = tf(d, 1, c.g);
            c = c.getHeight();
            return tf(d, 2, c)
        });
        return Gn(Fn(new Hn, a), b)
    }

    function DS(a) {
        var b = Ve(a, En, 2, w()).map(c => `G${gf(c,1)}~${c.getHeight()}`);
        return `W${gf(a,1)}${b.join("")}`
    }

    function ES(a, b) {
        var c = [],
            d = 0;
        for (let e of zs(b)) {
            let f = b.get(e);
            f.sort((g, h) => h.getHeight() - g.getHeight());
            a.G || f.splice(a.B, f.length);
            !a.D && d + f.length > a.j && f.splice(a.j - d, f.length);
            c.push(CS(e, f));
            d += f.length;
            if (!a.D && d >= a.j) break
        }
        return c
    }

    function FS(a) {
        var b = Ve(a, Hn, 5, w()).map(c => DS(c));
        return `M${gf(a,1)}H${gf(a,2)}C${gf(a,3)}B${Number(!!B(a,4))}${b.join("")}`
    }

    function GS(a) {
        var b = cL(Xt(a.l.j.j), a.g),
            c = yS(a),
            d = new Cs(zS(a));
        for (var e = 0; e < b.length; ++e) {
            if (d.contains(e)) continue;
            var f = AS(a, b[e]);
            c.push(...f)
        }
        c.push(new Mt(0, 0));
        c.push(Nt(new Mt(ms(a.g).scrollHeight, 0)));
        b = BS(c);
        c = new Bs;
        for (d = 0; d < b.length; ++d) e = b[d], f = a.O ? 0 : Math.floor(e.g / a.A), xs(c, f) || c.set(f, []), c.get(f).push(e);
        b = ES(a, c);
        c = new In;
        c = tf(c, 1, a.j);
        c = tf(c, 2, a.A);
        c = tf(c, 3, a.B);
        a = rf(c, 4, a.C);
        return Xe(a, 5, b)
    }

    function HS(a) {
        a = GS(a);
        return FS(a)
    }
    var wS = class {
        constructor(a, b, c) {
            this.O = c.he == -1;
            this.A = c.he;
            this.G = c.vd == -1;
            this.B = c.vd;
            this.D = c.Gd == -1;
            this.j = c.Gd;
            this.C = c.eh;
            this.l = b;
            this.g = a
        }
    };

    function wI(a, b, c) {
        var d = b.Vb;
        b.Qc && U(Fv) && (d = 1, "r" in c && (c.r += "F"));
        d <= 0 || (!b.mc || "pvc" in c || (c.pvc = Cl(a.g)), zA(b.Nc, c, d))
    }

    function IS(a, b, c) {
        c = c.getData(a.g);
        b.mc && (c.pvc = Cl(a.g));
        0 <= b.Vb && (c.r = b.Vb, wI(a, b, c))
    }
    var JS = class {
        constructor(a) {
            this.g = a
        }
    };
    const KS = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function LS(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        zA("ama", b, .01)
    }

    function MS(a) {
        var b = {};
        Nk(KS, (c, d) => {
            a.hasOwnProperty(d) && (b[d] = a[d])
        });
        return b
    };

    function NS(a) {
        var b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                let e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function OS(a) {
        var b = "",
            c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            let e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function PS(a, b) {
        a = mf(a, 2);
        if (!a) return !1;
        for (let c = 0; c < a.length; c++)
            if (a[c] == b) return !0;
        return !1
    }

    function QS(a, b) {
        a = OS(NS(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        var c = ou(a),
            d = RS(a);
        return b.find(e => {
            if (ze(e, qJ, 7)) {
                var f = x(e, qJ, 7);
                f = kd(ve(f, 1, void 0, ue))
            } else f = kd(ve(e, 1, void 0, ue));
            ze(e, qJ, 7) ? (e = x(e, qJ, 7), e = qf(e, 2)) : e = 2;
            if (!qc(f)) return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function RS(a) {
        for (var b = {};;) {
            b[ou(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };

    function SS(a, b) {
        try {
            b.removeItem("google_ama_config")
        } catch (c) {
            LS(a, {
                lserr: 1
            })
        }
    };
    var US = (a, b, c, d, e, f = null, g = null) => {
            TS(a, new JS(a), b, c, d, e, f, g)
        },
        TS = (a, b, c, d, e, f, g = null, h = null) => {
            if (c)
                if (d) {
                    var k = fN(d, e);
                    try {
                        let l = new VS(a, b, c, d, e, k, f, g, h);
                        Lf(d, 35) && c !== pf(d, 35) ? YA(HA(), yg(Eo(Fo(new Go, pf(d, 35)), c))) : dK(990, () => WS(l), a)
                    } catch (l) {
                        Rl() && Sl(15, [l]), IS(b, pI, AQ(yQ(xQ(DQ(CQ(new EQ(0), d), k), c), 1), l)), RA(HA(), ro(new Ao, Bn(1)))
                    }
                } else IS(b, pI, yQ(xQ(new EQ(0), c), 8)), RA(HA(), ro(new Ao, Bn(8)));
            else IS(b, pI, yQ(new EQ(0), 9)), RA(HA(), ro(new Ao, Bn(9)))
        };

    function WS(a) {
        a.J.forEach(b => {
            switch (b) {
                case 0:
                    dK(991, () => XS(a), a.g);
                    break;
                case 1:
                    dK(1073, () => {
                        ZM(new eN(a.g, a.C, a.A, a.B, a.j.ja))
                    }, a.g);
                    break;
                case 3:
                    dK(1663, () => {
                        AM(new EM(a.g, a.C, a.A, a.B, a.j.ja))
                    }, a.g);
                    break;
                case 2:
                    YS(a);
                    break;
                case 4:
                    dK(1680, () => {
                        var c = x(a.A, PJ, 38);
                        c && a.Aa.runVideoFeed({
                            win: a.g,
                            Gn: pe(c),
                            webPropertyCode: a.B
                        })
                    }, a.g)
            }
        })
    }

    function XS(a) {
        var b = U(ov) ? void 0 : a.j.Pm,
            c = null;
        c = U(ov) ? uL(a.g) : sL(a.g, b);
        if (a.j.ja && ze(a.j.ja, pJ, 10)) {
            var d = oJ(a.j.ja.g());
            d !== null && d !== void 0 && (c = iL(a.g, d, b));
            U(Kv) && (b = a.j.ja.g(), b ? .g() === 2 && (c = kL(b, c)))
        }
        ze(a.A, lJ, 26) && (c = xL(c, x(a.A, lJ, 26), a.g));
        c = zL(c, a.g);
        b = a.j.ja ? mf(a.j.ja, 6) : [];
        d = a.j.ja ? Ve(a.j.ja, uJ, 5, w()) : [];
        var e = a.j.ja ? mf(a.j.ja, 2) : [],
            f = dK(993, () => {
                var g = a.A,
                    h = RJ(g),
                    k = a.j.ja && PS(a.j.ja, 1) ? "text_image" : "text",
                    l = new kS,
                    m = tK(h, a.g, {
                        Ok: l,
                        am: new rK(k)
                    });
                h.length != m.length && a.G.push(13);
                m = m.concat(pS(new qS(a.g,
                    l)));
                h = U(Gv);
                l = x(g, OJ, 24) ? .l() ? .g() ? .g() || !1;
                if (h || l) h = mS(new nS(a.g)), l = ar($Q), m = m.concat(h), l.W = !0, l.D = h.length, a.O === "n" && (a.O = x(g, OJ, 24) ? .g() ? .length ? "o" : "p");
                h = U(Kv) && a.j.ja.g() ? .g() === 2 && a.j.ja.g() ? .l();
                h = U(iv) || h;
                a: {
                    if (l = x(g, FI, 6))
                        for (n of l.g())
                            if (ze(n, mu, 4)) {
                                var n = !0;
                                break a
                            }
                    n = !1
                }
                h && n ? (n = m.concat, h = a.g, (l = x(g, FI, 6)) ? (h = VK(l.g(), h), k = tP(g, k, h)) : k = [], k = n.call(m, k)) : (n = m.concat, h = a.g, (l = x(g, FI, 6)) ? (h = UK(l.g(), h), k = tP(g, k, h)) : k = [], k = n.call(m, k));
                m = k;
                g = x(g, OJ, 24);
                return new nR(m, a.g, g)
            }, a.g);
        a.l = new aS(f, a.B, a.g, {
            Cc: c,
            Fl: a.W,
            ee: a.j.ee,
            ul: b,
            ig: d
        }, ZS(a), e, U(Fv));
        WR(a.l) ? .optimization ? .ablatingThisPageview && !a.l.Rc() && (cJ(a.g), ar($Q).C = !0, a.O = "f");
        a.D = dS(e, a.l, a.g);
        dK(992, () => jS(a.D), a.g).then(dK(994, () => a.pa.bind(a), a.g), a.Z.bind(a))
    }

    function YS(a) {
        var b = x(a.A, FJ, 18);
        b && GO(new HO(a.g, new sP(a.g, a.B), b, new EC(a.g), RJ(a.A)))
    }

    function ZS(a) {
        var b = U(Iv);
        if (!a.A.g()) return {
            Vj: b,
            Ui: !1,
            Qj: !1,
            Nm: 0,
            Gj: 0,
            yi: $S(a),
            Wg: a.T
        };
        var c = a.A.g();
        return {
            Vj: b || B(c, 14),
            Ui: B(c, 5),
            Qj: B(c, 6),
            Nm: jf(c, 8),
            Gj: qf(c, 10),
            yi: $S(a),
            Wg: a.T
        }
    }

    function $S(a) {
        return U(zv) || U(Kv) && a.j.ja ? .g() ? .g() === 2 ? !1 : a.j.ja && ze(a.j.ja, pJ, 10) ? (oJ(a.j.ja.g()) || 0) >= .5 : !0
    }

    function aT(a, b) {
        var c = new EQ(b.dc);
        c.g.pp = b.Kf;
        c.g.ppp = b.Lf;
        c.g.ppos = b.placementPositionDiffs;
        c.g.eatf = b.Yd;
        c.g.eatfAbg = b.Zd;
        c.g.reatf = b.wd;
        c.g.a = a.D.A.slice(0).join(",");
        c = DQ(CQ(c, a.A), a.J);
        var d = b.xb;
        d && (c.g.as_count = d.ui, c.g.d_count = d.Si, c.g.ng_count = d.xj, c.g.am_count = d.zi, c.g.atf_count = d.wi, c.g.mdns = FQ(d.pj), c.g.alldns = FQ(d.xi));
        d = b.Kd;
        d != null && (c.g.allp = d);
        if (d = b.jf) {
            var e = [];
            for (var f of zs(d))
                if (d.get(f).length > 0) {
                    var g = d.get(f)[0];
                    e.push("(" + [f, g.qb, g.ck].join() + ")")
                }
            c.g.fd = e.join(",")
        }
        f =
            b.Lh;
        f != null && (c.g.pgh = f);
        c.g.abl = b.dj;
        c.g.rr = a.O;
        a = zQ(zQ(xQ(c, a.B), b.errors), a.G);
        c = b.ed;
        for (e = 0; e < c.length; e++) a: {
            f = a;d = c[e];
            for (g = 0; g < f.B.length; g++)
                if (f.B[g] == d) break a;f.B.push(d)
        }
        b.exception !== void 0 && yQ(AQ(a, b.exception), 1);
        return a
    }

    function bT(a, b) {
        var c = aT(a, b);
        IS(a.C, b.errors.length > 0 || a.G.length > 0 || b.exception !== void 0 ? pI : oI, c);
        if (x(a.A, OJ, 24)) {
            a.l.j.g.g ? .G();
            b = WR(a.l);
            let d = ar($Q);
            d.l = !!b ? .optimization ? .ablationFromStorage;
            b ? .optimization ? .ablatingThisPageview && (d.O = !0);
            d.Z = !!b ? .optimization ? .availableAbg;
            b = ar($Q);
            c = new RQ(c);
            b.B ? (c.j.sl = HQ(b.B ? ? []), c.j.daaos = HQ(b.J ? ? []), c.j.ab = IQ(b.O), c.j.rr = IQ(b.W), c.j.oab = IQ(b.G), b.l != null && (c.j.sab = IQ(b.l)), b.C && (c.j.fb = IQ(b.C)), c.j.ls = IQ(b.Z), JQ(c, b.j.je()), b.D != null && (c.j.rp = IQ(b.D)),
                b.A != null && (c.j.expl = IQ(b.A)), ZQ(b, c)) : c.errors.push("irr");
            IS(a.C, rI, c)
        }
        c = a.l ? .Gb();
        U(Fv) && c != null && (c = new Map([...c.l.map.entries()].map(vP)), b = new sS, rS(b, c), IS(a.C, uI, b))
    }

    function cT(a, b) {
        if (U(sv) && a.l != null) {
            var c = vS(a.g, a.l, {
                he: V(Ev),
                vd: V(Dv),
                Gd: V(vv),
                eh: !0,
                kg: !1
            });
            if (du(c)) a = new Ln, c = GS(c.getValue()), a = z(a, 2, Kn, c), y(b, 16, a);
            else {
                var d = c.g;
                a = new Ln;
                c = a.setError;
                var e = new Jn;
                e = Kf(e, 2, d.field);
                d = Kf(e, 1, d.g);
                a = c.call(a, d);
                y(b, 16, a)
            }
        }
    }

    function dT(a, b) {
        var c = HA();
        if (c.g) {
            var d = new Ao,
                e = b.ed.filter(g => g !== null),
                f = a.G.concat(b.errors, b.exception ? [1] : []).filter(g => g !== null);
            wo(to(zo(yo(xo(vo(uo(oo(qo(so(po(d, a.D.A.slice(0).map(g => {
                var h = new An;
                return Kf(h, 1, g)
            })), e.map(g => {
                var h = new Dn;
                return Kf(h, 1, g)
            })), f.map(g => Bn(g))), x(a.A, zJ, 23) ? .g()), b.dc), b.Kd), b.wd), b.Yd), b.Zd), a.J.map(g => g.toString())), Sn(Rn(Qn(Pn(On(Nn(Mn(new Tn, b.xb ? .ui), b.xb ? .Si), b.xb ? .xj), b.xb ? .zi), b.xb ? .wi), b.xb ? .pj), b.xb ? .xi));
            if (b.jf)
                for (let g of zs(b.jf)) {
                    e = new Yn;
                    for (let h of b.jf.get(g)) Xn(e, Vn(Un(new Wn, h.qb), h.ck));
                    Le(d, 14, Yn).set(g.toString(), e)
                }
            x(a.A, OJ, 24) && mo(d);
            cT(a, d);
            RA(c, d)
        }
    }

    function eT(a, b, c) {
        {
            var d = WR(a.l),
                e = b.g;
            let f = e.g,
                g = e.Kf,
                h = e.dc,
                k = e.Lf,
                l = e.errors.slice(),
                m = e.ed.slice(),
                n = b.exception,
                p = eA(a.g).had_ads_ablation ? ? !1;
            d ? (d.numAutoAdsPlaced ? h += d.numAutoAdsPlaced : a.D.l && m.push(13), d.exception !== void 0 && (n = d.exception), d.numPostPlacementsPlaced && (k += d.numPostPlacementsPlaced), c = {
                dc: h,
                Kf: g,
                Lf: k,
                Kd: f,
                errors: e.errors.slice(),
                ed: m,
                exception: n,
                wd: c,
                Yd: !!d.eatf,
                Zd: !!d.eatfAbg,
                dj: p
            }) : (m.push(12), a.D.l && m.push(13), c = {
                dc: h,
                Kf: g,
                Lf: k,
                Kd: f,
                errors: l,
                ed: m,
                exception: n,
                wd: c,
                Yd: !1,
                Zd: !1,
                dj: p
            })
        }
        c.xb = SR(a.l.g);
        if (b = b.g.j) c.jf = b;
        c.Lh = ms(a.g).scrollHeight;
        if (Rl() || x(a.A, yJ, 25) ? .A()) {
            d = Xt(a.l.j.j);
            b = [];
            for (let f of d) {
                d = {};
                e = f.T;
                for (let g of zs(e)) d[g] = e.get(g);
                d = {
                    anchorElement: f.O.j(f.j),
                    position: f.g(),
                    clearBoth: f.G,
                    locationType: f.Dd,
                    placed: f.A,
                    placementProto: f.l ? $d(f.l) : null,
                    articleStructure: f.B ? $d(f.B) : null,
                    rejectionReasons: d
                };
                b.push(d)
            }
            Sl(14, [{
                placementIdentifiers: b
            }, a.l.G, c.xb])
        }
        return c
    }

    function fT(a, b) {
        var c = a.l.g;
        c = c.googleSimulationState = c.googleSimulationState || {};
        c.amaConfigPlacementCount = b.Kd;
        c.numAutoAdsPlaced = b.dc;
        c.hasAtfAd = b.wd;
        b.exception !== void 0 && (c.exception = b.exception);
        if (a.l != null)
            if (a = vS(a.g, a.l, {
                    he: -1,
                    vd: -1,
                    Gd: -1,
                    eh: !0,
                    kg: !0
                }), du(a)) c.placementPositionDiffs = HS(a.getValue()), b = GS(a.getValue()), a = new Ln, a = z(a, 2, Kn, b), c.placementPositionDiffsReport = xg(a);
            else {
                c.placementPositionDiffs = "E" + a.g.message;
                var d = a.g;
                a = new Ln;
                b = a.setError;
                var e = new Jn;
                e = Kf(e, 2, d.field);
                d =
                    Kf(e, 1, d.g);
                a = b.call(a, d);
                c.placementPositionDiffsReport = xg(a)
            }
    }

    function gT(a, b) {
        bT(a, {
            dc: 0,
            Kd: void 0,
            errors: [],
            ed: [],
            exception: b,
            wd: void 0,
            Yd: void 0,
            Zd: void 0,
            xb: void 0
        });
        dT(a, {
            dc: 0,
            Kd: void 0,
            errors: [],
            ed: [],
            exception: b,
            wd: void 0,
            Yd: void 0,
            Zd: void 0,
            xb: void 0
        })
    }
    var VS = class {
        constructor(a, b, c, d, e, f, g, h, k) {
            this.g = a;
            this.C = b;
            this.B = c;
            this.A = d;
            this.j = e;
            this.J = f;
            this.Aa = g;
            this.W = h || null;
            this.G = [];
            this.T = k;
            this.O = "n"
        }
        pa(a) {
            try {
                let b = RR(this.l.g) || void 0;
                IM({
                    Jg: b
                }, this.g);
                let c = eT(this, a, RR(this.l.g));
                ze(this.A, yJ, 25) && xJ(x(this.A, yJ, 25)) && fT(this, c);
                bT(this, c);
                dT(this, c);
                xA(753, () => {
                    if (U(rv) && this.l != null) {
                        var d = vS(this.g, this.l, {
                                he: V(Ev),
                                vd: V(Dv),
                                Gd: V(vv),
                                eh: !0,
                                kg: !1
                            }),
                            e = $i(c);
                        du(d) ? (d = HS(d.getValue()), e.placementPositionDiffs = d) : e.placementPositionDiffs = "E" +
                            d.g.message;
                        e = aT(this, e);
                        IS(this.C, qI, e)
                    }
                })()
            } catch (b) {
                gT(this, b)
            }
        }
        Z(a) {
            gT(this, a)
        }
    };
    var hT = class extends J {},
        iT = yh(hT);

    function jT(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        var c = b;
        return c ? cu(() => iT(c)) : $t(null)
    };

    function kT(a, b) {
        return rf(a, 5, b)
    }

    function lT(a, b) {
        return rf(a, 12, b)
    }
    var mT = class extends J {
        A() {
            return Lf(this, 1)
        }
        l() {
            return Lf(this, 2)
        }
        g() {
            return B(this, 3)
        }
        ha() {
            return B(this, 5)
        }
    };
    var qT = ({
            Jb: a,
            win: b,
            Ya: c,
            sf: d = !1,
            tf: e = !1
        }) => {
            nT({
                win: b,
                Ya: c,
                sf: d,
                tf: e
            }) ? (b = (b = Rz(Hz())) ? oT(b) : void 0) ? a($t(b)) : pT().then(f => f.map(oT)).then(a) : a($t(kT(new mT, !0)))
        },
        sT = ({
            win: a,
            Ya: b,
            sf: c = !1,
            tf: d = !1
        }) => nT({
            win: a,
            Ya: b,
            sf: c,
            tf: d
        }) ? (b = Rz(Hz())) ? rT(a, oT(b)) : bu(Error("tcunav")) : rT(a, kT(new mT, !0));

    function nT({
        win: a,
        Ya: b,
        sf: c,
        tf: d
    }) {
        if (!(d = !d && lP(new pP(a)))) {
            if (c = !c) {
                if (b) {
                    a = jT(a);
                    if (du(a))
                        if ((a = a.getValue()) && gd(ve(a, 1)) != null) b: switch (a = F(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else AA(806, a.g), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function pT() {
        return (new Promise(a => {
            var b = Hz();
            a = {
                resolve: a
            };
            var c = Mz(b, 25, []);
            c.push(a);
            Nz(b, 25, c)
        })).then(tT)
    }

    function tT(a) {
        return a ? $t(a) : bu(Error("tcnull"))
    }

    function oT(a) {
        return kT(new mT, gP(a))
    }

    function rT(a, b) {
        return (a = pH(b, a)) ? $t(a) : bu(Error("unav"))
    };
    var uT = class {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.B = b;
            this.A = c;
            this.j = !1;
            this.l = d;
            this.C = e
        }
    };
    var vT = class extends J {
        getName() {
            return F(this, 1)
        }
        getVersion() {
            return C(this, 3)
        }
    };
    var wT = [0, vh, -1, sh];
    var xT = class extends J {
        Pl() {
            return F(this, 3)
        }
    };
    const yT = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var zT = class extends J {
        getVersion() {
            return gf(this, 2)
        }
    };

    function AT(a) {
        return a.includes("~") ? a.split("~").slice(1) : []
    };

    function BT(a) {
        return Db(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function CT(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function DT(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        var b = [1, 2, 3, 5],
            c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    }

    function ET(a, b) {
        a = BT(a);
        return a.length < b ? a.padEnd(b, "0") : a
    };

    function FT(a) {
        var b = BT(a),
            c = CT(b.slice(0, 6));
        a = CT(b.slice(6, 12));
        var d = new zT;
        c = uf(d, 1, c);
        a = uf(c, 2, a);
        b = b.slice(12);
        c = CT(b.slice(0, 12));
        d = [];
        var e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = CT(e[0]) === 0;
            e = e.slice(1);
            var g = GT(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = DT(g) + h;
            e = e.slice(g.length);
            if (f) {
                d.push(h);
                continue
            }
            f = GT(e, b);
            g = DT(f);
            for (let l = 0; l <= g; l++) d.push(h + l);
            e = e.slice(f.length)
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return Ne(a, 3, d, hd)
    }

    function GT(a, b) {
        var c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var HT = class extends J {
        g() {
            return F(this, 1)
        }
        l() {
            return F(this, 2)
        }
    };
    var IT = class extends J {};
    var JT = class extends J {
        getVersion() {
            return gf(this, 1)
        }
    };
    var KT = class extends J {};

    function LT(a) {
        var b = new MT;
        return y(b, 1, a)
    }
    var MT = class extends J {};
    const NT = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        OT = 6 + NT.reduce((a, b) => a + b);
    var PT = class extends J {};
    var QT = class extends J {
        getVersion() {
            return gf(this, 1)
        }
    };
    var RT = class extends J {};

    function ST(a) {
        var b = new TT;
        return y(b, 1, a)
    }
    var TT = class extends J {};
    const UT = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        VT = 6 + UT.reduce((a, b) => a + b);
    var WT = class extends J {
        g() {
            return F(this, 1)
        }
        l() {
            return F(this, 2)
        }
        A() {
            return F(this, 3)
        }
    };
    var XT = class extends J {};
    var YT = class extends J {
        getVersion() {
            return gf(this, 1)
        }
    };
    var ZT = class extends J {};

    function $T(a) {
        var b = new aU;
        return y(b, 1, a)
    }
    var aU = class extends J {};
    const bU = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        cU = 6 + bU.reduce((a, b) => a + b);
    var dU = class extends J {
        g() {
            return F(this, 1)
        }
        l() {
            return F(this, 2)
        }
        A() {
            return F(this, 3)
        }
    };
    var eU = class extends J {};
    var fU = class extends J {
        getVersion() {
            return gf(this, 1)
        }
    };
    const gU = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        hU = 6 + gU.reduce((a, b) => a + b);
    var iU = class extends J {
        l() {
            return F(this, 1)
        }
        A() {
            return F(this, 2)
        }
        g() {
            return F(this, 3)
        }
    };
    var jU = class extends J {};

    function kU(a) {
        var b = new lU;
        return uf(b, 1, a)
    }
    var lU = class extends J {
        getVersion() {
            return gf(this, 1)
        }
    };
    var mU = class extends J {};

    function nU(a) {
        var b = new oU;
        return y(b, 1, a)
    }
    var oU = class extends J {};
    const pU = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        qU = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        rU = 6 + qU.reduce((a, b) => a + b);

    function sU(a, b = [1]) {
        if (a.length === 0) throw Error("Cannot decode empty USNat section string.");
        var c = a.split(".");
        if (c.length > 2) throw Error(`Expected at most 2 segments but got ${c.length} when decoding ${a}.`);
        a = tU(c[0], b);
        if (c.length === 1) a = nU(a);
        else {
            a = nU(a);
            c = c[1];
            if (c.length === 0) throw Error("Cannot decode empty GPC segment string.");
            b = ET(c, 3);
            c = CT(b.slice(0, 2));
            if (c < 0 || c > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${c}.`);
            c += 1;
            b = CT(b.charAt(2));
            var d = new mU;
            c = H(d, 2,
                c);
            c = sf(c, 1, !!b);
            a = y(a, 2, c)
        }
        return a
    }

    function tU(a, b = [1]) {
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = ET(a, rU),
            d = CT(c.slice(0, 6));
        c = c.slice(6);
        if (!b.includes(d)) throw Error(`Unable to decode unsupported USNat Section specification version ${d} - only version${b.length>1?"s":""} ${b.join(", ")} ${b.length>1?"are":"is"} supported.`);
        var e = 0,
            f = [],
            g = d === 1 ? pU : qU;
        for (let tj = 0; tj < g.length; tj++) {
            let am = g[tj];
            f.push(CT(c.slice(e, e + am)));
            e += am
        }
        if (d === 1) {
            var h = kU(d),
                k = f.shift();
            var l = H(h, 2, k);
            var m = f.shift();
            var n =
                H(l, 3, m);
            var p = f.shift();
            var q = H(n, 4, p);
            var u = f.shift();
            var A = H(q, 5, u);
            var D = f.shift();
            var K = H(A, 6, D);
            var I = f.shift();
            var G = H(K, 7, I);
            var E = f.shift();
            var Q = H(G, 8, E);
            var wa = f.shift();
            var Ca = H(Q, 9, wa);
            var ia = f.shift();
            var Fa = H(Ca, 10, ia);
            var Sb = new jU,
                $c = f.shift();
            var Lc = H(Sb, 1, $c);
            var ee = f.shift();
            var ya = H(Lc, 2, ee);
            var Mc = f.shift();
            var Qg = H(ya, 3, Mc);
            var Rg = f.shift();
            var Sg = H(Qg, 4, Rg);
            var Tg = f.shift();
            var Ug = H(Sg, 5, Tg);
            var Wg = f.shift();
            var Xg = H(Ug, 6, Wg);
            var Yg = f.shift();
            var Zg = H(Xg, 7, Yg);
            var $g = f.shift();
            var ah = H(Zg, 8, $g);
            var bh = f.shift();
            var Ni = H(ah, 9, bh);
            var Oi = f.shift();
            var Pi = H(Ni, 10, Oi);
            var Qi = f.shift();
            var Ri = H(Pi, 11, Qi);
            var Si = f.shift();
            var Af = H(Ri, 12, Si);
            var Ti = y(Fa, 11, Af);
            var dh = new iU,
                Ui = f.shift();
            var Df = H(dh, 1, Ui);
            var Vi = f.shift();
            var Wi = H(Df, 2, Vi);
            var Xi = y(Ti, 12, Wi);
            var Ef = f.shift();
            var gh = H(Xi, 13, Ef);
            var Yi = f.shift();
            var ih = H(gh, 14, Yi);
            var xc = f.shift();
            var jh = H(ih, 15, xc);
            var Zi = f.shift();
            var Gf = H(jh, 16, Zi)
        } else {
            var kh = kU(d),
                Hf = f.shift();
            var uc = H(kh, 2, Hf);
            var ad = f.shift();
            var Va = H(uc,
                3, ad);
            var Vb = f.shift();
            var Pg = H(Va, 4, Vb);
            var Ge = f.shift();
            var Ff = H(Pg, 5, Ge);
            var vc = f.shift();
            var cc = H(Ff, 6, vc);
            var Zc = f.shift();
            var md = H(cc, 7, Zc);
            var Gb = f.shift();
            var wc = H(md, 8, Gb);
            var zf = f.shift();
            var Mi = H(wc, 9, zf);
            var Vg = f.shift();
            var nd = H(Mi, 10, Vg);
            var ch = new jU,
                Bf = f.shift();
            var Cf = H(ch, 1, Bf);
            var fe = f.shift();
            var fh = H(Cf, 2, fe);
            var hh = f.shift();
            var eh = H(fh, 3, hh);
            var rr = f.shift();
            var sr = H(eh, 4, rr);
            var tr = f.shift();
            var ur = H(sr, 5, tr);
            var vr = f.shift();
            var wr = H(ur, 6, vr);
            var xr = f.shift();
            var yr = H(wr,
                7, xr);
            var zr = f.shift();
            var Ar = H(yr, 8, zr);
            var Br = f.shift();
            var Cr = H(Ar, 9, Br);
            var Dr = f.shift();
            var Er = H(Cr, 10, Dr);
            var Fr = f.shift();
            var Gr = H(Er, 11, Fr);
            var Hr = f.shift();
            var Ir = H(Gr, 12, Hr);
            var Jr = f.shift();
            var Kr = H(Ir, 13, Jr);
            var Lr = f.shift();
            var Mr = H(Kr, 14, Lr);
            var bm = f.shift();
            var cm = H(Mr, 15, bm);
            var dm = f.shift();
            var em = H(cm, 16, dm);
            var fm = y(nd, 11, em);
            var gm = new iU,
                hm = f.shift();
            var im = H(gm, 1, hm);
            var jm = f.shift();
            var km = H(im, 2, jm);
            var lm = f.shift();
            var mm = H(km, 3, lm);
            var nm = y(fm, 12, mm);
            var om = f.shift();
            var pm =
                H(nm, 13, om);
            var qm = f.shift();
            var rm = H(pm, 14, qm);
            var sm = f.shift();
            var Nr = H(rm, 15, sm);
            var Or = f.shift();
            Gf = H(Nr, 16, Or)
        }
        return Gf
    };
    var uU = class extends J {};
    var vU = class extends J {
        getVersion() {
            return gf(this, 1)
        }
    };
    const wU = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        xU = 6 + wU.reduce((a, b) => a + b);

    function yU(a, b) {
        return Ne(a, 1, b, hd)
    }
    var zU = class extends J {};
    var AU = class extends J {};

    function BU(a, b) {
        return Ne(a, 1, b, fd)
    }

    function CU(a, b) {
        return Ne(a, 2, b, fd)
    }

    function DU(a, b) {
        return Ne(a, 3, b, hd)
    }

    function EU(a, b) {
        Ne(a, 4, b, hd)
    }
    var FU = class extends J {};

    function GU(a, b) {
        return wf(a, 1, b)
    }

    function HU(a) {
        var b = Number; {
            var c = ve(a, 1, void 0, void 0, zd);
            let d = typeof c;
            c = c == null ? c : d === "bigint" ? String(Sc(64, c)) : ed(c) ? d === "string" ? od(c) : sd(c) : void 0
        }
        b = b(c ? ? "0");
        a = gf(a, 2);
        return new Date(b * 1E3 + a / 1E6)
    }
    var IU = class extends J {};

    function JU(a, b) {
        return uf(a, 1, b)
    }

    function KU(a, b) {
        return y(a, 2, b)
    }

    function LU(a, b) {
        return y(a, 3, b)
    }

    function MU(a, b) {
        return uf(a, 4, b)
    }

    function NU(a, b) {
        return uf(a, 5, b)
    }

    function OU(a, b) {
        return uf(a, 6, b)
    }

    function PU(a, b) {
        return Jf(a, 7, b)
    }

    function QU(a, b) {
        return uf(a, 8, b)
    }

    function RU(a, b) {
        return uf(a, 9, b)
    }

    function SU(a, b) {
        return sf(a, 10, b)
    }

    function TU(a, b) {
        return sf(a, 11, b)
    }

    function UU(a, b) {
        return Ne(a, 12, b, fd)
    }

    function VU(a, b) {
        return Ne(a, 13, b, fd)
    }

    function WU(a, b) {
        return Ne(a, 14, b, fd)
    }

    function XU(a, b) {
        return sf(a, 15, b)
    }

    function YU(a, b) {
        return Jf(a, 16, b)
    }

    function ZU(a, b) {
        return Ne(a, 17, b, hd)
    }

    function $U(a, b) {
        return Ne(a, 18, b, hd)
    }

    function aV(a, b) {
        return Xe(a, 19, b)
    }
    var bV = class extends J {
        getVersion() {
            return gf(this, 1)
        }
    };
    var cV = class extends J {};
    var dV = Li(Zr).map(a => Number(a)),
        eV = Li($r).map(a => Number(a));

    function fV(a, b) {
        if (a.g + b > a.j.length) throw Error(`Requested length ${b} is past end of string.`);
        var c = a.j.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function gV(a) {
        a = fV(a, 36);
        var b = GU(new IU, Math.floor(a / 10));
        return uf(b, 2, a % 10 * 1E8)
    }

    function hV(a) {
        var b = () => {
            var c = fV(a, 6);
            if (c > 25 || c < 0) throw Error(`Invalid character code, expected in range [0,25], got: ${c}`);
            return String.fromCharCode(97 + c)
        };
        return b() + b()
    }

    function iV(a) {
        for (var b = fV(a, 12), c = []; b--;) {
            var d = !!fV(a, 1) === !0,
                e = fV(a, 16);
            if (d)
                for (d = fV(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function jV(a, b, c) {
        var d = [];
        for (let e = 0; e < b; e++)
            if (fV(a, 1)) {
                let f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function kV(a) {
        var b = fV(a, 16);
        if (!!fV(a, 1) === !0) {
            a = iV(a);
            for (let c of a)
                if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
            return a
        }
        return jV(a, b)
    }

    function lV(a) {
        for (var b = [], c = fV(a, 12); c--;) {
            let k = fV(a, 6);
            var d = fV(a, 2),
                e = iV(a),
                f = b,
                g = f.push;
            var h = new AU;
            h = H(h, 1, k);
            d = H(h, 2, d);
            e = Ne(d, 3, e, hd);
            g.call(f, e)
        }
        return b
    }
    var mV = class {
        constructor(a) {
            this.j = a;
            this.g = 0;
            if (/[^01]/.test(this.j)) throw Error(`Input bitstring ${this.j} is malformed!`);
        }
        skip(a) {
            this.g += a
        }
    };

    function nV(a) {
        try {
            let b = Db(a).map(d => d.toString(2).padStart(8, "0")).join(""),
                c = new mV(b);
            return fV(c, 3) !== 1 ? null : yU(new zU, kV(c))
        } catch (b) {
            return null
        }
    };

    function oV(a) {
        try {
            let b = Db(a).map(f => f.toString(2).padStart(8, "0")).join(""),
                c = new mV(b);
            if (fV(c, 3) !== 3) return null;
            let d = CU(BU(new FU, jV(c, 24, dV)), jV(c, 24, dV)),
                e = fV(c, 6);
            e !== 0 && EU(DU(d, jV(c, e)), jV(c, e));
            return d
        } catch (b) {
            return null
        }
    };

    function pV(a) {
        try {
            let b = Db(a).map(d => d.toString(2).padStart(8, "0")).join(""),
                c = new mV(b);
            return aV($U(ZU(YU(XU(WU(VU(UU(TU(SU(RU(QU(PU(OU(NU(MU(LU(KU(JU(new bV, fV(c, 6)), gV(c)), gV(c)), fV(c, 12)), fV(c, 12)), fV(c, 6)), hV(c)), fV(c, 12)), fV(c, 6)), !!fV(c, 1)), !!fV(c, 1)), jV(c, 12, eV)), jV(c, 24, dV)), jV(c, 24, dV)), !!fV(c, 1)), hV(c)), kV(c)), kV(c)), lV(c))
        } catch (b) {
            return null
        }
    };

    function qV(a) {
        if (!a) return null;
        a = a.split(".");
        if (a.length > 4) return null;
        var b = pV(a[0]);
        if (!b) return null;
        var c = new cV;
        b = y(c, 1, b);
        a.shift();
        for (let d of a) switch (rV(d)) {
            case 1:
                a = nV(d);
                if (!a) return null;
                y(b, 3, a);
                break;
            case 2:
                break;
            case 3:
                a = oV(d);
                if (!a) return null;
                y(b, 2, a);
                break;
            default:
                return null
        }
        return b
    }

    function rV(a) {
        try {
            let b = Db(a).map(c => c.toString(2).padStart(8, "0")).join("");
            return fV(new mV(b), 3)
        } catch (b) {
            return -1
        }
    };

    function sV(a, b) {
        var c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (let d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (let d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var tV = class extends J {
        g() {
            return Lf(this, 2)
        }
    };
    var uV = class extends J {
        g() {
            return Lf(this, 2)
        }
    };
    var vV = class extends J {};
    var wV = yh(class extends J {});

    function xV(a) {
        a = yV(a);
        try {
            var b = a ? wV(a) : null
        } catch (c) {
            b = null
        }
        return b ? x(b, vV, 4) || null : null
    }

    function yV(a) {
        a = qH({
            document: a,
            origin: a ? .location ? .origin,
            navigator: {
                cookieEnabled: !0
            },
            isSecureContext: !0
        }) ? (new lH(a)).get("FCCDCF", "") : "";
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function zV(a) {
        a.__tcfapiPostMessageReady || AV(new BV(a))
    }

    function AV(a) {
        a.g = b => {
            var c = typeof b.data === "string";
            try {
                var d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            var e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.win.__tcfapi)(e.command, e.version, (f, g) => {
                var h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            }, e.parameter)
        };
        a.win.addEventListener("message", a.g);
        a.win.__tcfapiPostMessageReady = !0
    }
    var BV = class {
        constructor(a) {
            this.win = a
        }
    };

    function CV(a) {
        a.__uspapiPostMessageReady || DV(new EV(a))
    }

    function DV(a) {
        a.g = b => {
            var c = typeof b.data === "string";
            try {
                var d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            var e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.win.__uspapi(e.command, e.version, (f, g) => {
                var h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.win.addEventListener("message", a.g);
        a.win.__uspapiPostMessageReady = !0
    }
    var EV = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
    };
    var FV = class extends J {};
    var GV = yh(class extends J {
        g() {
            return Lf(this, 1)
        }
    });

    function HV(a, b) {
        try {
            let c = a.split("."),
                d = Db(c[0]).map(g => g.toString(2).padStart(8, "0")).join(""),
                e = new mV(d);
            a = {
                tcString: a ? ? void 0,
                gdprApplies: b
            };
            e.skip(78);
            a.cmpId = fV(e, 12);
            a.cmpVersion = fV(e, 12);
            e.skip(30);
            a.tcfPolicyVersion = fV(e, 6);
            a.isServiceSpecific = !!fV(e, 1);
            a.useNonStandardStacks = !!fV(e, 1);
            a.specialFeatureOptins = IV(jV(e, 12, eV), eV);
            a.purpose = {
                consents: IV(jV(e, 24, dV), dV),
                legitimateInterests: IV(jV(e, 24, dV), dV)
            };
            a.purposeOneTreatment = !!fV(e, 1);
            a.publisherCC = hV(e);
            a.vendor = {
                consents: IV(kV(e), null),
                legitimateInterests: IV(kV(e), null)
            };
            let f = JV(c);
            f && (a.vendor.disclosedVendors = f);
            return a
        } catch (c) {
            return null
        }
    }

    function JV(a) {
        a.shift();
        for (let b of a)
            if (a = Db(b).map(c => c.toString(2).padStart(8, "0")).join(""), a = new mV(a), fV(a, 3) === 1) return IV(kV(a), null)
    }

    function IV(a, b) {
        var c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (let d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (let d of a) c[d] = !0;
        delete c[0];
        return c
    };

    function KV(a, b) {
        function c(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 4));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function d(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function e(n) {
            if (n.length < 12) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(8, 12));
            n = l(n);
            return "1" + p + n + "N"
        }

        function f(n) {
            if (n.length < 18) return null;
            var p = h(n.slice(0, 8));
            p = k(p);
            n = h(n.slice(12, 18));
            n = l(n);
            return "1" + p + n + "N"
        }

        function g(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function h(n) {
            var p = [],
                q = 0;
            for (let u = 0; u < n.length / 2; u++) p.push(CT(n.slice(q, q + 2))), q += 2;
            return p
        }

        function k(n) {
            return n.every(p => p === 1) ? "Y" : "N"
        }

        function l(n) {
            return n.some(p => p === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = BT(a[0]);
        var m = CT(a.slice(0, 6));
        a = a.slice(6);
        if (m !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function LV(a, b) {
        a === a.top && (a = new MV(a, b), NV(a), OV(a))
    }

    function NV(a) {
        !a.l || a.win.__uspapi || a.win.frames.__uspapiLocator || (a.win.__uspapiManager = "fc", RO(a.win, "__uspapiLocator"), Da("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && (b = B(a.j, 3), d({
                version: 1,
                uspString: b ? a.l : "1---"
            }, !0))
        }, a.win), CV(a.win))
    }

    function OV(a) {
        !a.tcString || a.win.__tcfapi || a.win.frames.__tcfapiLocator || (a.win.__tcfapiManager = "fc", RO(a.win, "__tcfapiLocator"), a.win.__tcfapiEventListeners = a.win.__tcfapiEventListeners || [], Da("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.3 || c <= 1)) d(null, !1);
                else {
                    var f = a.win.__tcfapiEventListeners;
                    c = a.j.g();
                    switch (b) {
                        case "ping":
                            d({
                                gdprApplies: c,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.3",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            b = f.push(d) -
                                1;
                            a.tcString ? (e = HV(a.tcString, c), e.addtlConsent = a.g != null ? a.g : void 0, e.cmpStatus = "loaded", e.eventStatus = "tcloaded", b != null && (e.listenerId = b), b = e) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && f[e] ? (f[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
                }
        }, a.win), zV(a.win))
    }

    function PV(a) {
        if (!a ? .g() || C(a, 1).length === 0 || Ve(a, FV, 2, w()).length === 0) return null;
        var b = C(a, 1);
        try {
            var c = FT(b.split("~")[0]);
            var d = AT(b)
        } catch (e) {
            return null
        }
        a = Ve(a, FV, 2, w()).reduce((e, f) => {
            var g = QV(e);
            g = hf(g, 1);
            g = HG(g);
            var h = QV(f);
            h = hf(h, 1);
            return g > HG(h) ? e : f
        });
        c = lf(c, 3).indexOf(gf(a, 1));
        return c === -1 || c >= d.length ? null : {
            uspString: KV(d[c], gf(a, 1)),
            Eg: HU(QV(a))
        }
    }

    function RV(a) {
        a = a.find(b => b && F(b, 1) === 13);
        if (a ? .g()) try {
            return GV(C(a, 2))
        } catch (b) {}
        return null
    }

    function QV(a) {
        return ze(a, IU, 2) ? x(a, IU, 2) : GU(new IU, 0)
    }
    var MV = class {
        constructor(a, b) {
            this.win = a;
            this.j = b;
            b = yV(this.win.document);
            try {
                var c = b ? wV(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = x(b, uV, 5) || null, b = Ve(b, tV, 7, w()), b = RV(b ? ? []), c = {
                Gi: c,
                cj: b
            }) : c = {
                Gi: null,
                cj: null
            };
            b = c;
            c = PV(b.cj);
            b = b.Gi;
            if (b ? .g() && C(b, 2).length !== 0) {
                var d = ze(b, IU, 1) ? x(b, IU, 1) : GU(new IU, 0);
                b = {
                    uspString: C(b, 2),
                    Eg: HU(d)
                }
            } else b = null;
            this.l = b && c ? c.Eg > b.Eg ? c.uspString : b.uspString : b ? b.uspString : c ? c.uspString : null;
            this.tcString = (c = xV(a.document)) && Lf(c, 1) ? C(c, 1) : null;
            this.g = (a = xV(a.document)) && Lf(a,
                2) ? C(a, 2) : null
        }
    };

    function SV(a, b, c, d = null) {
        var e = g => {
            try {
                var h = JSON.parse(g.data)
            } catch (k) {
                return
            }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
        };
        gk(a, "message", e);
        var f = !1;
        return () => {
            var g = !1;
            f || (f = !0, g = hk(a, "message", e));
            return g
        }
    }

    function TV(a, b, c, d = null) {
        var e = SV(a, b, ui(c, () => e()), d);
        return e
    }

    function UV(a, b, c, d) {
        c.googMsgType = b;
        a.postMessage(JSON.stringify(c), d)
    }

    function VV(a, b, c, d, e) {
        if (!(e <= 0) && (UV(a, b, c, d), a = a.frames))
            for (let f = 0; f < a.length; ++f) e > 1 && VV(a[f], b, c, d, --e)
    };

    function WV(a, b, c, d) {
        return SV(a, "fullscreen", d.wc(952, (e, f) => {
            if (f.source === b) {
                if (!("eventType" in e)) throw Error(`bad message ${JSON.stringify(e)}`);
                delete e.googMsgType;
                c(e)
            }
        }))
    };
    class XV {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };
    async function YV(a) {
        return a.B.promise
    }
    async function ZV(a) {
        return a.g.promise
    }
    async function $V(a) {
        return a.l.promise
    }

    function aW(a, b) {
        b.type = "err_st";
        b.slot = a.slotType;
        b.freq = .25;
        a.qem && (b.qem = a.qem);
        b.tag_type = a.C.yn;
        b.version = a.C.version;
        $m(a.F, "fullscreen_tag", b, !1, .25)
    }
    class bW extends Gs {
        constructor(a, b, c) {
            var d = tA,
                e = rA,
                f = {
                    yn: 2,
                    version: Yp()
                };
            super();
            this.slotType = a;
            this.pubWin = b;
            this.Cg = c;
            this.ob = d;
            this.F = e;
            this.C = f;
            this.state = 1;
            this.qem = null;
            this.B = new XV;
            this.g = new XV;
            this.l = new XV
        }
        init() {
            var a = WV(this.pubWin, this.Cg, b => {
                if (b.eventType === "adError") this.l.resolve(), this.state = 4;
                else if (b.eventType === "adReady" && this.state === 1) this.qem = b.qem, b.slotType !== this.slotType && (aW(this, {
                        cur_st: this.state,
                        evt: b.eventType,
                        adp_tp: b.slotType
                    }), this.state = 4), this.B.resolve(),
                    this.state = 2;
                else if (b.eventType === "adClosed" && this.state === 2) this.g.resolve(b.result), this.state = 3;
                else if (b.eventType !== "adClosed" || this.state !== 3) b.eventType === "adClosed" && b.closeAfterError && (this.g.resolve(b.result), this.state = 3), aW(this, {
                    cur_st: this.state,
                    evt: b.eventType
                }), this.state = 4
            }, this.ob);
            Is(this, a)
        }
    };
    var cW = Promise;
    class dW {
        constructor(a) {
            this.l = a
        }
        g(a, b, c) {
            this.l.then(d => {
                d.g(a, b, c)
            })
        }
        j(a, b) {
            return this.l.then(c => c.j(a, b))
        }
    };
    class eW {
        constructor(a) {
            this.data = a
        }
    };

    function fW(a, b) {
        gW(a, b);
        return new hW(a)
    }
    class hW {
        constructor(a) {
            this.l = a
        }
        g(a, b, c = []) {
            var d = new MessageChannel;
            gW(d.port1, b);
            this.l.postMessage(a, [d.port2].concat(c))
        }
        j(a, b) {
            return new cW(c => {
                this.g(a, c, b)
            })
        }
    }

    function gW(a, b) {
        b && (a.onmessage = c => {
            b(new eW(c.data, fW(c.ports[0])))
        })
    };
    var iW = class {
        constructor(a) {
            this.g = a
        }
    };
    const jW = a => {
        var b = Object.create(null);
        (typeof a === "string" ? [a] : a).forEach(c => {
            if (c === "null") throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
            b[c] = !0
        });
        return c => b[c] === !0
    };
    var lW = ({
        destination: a,
        L: b,
        origin: c,
        Ob: d = "ZNWN1d",
        onMessage: e,
        Aj: f
    }) => kW({
        destination: a,
        pf: () => b.contentWindow,
        Em: c instanceof iW ? c : typeof c === "function" ? new iW(c) : new iW(jW(c)),
        Ob: d,
        onMessage: e,
        Aj: f
    });
    const kW = ({
        destination: a,
        pf: b,
        Em: c,
        mp: d,
        Ob: e,
        onMessage: f,
        Aj: g
    }) => new dW(new cW((h, k) => {
        var l = m => {
            m.source && m.source === b() && c.g(m.origin) && (m.data.n || m.data) === e && (a.removeEventListener("message", l, !1), d && m.data.t !== d ? k(Error(`Token mismatch while establishing channel "${e}". Expected ${d}, but received ${m.data.t}.`)) : (h(fW(m.ports[0], f)), g && g(m)))
        };
        a.addEventListener("message", l, !1)
    }));
    var mW = xh(vn);
    var nW = xh(wn);
    var oW = xh(yn);
    var pW = xh(un);
    var qW = xh(xn);

    function rW() {
        var {
            promise: a,
            resolve: b
        } = new XV;
        return {
            promise: a,
            resolve: b
        }
    };

    function sW(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        var d = b[a];
        if (d) return d;
        d = rW();
        b[a] = d;
        c();
        return d
    }

    function tW(a, b, c) {
        return sW(a, b, () => {
            gl(b.document, c)
        }).promise
    };
    var uW = class {
        constructor(a) {
            this.cg = a
        }
        runVideoFeed({
            win: a,
            Gn: b,
            webPropertyCode: c
        }) {
            yA(1678, tW(13, a, this.cg).then(d => {
                d.runVideoFeed({
                    win: a,
                    serializedVideoFeedConfig: xg(b),
                    webPropertyCode: c
                })
            }))
        }
    };

    function vW(a, b, c, d, e, f, g = null) {
        if (e) {
            if (U(nv)) var h = null;
            else try {
                h = e.getItem("google_ama_config")
            } catch (m) {
                h = null
            }
            try {
                var k = h ? TJ(h) : null
            } catch (m) {
                k = null
            }
        } else k = null;
        a: {
            if (d) try {
                var l = TJ(d);
                break a
            } catch (m) {
                LS(a, {
                    cfg: 1,
                    inv: 1
                })
            }
            l = null
        }
        if (d = l) {
            if (e) {
                l = new nJ;
                y(d, 3, l);
                k = GG(d ? .g() ? .l()) || 1;
                k = Date.now() + 864E5 * k;
                Number.isFinite(k) && vf(l, 1, Math.round(k));
                l = oe(d);
                d.g() && (k = new mJ, h = d ? .g() ? .g(), k = rf(k, 23, h), h = d ? .g() ? .A(), k = rf(k, 12, h), y(l, 15, k));
                k = RJ(l);
                for (h = 0; h < k.length; h++) xe(k[h], 11);
                xe(l, 22);
                if (U(nv)) SS(a,
                    e);
                else try {
                    e.setItem("google_ama_config", xg(l))
                } catch (m) {
                    LS(a, {
                        lserr: 1
                    })
                }
            }
            e = QS(a, Ve(d, wJ, 7, w()));
            l = {};
            U(ov) || (l.Pm = x(d, EJ, 8) || new EJ);
            e && (l.ja = e);
            e && PS(e, 3) && (l.ee = [1]);
            e = l;
            fA(a, 2) && (Sl(5, [$d(d)]), c = MS(c), f = new uW(f), l = (l = e.ja) && pf(l, 4) || "", c.google_package = l, US(a, b, d, e, f, new yu(["google-auto-placed"], c), g));
            return !0
        }
        k && (LS(a, {
            cfg: 1,
            cl: 1
        }), e != null && SS(a, e));
        return !1
    };

    function wW(a) {
        var b = new O(a.dataset.adStatus || null);
        (new MutationObserver(() => {
            b.g(a.dataset.adStatus || null)
        })).observe(a, {
            attributes: !0
        });
        return ct(b)
    };

    function xW(a) {
        a.g != null || a.A || (a.g = new MutationObserver(b => {
            for (let c of b)
                for (let d of c.addedNodes) ra(d) && d.nodeType == 1 && (b = a, d.matches('A[href]:not([href=""])') && mt(b.l, d))
        }), a.g.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0
        }))
    }
    var yW = class extends Gs {
        constructor(a) {
            super();
            this.win = a;
            this.l = new nt;
            this.g = null;
            Is(this, () => {
                this.g ? .disconnect();
                this.g = null
            })
        }
    };

    function zW(a, b) {
        b.addEventListener("click", () => {
            var c = a.j;
            var d = b.getAttribute("href");
            c = d ? d === "#" ? $t(Io(4)) : d.startsWith("#") ? $t(Io(5)) : AW(d, c) : bu(Error("Empty href"));
            if (du(c)) {
                d = c.getValue();
                c = a.g;
                var e = new Ko;
                d = y(e, 1, d);
                c.call(a, d)
            } else a.l(c.g)
        })
    }
    var CW = class {
        constructor(a, b, c) {
            var d = BW();
            this.win = a;
            this.j = b;
            this.g = c;
            this.l = d
        }
        init() {
            var a = new yW(this.win);
            Array.from(a.win.document.querySelectorAll('A[href]:not([href=""])')).forEach(b => {
                zW(this, b)
            });
            xW(a);
            kt(a.l).listen(b => {
                zW(this, b)
            })
        }
    };

    function AW(a, b) {
        return DW(a, b).map(c => DW(b).map(d => {
            if (c.protocol === "http:" || c.protocol === "https:") {
                var e = Io(2);
                e = Jf(e, 2, `${c.host}${c.pathname}`);
                d = Jf(e, 3, `${d.host}${d.pathname}`)
            } else d = c.protocol === "javascript:" ? Io(3) : Io(1);
            return d
        }))
    }

    function DW(a, b) {
        return gu(cu(() => new URL(a, b)), () => Error("Invalid URL"))
    };

    function EW(a) {
        if (a < 0 || !Number.isInteger(a)) return bu(Error(`Not a non-negative integer: ${a}`));
        var b = [];
        do b.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a % 64)), a = Math.floor(a / 64); while (a > 0);
        return $t(b.reverse().join(""))
    };
    class FW {
        constructor() {
            this.kk = 5E3
        }
        el() {
            return 5E3
        }
    }

    function GW(a, b) {
        return a.quantizer ? Math.floor(b / 5E3) * 5E3 / a.quantizer.kk : b
    }

    function HW(a, b) {
        b = b.map(c => GW(a, c));
        return IW(b, a.g === void 0 ? void 0 : GW(a, a.g)).map(c => {
            a: {
                var d = JW;
                let e = [];
                for (let f of c) {
                    c = d(f);
                    if (!du(c)) {
                        d = bu(c.g);
                        break a
                    }
                    e.push(c.getValue())
                }
                d = $t(e)
            }
            return d
        }).map(c => c.join(".")).map(c => KW(c, a.quantizer ? .el()))
    }
    var LW = class {
        constructor(a, b) {
            this.quantizer = a;
            this.g = b
        }
    };

    function JW(a) {
        var b = EW(a.value);
        if (!du(b)) return b;
        var c = b.getValue();
        return a.Of === 1 ? $t(`${c}`) : a.Of === 2 ? $t(`${c}~`) : iu(EW(a.Of - 2), d => {
            throw d;
        }).map(d => `${c}~${d}`)
    }

    function IW(a, b) {
        var c = [];
        for (let d = 0; d < a.length; d++) {
            let e = a[d] ? ? b;
            if (e === void 0) return bu(Error("Sparse but no default"));
            c.length === 0 || e !== c[c.length - 1].value ? c.push({
                value: e,
                Of: 1
            }) : c[c.length - 1].Of++
        }
        return $t(c)
    }

    function KW(a, b) {
        return a === "" ? $t("") : MW(b).map(c => `${c}${a}`)
    }

    function MW(a) {
        return a === void 0 || a === 1 ? $t("") : hu(EW(a), "ComFactor: ").map(b => `~${b}.`)
    };
    var NW = class extends Gs {
        constructor(a) {
            super();
            this.win = a;
            this.l = new O(!1);
            this.g = () => {
                this.l.g(this.win.document.hasFocus())
            }
        }
        init() {
            this.win.addEventListener("focus", this.g);
            this.win.addEventListener("blur", this.g);
            Is(this, () => void this.win.removeEventListener("focus", this.g));
            Is(this, () => void this.win.removeEventListener("blur", this.g));
            this.l.g(this.win.document.hasFocus())
        }
    };

    function OW(a) {
        a.l.g(a.win.document.visibilityState === "visible")
    }
    var PW = class extends Gs {
        constructor(a) {
            super();
            this.win = a;
            this.l = new O(!1);
            this.g = () => void OW(this)
        }
        init() {
            this.win.addEventListener("visibilitychange", this.g);
            Is(this, () => void this.win.removeEventListener("visibilitychange", this.g));
            OW(this)
        }
    };

    function QW(a) {
        return a.g !== null ? a.j + a.l() - a.g : a.j
    }
    var SW = class {
        constructor(a) {
            this.win = a;
            this.j = 0;
            this.g = null;
            this.l = RW(this.win)
        }
        start() {
            this.g === null && (this.g = this.l())
        }
    };

    function RW(a) {
        return a.performance && a.performance.now ? () => a.performance.now() : () => Date.now()
    };

    function TW(a) {
        a = new UW(a);
        a.init();
        return a
    }

    function VW(a) {
        var b = yt(a.win, 1E3, () => void a.handleEvent());
        a.win.addEventListener("scroll", () => void b())
    }

    function WW(a) {
        var b = XW(a.win),
            c = () => {
                var d = XW(a.win),
                    e = Math.abs(d.height - b.height);
                if (Math.abs(d.width - b.width) > 20 || e > 20) a.G = !0, a.win.removeEventListener("resize", c)
            };
        a.win.addEventListener("resize", c)
    }

    function YW(a) {
        a.A = !a.g.X;
        gt(a.g, !1, () => {
            a.win.setTimeout(() => {
                a.A = !0
            }, 100)
        })
    }

    function ZW(a) {
        ft(a.g, !0, () => void a.l.start());
        ft(a.g, !1, () => {
            var b = a.l;
            b.g !== null && (b.j += b.l() - b.g);
            b.g = null
        });
        a.O.start()
    }

    function $W(a) {
        var b = a.win.scrollY;
        var c = is(a.win);
        b = {
            Wf: Math.floor(b / 100),
            bf: Math.floor((b + c) / 100),
            Zj: a.win.performance.now()
        };
        if (b.Wf < 0 || b.bf < 0 || b.Wf > 1E3 || b.bf > 1E3) a.D = !0, a.j = null;
        else {
            if (a.j) {
                c = a.j;
                var d = new DB(c.Wf, c.bf),
                    e = new DB(b.Wf, b.bf);
                var f = Math.max(d.start, e.start);
                d = Math.min(d.end, e.end);
                if (f = f <= d ? new DB(f, d) : null)
                    for (c = b.Zj - c.Zj, d = f.start; d <= f.end; d++) a.C[d] = (a.C[d] ? ? 0) + c
            }
            a.j = a.B.X ? b : null
        }
    }
    var UW = class {
        constructor(a) {
            this.win = a;
            this.C = [];
            this.G = this.A = this.D = !1;
            this.j = null;
            var b = this.win;
            a = new NW(b);
            a.init();
            a = ct(a.l);
            b = new PW(b);
            b.init();
            b = ct(b.l);
            this.B = this.g = bt(a, b);
            this.l = new SW(this.win);
            this.O = new SW(this.win);
            this.J = new LW((new LW(new FW)).quantizer, 0)
        }
        init() {
            VW(this);
            WW(this);
            YW(this);
            ZW(this);
            this.B.listen(() => void $W(this));
            r.setInterval(() => void this.handleEvent(), 5E3);
            this.handleEvent()
        }
        handleEvent() {
            this.B.X && $W(this)
        }
    };

    function XW(a) {
        return new Ei(hs(a), is(a))
    };

    function aX(a, {
        Ya: b
    }) {
        a = new bX(a, b);
        if (!a.Ya && U(Uv)) {
            b = a.win;
            var c = cX(dX(a));
            (new CW(b, b.document.baseURI, c)).init()
        }
        eX(a)
    }

    function eX(a) {
        if (U(Vv)) {
            var b = TW(a.win);
            Yq(new FA(a.win), fX(() => {
                var c = dX(a),
                    d = new No,
                    e = HW(b.J, b.C);
                if (!du(e)) throw hu(e, "PVDC: ").g;
                var f = new Mo;
                f = uf(f, 2, 5E3);
                f = uf(f, 1, 100);
                e = e.getValue();
                e = Jf(f, 3, e);
                f = XW(b.win);
                var g = new Lo;
                g = uf(g, 1, f.width);
                f = uf(g, 2, f.height);
                e = y(e, 4, f);
                f = new Lo;
                f = uf(f, 1, ms(b.win).scrollWidth);
                f = uf(f, 2, ms(b.win).scrollHeight);
                e = y(e, 5, f);
                e = sf(e, 6, b.A);
                f = Math.round(QW(b.O) / 1E3);
                e = uf(e, 8, f);
                f = Math.round(QW(b.l) / 1E3);
                e = uf(e, 9, f);
                b.D && Ye(e, 7, fd, 1, gd);
                b.G && Ye(e, 7, fd, 2, gd);
                d = z(d, 2, Oo,
                    e);
                c(d)
            }))
        }
    }

    function dX(a) {
        if (!a.g) {
            let b = HA();
            a.g = c => {
                VA(b, c)
            }
        }
        return a.g
    }
    var bX = class {
        constructor(a, b) {
            this.win = a;
            this.Ya = b;
            this.g = null
        }
    };

    function cX(a) {
        return b => {
            var c = new No;
            b = z(c, 1, Oo, b);
            return void a(b)
        }
    }

    function BW() {
        return a => {
            AA(1243, a, void 0, gX("LCC"))
        }
    }

    function fX(a) {
        return () => void wA(1243, a, gX("PVC"))
    }

    function gX(a) {
        return b => {
            b.errSrc = a
        }
    };
    const hX = {
        google: 1,
        googlegroups: 1,
        gmail: 1,
        googlemail: 1,
        googleimages: 1,
        googleprint: 1
    };

    function iX(a) {
        if (U(Kw)) return !1;
        var b = a.google_page_location || a.google_page_url;
        "EMPTY" === b && (b = a.google_page_url);
        if (!b) return !1;
        a = b.toString();
        a.indexOf("http://") == 0 ? a = a.substring(7, a.length) : a.indexOf("https://") == 0 && (a = a.substring(8, a.length));
        b = a.indexOf("/");
        b === -1 && (b = a.length);
        a = a.substring(0, b).split(".");
        b = !1;
        a.length >= 3 && (b = a[a.length - 3] in hX);
        a.length >= 2 && (b = b || a[a.length - 2] in hX);
        return b
    };

    function jX(a, b = !1) {
        try {
            return b ? (new Ei(a.innerWidth, a.innerHeight)).round() : vj(a || window).round()
        } catch (c) {
            return new Ei(-12245933, -12245933)
        }
    }

    function kX(a = r) {
        a = a.devicePixelRatio;
        return qc(a) ? +a.toFixed(3) : null
    }

    function lX(a, b = r) {
        a = a.scrollingElement || (a.compatMode === "CSS1Compat" ? a.documentElement : a.body);
        return new Di(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
    }

    function mX(a) {
        try {
            return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
        } catch (b) {
            return !1
        }
    };

    function nX(a, b) {
        var c = tA,
            d;
        var e;
        d = (e = (e = lr()) && (d = e.initialLayoutRect) && qc(d.top) && qc(d.left) && qc(d.width) && qc(d.height) ? new Nj(d.left, d.top, d.width, d.height) : null) ? new Di(e.left, e.top) : (d = or()) && d.rootBounds && ra(d.rootBounds) ? new Di(d.rootBounds.left + d.boundingClientRect.left, d.rootBounds.top + d.boundingClientRect.top) : null;
        if (d) return d;
        try {
            {
                let h = new Di(0, 0),
                    k = xj(rj(b));
                if (tb(k, "parent")) {
                    do {
                        if (k == a) var f = Zj(b);
                        else {
                            let l = Xj(b);
                            f = new Di(l.left, l.top)
                        }
                        d = f;
                        h.x += d.x;
                        h.y += d.y
                    } while (k && k != a && k != k.parent &&
                        (b = k.frameElement) && (k = k.parent))
                }
                var g = h
            }
            return g
        } catch (h) {
            return c.Da(888, h), new Di(-12245933, -12245933)
        }
    }

    function oX(a, b, c, d = !1) {
        a = nX(a, c);
        c = pr() || jX(b.top);
        if (!a || a.y === -12245933 || c.width === -12245933 || c.height === -12245933 || !c.height) return 0;
        var e = 0;
        try {
            let f = b.top;
            e = lX(f.document, f).y
        } catch (f) {
            return 0
        }
        b = e + c.height;
        return a.y < e ? d ? 0 : (e - a.y) / c.height : a.y > b ? (a.y - b) / c.height : 0
    };

    function pX(a) {
        a.asro = U(tw);
        a.aimartd = V(Cw);
        var b = ar(my).l(lw.g, lw.defaultValue);
        a.aiof = b.length ? b.join("~") : void 0
    };

    function qX(a) {
        a = GP(a, 600, "__lsa__");
        var b = V(Fu);
        return a ? .length ? Math.floor((Date.now() - Math.max(...a)) / 6E4) <= b : !1
    };
    var rX = {
            Xn: "google_ads_preview",
            io: "google_anchor_debug",
            ho: "google_bottom_anchor_debug",
            INTERSTITIAL: "google_ia_debug",
            Ao: "google_scr_debug",
            Do: "google_ia_debug_allow_onclick",
            Jo: "googleads",
            lk: "google_pedestal_debug",
            Qo: "google_responsive_slot_preview",
            Po: "google_responsive_dummy_ad"
        },
        sX = {
            google_bottom_anchor_debug: 1,
            google_anchor_debug: 2,
            google_ia_debug: 8,
            google_scr_debug: 9,
            googleads: 2,
            google_pedestal_debug: 30
        };
    var tX = {
        INTERSTITIAL: 1,
        BOTTOM_ANCHOR: 2,
        TOP_ANCHOR: 3,
        1: "INTERSTITIAL",
        2: "BOTTOM_ANCHOR",
        3: "TOP_ANCHOR"
    };

    function uX(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        var c = "";
        for (let d of b.split("_")) c += d.substring(0, 2);
        b = c;
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    }

    function vX() {
        var a = r.location,
            b = !1;
        Nk(rX, c => {
            uX(a, c) && (b = !0)
        });
        return b
    }

    function wX(a, b) {
        switch (a) {
            case 1:
                return uX(b, "google_ia_debug");
            case 2:
                return uX(b, "google_bottom_anchor_debug");
            case 3:
                return uX(b, "google_anchor_debug") || uX(b, "googleads")
        }
    };

    function xX(a, b) {
        return uB({
            K: a,
            pm: 3E3,
            xm: a.innerWidth > fs ? 450 : 0,
            F: rA,
            Vk: b,
            Tl: U(av)
        })
    };

    function yX(a) {
        var b = 0;
        try {
            b |= gs(a)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function zX(a) {
        var b = 0;
        try {
            b |= gs(a), b |= js(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function AX() {
        var a = {};
        ny(bv) && (a.bust = ny(bv));
        return a
    };

    function BX(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] ? ? 0
    }

    function CX(a) {
        return a.hidden != null ? a.hidden : a.mozHidden != null ? a.mozHidden : a.webkitHidden != null ? a.webkitHidden : null
    }

    function DX(a, b) {
        if (BX(b) === 3) var c = !1;
        else a(), c = !0;
        if (!c) {
            let d = () => {
                hk(b, "prerenderingchange", d);
                a()
            };
            gk(b, "prerenderingchange", d)
        }
    };
    Array.from({
        length: 11
    }, (a, b) => b / 10);

    function EX(a, b = !1) {
        var c = 0;
        try {
            c |= gs(a);
            var d;
            if (!(d = !a.navigator)) {
                var e = a.navigator;
                d = "brave" in e && "isBrave" in e.brave || !1
            }
            c |= d || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            c |= js(a, b ? Number.MAX_SAFE_INTEGER : 2500, !0)
        } catch (f) {
            c |= 32
        }
        return c
    };
    const FX = ["body", "html"];

    function GX(a, b = null, c) {
        var d = gs(a);
        vB(a.navigator ? .userAgent) && (d |= 1048576);
        var e = a.innerWidth;
        e < 1200 && (d |= 65536);
        var f = a.innerHeight;
        f < 650 && (d |= 2097152);
        b && d === 0 && (b = b === 3 ? "left" : "right", (c = HX({
            K: a,
            gn: 1,
            position: b,
            ba: e,
            ga: f,
            rd: new Set,
            minWidth: 120,
            minHeight: 500,
            flags: c
        })) ? bB(a).sideRailPlasParam.set(b, `${c.width}x${c.height}_${String(b).charAt(0)}`) : d |= 16);
        return d
    }

    function IX(a) {
        a = bB(a).sideRailPlasParam;
        return [...Array.from(a.values())].join("|")
    }

    function JX(a, b) {
        return Ij(a, c => c.nodeType === Node.ELEMENT_NODE && b.has(c)) !== null
    }

    function KX(a) {
        return Ij(a, b => b.nodeType === Node.ELEMENT_NODE && b.hasAttribute("google-side-rail-overlap")) ? .getAttribute("google-side-rail-overlap") || null
    }

    function LX(a, b) {
        return Ij(a, c => c.nodeType === Node.ELEMENT_NODE && b.getComputedStyle(c, null).position === "fixed")
    }

    function MX(a) {
        var b = [];
        for (let c of a.document.querySelectorAll("*")) {
            let d = a.getComputedStyle(c, null);
            d.position === "fixed" && d.display !== "none" && d.visibility !== "hidden" && b.push(c)
        }
        return b
    }

    function NX(a, b) {
        var {
            top: c,
            left: d,
            bottom: e,
            right: f
        } = b.getBoundingClientRect();
        return c >= 0 && d >= 0 && e <= a.innerHeight && f <= a.innerWidth
    }

    function OX(a, b, c = !1) {
        var d = KX(a);
        if (d === "true") return !0;
        if (d === "false" || c && !b.flags.Dj && !b.flags.Qh) return !1;
        if (b.flags.Ej && FX.includes(a.tagName.toLowerCase())) return !0;
        if (b.flags.Qh) {
            let {
                width: e,
                height: f,
                top: g
            } = a.getBoundingClientRect();
            a = f >= b.ga * .25;
            d = e >= b.ba * .9;
            return c ? d && a : d ? a ? !0 : g + (b.K.scrollY || b.K.pageYOffset) > b.ga * .15 : !1
        }
        c = a.offsetHeight >= b.ga * .25;
        return a.offsetWidth >= b.ba * .9 && c
    }

    function PX(a) {
        return Math.round(Math.round(a / 10) * 10)
    }

    function QX(a) {
        return `${a.position}-${PX(a.ba)}x${PX(a.ga)}-${PX(a.scrollY+a.Md)}Y`
    }

    function RX(a) {
        return `f-${QX({position:a.position,Md:a.Md,scrollY:0,ba:a.ba,ga:a.ga})}`
    }

    function SX(a, b) {
        a = Math.min(a ? ? Infinity, b ? ? Infinity);
        return a !== Infinity ? a : 0
    }

    function TX(a, b, c) {
        var d = bB(c.K).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.max(e.top - 10, 0),
                    g = Math.min(e.bottom + 10, c.ga),
                    h = Math.max(e.left - 10, 0);
                e = Math.min(e.right + 10, c.ba);
                for (var k = c.ba * .3; f <= g; f += 10) {
                    if (e > 0 && h < k) {
                        var l = RX({
                            position: "left",
                            Md: f,
                            ba: c.ba,
                            ga: c.ga
                        });
                        b.set(l, SX(b.get(l), h))
                    }
                    if (h < c.ba && e > c.ba - k) {
                        l = RX({
                            position: "right",
                            Md: f,
                            ba: c.ba,
                            ga: c.ga
                        });
                        let m = c.ba - e;
                        b.set(l, SX(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    }

    function UX(a, b) {
        var c = b.K,
            d = b.flags,
            e = `f-${PX(b.ba)}x${PX(b.ga)}`;
        a.has(e) || (a.set(e, 0), e = MX(c), d.ij || d.Jh ? (VX(a, b, e.filter(f => NX(c, f))), WX(c, e.filter(f => !NX(c, f)).concat(d.Jh ? Array.from(c.document.querySelectorAll("[google-side-rail-overlap=false]")) : []))) : VX(a, b, e))
    }

    function VX(a, b, c) {
        var d = b.rd,
            e = b.K;
        bB(e).sideRailProcessedFixedElements.clear();
        d = new Set([...Array.from(e.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]")), ...d]);
        for (let f of c) JX(f, d) || OX(f, b, !0) || TX(f, a, b)
    }

    function XX(a) {
        if (a.ba < 1200 || a.ga < 650) return null;
        var b = bB(a.K).sideRailAvailableSpace;
        UX(b, {
            K: a.K,
            ba: a.ba,
            ga: a.ga,
            rd: a.rd,
            flags: a.flags
        });
        var c = [],
            d = a.ga * .9,
            e = qs(a.K),
            f = (a.ga - d) / 2,
            g = f,
            h = d / 7;
        for (var k = 0; k < 8; k++) {
            var l = c,
                m = l.push;
            a: {
                var n = g;
                var p = a.position,
                    q = b,
                    u = {
                        K: a.K,
                        ba: a.ba,
                        ga: a.ga,
                        rd: a.rd,
                        flags: a.flags
                    };
                let D = RX({
                        position: p,
                        Md: n,
                        ba: u.ba,
                        ga: u.ga
                    }),
                    K = QX({
                        position: p,
                        Md: n,
                        scrollY: e,
                        ba: u.ba,
                        ga: u.ga
                    });
                if (q.has(K)) {
                    n = SX(q.get(D), q.get(K));
                    break a
                }
                let I = p === "left" ? 20 : u.ba - 20,
                    G = I;p = u.ba * .3 / 5 * (p === "left" ?
                    1 : -1);
                let E = 0,
                    Q = !1;
                for (let wa = 0; wa < 6; wa++) {
                    var A = lB(u.K.document, {
                        x: Math.round(G),
                        y: Math.round(n)
                    });
                    let Ca = LX(A, u.K),
                        ia = JX(A, u.rd);
                    A = OX(A, u) || ia;
                    if (Ca === null || ia)
                        if (A) E = Math.round(Math.abs(G - I) + 20);
                        else if (G !== I) G -= p, p /= 2;
                    else {
                        E = 0;
                        break
                    } else {
                        q.delete(K);
                        Q = !0;
                        if (!Ca || !OX(Ca, u, !0)) {
                            TX(Ca, q, u);
                            E = q.get(D) ? ? 0;
                            break
                        }
                        E = Math.round(Math.abs(G - I) + 20)
                    }
                    G += p
                }
                Q || q.set(K, E);n = E
            }
            m.call(l, n);
            g += h
        }
        b = a.gn;
        e = a.position;
        d = Math.round(d / 8);
        f = Math.round(f);
        g = a.minWidth;
        a = a.minHeight;
        m = [];
        h = Array(c.length).fill(0);
        for (l =
            0; l < c.length; l++) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[l];) m.pop();
            h[l] = m.length === 0 ? 0 : m[m.length - 1] + 1;
            m.push(l)
        }
        m = [];
        k = c.length - 1;
        l = Array(c.length).fill(0);
        for (n = k; n >= 0; n--) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[n];) m.pop();
            l[n] = m.length === 0 ? k : m[m.length - 1] - 1;
            m.push(n)
        }
        m = null;
        for (k = 0; k < c.length; k++)
            if (n = {
                    position: e,
                    width: Math.round(c[k]),
                    height: Math.round((l[k] - h[k] + 1) * d),
                    offsetY: f + h[k] * d
                }, q = n.width >= g && n.height >= a, b === 0 && q) {
                m = n;
                break
            } else b === 1 && q && (!m || n.width * n.height > m.width * m.height) && (m =
                n);
        return m
    }

    function WX(a, b) {
        var c = bB(a);
        if (b.length && !c.g) {
            var d = new MutationObserver(() => {
                setTimeout(() => {
                    YX(a);
                    for (let e of c.sideRailMutationCallbacks) e()
                }, 500)
            });
            for (let e of b) d.observe(e, {
                attributes: !0
            });
            c.g = d
        }
    }

    function YX(a) {
        ({
            sideRailAvailableSpace: a
        } = bB(a));
        var b = Array.from(a.keys()).filter(c => c.startsWith("f-"));
        for (let c of b) a.delete(c)
    }

    function HX(a) {
        if (a.ob) return a.ob.uc(1228, () => XX(a)) || null;
        try {
            return XX(a)
        } catch {}
        return null
    };
    const ZX = {
        [27]: 512,
        [26]: 128
    };
    var $X = (a, b, c, d) => {
            d = pH(d);
            switch (c) {
                case 1:
                case 2:
                    return xX(a, c) === 0;
                case 3:
                case 4:
                    return GX(a, c, {
                        ij: !0,
                        Jh: !0,
                        Ej: !0,
                        Dj: U(Sv),
                        Qh: U(Tv)
                    }) === 0;
                case 8:
                    return EX(a, U(Qu)) === 0;
                case 9:
                    return b = !(b.google_adtest === "on" || uX(a.location, "google_scr_debug")), !HP(a, b, d);
                case 30:
                    return IR(a) === 0;
                case 26:
                    return zX(a) === 0;
                case 27:
                    return yX(a) === 0;
                case 40:
                    return !0;
                default:
                    return !1
            }
        },
        aY = (a, b, c, d) => {
            d = d ? pH(d) : null;
            switch (c) {
                case 0:
                case 40:
                case 10:
                case 11:
                    return 0;
                case 1:
                case 2:
                    return xX(a, c);
                case 3:
                case 4:
                    return GX(a,
                        c, {
                            ij: !1,
                            Jh: !1,
                            Ej: !1,
                            Dj: U(Sv),
                            Qh: U(Tv)
                        });
                case 8:
                    return EX(a, U(Qu));
                case 9:
                    return HP(a, !(b.google_adtest === "on" || uX(a.location, "google_scr_debug")), d);
                case 16:
                    return vR(b, a) ? 0 : 8388608;
                case 30:
                    return IR(a);
                case 26:
                    return zX(a);
                case 27:
                    return yX(a);
                default:
                    return 32
            }
        },
        bY = a => {
            if (!a.hash) return null;
            var b = null;
            Nk(rX, c => {
                !b && uX(a, c) && (b = sX[c] || null)
            });
            return b
        },
        dY = (a, b) => {
            var c = bB(a).tagSpecificState[1] || null;
            c !== null && c.debugCard == null && Nk(tX, d => {
                !c.debugCardRequested && qc(d) && wX(d, a.location) && (c.debugCardRequested = !0, cY(a, b, e => {
                    c.debugCard = e.createDebugCard(d, a)
                }))
            })
        },
        fY = (a, b, c) => {
            if (!b) return null;
            var d = bB(b),
                e = 0;
            Nk(Ki, f => {
                var g = ZX[f];
                g && eY(a, b, f, c) === 0 && (e |= g)
            });
            d.wasPlaTagProcessed && (e |= 256);
            a.google_reactive_tag_first && (e |= 1024);
            return e ? `${e}` : null
        },
        gY = (a, b, c) => {
            var d = [];
            Nk(Ki, e => {
                var f = eY(b, a, e, c);
                f !== 0 && d.push(`${e}:${f}`)
            });
            return d.join(",") || null
        },
        hY = a => {
            var b = [],
                c = {};
            Nk(a, (d, e) => {
                if ((e = ds[e]) && !c[e]) {
                    c[e] = !0;
                    if (d) d = 1;
                    else if (d === !1) d = 2;
                    else return;
                    b.push(`${e}:${d}`)
                }
            });
            return b.join(",")
        };

    function iY(a) {
        a = a.overlays;
        if (!a) return "";
        a = a.bottom;
        return rc(a) ? a ? "1" : "0" : ""
    }

    function jY(a) {
        return (a = a.overlays) ? a["collapsed-bottom"] === !0 : !1
    }
    var eY = (a, b, c, d) => {
            if (!b) return 256;
            var e = 0,
                f = bB(b),
                g = ns(f, c);
            if (a.google_reactive_ad_format === c || g) e |= 64;
            var h = !1;
            Nk(f.reactiveTypeDisabledByPublisher, (k, l) => {
                String(c) === String(l) && (h = !0)
            });
            return h && bY(b.location) !== c && (e |= 128, c === 2 || c === 1 || c === 3 || c === 4 || c === 8) ? e : e | aY(b, a, c, d)
        },
        kY = (a, b) => {
            if (a) {
                var c = bB(a),
                    d = {};
                Nk(b, (e, f) => {
                    (f = ds[f]) && (e === !1 || /^false$/i.test(e)) && (d[f] = !0)
                });
                Nk(Ki, e => {
                    d[es[e]] && (c.reactiveTypeDisabledByPublisher[e] = !0)
                })
            }
        },
        lY = (a, b, c) => {
            b = xA(b, c);
            c = { ...AX()
            };
            return tW(1, window,
                oi(a, new Map(Object.entries(c)))).then(b)
        },
        cY = (a, b, c) => {
            c = xA(212, c);
            tW(3, a, b).then(c)
        },
        mY = a => {
            a = a.google_reactive_ad_format;
            return Ji(a) ? `${a}` : null
        },
        nY = a => !!mY(a) || a.google_pgb_reactive != null,
        oY = a => {
            a = Number(mY(a));
            return a === 26 || a === 27 || a === 30 || a === 16 || a === 40 || a === 41 || a === 44
        };

    function pY(a) {
        return qc(a.google_reactive_sra_index)
    }

    function qY(a) {
        return U(Iw) ? (a = a.google_ama_state = a.google_ama_state || {}, (a.numAutoAdsPlaced ? ? 0) > 0 || (a.eatf ? ? !1) || (a.eatfAbg ? ? !1)) : !1
    }

    function rY(a, b, c) {
        var d = b.K || b.pubWin,
            e = b.I,
            f = pH(c);
        c = gY(d, e, c);
        e.google_reactive_plat = c;
        (c = hY(a)) && (e.google_reactive_plaf = c);
        (c = iY(a)) && (e.google_reactive_fba = c);
        sY(a, e);
        c = bY(b.pubWin.location);
        tY(a, c, e);
        c ? (e.fra = c, e.google_pgb_reactive = 6) : e.google_pgb_reactive = 5;
        pX(e);
        e.fsapi = !0;
        c !== 8 && (f && DP(f) ? (c = GP(f, 86400, "__lsv__"), c ? .length && (c = Math.floor((Date.now() - Math.max(...c)) / 6E4), c >= 0 && (e.vmsli = c))) : e.vmsli = -1);
        jY(a) ? e.dap = 2 : qX(f) && (e.dap = 3);
        qY(d) && !e.dap && (e.dap = 5);
        pr() || jX(b.pubWin.top);
        c = TV(b.pubWin,
            "rsrai", xA(429, (g, h) => uY(b, d, e.google_ad_client, a, g, h, f)), xA(430, (g, h) => ts(b.pubWin, "431", rA, h)));
        b.Ja.push(c);
        bB(d).wasReactiveTagRequestSent = !0;
        vY(b, a, f)
    }

    function vY(a, b, c) {
        var d = a.I,
            e = ra(b.page_level_pubvars) ? b.page_level_pubvars : {};
        b = TV(a.pubWin, "apcnf", xA(353, (f, g) => {
            var h = a.pubWin,
                k = d.google_ad_client,
                l = a.Oa.cg;
            return Bl(g.origin) ? vW(h, k, e, f.config, c, l, null) : !1
        }), xA(353, (f, g) => ts(a.pubWin, "353", rA, g)));
        a.Ja.push(b)
    }

    function uY(a, b, c, d, e, f, g) {
        if (!Bl(f.origin)) return !1;
        f = e.data;
        if (!Array.isArray(f)) return !1;
        if (!fA(b, 1)) return !0;
        f && Sl(6, [f]);
        e = e.amaConfig;
        var h = [],
            k = bB(b),
            l = null;
        for (let n = 0; n < f.length; n++) {
            if (!f[n]) continue;
            let p = f[n];
            var m = p.adFormat;
            k && p.enabledInAsfe && (k.reactiveTypeEnabledInAsfe[m] = !0);
            if (!p.noCreative) {
                p.google_reactive_sra_index = n;
                if (m === 9 && e && (p.pubVars = Object.assign(p.pubVars || {}, wY(d, p)), m = new IP, BP(m, p) && m.B(p))) {
                    l = m;
                    continue
                }
                h.push(p)
            }
        }
        h.length && lY(a.Oa.Kj, 522, n => {
            xY(h, b, n, d, g)
        });
        e &&
            vW(b, c, d, e, g, a.Oa.cg, l);
        return !0
    }

    function wY(a, b) {
        var c = b.adFormat,
            d = b.adKey;
        delete b.adKey;
        var e = {};
        a = a.page_level_pubvars;
        ra(a) && Object.assign(e, a);
        e.google_ad_unit_key = d;
        e.google_reactive_sra_index = b.google_reactive_sra_index;
        c === 30 && (e.google_reactive_ad_format = 30);
        e.google_pgb_reactive = e.google_pgb_reactive || 5;
        return b.pubVars = e
    }

    function xY(a, b, c, d, e) {
        for (let f = 0; f < a.length; f++) {
            let g = a[f],
                h = g.adFormat,
                k = g.adKey,
                l = c.configProcessorForAdFormat(h);
            h && l && k && (g.pubVars = wY(d, g), delete g.google_reactive_sra_index, wA(466, () => l.verifyAndProcessConfig(b, g, e)))
        }
    }

    function sY(a, b) {
        var c = [],
            d = !1;
        Nk(ds, (e, f) => {
            var g;
            a.hasOwnProperty(f) && (f = a[f], f ? .google_ad_channel && (g = String(f.google_ad_channel)));
            --e;
            c[e] && c[e] !== "+" || (c[e] = g ? g.replace(/,/g, "+") : "+", d || (d = !!g))
        });
        d && (b.google_reactive_sra_channels = c.join(","))
    }

    function tY(a, b, c) {
        if (!c.google_adtest) {
            var d = a.page_level_pubvars;
            if (a.google_adtest === "on" || d ? .google_adtest === "on" || b) c.google_adtest = "on"
        }
    };
    const yY = /^blogger$/,
        zY = /^wordpress(.|\s|$)/i,
        AY = /^joomla!/i,
        BY = /^drupal/i,
        CY = /\/wp-content\//,
        DY = /\/wp-content\/plugins\/advanced-ads/,
        EY = /\/wp-content\/themes\/genesis/,
        FY = /\/wp-content\/plugins\/genesis/;

    function GY(a) {
        var b = a.getElementsByTagName("script"),
            c = b.length;
        for (var d = 0; d < c; ++d) {
            var e = b[d];
            if (e.hasAttribute("src")) {
                e = e.getAttribute("src") || "";
                if (DY.test(e)) return 5;
                if (FY.test(e)) return 6
            }
        }
        b = a.getElementsByTagName("link");
        c = b.length;
        for (d = 0; d < c; ++d)
            if (e = b[d], e.hasAttribute("href") && (e = e.getAttribute("href") || "", EY.test(e) || FY.test(e))) return 6;
        a = a.getElementsByTagName("meta");
        d = a.length;
        for (e = 0; e < d; ++e) {
            var f = a[e];
            if (f.getAttribute("name") == "generator" && f.hasAttribute("content")) {
                f = f.getAttribute("content") ||
                    "";
                if (yY.test(f)) return 1;
                if (zY.test(f)) return 2;
                if (AY.test(f)) return 3;
                if (BY.test(f)) return 4
            }
        }
        for (a = 0; a < c; ++a)
            if (d = b[a], d.getAttribute("rel") == "stylesheet" && d.hasAttribute("href") && (d = d.getAttribute("href") || "", CY.test(d))) return 2;
        return 0
    };
    var HY = class extends Error {
            constructor(a) {
                super(a)
            }
        },
        IY = class {
            constructor(a) {
                this.reason = a
            }
        };
    class JY {
        constructor() {
            this.g = !1
        }
    }

    function KY(a, b) {
        a.g || (a.g = !0, a.A = b, a.l.resolve(b))
    }

    function LY(a, b, c) {
        a.g = !0;
        a.j = b;
        c && c(a.j);
        a.l.reject(b)
    }
    class MY extends JY {
        constructor() {
            super(...arguments);
            this.l = new XV
        }
        get promise() {
            return this.l.promise
        }
        get Pj() {
            return this.g
        }
        get error() {
            return this.j
        }
    }

    function NY(a, b) {
        KY(a, b)
    }

    function OY(a, b) {
        b.then(c => {
            KY(a, c)
        }).catch(c => {
            a.setError(c, void 0)
        })
    }
    var PY = class extends MY {
        setError(a, b) {
            this.g || (this.g = !0, this.A = null, this.j = a, b && b(this.j), this.l.reject(a))
        }
    };
    class QY extends JY {
        constructor(a) {
            super();
            this.l = a
        }
        get error() {
            return this.l.j
        }
        Pj() {
            return this.l.g
        }
    }
    var RY = class extends QY {
        constructor(a) {
            super(a);
            this.l = a
        }
        get value() {
            return this.l.A ? ? null
        }
    };

    function SY(a, b, c) {
        b.then(() => {
            a.notify()
        }).catch(d => {
            LY(a, d, c)
        })
    }
    var TY = class extends MY {
            notify() {
                KY(this, null)
            }
        },
        UY = class extends PY {
            constructor(a, b = !1) {
                super();
                a = a.map(c => c.promise.then(d => {
                    if (b || d != null) return d;
                    throw d;
                }, d => {
                    LY(this, d);
                    return null
                }));
                ka(Promise, "any").call(Promise, a).then(c => {
                    this.g || KY(this, c)
                }, () => {
                    this.g || KY(this, null)
                })
            }
        };

    function VY(a, b) {
        a.g.push({
            Re: !1,
            Hg: b
        })
    }
    var WY = class extends Gs {
        constructor() {
            super(...arguments);
            this.l = [];
            this.g = [];
            this.B = []
        }
        Re(a) {
            var b = this.g.find(c => c.Hg === a);
            b && (b.Re = !0)
        }
        j() {
            this.l.length = 0;
            this.B.length = 0;
            this.g.length = 0;
            super.j()
        }
    };
    async function XY(a, b) {
        var c = b ? a.filter(d => !d.Re) : a;
        await Promise.all(c.map(({
            Hg: d
        }) => d.promise));
        a.length !== c.length && (a = a.filter(d => d.Re), await Promise.race([Promise.all(a.map(({
            Hg: d
        }) => d.promise)), new Promise(d => void setTimeout(d, b))]))
    }

    function YY(a, b = new PY) {
        a.l.l.push(b);
        return b
    }
    var ZY = class extends Gs {
        constructor(a, b) {
            super();
            this.id = a;
            this.G = b;
            this.timeoutMs = void 0;
            this.D = !1;
            this.l = new WY;
            Hs(this, this.l)
        }
        async start() {
            if (!this.D) {
                this.D = !0;
                try {
                    if (await XY(this.l.g, this.pa ? ? this.timeoutMs), !this.A) {
                        let a = 0;
                        for (let b of this.l.B) {
                            if (b.l.A == null) throw Error(`missing input: ${this.id}/${a}`);
                            ++a
                        }
                        this.W()
                    }
                } catch (a) {
                    this.A || (a instanceof HY ? this.T(a) : a instanceof Error && (this.G.Ka({
                        methodName: this.id,
                        hb: a
                    }), this.g(a)))
                }
            }
        }
        T() {}
        g(a) {
            if (this.l.l.length) {
                var b = new HY(a.message);
                for (let c of this.l.l) c.Pj || LY(c, b)
            }
            a instanceof HY || console ? .error(a)
        }
    };

    function $Y(a) {
        var b = {};
        for (let [c, d] of Object.entries(a.Z)) b[c] = d.value;
        return b
    }

    function X(a, b) {
        if (a.D) throw Error("Invalid operation: producer has already started");
        VY(a.l, b);
        return a
    }
    var aZ = class extends ZY {
        constructor(a, b, c, d, e) {
            super(a, c);
            this.f = b;
            this.J = e;
            a = {};
            for (let [f, g] of Object.entries(d))
                if (d = g) VY(this.l, d), a[f] = new RY(d);
            this.Z = a
        }
        W() {
            var a = this.f($Y(this), ...this.J);
            this.B(a)
        }
        T(a) {
            this.g(a)
        }
        reportError() {}
    };
    class bZ extends aZ {
        constructor(a, b, c, d, e, f, g) {
            super(a, b, c, d, g);
            this.qa = f;
            this.finished = new TY;
            a = Object.keys(e);
            for (let h of a) this[h] = YY(this)
        }
        B(a) {
            for (let [b, c] of Object.entries(a)) {
                a = b;
                let d = c;
                d instanceof Error && this[a].setError(d);
                d instanceof IY || KY(this[a], d)
            }
            this.finished.notify()
        }
        g(a) {
            this.qa ? this.B(this.qa(a)) : super.g(a)
        }
    }

    function Y(a, b) {
        a.id = b.id;
        a.H = b.H;
        a.qa = b.qa;
        return a
    }

    function cZ(a, b, c, ...d) {
        return new bZ(a.id, a, b, c, a.H, a.qa, d)
    };

    function dZ(a, b) {
        a = b.PygXN.map(c => {
            var d = new wk;
            d = If(d, 1, c.aJhyn);
            c = Pe(d, 2, Nf, Fd(c.ihulF));
            return rf(c, 4, !1)
        });
        a = a.length > 0 ? Ak(xk(), a) : Ak(new yk, []);
        return {
            Ce: a,
            Qf: [a]
        }
    }
    var eZ = Y(dZ, {
        id: 1377,
        H: {
            Ce: void 0,
            Qf: void 0
        }
    });
    var fZ = {
        Ji: [],
        Fi: 0,
        Pi: [],
        jp: !1
    };

    function gZ(a, b = window, c = () => {}) {
        try {
            return b.localStorage.getItem(a)
        } catch (d) {
            return c(d), null
        }
    }

    function hZ(a, b, c = window, d = () => {}) {
        return b.ha() ? gZ(a, c, d) : null
    }

    function iZ(a, b, c = window, d = () => {}) {
        try {
            return c.localStorage.setItem(a, b), !0
        } catch (e) {
            d(e)
        }
        return !1
    }

    function jZ(a, b, c, d = window, e = () => {}) {
        return c.ha() ? iZ(a, b, d, e) : !1
    }

    function kZ(a, b = window, c = () => {}) {
        try {
            b.localStorage.removeItem(a)
        } catch (d) {
            c(d)
        }
    }

    function lZ(a, b, c = window, d = () => {}) {
        b.ha() && kZ(a, c, d)
    }

    function mZ(a = window, b = () => {}) {
        try {
            return a.localStorage.length
        } catch (c) {
            b(c)
        }
        return null
    }

    function nZ(a) {
        var b = window,
            c = () => {};
        return a.ha() ? mZ(b, c) : null
    }

    function oZ(a, b = window, c = () => {}) {
        try {
            return b.localStorage.key(a)
        } catch (d) {
            c(d)
        }
        return null
    }

    function pZ(a, b) {
        var c = window,
            d = () => {};
        return b.ha() ? oZ(a, c, d) : null
    }

    function qZ(a = window, b = () => {}) {
        try {
            return Object.keys(a.localStorage)
        } catch (c) {
            b(c)
        }
        return null
    }

    function rZ(a) {
        var b = window,
            c = () => {};
        return a.ha() ? qZ(b, c) : null
    };
    class sZ {
        static bj() {
            throw Error("Must be overridden");
        }
    }
    class tZ extends sZ {
        constructor() {
            super(...arguments);
            this.g = 0
        }
    }(function() {
        var a = tZ;
        a.Pc = void 0;
        a.bj = function() {
            return a.Pc ? a.Pc : a.Pc = new a
        }
    })();

    function uZ(a, b, c = null, d = {}, e) {
        var f = tZ.bj(),
            g = e ? .Sj ? ? 1E3;
        f.g === 0 && (f.g = Math.random() < 1 / g ? 2 : 1);
        f.g === 2 && (e && Qq(e.F, vZ(a, b, c, d, e.uh, g)), Hl({
            c: String(a),
            pc: String(Cl(window)),
            em: c,
            lid: b,
            eids: Xq().join(),
            ...d
        }, "esp"))
    }

    function vZ(a, b, c = null, d = {}, e, f) {
        var g = new eq;
        a = H(g, 1, a);
        e = fl(window, e);
        e = wf(a, 2, e);
        c = Jf(e, 3, c);
        b = Jf(c, 4, b);
        c = Xq();
        b = Ne(b, 5, c, hd);
        f = uf(b, 8, f);
        d.sl && xf(f, 6, fq, Number(d.sl));
        d.url && Pe(f, 7, fq, Fd(d.url));
        return f
    };

    function wZ() {
        var a = window;
        return new Promise(b => {
            var c = () => {
                b(void 0);
                hk(a, "load", c)
            };
            gk(a, "load", c)
        })
    }

    function xZ(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$"),
            d = nZ(a);
        for (let f = 0; f < (d ? ? 0); f++) {
            var e = pZ(f, a);
            if (e === null) continue;
            (e = (c.exec(e) || [])[1]) && b.push(e)
        }
        return b
    };

    function yZ() {
        zZ || (zZ = new AZ);
        return zZ
    }

    function BZ(a) {
        var b = IG(cf(a, 3));
        if (!b) return 3;
        if (pf(a, 2) === void 0) return 4;
        a = Date.now();
        return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
    }

    function CZ(a, b, c, d) {
        function e(g) {
            uZ(8, b, g ? .message, {}, f)
        }
        var f;
        d ? kZ(`_GESPSK-${b}`, window, e) : lZ(`_GESPSK-${b}`, c, window, e);
        delete a.cache[b]
    }
    var AZ = class {
            constructor() {
                this.cache = {}
            }
            get(a, b, c, d) {
                function e(h) {
                    uZ(6, a, h ? .message, {}, d);
                    f = !0
                }
                if (this.cache[a]) return {
                    U: this.cache[a],
                    success: !0
                };
                var f = !1,
                    g = `_GESPSK-${a}`;
                b = c ? gZ(g, window, e) : hZ(g, b, window, e);
                if (f) return {
                    U: null,
                    success: !1
                };
                if (!b) return {
                    U: null,
                    success: !0
                };
                try {
                    let h = Kk(b);
                    this.cache[a] = h;
                    return {
                        U: h,
                        success: !0
                    }
                } catch (h) {
                    return uZ(5, a, h ? .message, {}, d), {
                        U: null,
                        success: !1
                    }
                }
            }
            set(a, b, c, d) {
                function e(h) {
                    uZ(7, f, h ? .message, {}, d)
                }
                var f = a.jb(),
                    g = `_GESPSK-${f}`;
                Jk(a);
                if (c ? !iZ(g, xg(a), window,
                        e) : !jZ(g, xg(a), b, window, e)) return !1;
                this.cache[f] = a;
                return !0
            }
        },
        zZ = null;

    function DZ(a, b, c) {
        return !!a.g ? .get(c) ? .get(b) ? .some(d => B(d, 4))
    }

    function EZ(a, b) {
        for (let c of a.g.values())
            if (c.get(b) ? .some(d => B(d, 4))) return !0;
        return !1
    }

    function FZ(a, b, c) {
        var d = new Set;
        a = a.g.get(b);
        if (!a) return d;
        for (let [e, f] of a.entries()) a = e, f.some(g => c(g)) && d.add(a);
        return d
    }

    function GZ(a, b) {
        return FZ(a, b, c => B(c, 4))
    }
    var HZ = class {
        constructor(a) {
            var b = new Map;
            for (let c of a) {
                a = C(c, 1);
                let d = b.get(a) ? ? new Map;
                for (let e of zk(c)) {
                    let f = e.jb();
                    d.has(f) || d.set(f, []);
                    d.get(f).push(e)
                }
                b.set(a, d)
            }
            this.g = b
        }
    };

    function IZ(a, b) {
        return [].some(c => DZ(b, a, c))
    };

    function JZ(a, b, c, d) {
        ({
            Ce: a
        } = dZ({}, a.pageState.jzoix)); {
            var e = [a];
            a = new Map;
            uZ(56, "", null, void 0, d);
            var f = a;
            e = new HZ(e ? ? []);
            var g = Array,
                h = g.from,
                k = [];
            let n = new Set(xZ(c));
            for (var l of k)
                for (var m of GZ(e, l)) n.add(m);
            l = h.call(g, n);
            for (let p of l) {
                if (f.get(p) ? .g()) continue;
                ({
                    U: l
                } = yZ().get(p, c, IZ(p, e), d));
                if (!l) continue;
                m = BZ(l);
                if (m === 2 || m === 3) continue;
                rf(l, 9, !1);
                (m = pf(l, 2)) && m.length > 1024 && (uZ(55, p, null, {
                    sl: String(m.length)
                }, d), m = l.setError(Fk(108)), xe(m, 2));
                f.set(p, l);
                l = pf(l, 2);
                uZ(19, p, null, {
                    hs: l ?
                        "1" : "0",
                    sl: String(l ? .length ? ? -1)
                }, d)
            }
            c = new Lk;
            for (let [, p] of a) Ze(c, 2, Ik, p);
            Ve(c, Ik, 2, w()).length ? (uZ(50, "", null, {
                ns: String(Ve(c, Ik, 2, w()).length)
            }, d), d = c.g(), d = Bb(d, 3)) : d = null
        }
        d && (b.a3p = d)
    };

    function KZ(a) {
        var b = {};
        b.dtd = LZ((new Date).getTime(), Yr);
        return Qr(b, a)
    }

    function LZ(a, b, c = 1E5) {
        a -= b;
        return a >= c ? "M" : a >= 0 ? a : "-M"
    };
    const MZ = sb("script");
    var NZ = class {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, l = null, m = null, n = null) {
            this.D = a;
            this.Xb = b;
            this.la = c;
            this.g = d;
            this.O = e;
            this.Ca = f;
            this.Cb = g;
            this.A = h;
            this.B = k;
            this.j = l;
            this.l = m;
            this.C = n
        }
        size() {
            return this.Xb
        }
    };
    var OZ = class {
        constructor(a, b) {
            this.na = a;
            this.height = b
        }
        g(a) {
            return a > 300 && this.height > 300 ? this.na : Math.min(1200, Math.round(a))
        }
    };
    var PZ = class extends OZ {
        j() {}
    };
    const QZ = {
        "image-top": a => a <= 600 ? 284 + (a - 250) * .414 : 429,
        "image-middle": a => a <= 500 ? 196 - (a - 250) * .13 : 164 + (a - 500) * .2,
        "image-side": a => a <= 500 ? 205 - (a - 250) * .28 : 134 + (a - 500) * .21,
        "text-only": a => a <= 500 ? 187 - .228 * (a - 250) : 130,
        "in-article": a => a <= 420 ? a / 1.2 : a <= 460 ? a / 1.91 + 130 : a <= 800 ? a / 4 : 200
    };
    var RZ = {
            "image-top": 0,
            "image-middle": 1,
            "image-side": 2,
            "text-only": 3,
            "in-article": 4
        },
        SZ = class extends PZ {
            constructor(a, b) {
                super(a, b)
            }
            g() {
                return Math.min(1200, this.na)
            }
        };

    function TZ(a, b, c, d, e) {
        var f = e.google_ad_layout || "image-top";
        if (f === "in-article") {
            var g = a;
            if (e.google_full_width_responsive === "false") a = g;
            else if (a = wR(b, c, g, V(Wu), e), a !== !0) e.gfwrnwer = a, a = g;
            else if (a = hs(b))
                if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                    b: {
                        g = c;
                        for (let h = 0; h < 100 && g.parentElement; ++h) {
                            let k = g.parentElement.childNodes;
                            for (let l = 0; l < k.length; ++l) {
                                let m = k[l];
                                if (m !== g && zR(b, m)) break b
                            }
                            g = g.parentElement;
                            g.style.width = "100%";
                            g.style.height = "auto"
                        }
                    }
                    DR(b, c)
                }
            else a = g;
            else a = g
        }
        if (a <
            250) throw new qA(`Fluid responsive ads must be at least 250px wide: availableWidth=${a}`);
        a = Math.min(1200, Math.floor(a));
        if (d && f !== "in-article") {
            f = Math.ceil(d);
            if (f < 50) throw new qA(`Fluid responsive ads must be at least 50px tall: height=${f}`);
            return new NZ(11, new PZ(a, f))
        }
        if (f !== "in-article" && (d = e.google_ad_layout_key)) {
            f = `${d}`;
            if (d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length)
                for (b = [], e = 0; e < d; e++) b.push(parseInt(c[e], 36) / 1E3);
            else b = null;
            if (!b) throw new qA(`Invalid data-ad-layout-key value: ${f}`);
            f = (a + -725) / 1E3;
            c = 0;
            d = 1;
            e = b.length;
            for (g = 0; g < e; g++) c += b[g] * d, d *= f;
            f = Math.ceil(c * 1E3 - -725 + 10);
            if (isNaN(f)) throw new qA(`Invalid height: height=${f}`);
            if (f < 50) throw new qA(`Fluid responsive ads must be at least 50px tall: height=${f}`);
            if (f > 1200) throw new qA(`Fluid responsive ads must be at most 1200px tall: height=${f}`);
            return new NZ(11, new PZ(a, f))
        }
        d = QZ[f];
        if (!d) throw new qA("Invalid data-ad-layout value: " + f);
        c = UI(c, b);
        b = hs(b);
        b = f !== "in-article" || c || a !== b ? Math.ceil(d(a)) : Math.ceil(d(a) * 1.25);
        return new NZ(11,
            f === "in-article" ? new SZ(a, b) : new PZ(a, b))
    };

    function UZ(a) {
        var b = window;
        return a.google_adtest === "on" || a.google_adbreak_test === "on" || b.location.host.endsWith("h5games.usercontent.goog") || b.location.host === "gamesnacks.com" ? b.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(c => Math.floor(Number(c))).filter(c => !isNaN(c) && c > 0) || [] : []
    };
    var VZ = class {
            constructor() {
                this.A = new Date(Date.now());
                this.l = this.g = null;
                this.j = {
                    [3]: {},
                    [4]: {},
                    [5]: {}
                };
                this.j[3] = {
                    [71]: (...a) => {
                        var b = this.g;
                        var c = this.A,
                            d = Number(a[0]);
                        a = Number(a[1]);
                        b = b !== null ? ou(`w5uHecUBa2S:${d}:${b}`) % a === Math.floor(c.valueOf() / 864E5) % a : void 0;
                        return b
                    }
                };
                this.j[4] = {
                    [15]: () => {
                        var a = Number(this.l || void 0);
                        isNaN(a) ? a = void 0 : (a = new Date(a * 1E3), a = a.getFullYear() * 1E4 + (a.getMonth() + 1) * 100 + a.getDate());
                        return a
                    }
                }
            }
        },
        WZ;

    function XZ(a, b = "") {
        return YZ(a, b, c => hb(Ve(c, Bk, 2, w()), d => qf(d, 1) === 1))
    }

    function YZ(a, b, c) {
        a = Tk(a) || a;
        var d = ZZ(a);
        b && (b = Xr(String(b)));
        return Ii(d, (e, f) => Object.prototype.hasOwnProperty.call(d, f) && (!b || b === f) && c(e))
    }

    function ZZ(a) {
        a = $Z(a, !1);
        var b = {};
        Nk(a, (c, d) => {
            try {
                let e = zg(Ek, ae(c));
                b[d] = e
            } catch (e) {}
        });
        return b
    }

    function $Z(a, b) {
        a = sT({
            win: a,
            Ya: b
        });
        return du(a) ? a_(a.getValue()) : {}
    }

    function a_(a) {
        try {
            let b = a.getItem("google_adsense_settings");
            if (!b) return {};
            let c = JSON.parse(b);
            return c !== Object(c) ? {} : Hi(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && v(e) && Array.isArray(d))
        } catch (b) {
            return {}
        }
    };

    function b_(a = r) {
        return a.ggeac || (a.ggeac = {})
    };

    function c_(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    };

    function d_(a = bl()) {
        return b => ou(`${b} + ${a}`) % 1E3
    };

    function e_(a, b) {
        a.g = br(14, b, () => {})
    }
    class f_ {
        constructor() {
            this.g = () => {}
        }
    }

    function g_(a) {
        ar(f_).g(a)
    };

    function h_(a = b_()) {
        cr(ar(dr), a);
        i_(a);
        e_(ar(f_), a);
        ar(my).g()
    }

    function i_(a) {
        var b = ar(my);
        b.j = (c, d) => br(5, a, () => !1)(c, d, 1);
        b.A = (c, d) => br(6, a, () => 0)(c, d, 1);
        b.B = (c, d) => br(7, a, () => "")(c, d, 1);
        b.C = (c, d) => br(8, a, () => [])(c, d, 1);
        b.l = (c, d) => br(17, a, () => [])(c, d, 1);
        b.g = () => {
            br(15, a, () => {})(1)
        }
    };

    function j_(a, b, c, d) {
        b = {
            [0]: d_(Cl(b).toString())
        };
        if (c && d) {
            d = AH(d, c);
            WZ || (WZ = new VZ);
            c = WZ;
            d.gfpCookie && !c.g && (c.g = d.parsedGfpCookie.id, c.l = d.parsedGfpCookie.creationTimeSeconds);
            g_(c.j);
            let e = d.parsedGfpCookie.id;
            b[1] = f => e ? d_(e)(f) : void 0
        }
        b = er(a, b);
        jr(QA(HA(), a, b))
    }

    function k_(a) {
        var b = Xq();
        a = UZ(a);
        return b.concat(a).join(",")
    }

    function l_(a) {
        var b = tm();
        b && (a.debug_experiment_id = b)
    };
    var m_ = {
        google_ad_block: "ad_block",
        google_ad_client: "client",
        google_ad_intent_query: "ait_q",
        google_ad_intent_rs_token: "afdt",
        google_ad_output: "output",
        google_ad_height: "h",
        google_ad_resize: "twa",
        google_ad_slot: "slotname",
        google_language: "hl",
        google_max_num_ads: "num_ads",
        google_ad_unit_key: "adk",
        google_ad_dom_fingerprint: "adf",
        google_ad_intents_encoded_verticals4_ids: "ait_v",
        google_ad_intents_encoded_browseonomy_ids: "ait_b",
        google_ad_intents_format: "ait_f",
        google_ad_intents_in_drawer_format: "ait_df",
        google_ad_intents_ad_position: "ait_pos",
        google_placement_id: "pi",
        google_daaos_ts: "daaos",
        google_erank: "epr",
        abgtt: "abgtt",
        google_ad_width: "w",
        google_content_recommendation_columns_num: "cr_col",
        google_content_recommendation_rows_num: "cr_row",
        google_ctr_threshold: "ctr_t",
        gfwrnwer: "fwrn",
        gfwrnher: "fwrnh",
        google_last_modified_time: "lmt",
        google_enable_content_recommendations: "ecr",
        google_reactive_plaf: "plaf",
        google_reactive_plat: "plat",
        google_reactive_fba: "fba",
        google_reactive_sra_channels: "plach",
        google_responsive_auto_format: "rafmt",
        armr: "armr",
        google_video_play_muted: "vpmute",
        google_source_type: "src_type",
        google_restrict_data_processing: "rdp",
        google_pucrd: "pucrd",
        google_cust_criteria: "cust_params",
        google_tag_for_child_directed_treatment: "tfcd",
        google_tag_for_under_age_of_consent: "tfua",
        google_tag_for_age_treatment: "tfat",
        google_tag_origin: "to",
        google_ad_semantic_area: "sem",
        google_package: "pwprc",
        google_tag_partner: "tp",
        fra: "fpla",
        google_ml_rank: "mlr",
        google_ad_channel: "channel",
        google_ad_type: "ad_type",
        google_ad_format: "format",
        google_color_bg: "color_bg",
        google_color_border: "color_border",
        google_color_link: "color_link",
        google_color_text: "color_text",
        google_color_url: "color_url",
        google_page_url: "url",
        google_ad_section: "region",
        google_encoding: "oe",
        google_safe: "adsafe",
        google_font_face: "f",
        google_font_size: "fs",
        google_ad_host: "host",
        google_ad_host_channel: "h_ch",
        google_kw: "kw",
        google_adtest: "adtest",
        google_alternate_color: "alt_color",
        google_cust_age: "cust_age",
        google_cust_gender: "cust_gender",
        google_country: "gl",
        google_alternate_ad_url: "alternate_ad_url",
        google_region: "gr",
        google_image_size: "image_size",
        google_video_doc_id: "video_doc_id",
        google_content_recommendation_ui_type: "crui",
        sso: "sso",
        google_color_line: "color_line",
        google_full_width_responsive_allowed: "fwr",
        google_full_width_responsive: "fwrattr",
        google_tfs: "tfs",
        efwr: "efwr",
        google_pgb_reactive: "pra",
        rc: "rc",
        google_resizing_allowed: "rs",
        google_resizing_height: "rh",
        google_resizing_width: "rw",
        rpe: "rpe",
        google_responsive_formats: "resp_fmts",
        google_safe_for_responsive_override: "sfro",
        aiof: "aiof",
        asro: "asro",
        vmsli: "itsi",
        dap: "dap",
        aimartd: "aimartd",
        aieuf: "aieuf",
        aicrs: "aicrs"
    };

    function n_(a) {
        a.g === -1 && (a.g = a.data.reduce((b, c, d) => b + (c ? 2 ** d : 0), 0));
        return a.g
    }
    var o_ = class {
        constructor() {
            this.data = [];
            this.g = -1
        }
        set(a, b = !0) {
            0 <= a && a < 52 && Number.isInteger(a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
        }
        get(a) {
            return !!this.data[a]
        }
    };

    function p_() {
        var a = new o_;
        "SVGElement" in r && "createElementNS" in r.document && a.set(0);
        var b = ql();
        b["allow-top-navigation-by-user-activation"] && a.set(1);
        b["allow-popups-to-escape-sandbox"] && a.set(2);
        r.crypto && r.crypto.subtle && a.set(3);
        "TextDecoder" in r && "TextEncoder" in r && a.set(4);
        return n_(a)
    };

    function q_(a, b, {
        Sm: c,
        Tm: d
    }) {
        return B(b, 17) && (!c && b.ha() || !d) && sH(a) ? !0 : !1
    };
    var r_ = class {
        constructor() {
            this.g = tA
        }
        Ka(a) {
            var b = a.hb;
            this.g.Da(a.methodName ? ? 0, b instanceof Error ? b : Error(String(b)))
        }
    };
    var s_ = function(a) {
        return b => lh(b, a)
    }(wT);
    var t_ = () => {
        var a = new Map;
        a.set(1, "All in One SEO (AIOSEO)");
        a.set(2, "All in One SEO Pro (AIOSEO)");
        a.set(3, "AMP for WP");
        a.set(4, "Site Kit by Google");
        a.set(5, "Elementor");
        a.set(6, "Powered by WPBakery Page Builder - drag and drop page builder for WordPress.");
        return a
    };
    var u_ = () => {
        var a = new Map;
        a.set(1, "WordPress");
        a.set(2, "Drupal");
        a.set(3, "MediaWiki");
        a.set(4, "Blogger");
        a.set(5, "SEOmatic");
        a.set(7, "Flutter");
        a.set(8, "Joomla! - Open Source Content Management");
        a.set(9, "React");
        a.set(10, "Angular");
        a.set(11, "Vue");
        return a
    };

    function v_(a) {
        return a.querySelector("[ng-version]") != null || a.querySelector('[class*="_ngcontent-"]') != null
    };

    function w_(a, {
        rj: b
    }) {
        return Array.from(a.querySelectorAll("div")).slice(0, b).some(c => Object.keys(c).some(d => d.startsWith("__react")))
    };

    function x_(a) {
        return Array.from(a.querySelectorAll("*")).slice(0, 1E3).some(b => Object.keys(b).some(c => c.startsWith("__vue")))
    };

    function y_(a = document) {
        var b = {
                rj: V(Qv),
                yl: U(Nv)
            },
            c = [],
            d = [];
        for (var e of Array.from(a.querySelectorAll("meta[name=generator][content]"))) {
            if (!e) continue;
            var f = e.getAttribute("content") ? ? "";
            let [, l, m] = /^([^0-9]+)(?:\s([0-9]+(?:\.[0-9]+){0,2})[.0-9]*)?[^0-9]*$/.exec(f) ? ? [];
            var g = new vT;
            m && If(g, 3, m.substring(0, 20));
            var h = void 0;
            let n;
            if (l) {
                for (let [p, q] of u_().entries()) {
                    var k = p;
                    if (q === l.trim()) {
                        h = k;
                        break
                    }
                }
                for (let [p, q] of t_().entries())
                    if (k = p, q === l.trim()) {
                        n = k;
                        break
                    }
            }
            n ? (f = Kf(g, 1, 1), Kf(f, 2, n)) : h ? Kf(g,
                1, h) : (k = Kf(g, 1, 0), xe(k, 3), d.push({
                content: f,
                name: l,
                version: m
            }));
            c.push(g)
        }
        e = [];
        b.rj > 0 && e.push({
            label: 9,
            Yg: w_
        });
        b.yl && e.push({
            label: 10,
            Yg: v_
        });
        e.push({
            label: 11,
            Yg: x_
        });
        for (let l of e) l.Yg(a, b) && (e = c, g = e.push, h = new vT, h = Kf(h, 1, l.label), g.call(e, h));
        return {
            labels: c,
            np: d
        }
    };
    var z_ = class extends Gs {
        constructor() {
            super();
            this.value = null
        }
        get() {
            return this.value
        }
    };
    const A_ = new Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        B_ = new Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);

    function C_(a) {
        try {
            let b = a.performance ? .getEntriesByType("navigation") ? .[0];
            if (a.document.prerendering || (b ? .activationStart ? ? 0) > 0) return 4;
            if (b ? .deliveryType === "navigational-prefetch") return 6;
            if (b ? .deliveryType === "cache") return 7;
            if (b ? .type) return A_.get(b.type) ? ? null
        } catch {}
        return B_.get(a.performance ? .navigation ? .type) ? ? null
    };

    function D_(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return typeof c === "string" ? c : c.property + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        Qj(a, "transition", b.join(","))
    }
    const E_ = wi(function() {
        var a = yj(document, "DIV"),
            b = xb ? "-webkit" : wb ? "-moz" : null,
            c = "transition:opacity 1s linear;";
        b && (c += b + "-transition:opacity 1s linear;");
        gj(a, li("div", {
            style: c
        }));
        return Vj(a.firstChild, "transition") != ""
    });

    function F_(a, b, c) {
        a.j[b].indexOf(c) < 0 && (a.j[b] += c)
    }

    function G_(a, b) {
        a.g.indexOf(b) >= 0 || (a.g = b + a.g)
    }

    function H_(a, b) {
        a.errors.indexOf(b) < 0 && (a.errors = b + a.errors)
    }

    function I_(a, b, c, d) {
        return a.errors != "" || b ? null : a.g.replace(J_, "") == "" ? c != null && a.j[0] || d != null && a.j[1] ? !1 : !0 : !1
    }

    function K_(a) {
        var b = I_(a, "", null, 0);
        if (b === null) return "XS";
        b = b ? "C" : "N";
        a = a.g;
        return a.indexOf("a") >= 0 ? b + "A" : a.indexOf("f") >= 0 ? b + "F" : b + "S"
    }
    var L_ = class {
        constructor(a, b) {
            this.j = ["", ""];
            this.g = a || "";
            this.errors = b || ""
        }
        toString() {
            return [this.j[0], this.j[1], this.g, this.errors].join("|")
        }
    };

    function M_(a) {
        var b = a.Z;
        a.O = () => {};
        N_(a, a.C, b);
        var c = a.C.parentElement;
        if (!c) return a.g;
        for (var d = !0, e = null; c;) {
            try {
                e = /^head|html$/i.test(c.nodeName) ? null : il(c, b)
            } catch (g) {
                H_(a.g, "c")
            }
            let f = O_(a, b, c, e);
            c.classList.contains("adsbygoogle") && e && (/^\-.*/.test(e["margin-left"]) || /^\-.*/.test(e["margin-right"])) && (a.W = !0);
            if (d && !f && P_(e)) {
                G_(a.g, "l");
                a.G = c;
                break
            }
            d = d && f;
            if (e && Q_(a, e)) break;
            c = c.parentElement;
            if (!c) {
                if (b === a.pubWin) break;
                try {
                    if (c = b.frameElement, b = b.parent, !Qk(b)) {
                        G_(a.g, "c");
                        break
                    }
                } catch (g) {
                    G_(a.g,
                        "c");
                    break
                }
            }
        }
        a.D && a.B && R_(a);
        return a.g
    }

    function S_(a) {
        function b(m) {
            for (let n = 0; n < m.length; n++) Qj(k, m[n], "0px")
        }

        function c() {
            T_(d, g, h);
            !k || l || h || (b(U_), b(V_))
        }
        var d = a.C;
        d.style.overflow = a.Pe ? "visible" : "hidden";
        a.D && (a.G ? (D_(d, W_()), D_(a.G, W_())) : D_(d, "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1) .3s, height .5s cubic-bezier(.4, 0, 1, 1)"));
        a.T !== null && (d.style.opacity = String(a.T));
        var e = a.width != null && a.l != null && (a.Nf || a.l > a.width) ? a.l : null,
            f = a.height != null && a.j != null && (a.Nf || a.j > a.height) ? a.j : null;
        if (a.J) {
            let m =
                a.J.length;
            for (let n = 0; n < m; n++) T_(a.J[n], e, f)
        }
        var g = a.l,
            h = a.j,
            k = a.G,
            l = a.W;
        a.D ? r.setTimeout(c, 1E3) : c()
    }

    function X_(a) {
        if (a.B && !a.pa || a.l == null && a.j == null && a.T == null && a.B) return a.g;
        var b = a.B;
        a.B = !1;
        M_(a);
        a.B = b;
        if (!b || a.check != null && !I_(a.g, a.check, a.l, a.j)) return a.g;
        a.g.g.indexOf("n") >= 0 && (a.width = null, a.height = null);
        if (a.width == null && a.l !== null || a.height == null && a.j !== null) a.D = !1;
        (a.l == 0 || a.j == 0) && a.g.g.indexOf("l") >= 0 && (a.l = 0, a.j = 0);
        b = a.g;
        b.j[0] = "";
        b.j[1] = "";
        b.g = "";
        b.errors = "";
        S_(a);
        return M_(a)
    }

    function Q_(a, b) {
        var c = !1;
        b.display == "none" && (G_(a.g, "n"), a.B && (c = !0));
        b.visibility != "hidden" && b.visibility != "collapse" || G_(a.g, "v");
        b.overflow == "hidden" && G_(a.g, "o");
        b.position == "absolute" ? (G_(a.g, "a"), c = !0) : b.position == "fixed" && (G_(a.g, "f"), c = !0);
        return c
    }

    function N_(a, b, c) {
        var d = 0;
        if (!b || !b.parentElement) return !0;
        var e = !1,
            f = 0,
            g = b.parentElement.childNodes;
        for (let k = 0; k < g.length; k++) {
            var h = g[k];
            h == b ? e = !0 : (h = Y_(a, h, c), d |= h, e && (f |= h))
        }
        f & 1 && (d & 2 && F_(a.g, 0, "o"), d & 4 && F_(a.g, 1, "o"));
        return !(d & 1)
    }

    function O_(a, b, c, d) {
        var e = null;
        try {
            e = c.style
        } catch (A) {
            H_(a.g, "s")
        }
        var f = c.getAttribute("width"),
            g = ll(f),
            h = c.getAttribute("height"),
            k = ll(h),
            l = d && /^block$/.test(d.display) || e && /^block$/.test(e.display);
        b = N_(a, c, b);
        var m = d && d.width,
            n = d && d.height,
            p = e && e.width,
            q = e && e.height,
            u = ml(m) == a.width && ml(n) == a.height;
        m = u ? m : p;
        q = u ? n : q;
        p = ml(m);
        u = ml(q);
        g = a.width !== null && (p !== null && a.width >= p || g !== null && a.width >= g);
        u = a.height !== null && (u !== null && a.height >= u || k !== null && a.height >= k);
        k = !b && P_(d);
        u = b || u || k || !(f || m || d && (!Z_(String(d.minWidth)) ||
            !$_(String(d.maxWidth))));
        l = b || g || k || l || !(h || q || d && (!Z_(String(d.minHeight)) || !$_(String(d.maxHeight))));
        a0(a, 0, u, c, "width", f, a.width, a.l);
        b0(a, 0, "d", u, e, d, "width", m, a.width, a.l);
        b0(a, 0, "m", u, e, d, "minWidth", e && e.minWidth, a.width, a.l);
        b0(a, 0, "M", u, e, d, "maxWidth", e && e.maxWidth, a.width, a.l);
        a.Uh ? (c = /^html|body$/i.test(c.nodeName), f = ml(n), h = d ? d.overflowY === "auto" || d.overflowY === "scroll" : !1, h = a.j != null && d && f && Math.round(f) !== a.j && !h && d.minHeight !== "100%", a.B && !c && h && (e.setProperty("height", "auto", "important"),
            d && !Z_(String(d.minHeight)) && e.setProperty("min-height", "0px", "important"), d && !$_(String(d.maxHeight)) && a.j && Math.round(f) < a.j && e.setProperty("max-height", "none", "important"))) : (a0(a, 1, l, c, "height", h, a.height, a.j), b0(a, 1, "d", l, e, d, "height", q, a.height, a.j), b0(a, 1, "m", l, e, d, "minHeight", e && e.minHeight, a.height, a.j), b0(a, 1, "M", l, e, d, "maxHeight", e && e.maxHeight, a.height, a.j));
        return b
    }

    function R_(a) {
        function b() {
            if (c > 0) {
                var l = il(e, d) || {
                    width: 0,
                    height: 0
                };
                let m = ml(l.width);
                l = ml(l.height);
                m !== null && f !== null && h && h(0, f - m);
                l !== null && g !== null && h && h(1, g - l);
                --c
            } else r.clearInterval(k), h && (h(0, 0), h(1, 0))
        }
        var c = 31.25,
            d = a.Z,
            e = a.C,
            f = a.l,
            g = a.j,
            h = a.O,
            k;
        r.setTimeout(() => {
            k = r.setInterval(b, 16)
        }, 990)
    }

    function Y_(a, b, c) {
        if (b.nodeType == 3) return /\S/.test(b.data) ? 1 : 0;
        if (b.nodeType == 1) {
            if (/^(head|script|style)$/i.test(b.nodeName)) return 0;
            let d = null;
            try {
                d = il(b, c)
            } catch (e) {}
            if (d) {
                if (d.display == "none" || d.position == "fixed") return 0;
                if (d.position == "absolute") {
                    if (!a.A.boundingClientRect || d.visibility == "hidden" || d.visibility == "collapse") return 0;
                    c = null;
                    try {
                        c = b.getBoundingClientRect()
                    } catch (e) {
                        return 0
                    }
                    return (c.right > a.A.boundingClientRect.left ? 2 : 0) | (c.bottom > a.A.boundingClientRect.top ? 4 : 0)
                }
            }
            return 1
        }
        return 0
    }

    function a0(a, b, c, d, e, f, g, h) {
        if (h != null) {
            if (v(f)) {
                if (f == "100%" || !f) return;
                f = ll(f);
                f == null && (H_(a.g, "n"), F_(a.g, b, "d"))
            }
            if (f != null)
                if (c) {
                    if (a.B)
                        if (a.D) {
                            let k = Math.max(f + h - (g || 0), 0),
                                l = a.O;
                            a.O = (m, n) => {
                                m == b && hj(d, e, String(k - n));
                                l && l(m, n)
                            }
                        } else hj(d, e, String(h))
                } else F_(a.g, b, "d")
        }
    }

    function b0(a, b, c, d, e, f, g, h, k, l) {
        if (l != null) {
            f = f && f[g];
            !v(f) || (c == "m" ? Z_(f) : $_(f)) || (f = ml(f), f == null ? G_(a.g, "p") : k != null && G_(a.g, f == k ? "E" : "e"));
            if (v(h)) {
                if (c == "m" ? Z_(h) : $_(h)) return;
                h = ml(h);
                h == null && (H_(a.g, "p"), F_(a.g, b, c))
            }
            if (h != null)
                if (d && e) {
                    if (a.B)
                        if (a.D) {
                            let m = Math.max(h + l - (k || 0), 0),
                                n = a.O;
                            a.O = (p, q) => {
                                p == b && (e[g] = W(m - q));
                                n && n(p, q)
                            }
                        } else e[g] = W(l)
                } else F_(a.g, b, c)
        }
    }
    var g0 = class {
        constructor(a, b, c, d, e, f, g) {
            this.pubWin = a;
            this.C = b;
            this.J = c;
            this.G = this.O = null;
            this.W = !1;
            this.A = new c0(this.C);
            this.Z = (a = this.C.ownerDocument) && (a.defaultView || a.parentWindow);
            this.A = new c0(this.C);
            this.B = g;
            this.pa = d0(this.A, d.fi, d.height, d.ze);
            this.width = this.B ? this.A.boundingClientRect ? this.A.boundingClientRect.right - this.A.boundingClientRect.left : null : e;
            this.height = this.B ? this.A.boundingClientRect ? this.A.boundingClientRect.bottom - this.A.boundingClientRect.top : null : f;
            this.l = e0(d.width);
            this.j = e0(d.height);
            this.T = this.B ? e0(d.opacity) : null;
            this.check = d.check;
            this.ze = !!d.ze;
            this.D = d.fi == "animate" && !f0(this.A, this.j, this.ze) && E_();
            this.Pe = !!d.Pe;
            this.g = new L_;
            f0(this.A, this.j, this.ze) && G_(this.g, "r");
            e = this.A;
            e.g && e.j >= e.ga && G_(this.g, "b");
            this.Nf = !!d.Nf;
            this.Uh = !!d.Uh
        }
    };

    function f0(a, b, c) {
        var d;
        (d = a.g) && !(d = !a.visible) && (c ? (b = a.j + Math.min(b, e0(a.getHeight())), a = a.g && b >= a.ga) : a = a.g && a.j >= a.ga, d = a);
        return d
    }
    var c0 = class {
        constructor(a) {
            this.boundingClientRect = null;
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c && Tk(c);
            this.g = !!c;
            if (a) try {
                this.boundingClientRect = a.getBoundingClientRect()
            } catch (g) {}
            for (var d = a, e = 0, f = this.boundingClientRect; d;) try {
                f && (e += f.top);
                let g = d.ownerDocument,
                    h = g && (g.defaultView || g.parentWindow);
                (d = h && h.frameElement) && (f = d.getBoundingClientRect())
            } catch (g) {
                break
            }
            this.j = e;
            c = c || r;
            this.ga = (c.document.compatMode == "CSS1Compat" ? c.document.documentElement : c.document.body).clientHeight;
            b = b && BX(b);
            this.visible = !!a && !(b == 2 || b == 3) && !(this.boundingClientRect && this.boundingClientRect.top >= this.boundingClientRect.bottom && this.boundingClientRect.left >= this.boundingClientRect.right)
        }
        isVisible() {
            return this.visible
        }
        getWidth() {
            return this.boundingClientRect ? this.boundingClientRect.right - this.boundingClientRect.left : null
        }
        getHeight() {
            return this.boundingClientRect ? this.boundingClientRect.bottom - this.boundingClientRect.top : null
        }
    };

    function d0(a, b, c, d) {
        switch (b) {
            case "no_rsz":
                return !1;
            case "force":
            case "animate":
                return !0;
            default:
                return f0(a, c, d)
        }
    }

    function P_(a) {
        return !!a && /^left|right$/.test(a.cssFloat || a.styleFloat)
    }
    var h0 = new L_("s", ""),
        J_ = RegExp("[lonvafrbpEe]", "g");

    function $_(a) {
        return !a || /^(auto|none|100%)$/.test(a)
    }

    function Z_(a) {
        return !a || /^(0px|auto|none|0%)$/.test(a)
    }

    function T_(a, b, c) {
        b !== null && ll(a.getAttribute("width")) !== null && a.setAttribute("width", String(b));
        c !== null && ll(a.getAttribute("height")) !== null && a.setAttribute("height", String(c));
        b !== null && (a.style.width = W(b));
        c !== null && (a.style.height = W(c))
    }
    var U_ = "margin-left margin-right padding-left padding-right border-left-width border-right-width".split(" "),
        V_ = "margin-top margin-bottom padding-top padding-bottom border-top-width border-bottom-width".split(" ");

    function W_() {
        var a = "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1), height .3s cubic-bezier(.4, 0, 1, 1) .2s",
            b = U_;
        for (var c = 0; c < b.length; c++) a += ", " + b[c] + " .2s cubic-bezier(.4, 0, 1, 1)";
        b = V_;
        for (c = 0; c < b.length; c++) a += ", " + b[c] + " .3s cubic-bezier(.4, 0, 1, 1) .2s";
        return a
    }

    function e0(a) {
        return v(a) ? ll(a) : qc(a) && isFinite(a) ? a : null
    };

    function i0(a) {
        if (a = a.navigator ? .userActivation) {
            var b = 0;
            a ? .hasBeenActive && (b |= 1);
            a ? .isActive && (b |= 2);
            return b
        }
    };
    const j0 = /[+, ]/;

    function k0(a) {
        try {
            if (a.parentNode) return a.parentNode
        } catch {
            return null
        }
        if (a.nodeType === 9) a: {
            try {
                let c = xj(a);
                if (c) {
                    let d = c.frameElement;
                    if (d && Qk(c.parent)) {
                        var b = d;
                        break a
                    }
                }
            } catch {}
            b = null
        }
        else b = null;
        return b
    }

    function l0(a, b) {
        var c = k_(a.pubWin);
        a.I.saaei && (c += (c === "" ? "" : ",") + a.I.saaei);
        b.eid = c
    }

    function m0(a, b) {
        a = (a = Tk(a.pubWin)) && a.document ? lX(a.document, a) : new Di(-12245933, -12245933);
        b.scr_x = Math.round(a.x);
        b.scr_y = Math.round(a.y)
    }

    function n0(a) {
        try {
            let b = r.top.location.hash;
            if (b) {
                let c = b.match(a);
                return c && c[1] || ""
            }
        } catch {}
        return ""
    }

    function o0(a, b, c) {
        var d = a.I,
            e = a.pubWin,
            f = a.K,
            g = Uk(window);
        d.fsapi && (b.fsapi = !0);
        b.ref = d.google_referrer_url;
        b.loc = d.google_page_location;
        var h;
        (h = lr(e)) && h.data && ra(h.data) && v(h.data.type) ? (h = h.data.type.toLowerCase(), h = h === "doubleclick" || h === "adsense" ? null : h) : h = null;
        h && (b.apn = h.substr(0, 10));
        g = Pk(g);
        b.url || b.loc || !g.url || (b.url = g.url, g.sh || (b.usrc = 1));
        g.url != (b.loc || b.url) && (b.top = g.url);
        a.Mc && (b.etu = a.Mc);
        (c = fY(d, f, c)) && (b.fc = c);
        if (!Vr(d)) {
            c = a.pubWin.document;
            g = "";
            if (c.documentMode && (h = Jj(new qj(c),
                    "IFRAME"), h.frameBorder = "0", h.style.height = 0, h.style.width = 0, h.style.position = "absolute", c.body)) {
                c.body.appendChild(h);
                try {
                    let ya = h.contentWindow.document;
                    ya.open();
                    var k = Uh("<!DOCTYPE html>");
                    ya.write(Vh(k));
                    ya.close();
                    g += ya.documentMode
                } catch (ya) {}
                c.body.removeChild(h)
            }
            b.docm = g
        }
        try {
            var l = e.screenX;
            var m = e.screenY
        } catch (ya) {}
        try {
            var n = e.outerWidth;
            var p = e.outerHeight
        } catch (ya) {}
        try {
            var q = e.innerWidth;
            var u = e.innerHeight
        } catch (ya) {}
        try {
            var A = e.screenLeft;
            var D = e.screenTop
        } catch (ya) {}
        try {
            q = e.innerWidth,
                u = e.innerHeight
        } catch (ya) {}
        try {
            var K = e.screen.availWidth;
            var I = e.screen.availTop
        } catch (ya) {}
        b.brdim = [A, D, l, m, K, I, n, p, q, u].join();
        k = 0;
        r.postMessage === void 0 && (k |= 1);
        k > 0 && (b.osd = k);
        b.vis = BX(e.document);
        a = a.da;
        e = nY(d) ? h0 : X_(new g0(e, a, null, {
            width: 0,
            height: 0
        }, d.google_ad_width, d.google_ad_height, !1));
        b.rsz = e.toString();
        b.abl = K_(e);
        if (!nY(d) && (e = Wr(d), e !== null)) {
            a = 0;
            a: {
                try {
                    {
                        var G = d.google_async_iframe_id;
                        let ya = window.document;
                        if (G) var E = ya.getElementById(G);
                        else {
                            var Q = ya.getElementsByTagName("script"),
                                wa = Q[Q.length - 1];
                            E = wa && wa.parentNode || null
                        }
                    }
                    if (E) {
                        d = [];
                        G = 0;
                        for (var Ca = Date.now(); ++G <= 100 && Date.now() - Ca < 50 && (E = k0(E));) E.nodeType === 1 && d.push(E);
                        var ia = d;
                        b: {
                            for (Ca = 0; Ca < ia.length; Ca++) {
                                c: {
                                    var Fa = ia[Ca];
                                    try {
                                        if (Fa.parentNode && Fa.offsetWidth > 0 && Fa.offsetHeight > 0 && Fa.style && Fa.style.display !== "none" && Fa.style.visibility !== "hidden" && (!Fa.style.opacity || Number(Fa.style.opacity) !== 0)) {
                                            let ya = Fa.getBoundingClientRect();
                                            var Sb = ya.right > 0 && ya.bottom > 0;
                                            break c
                                        }
                                    } catch (ya) {}
                                    Sb = !1
                                }
                                if (!Sb) {
                                    var $c = !1;
                                    break b
                                }
                            }
                            $c = !0
                        }
                        if ($c) {
                            b: {
                                let ya = Date.now();$c = /^html|body$/i;Sb = /^fixed/i;
                                for (Fa = 0; Fa < ia.length && Date.now() - ya < 50; Fa++) {
                                    let Mc = ia[Fa];
                                    if (!$c.test(Mc.tagName) && Sb.test(Mc.style.position || Wj(Mc, "position"))) {
                                        var Lc = Mc;
                                        break b
                                    }
                                }
                                Lc = null
                            }
                            break a
                        }
                    }
                } catch {}
                Lc = null
            }
            Lc && Lc.offsetWidth * Lc.offsetHeight <= e.width * e.height * 4 && (a = 1);
            b.pfx = a
        }
        a: {
            if (Math.random() < .05 && f) try {
                let ya = f.document.getElementsByTagName("head")[0];
                var ee = ya ? GY(ya) : 0;
                break a
            } catch (ya) {}
            ee = 0
        }
        f = ee;
        f !== 0 && (b.cms = f)
    }

    function p0(a, b) {
        var c = 0;
        a.location && a.location.ancestorOrigins ? c = a.location.ancestorOrigins.length : Rk(() => {
            c++;
            return !1
        }, a);
        c && (b.nhd = c)
    }

    function q0(a, b) {
        var c = Mz(b, 8, {});
        b = Mz(b, 9, {});
        var d = a.google_ad_section,
            e = a.google_ad_format;
        a = a.google_ad_slot;
        e ? c[d] = c[d] ? c[d] + `,${e}` : e : a && (b[d] = b[d] ? b[d] + `,${a}` : a)
    }

    function r0(a, b, c, d) {
        var e = a.I,
            f = a.I;
        b.dt = Yr;
        f.google_async_iframe_id && f.google_bpp && (b.bpp = f.google_bpp);
        a: {
            try {
                var g = r.performance;
                if (g && g.timing && g.now) {
                    var h = g.timing.navigationStart + Math.round(g.now()) - g.timing.domLoading;
                    break a
                }
            } catch (m) {}
            h = null
        }(f = (f = h) ? LZ(f, r.Date.now() - Yr, 1E6) : null) && (b.bdt = f);
        b.idt = LZ(a.A, Yr);
        f = a.I;
        b.shv = a.pageState.jTCuI;
        a.Tc && (b.mjsv = a.Tc);
        f.google_loader_used === "sd" ? b.ptt = 5 : f.google_loader_used === "aa" && (b.ptt = 9);
        /^\w{1,3}$/.test(f.google_loader_used) && (b.saldr = f.google_loader_used);
        if (f = lr(a.pubWin)) b.is_amp = 1, b.amp_v = mr(f), (f = nr(f)) && (b.act = f);
        f = a.pubWin;
        f === f.top && (b.abxe = 1);
        (f = d.get("__gads", c)) ? b.cookie = f: (f = a.pubWin, c.ha() && sH(f) && (b.cookie_enabled = "1"));
        f = d.get("__gpi", c);
        h = d.get("__gpi_opt_out", c);
        f && !f.includes("&") && (b.gpic = f);
        h === "1" && (b.pdopt = "1");
        (d = (c = q_(a.pubWin, c, {
            Sm: !1,
            Tm: !a.zb
        })) && d.get("__eoi")) ? b.eo_id_str = d: c && (b.eoidce = "1");
        d = Hz();
        f = Mz(d, 8, {});
        c = e.google_ad_section;
        f[c] && (b.prev_fmts = f[c]);
        f = Mz(d, 9, {});
        f[c] && (b.prev_slotnames = f[c].toLowerCase());
        q0(e, d);
        c = Mz(d, 15, 0);
        c > 0 && (b.nras = String(c));
        (f = lr(window)) ? (f ? (c = f.pageViewId, f = f.clientId, v(f) && (c += f.replace(/\D/g, "").substring(0, 6))) : c = null, c = +c) : (c = Uk(window), f = c.google_global_correlator, f || (c.google_global_correlator = f = 1 + Math.floor(Math.random() * 8796093022208)), c = f);
        b.correlator = Mz(d, 7, c);
        U($w) && (b.rume = 1);
        if (e.google_ad_channel) {
            c = Mz(d, 10, {});
            f = "";
            h = e.google_ad_channel.split(j0);
            for (g = 0; g < h.length; g++) {
                var k = h[g];
                c[k] ? f += k + "+" : c[k] = !0
            }
            b.pv_ch = f
        }
        if (e.google_ad_host_channel) {
            c = e.google_ad_host_channel;
            f = Mz(d, 11, []);
            h = c.split("|");
            d = -1;
            c = [];
            for (g = 0; g < h.length; g++) {
                k = h[g].split(j0);
                f[g] || (f[g] = {});
                let m = "";
                for (let n = 0; n < k.length; n++) {
                    let p = k[n];
                    p !== "" && (f[g][p] ? m += "+" + p : f[g][p] = !0)
                }
                m = m.slice(1);
                c[g] = m;
                m !== "" && (d = g)
            }
            f = "";
            if (d > -1) {
                for (h = 0; h < d; h++) f += c[h] + "|";
                f += c[d]
            }
            b.pv_h_ch = f
        }
        b.frm = e.google_iframing;
        b.ife = e.google_iframing_environment;
        a: {
            d = e.google_ad_client;
            try {
                let m = Uk(window),
                    n = m.google_prev_clients;
                n || (n = m.google_prev_clients = {});
                if (d in n) {
                    var l = 1;
                    break a
                }
                n[d] = !0;
                l = 2;
                break a
            } catch {
                l = 0;
                break a
            }
            l =
            void 0
        }
        b.pv = l;
        U(Rv) && a.pubWin.location.host.endsWith("h5games.usercontent.goog") && (b.cdm = a.pubWin.location.host);
        p0(a.pubWin, b);
        (a = e.google_ad_layout) && RZ[a] >= 0 && (b.rplot = RZ[a])
    }

    function s0(a, b) {
        a = a.P;
        var c = Hz();
        Mz(c, 26) && (b.npa = 1);
        a && (ef(a, 3) != null && (b.gdpr = a.g() ? "1" : "0"), (c = pf(a, 1)) && (b.us_privacy = c), (c = pf(a, 2)) && (b.gdpr_consent = c), (c = pf(a, 4)) && (b.addtl_consent = c), (c = qf(a, 7)) && (b.tcfe = c), (c = C(a, 11)) && (b.gpp = c), (a = df(a, 10)) && a.length > 0 && (b.gpp_sid = a.join(",")))
    }

    function t0(a, b) {
        var c = a.I;
        s0(a, b);
        Nk(m_, (d, e) => {
            e !== "google_source_type" && e !== "google_tag_for_child_directed_treatment" && e !== "google_tag_for_under_age_of_consent" && (b[d] = c[e])
        });
        nY(c) && (a = mY(c), b.fa = a);
        b.pi || c.google_ad_slot == null || (a = WK(c), du(a) && (a = ru(a.getValue()), b.pi = a))
    }

    function u0(a, b) {
        var c = pr() || jX(a.pubWin.top);
        c && (b.biw = c.width, b.bih = c.height);
        c = a.pubWin;
        c !== c.top && (a = jX(a.pubWin)) && (b.isw = a.width, b.ish = a.height)
    }

    function v0(a, b) {
        var c = a.pubWin;
        c !== null && c != c.top ? (a = [c.document.URL], c.name && a.push(c.name), c = jX(c, !1), a.push(c.width.toString()), a.push(c.height.toString()), a = ou(a.join(""))) : a = 0;
        a !== 0 && (b.ifk = a)
    }

    function w0(a, b) {
        (a = Pz()[a.I.google_ad_client]) && (b.psts = a.join())
    }

    function x0(a, b) {
        (a = a.pageState.AyxaY) && a >= 0 && (b.tmod = a)
    }

    function y0(a, b) {
        if (a = a.pubWin.google_user_agent_client_hint) {
            let c = [],
                d = 0;
            for (let e = 0; e < a.length; e++) {
                let f = a.charCodeAt(e);
                f > 255 && (c[d++] = f & 255, f >>= 8);
                c[d++] = f
            }
            a = Bb(c, 3);
            b.uach = a
        }
    }

    function z0(a, b) {
        if (a.Ac.OSwJs !== 2) {
            var c = a.I.google_ad_public_floor;
            a = a.I.google_ad_private_floor;
            c >= 0 && (b.pubf = c);
            a >= 0 && (b.pvtf = a)
        }
    }

    function A0(a, b) {
        var c = Number(a.I.google_traffic_source);
        c && Object.values(Ha).includes(c) && (b.trt = a.I.google_traffic_source)
    }

    function B0(a, b) {
        if (v(a.I.google_privacy_treatments)) {
            var c = new Map([
                ["disablePersonalization", 1]
            ]);
            a = a.I.google_privacy_treatments.split(",");
            var d = [];
            for (let [e, f] of c.entries()) c = f, a.includes(e) && d.push(c);
            d.length && (b.ppt = d.join("~"))
        }
    }

    function C0(a, b) {
        if (a.g) {
            a.g.bm && (b.xatf = 1);
            try {
                a.g.Zg ? .disconnect(), a.g.Zg = void 0
            } catch {}
        }
    }

    function D0(a, b = document) {
        if (U(Tu)) try {
            let {
                labels: c
            } = y_(b);
            c.length && (a.pgls = c.map(d => {
                d = s_(d);
                return Bb(d, 3)
            }).join("~"))
        } catch (c) {
            tA.Da(1278, c)
        }
    }

    function E0(a, b) {
        U(Su) && (a = a.Ib ? .get(), b.bisch = a ? .charging, b.blev = a ? .level)
    }

    function F0(a, b, c) {
        var d = {};
        t0(a, d);
        y0(a, d);
        r0(a, d, b, c);
        d.u_tz = -(new Date).getTimezoneOffset();
        try {
            var e = Kl.history.length
        } catch (f) {
            e = 0
        }
        d.u_his = e;
        d.u_h = Kl.screen ? .height;
        d.u_w = Kl.screen ? .width;
        d.u_ah = Kl.screen ? .availHeight;
        d.u_aw = Kl.screen ? .availWidth;
        d.u_cd = Kl.screen ? .colorDepth;
        d.u_sd = kX(a.pubWin);
        d.dmc = a.pubWin.navigator ? .deviceMemory;
        wA(889, () => {
            if (a.K === null) d.adx = -12245933, d.ady = -12245933;
            else {
                var f = a.da.parentElement,
                    g = f ? .style.display,
                    h = U(Tw) && f && getComputedStyle(f).display === "none";
                h && f.style.setProperty("display",
                    "block", "important");
                var k = nX(a.K, a.da);
                d.adx && d.adx !== -12245933 && d.ady && d.ady !== -12245933 || (d.adx = Math.round(k.x), d.ady = Math.round(k.y));
                mX(a.da) || (d.adx = -12245933, d.ady = -12245933, a.j |= 32768);
                h && (f.style.display = g || "");
                f = a.I.override_ady;
                qc(f) && (d.ady = f);
                f = a.I.override_adx;
                qc(f) && (d.adx = f)
            }
        });
        u0(a, d);
        v0(a, d);
        m0(a, d);
        l0(a, d);
        d.oid = 2;
        w0(a, d);
        U(Uu) && (c = V(hv), JZ(a, d, b, c > 0 ? {
            F: oA,
            uh: new r_,
            Sj: c
        } : void 0));
        d.pvsid = Cl(a.pubWin, tA);
        x0(a, d);
        d.uas = i0(a.pubWin);
        (c = C_(a.pubWin)) && (d.nvt = c);
        a.l && (d.scar = a.l);
        C0(a,
            d);
        o0(a, d, b);
        d.fu = a.j;
        d.bc = p_();
        a.pageState.xujKL && (l_(d), d.creatives = n0(/\b(?:creatives)=([\d,]+)/), d.adgroups = n0(/\b(?:adgroups)=([\d,]+)/), d.adgroups || d.sso) && (d.adtest = "on", d.disable_budget_throttling = !0, d.use_budget_filtering = !1, d.retrieve_only = !0, d.disable_fcap = !0);
        Ql() && (d.atl = !0);
        (b = IX(a.K || a.pubWin)) && (d.plas = b);
        d.bz = Zk(a.pubWin);
        z0(a, d);
        A0(a, d);
        B0(a, d);
        String(a.I.google_special_category_data) === "true" && (d.scd = 1);
        D0(d, a.pubWin.document);
        E0(a, d);
        return d
    }
    const G0 = /YtLoPri/;

    function H0(a) {
        var b = Hz(),
            c = a.google_ad_section;
        nY(a) && Oz(b, 15);
        if (Vr(a)) {
            if (Oz(b, 5) > 100) return !1
        } else if (Oz(b, 6) - Mz(b, 15, 0) > 100 && c === "") return !1;
        return !0
    }
    var I0 = Y(function(a, b) {
        var c = b.I,
            d = b.Oa,
            e = b.pubWin,
            f = a.P;
        a = a.Va;
        var g = "";
        if (pY(c)) g = (f.ha() ? d.jk : d.ik).toString() + "#" + (encodeURIComponent("RS-" + c.google_reactive_sra_index + "-") + "&" + Rr({
            adk: c.google_ad_unit_key,
            client: c.google_ad_client,
            fa: c.google_reactive_ad_format
        })), q0(c, Hz()), H0(c);
        else if ((d = c.google_pgb_reactive === 5 && !!c.google_reactive_ads_config) || (d = c.google_reactive_ad_format, d = !(!c.google_reactive_ads_config && nY(c) && d !== 16 && d !== 10 && d !== 11 && d !== 40 && d !== 41 && d !== 42 && d !== 44)), d || (d = c.google_reactive_ad_format,
                Ji(d) ? (e = Tk(e)) && $X(e, c, d, f) ? (e = bB(e), ns(e, d) ? d = !1 : (e.adCount[d] || (e.adCount[d] = 0), e.adCount[d]++, d = !0)) : d = !1 : d = !1), d && H0(c)) {
            d = g = b.I;
            var h = b.pubWin;
            e = {};
            let u = h.document;
            var k = {
                ak: Uk(h),
                bh: !1,
                hj: "",
                Rg: 1
            };
            a: {
                var l = d.google_ad_width || h.google_ad_width,
                    m = d.google_ad_height || h.google_ad_height;
                if (h && h.top === h) var n = !1;
                else {
                    n = h.document;
                    var p = n.documentElement;
                    if (l && m) {
                        let A = 1,
                            D = 1;
                        h.innerHeight ? (A = h.innerWidth, D = h.innerHeight) : p && p.clientHeight ? (A = p.clientWidth, D = p.clientHeight) : n.body && (A = n.body.clientWidth,
                            D = n.body.clientHeight);
                        if (D > 2 * m || A > 2 * l) {
                            n = !1;
                            break a
                        }
                    }
                    n = !0
                }
            }
            k.bh = n;
            n = k.bh;
            p = Pk(k.ak).sh;
            l = El(h);
            m = 4;
            n || l !== 1 ? n || l !== 2 ? n && l === 1 ? m = 7 : n && l === 2 && (m = 8) : m = 6 : m = 5;
            p && (m |= 16);
            k.hj = String(m);
            k.Rg = Gz(h);
            p = k;
            k = p.ak;
            n = p.bh;
            l = !!d.google_page_url;
            e.google_iframing = p.hj;
            p.Rg !== 0 && (e.google_iframing_environment = p.Rg);
            if (!l && u.domain === "ad.yieldmanager.com") {
                for (p = u.URL.substring(u.URL.lastIndexOf("http")); p.indexOf("%") > -1;) try {
                    p = decodeURIComponent(p)
                } catch (A) {
                    break
                }
                d.google_page_url = p;
                l = !!p
            }
            l ? (e.google_page_url =
                d.google_page_url, e.google_page_location = (n ? u.referrer : u.URL) || "EMPTY") : (n && Qk(h.top) && u.referrer && h.top.document.referrer === u.referrer ? e.google_page_url = h.top.document.URL : e.google_page_url = n ? u.referrer : u.URL, e.google_page_location = null);
            if (u.URL === e.google_page_url) try {
                var q = Math.round(Date.parse(u.lastModified) / 1E3) || null
            } catch {
                q = null
            } else q = null;
            e.google_last_modified_time = q;
            q = k === k.top ? k.document.referrer : (q = lr()) && q.referrer || "";
            e.google_referrer_url = q;
            Fz(e, g);
            q = f.ha() ? iX(g) ? "pagead2.googlesyndication.com" :
                "googleads.g.doubleclick.net" : "pagead2.googlesyndication.com";
            f = F0(b, f, a);
            a = b.I;
            e = a.google_ad_channel;
            d = "/pagead/ads?";
            a.google_ad_client === "ca-pub-6219811747049371" && G0.test(e) && (d = "/pagead/lopri?");
            g = Qr(f, `https://${q}${d}` + (b.pageState.xujKL && g.google_debug_params ? g.google_debug_params : ""))
        }
        Sl(2, [c, g]);
        return {
            Wa: g,
            ra: !g
        }
    }, {
        id: 1437,
        H: {
            Wa: void 0,
            ra: void 0
        }
    });
    var J0 = Y(function(a, b, c, d, e) {
        var f = a.hh;
        if (!f) return {
            Wa: "",
            Na: ""
        };
        var g = U(Pw);
        g || b.google_async_iframe_id || Tr(c);
        var h = g ? a.lc : Ur(b);
        g = g ? a.Na : c === d ? "a!" + h.toString(36) : `${h.toString(36)}.${lj()}`;
        c = oX(d, c, e, !0) > 0;
        h = {
            ifi: h,
            uci: g
        };
        c && (c = Hz(), h.btvi = Mz(c, 21, 1), Oz(c, 21));
        f = Qr(h, f);
        rl() && !pY(b) && (f = Wm(f, "fsb", 1));
        return a.Ga ? {
            Wa: Wm(f, "fca", "1"),
            Na: g
        } : {
            Wa: f,
            Na: g
        }
    }, {
        id: 1438,
        H: {
            Wa: void 0,
            Na: void 0
        }
    });
    var K0 = Y(function(a) {
        var b = a.url;
        if (a.ra) return {
            Wa: ""
        };
        a = b;
        a.length > 61440 && (a = a.substring(0, 61432), a = a.replace(/%\w?$/, ""), a = a.replace(/&[^=]*=?$/, ""), a += "&trunc=1");
        if (a !== b) {
            let c = b.lastIndexOf("&", 61432);
            c === -1 && (c = b.lastIndexOf("?", 61432));
            zA("trn", {
                ol: b.length,
                tr: c === -1 ? "" : b.substring(c + 1),
                url: b
            }, .01)
        }
        return {
            Wa: a
        }
    }, {
        id: 1374,
        H: {
            Wa: void 0
        }
    });
    var L0 = class extends aZ {
        constructor(a, b, c, d, e, f) {
            super(a, b, c, d, f);
            this.qa = e;
            this.output = YY(this, new PY);
            this.complete = new TY
        }
        B(a) {
            a.then(b => {
                b instanceof IY || (KY(this.output, b), this.complete.notify())
            }, b => {
                this.qa ? KY(this.output, this.qa(b)) : this.output.setError(new HY(`output error: ${b.message}`), () => {
                    this.G.Ka({
                        methodName: this.id,
                        hb: b
                    })
                });
                this.complete.notify()
            })
        }
        g(a) {
            this.qa ? (KY(this.output, this.qa(a)), this.complete.notify()) : super.g(a)
        }
    };

    function M0(a, b) {
        a.id = b.id;
        a.qa = b.qa;
        return a
    }

    function N0(a, b, c, ...d) {
        return new L0(a.id, a, b, c, a.qa, d)
    };

    function O0(a, b) {
        Hs(a, b);
        a.T.push(b);
        return b
    }

    function Z(a, b, c, ...d) {
        return O0(a, cZ(b, a.C, c, ...d))
    }

    function P0(a, b, c, ...d) {
        return O0(a, N0(b, a.C, c, ...d))
    }

    function Q0(a, b) {
        a.W.push(b);
        Hs(a, b);
        return b
    }
    async function R0(a) {
        a.B.length && await Promise.all(a.B.map(d => d.Z.promise));
        if (await a.pa()) {
            for (var b of a.T) b.start();
            for (var c of a.W) R0(c);
            if (a.D && (b = Object.keys(a.D), b.length)) {
                c = await Promise.all(Object.values(a.D).map(e => e.promise));
                let d = 0;
                for (let e of b) a.Aa[e] = c[d++]
            }
        }
        a.Z.resolve(a.Aa)
    }
    var S0 = class extends Gs {
        constructor(a) {
            super();
            this.C = a;
            this.T = [];
            this.W = [];
            this.Aa = {};
            this.B = [];
            this.Z = new XV;
            this.D = {}
        }
        async pa() {
            return !0
        }
        j() {
            super.j();
            this.T.length = 0;
            this.W.length = 0;
            this.B.length = 0
        }
    };
    var T0 = class extends S0 {
        constructor(a, b, c, d, e, f, g, h) {
            super(a);
            a = X(Z(this, I0, {
                P: c,
                Va: f
            }, b), d);
            b = Z(this, J0, {
                hh: a.Wa,
                Ga: e,
                lc: g,
                Na: h
            }, b.I, b.pubWin, b.K, b.da);
            this.g = {
                Fm: Z(this, K0, {
                    ra: a.ra,
                    url: b.Wa
                }).Wa,
                ra: a.ra,
                Na: b.Na
            }
        }
    };
    var U0 = Y(function(a, b) {
        return {
            P: b.P
        }
    }, {
        id: 1462,
        H: {
            P: void 0
        }
    });
    var V0 = Y(function(a, b, c, d) {
        b = a.zb;
        return a.P.ha() || b ? {
            Qd: !0
        } : (zA("afc_noc_req", {
            client: c.google_ad_client,
            isGdprCountry: d.OSCLM.UWEfJ.toString()
        }, V(cv)), {
            Qd: !1
        })
    }, {
        id: 1381,
        H: {
            Qd: void 0
        }
    });

    function W0(a, b, c, d, e) {
        var f = SV(a, "gpi-uoo", (g, h) => {
            h.source === c && (h = Ck(g.userOptOut ? "1" : "0"), h = vf(h, 2, 2147483647), h = If(h, 3, "/"), h = If(h, 4, a.location.hostname), b && (e.set("__gpi_opt_out", h, b), g.userOptOut || g.clearAdsData)) && (e.delete("__gads", b), e.delete("__gpi", b))
        });
        d.push(f)
    };
    var X0 = Y(function(a, b) {
        var c = a.P;
        a = a.Va;
        if (c.ha()) {
            b = b.location.hostname;
            var d = a.get("__gpi_opt_out", c);
            d && (d = Ck(d), d = vf(d, 2, 2147483647), d = If(d, 3, "/"), b = If(d, 4, b), a.set("__gpi_opt_out", b, c))
        }
        return {}
    }, {
        id: 1382,
        H: {}
    });
    var Y0 = Y(function(a, b, c, d) {
        if (!U(Pw)) return {
            lc: 0,
            Na: ""
        };
        b.google_async_iframe_id || (b.google_unique_id = Tr(c));
        a = Ur(b);
        return {
            lc: a,
            Na: c === d ? "a!" + a.toString(36) : `${a.toString(36)}.${lj()}`
        }
    }, {
        id: 1722,
        H: {
            lc: void 0,
            Na: void 0
        }
    });
    var Z0 = Y(function(a, b) {
        var c = a.P;
        a = a.Va;
        j_(20, b, c, a);
        j_(17, b, c, a);
        return {}
    }, {
        id: 1433,
        H: {}
    });
    var $0 = Y(function(a, b) {
        U(fw) && (b.aieuf = !0, b.aicrs = !0, pX(b));
        return {}
    }, {
        id: 1449,
        H: {}
    });
    var a1 = Y(function(a, b) {
        var c = b.I.google_reactive_ads_config;
        if (!c) return {};
        a = a.P;
        kY(b.K, c);
        rY(c, b, a);
        c = c.page_level_pubvars;
        ra(c) && bj(b.I, c);
        return {}
    }, {
        id: 1434,
        H: {}
    });
    var b1 = Y(function(a, b) {
        a = a.P;
        a: {
            var c = [r.top];
            var d = [];
            let f = 0,
                g;
            for (; g = c[f++];) {
                d.push(g);
                try {
                    if (g.frames)
                        for (let h = 0; h < g.frames.length && c.length < 1024; ++h) c.push(g.frames[h])
                } catch {}
            }
            c = d;
            for (d = 0; d < c.length; d++) try {
                var e = c[d].frames.google_esf;
                if (e) {
                    Jl = e;
                    break a
                }
            } catch (h) {}
            Jl = null
        }
        if (Jl) return {};
        e = hl("IFRAME");
        e.id = "google_esf";
        e.name = "google_esf";
        dj(e, a.ha() ? b.jk : b.ik);
        e.style.display = "none";
        e && document.documentElement.appendChild(e);
        return {}
    }, {
        id: 1441,
        H: {}
    });
    var c1 = M0(async function(a, b) {
        return b.g ? .pl || Promise.resolve()
    }, {
        id: 1436
    });
    var d1 = class extends S0 {
        async pa() {
            var a = await this.g();
            a || this.l();
            return a
        }
    };
    async function e1(a, b, c) {
        a = new f1(b.id, b, a, c, b.qa);
        await a.start();
        b = await a.C.promise;
        a.dispose();
        return b
    }
    class f1 extends aZ {
        constructor(a, b, c, d, e) {
            super(a, b, c, d, []);
            this.qa = e;
            this.C = ka(Promise, "withResolvers").call(Promise)
        }
        W() {
            var a = this.f($Y(this), ...this.J);
            this.C.resolve(a)
        }
        B() {}
        g(a) {
            this.qa !== void 0 ? this.C.resolve(this.qa(a)) : super.g(a)
        }
    }

    function g1(a, b) {
        a.id = b.id;
        a.qa = b.qa;
        return a
    };
    const h1 = g1(function(a) {
        return a.Xa
    }, {
        id: 1464
    });
    var i1 = class extends d1 {
        constructor(a, b, c, d, e, f) {
            super(a);
            this.ea = a;
            this.Xa = d;
            a = X(Z(this, b1, {
                P: c
            }, b.Oa), e);
            f = X(Z(this, Z0, {
                P: c,
                Va: f
            }, b.pubWin), a.finished);
            c = X(Z(this, a1, {
                P: c
            }, b), f.finished);
            c = X(P0(this, c1, {}, b), c.finished);
            c = X(Z(this, Y0, {}, b.I, b.pubWin, b.K), c.complete);
            this.G = X(Z(this, $0, {}, b.I), c.finished).finished;
            this.lc = c.lc;
            this.Na = c.Na
        }
        async g() {
            return e1(this.ea, h1, {
                Xa: this.Xa
            })
        }
        l() {
            this.G.notify();
            KY(this.lc, null);
            KY(this.Na, null)
        }
    };
    var j1 = Y(function(a, b) {
        return U(Qw) && b.pageState.uNjDc ? {
            Ga: !1
        } : {
            Ga: U(Nw) && !!b.pubWin.fetch && !pY(b.I) && !nY(b.I)
        }
    }, {
        id: 1488,
        H: {
            Ga: void 0
        }
    });
    var k1 = Y(function(a, b) {
        var c = b.pubWin,
            d = b.da,
            e = b.I,
            f = b.Tc;
        a = V(Ww);
        e = !os(e.google_reactive_ad_format) && (nY(e) || e.google_reactive_ads_config);
        if (b.g ? .Zg || a <= 0 || Tk(c) || !r.IntersectionObserver || e) return {};
        b.g = {};
        var g = V(Xw),
            h = new Vq(f),
            k = um();
        c = new Promise(l => {
            var m = 0,
                n = b.g,
                p = new r.IntersectionObserver(xA(1236, q => {
                    if (q = q.find(u => u.target === d)) h.Tb.Zb.Oe.g.g.Od({
                        Yc: um() - k,
                        Bn: ++m
                    }), n.bm = q.isIntersecting && q.intersectionRatio >= g, l()
                }), {
                    threshold: [g]
                });
            p.observe(d);
            n.Zg = p
        });
        b.g.pl = Promise.race([c, Dl(a, null)]).then(l => {
            h.Tb.Zb.Oe.g.j.Od({
                Yc: um() - k,
                status: l === null ? "TIMEOUT" : "OK"
            })
        });
        return {}
    }, {
        id: 1345,
        H: {}
    });

    function l1(a, b, c, d) {
        a.F ? .Tb.Zb.vk.il.ua({
            qk: b,
            gl: c,
            Dm: d,
            ca: 1
        })
    }
    var m1 = class extends Gs {
        constructor(a, b, c) {
            var d = ["__eoi", "__gads", "__gpi", "__gpi_opt_out"],
                e = kA(100) ? oA : void 0;
            super();
            this.win = b;
            this.ea = c;
            this.F = e;
            this.g = new Map;
            this.l = !1;
            for (let g of d) this.g.set(g, void 0);
            if (b.cookieStore && b.cookieStore.addEventListener && a.ha() && (!Za() || El(this.win) !== 2) && b.origin !== "null") {
                this.cookieStore = b.cookieStore;
                var f = g => {
                    if (!this.A) {
                        for (let h of g.changed) h.name && this.g.has(h.name) && this.g.set(h.name, h.value);
                        for (let h of g.deleted) h.name && this.g.has(h.name) && this.g.set(h.name,
                            void 0)
                    }
                };
                this.cookieStore.addEventListener("change", f);
                Is(this, () => {
                    this.cookieStore ? .removeEventListener("change", f)
                });
                this.cookieStore.getAll().then(g => {
                    if (!this.A && this.cookieStore) {
                        for (let h of g) h.name && this.g.has(h.name) && this.g.set(h.name, h.value);
                        this.l = !0
                    }
                }).catch(g => {
                    this.ea.Ka({
                        methodName: 1607,
                        hb: g
                    })
                })
            }
        }
        get(a, b) {
            if (b && !b.ha()) return null;
            if (!this.l) return l1(this, "safe_storage", a, "read"), uH(a, this.win);
            l1(this, "cookie_store", a, "read");
            return this.g.get(a) ? ? null
        }
        set(a, b, c) {
            if (!c || c.ha()) this.l &&
                this.cookieStore ? (b = {
                    name: a,
                    value: b.getValue(),
                    expires: HG(hf(b, 2)) * 1E3,
                    domain: C(b, 4) || void 0,
                    path: C(b, 3) || void 0,
                    sameSite: "none"
                }, l1(this, "cookie_store", a, "write"), this.cookieStore.set(b).catch(d => {
                    d instanceof Error && (d.message = `${d.message} (Cookie: ${a})`);
                    this.ea.Ka({
                        methodName: 1608,
                        hb: d
                    })
                })) : (c = HG(hf(b, 2)) - Date.now() / 1E3, c = {
                    Df: Math.max(c, 0),
                    path: C(b, 3),
                    domain: C(b, 4),
                    secure: !1
                }, l1(this, "safe_storage", a, "write"), vH(a, b.getValue(), c, this.win))
        }
        delete(a, b) {
            if (b.ha())
                for (let c of Sr(this.win.location.hostname)) this.l &&
                    this.cookieStore ? (b = {
                        name: a,
                        path: "/",
                        domain: c
                    }, l1(this, "cookie_store", a, "delete"), this.cookieStore.delete(b).catch(d => {
                        d instanceof Error && (d.message = `${d.message} (Cookie: ${a})`);
                        this.ea.Ka({
                            methodName: 1609,
                            hb: d
                        })
                    })) : (l1(this, "safe_storage", a, "delete"), wH(a, this.win, c))
        }
    };
    let n1 = null;
    var o1 = Y(function(a, b, c) {
        n1 || (n1 = new m1(a.P, b, c));
        return {
            Ni: n1
        }
    }, {
        id: 1638,
        H: {
            Ni: void 0
        }
    });
    var p1 = Y(function(a, b, c) {
        var d = a.ia;
        d && d.setAttribute("data-google-container-id", a.Na);
        a = b.iaaso;
        a != null && (b = c.parentElement, (b && ly.test(b.className) ? b : c).setAttribute("data-auto-ad-size", a));
        d.setAttribute("tabindex", "0");
        d.setAttribute("title", "Advertisement");
        d.setAttribute("aria-label", "Advertisement");
        return {}
    }, {
        id: 1418,
        H: {}
    });
    var q1 = Y(function(a) {
        return {
            ia: a.Ga ? a.Gl : a.In
        }
    }, {
        id: 1489,
        H: {
            ia: void 0
        }
    });

    function r1(a, b) {
        var c = hl("STYLE", a);
        c.textContent = Xh(Yh `* { pointer-events: none; }`);
        a ? .head.appendChild(c);
        setTimeout(() => {
            a ? .head.removeChild(c)
        }, b)
    }

    function s1(a, b, c) {
        if (!a.body) return null;
        var d = new t1;
        d.apply(a, b);
        return () => {
            var e = c || 0;
            e > 0 && r1(b.document, e);
            Qj(a.body, {
                filter: d.g,
                webkitFilter: d.g,
                overflow: d.l,
                position: d.A,
                top: d.B
            });
            b.scrollTo(0, d.j)
        }
    }
    class t1 {
        constructor() {
            this.g = this.B = this.A = this.l = null;
            this.j = 0
        }
        apply(a, b) {
            this.l = a.body.style.overflow;
            this.A = a.body.style.position;
            this.B = a.body.style.top;
            this.g = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
            this.j = qs(b);
            Qj(a.body, "top", `${-this.j}px`)
        }
    };

    function u1(a, b) {
        var c;
        if (!a.l)
            for (a.l = [], c = a.g.parentElement; c;) {
                a.l.push(c);
                if (a.J(c)) break;
                c = c.parentNode && c.parentNode.nodeType === 1 ? c.parentNode : null
            }
        c = a.l.slice();
        var d, e;
        for (d = 0; d < c.length; ++d)(e = c[d]) && b.call(a, e, d, c)
    }
    var v1 = class extends Gs {
        constructor(a, b, c) {
            super();
            this.g = a;
            this.W = b;
            this.D = c;
            this.l = null;
            Is(this, () => this.l = null)
        }
        J(a) {
            return this.D === a
        }
    };

    function w1(a, b) {
        var c = a.D;
        c && (b ? (FC(a.G), L(c, {
            display: "block"
        }), a.C.body && !a.B && (a.B = s1(a.C, a.W, a.Z)), c.setAttribute("tabindex", "0"), c.setAttribute("aria-hidden", "false"), a.C.body.setAttribute("aria-hidden", "true")) : (GC(a.G), L(c, {
            display: "none"
        }), a.B && (a.B(), a.B = null), a.C.body.setAttribute("aria-hidden", "false"), c.setAttribute("aria-hidden", "true")))
    }

    function x1(a) {
        w1(a, !1);
        var b = a.D;
        if (b) {
            var c = y1(a.T);
            u1(a, d => {
                L(d, c);
                us(d)
            });
            a.g.setAttribute("width", "");
            a.g.setAttribute("height", "");
            Qj(a.g, c);
            Qj(a.g, z1);
            Qj(b, A1);
            Qj(b, {
                background: "transparent"
            });
            L(b, {
                display: "none",
                position: "fixed"
            });
            us(b);
            us(a.g);
            Yk(a.T) <= 1 || (Qj(b, {
                overflow: "scroll",
                "max-width": "100vw"
            }), wl(b))
        }
    }
    var B1 = class extends v1 {
            constructor(a, b, c) {
                var d = V(Vw);
                super(a, b, c);
                this.T = b;
                this.Z = d;
                this.B = null;
                this.C = b.document;
                this.G = zC(new EC(b), 2147483646)
            }
        },
        A1 = {
            backgroundColor: "white",
            opacity: "1",
            position: "fixed",
            left: "0px",
            top: "0px",
            margin: "0px",
            padding: "0px",
            display: "none",
            zIndex: "2147483647"
        },
        z1 = {
            left: "0",
            position: "absolute",
            top: "0"
        };

    function y1(a) {
        a = Yk(a);
        a = 100 * (a < 1 ? 1 : a);
        return {
            width: `${a}vw`,
            height: `${a}vh`
        }
    };
    var C1 = class extends B1 {
        constructor(a, b, c) {
            super(b, a, c);
            x1(this)
        }
        J(a) {
            return a.classList ? a.classList.contains("adsbygoogle") : ib(a.classList ? a.classList : (typeof a.className == "string" ? a.className : a.getAttribute && a.getAttribute("class") || "").match(/\S+/g) || [], "adsbygoogle")
        }
    };
    const D1 = {
        [1]: "closed",
        [2]: "viewed",
        [3]: "dismissed"
    };
    async function E1(a, b, c, d, e) {
        a = new F1(a, b, c, d, e);
        await a.init();
        return a
    }

    function G1(a) {
        return setTimeout(xA(728, () => {
            H1(() => {
                a.C.reject()
            });
            a.dispose()
        }), V(Uw) * 1E3)
    }

    function I1(a, b) {
        var c = YV(a.g).then(() => {
            clearTimeout(b);
            a.C.resolve()
        });
        yA(1005, c);
        c = ZV(a.g).then(d => {
            J1(a, D1[d.status], d.payload)
        });
        yA(1006, c);
        c = $V(a.g).then(() => {
            J1(a, "error")
        });
        yA(1004, c)
    }

    function K1(a) {
        a.win.location.hash !== "" && zA("pub_hash", {
            o_url: a.win.location.href
        }, .1);
        a.win.location.hash = "goog_fullscreen_ad";
        var b = xA(950, c => {
            c.oldURL.endsWith("#goog_fullscreen_ad") && (a.l === 10 ? (J1(a, "closed"), a.win.removeEventListener("hashchange", b)) : (a.win.location.hash = "goog_fullscreen_ad", UV(a.g.Cg, "fullscreen", {
                eventType: "backButton"
            }, "*")))
        });
        a.win.addEventListener("hashchange", b);
        Is(a, () => {
            a.win.removeEventListener("hashchange", b);
            a.win.location.hash === "#goog_fullscreen_ad" && a.win.history.back()
        })
    }

    function H1(a) {
        try {
            a()
        } catch (b) {}
    }

    function J1(a, b, c) {
        w1(a.G, !1);
        a.B && (c && b === "viewed" ? H1(() => {
            a.B({
                status: b,
                reward: c
            })
        }) : H1(() => {
            a.B({
                status: b
            })
        }));
        a.l === 11 && zA("fs_ad", {
            tgorigin: a.I.google_tag_origin,
            client: a.I.google_ad_client,
            url: a.I.google_page_url ? ? "",
            slot: a.I.google_ad_slot ? ? "0",
            ratype: a.l,
            clostat: b
        }, 1);
        a.dispose()
    }
    var F1 = class extends Gs {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.D = b;
            this.J = c;
            this.l = d;
            this.I = e;
            this.B = null;
            this.G = new C1(a, c, b);
            a = new bW(this.l === 10 ? 1 : 2, this.win, this.J.contentWindow);
            a.init();
            this.g = a;
            this.C = new XV;
            this.D.dataset["slotcar" + (this.l === 10 ? "Interstitial" : "Rewarded")] = "true"
        }
        async init() {
            var a = G1(this);
            I1(this, a);
            Is(this, () => {
                this.g.dispose();
                clearTimeout(a);
                zj(this.D)
            });
            await this.C.promise
        }
        show(a) {
            this.A || (this.B = a, w1(this.G, !0), r.IntersectionObserver || UV(this.g.Cg, "fullscreen", {
                eventType: "visible"
            }, "*"), K1(this))
        }
        disposeAd() {
            this.dispose()
        }
    };
    var L1 = Y(function(a, b, c, d) {
        a = a.ia;
        if (!b.google_acr) return {};
        if (b.google_wrap_fullscreen_ad) {
            let e = b.google_acr;
            E1(c, d.parentElement, a, b.google_reactive_ad_format, b).then(e).catch(() => {
                e(null)
            })
        } else b.google_acr(a);
        return {}
    }, {
        id: 1354,
        H: {}
    });
    const M1 = (a, b) => {
        try {
            let p = B(b, 6) === void 0 ? !0 : B(b, 6);
            var c = tk(F(b, 2)),
                d = C(b, 3);
            a: switch (F(b, 4)) {
                case 1:
                    var e = "pt";
                    break a;
                case 2:
                    e = "cr";
                    break a;
                default:
                    e = ""
            }
            var f = new vk(c, d, e),
                g = x(b, rk, 5) ? .g() ? ? "";
            f.Sc = g;
            f.j = p;
            var h = !!B(b, 7);
            f.Bc = h;
            var k = !!B(b, 8);
            f.Kb = k;
            var l = !!B(b, 9);
            f.g = l;
            var m = !!B(b, 10);
            f.l = m;
            f.win = a;
            var n = f.build();
            qk(n)
        } catch {}
    };

    function N1(a, b) {
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), a.document.readyState === "complete" ? M1(a, b) : gk(a, "load", () => void M1(a, b)))
    };
    var O1 = Y(function(a, b, c, d) {
        a = a.P;
        var e = HA();
        e.g && (e.state.tar += 1);
        e.Qa = b.google_page_url;
        b = new sk;
        e = new rk;
        var f = String(Cl(c));
        e = Jf(e, 1, f);
        b = y(b, 5, e);
        b = H(b, 4, 1);
        b = H(b, 2, 1);
        d = Jf(b, 3, d.jTCuI);
        a = a.ha();
        d = sf(d, 6, a);
        d = sf(d, 7, !0);
        d = sf(d, 8, !0);
        N1(c, d);
        return {}
    }, {
        id: 1347,
        H: {}
    });

    function P1(a, b, c) {
        var d = b.parentElement ? .classList.contains("adsbygoogle") ? b.parentElement : b;
        c.addEventListener("load", () => {
            Q1(d)
        });
        return TV(a, "adpnt", (e, f) => {
            if (ps(f, c.contentWindow)) {
                e = ss(e).qid;
                try {
                    c.setAttribute("data-google-query-id", e), a.googletag ? ? (a.googletag = {
                        cmd: []
                    }), a.googletag.queryIds = a.googletag.queryIds ? ? [], a.googletag.queryIds.push(e), a.googletag.queryIds.length > 500 && a.googletag.queryIds.shift()
                } catch {}
                d.dataset.adStatus = "filled";
                e = !0
            } else e = !1;
            return e
        })
    }

    function Q1(a) {
        setTimeout(() => {
            var b = a.dataset.adStatus;
            b !== "filled" && b !== "unfill-optimized" && (a.dataset.adStatus = "unfilled")
        }, 1E3)
    };
    var R1 = Y(function(a, b, c, d) {
        a = a.ia;
        b && d.push(P1(b, c, a));
        return {}
    }, {
        id: 1423,
        H: {}
    });

    function S1(a) {
        if (a.location ? .ancestorOrigins) return a.location.ancestorOrigins.length;
        var b = 0;
        Rk(() => {
            b++;
            return !1
        }, a);
        return b
    }

    function T1(a, b, c, d = "//tpc.googlesyndication.com") {
        var e = c;
        e && (e = "?" + e);
        b = d + ("/safeframe/" + b + "/html/container.html" + e);
        (a = S1(a)) && (b += `${c?"&":"?"}n=${a}`);
        return `https:${b}`
    };
    var U1 = {
        km: function(a) {
            if (!v(a.version)) throw new TypeError("version is not a string");
            if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError(`Invalid version: ${a.version}`);
            if (!v(a.Xf)) throw new TypeError("subdomain is not a string");
            if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.Xf)) throw new RangeError(`Invalid subdomain: ${a.Xf}`);
            return $h(`https://${a.Xf}.safeframe.googlesyndication.com/safeframe/${a.version}/html/container.html`)
        },
        kp(a) {
            return ni `https://tpc.googlesyndication.com/safeframe/${a}/html/container.html`
        }
    };

    function V1(a) {
        return `//${a}.safeframe.googlesyndication.com`
    }

    function W1(a, b) {
        return (b = S1(b)) ? oi(a, new Map([
            ["n", String(b)]
        ])) : a
    }
    var Y1 = wi(X1);

    function X1() {
        var a = "";
        for (let b of Z1()) b <= 15 && (a += "0"), a += b.toString(16);
        return a
    }

    function Z1() {
        if (typeof window.crypto ? .getRandomValues === "function") {
            var a = new Uint8Array(16);
            window.crypto.getRandomValues(a);
            return a
        }
        a = window;
        if (typeof a.msCrypto ? .getRandomValues === "function") {
            var b = new Uint8Array(16);
            a.msCrypto.getRandomValues(b);
            return b
        }
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(Math.random() * 255);
        return a
    };

    function $1(a, b, c) {
        try {
            if (!a2(a, c.origin) || !ps(c, a.g.contentWindow)) return
        } catch (f) {
            return
        }
        var d = b.msg_type,
            e = null;
        v(d) && (e = a.messageHandlers[d]) && a.ob.uc(168, () => {
            e.call(a, b, c)
        })
    }

    function a2(a, b) {
        return a.nk.includes(b) || Bl(b)
    }
    var b2 = class extends Gs {
        constructor(a, b) {
            var c = tA,
                d = rA,
                e = U(Nw) ? [`https:${V1(Y1())}`] : [];
            super();
            this.l = a;
            this.g = b;
            this.ob = c;
            this.F = d;
            this.nk = e;
            this.messageHandlers = {};
            this.pa = [];
            this.Gb = this.ob.wc(168, (f, g) => void $1(this, f, g));
            this.ri = this.ob.wc(169, (f, g) => ts(this.l, "ras::xsf", this.F, g));
            this.init({})
        }
        init() {
            this.Z(this.messageHandlers);
            this.pa.push(SV(this.l, "sth", this.Gb, this.ri))
        }
        j() {
            for (let a of this.pa) a();
            this.pa.length = 0;
            super.j()
        }
    };
    var c2 = class extends b2 {};

    function d2(a, b, c, d, e = null) {
        return new e2(a, b, c, d, e)
    }
    var e2 = class extends c2 {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.Ya = c;
            this.Va = d;
            this.P = e;
            this.ea = HA();
            this.B = () => {};
            gk(this.g, "load", this.B)
        }
        j() {
            hk(this.g, "load", this.B);
            super.j()
        }
        Z(a) {
            a["adsense-labs"] = b => {
                if (b = ss(b).settings)
                    if (b = zg(Ek, JSON.parse(b)), Lf(b, 1)) {
                        var c = b.aa;
                        if (Ue(b, c, c[t] | 0, Dk, 4, 3).length > 0) {
                            var d = Ve(b, Dk, 4, w(mc)),
                                e = d;
                            c = this.ea;
                            let h = new Po;
                            for (var f of e) switch (f.getVersion()) {
                                case 1:
                                    rf(h, 1, !0);
                                    break;
                                case 2:
                                    rf(h, 2, !0)
                            }
                            f = new Qo;
                            f = z(f, 1, Ro, h);
                            WA(c, f);
                            f = d;
                            c = this.P;
                            d = this.Va;
                            if (!Mz(Hz(),
                                    37, !1)) {
                                if (c)
                                    for (var g of f) switch (g.getVersion()) {
                                        case 1:
                                            d.set("__gads", g, c);
                                            break;
                                        case 2:
                                            d.set("__gpi", g, c)
                                    }
                                Nz(Hz(), 37, !0)
                            }
                            xe(b, 4)
                        }
                        if (g = x(b, Dk, 5)) f = this.Va, Mz(Hz(), 40, !1) || (f.set("__eoi", g), Nz(Hz(), 40, !0));
                        xe(b, 5);
                        g = this.l;
                        f = C(b, 1) || "";
                        c = this.Ya;
                        if (du(sT({
                                win: g,
                                Ya: c
                            }))) {
                            c = $Z(g, c);
                            b !== null && (c[f] = $d(b));
                            try {
                                g.localStorage.setItem("google_adsense_settings", JSON.stringify(c))
                            } catch (h) {}
                        }
                    }
            }
        }
    };
    var f2 = Y(function(a, b, c) {
        var d = a.ia,
            e = a.Ea,
            f = a.P;
        a = a.Va;
        b && e(d2(b, d, c.OSCLM.UWEfJ, a, f));
        return {}
    }, {
        id: 1424,
        H: {}
    });
    var g2 = Y(function(a, b, c, d) {
        return {
            Ea: e => {
                e && d.push(() => {
                    e.dispose()
                })
            },
            Ta: b && (!nY(c) || oY(c))
        }
    }, {
        id: 1425,
        H: {
            Ea: void 0,
            Ta: void 0
        }
    });
    var h2 = Y(function(a, b, c) {
        W0(b, a.P, a.ia.contentWindow, c, a.Va);
        return {}
    }, {
        id: 1429,
        H: {}
    });

    function i2(a) {
        var b = a.J.getBoundingClientRect(),
            c = b.top + b.height < 0;
        return !(b.top > a.g.innerHeight) && !c
    }
    var j2 = class extends Gs {
        constructor(a, b, c) {
            super();
            this.g = a;
            this.C = b;
            this.J = c;
            this.D = 0;
            this.B = i2(this);
            var d = yi(this.G, this);
            this.l = xA(433, () => {
                Kl.requestAnimationFrame ? Kl.requestAnimationFrame(d) : d()
            });
            gk(this.g, "scroll", this.l, dk)
        }
        G() {
            var a = i2(this);
            if (a && !this.B) {
                var b = {
                    rr: "vis-bcr"
                };
                let c = this.C.contentWindow;
                c && (VV(c, "ig", b, "*", 2), ++this.D >= 10 && this.dispose())
            }
            this.B = a
        }
        dispose() {
            this.l && hk(this.g, "scroll", this.l, dk)
        }
    };
    var k2 = Y(function(a, b, c) {
        var d = a.ia,
            e = a.Ta;
        a = a.Ea;
        b && e && a(b.IntersectionObserver ? null : new j2(b, d, c));
        return {}
    }, {
        id: 1427,
        H: {}
    });

    function l2(a, b) {
        var c = a.pubWin,
            d = a.I.google_ad_client,
            e = Pz(),
            f = null,
            g = SV(c, "pvt", (h, k) => {
                v(h.token) && k.source === b.contentWindow && (f = h.token, g(), e[d] = e[d] || [], e[d].push(f), e[d].length > 100 && e[d].shift())
            });
        a.Ja.push(g);
        return () => {
            f && Array.isArray(e[d]) && (jb(e[d], f), e[d].length || delete e[d], f = null)
        }
    };
    var m2 = Y(function(a, b) {
        return {
            Ue: l2(b, a.ia)
        }
    }, {
        id: 1430,
        H: {
            Ue: void 0
        }
    });
    var n2 = class extends J {},
        o2 = yh(n2);
    var r2 = class extends c2 {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.da = c;
            this.I = d;
            this.Mb = e
        }
        Z(a) {
            a["resize-me"] = (b, c) => {
                if (this.Mb && this.l ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/)) {
                    var d = this.I.google_ad_client;
                    if (!v(d)) throw new qA(`Invalid property code ${d}`);
                    c = this.Mb;
                    b = new n2;
                    b = Jf(b, 2, d);
                    p2(c, b)
                } else {
                    this.Mb && (d = ss(b), d.r_affa && d.r_affa !== "" && (d = o2(d.r_affa), q2(this.Mb, d)));
                    b = ss(b);
                    var e = b.r_chk;
                    if (e == null || e === "") {
                        d = ll(b.r_nw);
                        var f = ll(b.r_nh),
                            g = ll(b.r_no);
                        g != null || d !== 0 && f !== 0 || (g = 0);
                        var h =
                            b.r_str;
                        h = h ? h : null; {
                            var k = /^true$/.test(b.r_ao),
                                l = /^true$/.test(b.r_ifr),
                                m = /^true$/.test(b.r_cab);
                            let q = window;
                            if (q)
                                if (h === "no_rsz") b.err = "7", d = !0;
                                else {
                                    var n = new c0(this.g);
                                    if (n.g) {
                                        var p = n.getWidth();
                                        p != null && (b.w = p);
                                        p = n.getHeight();
                                        p != null && (b.h = p);
                                        d0(n, h, f, m) ? (n = this.da, e = X_(new g0(q, n, [this.g], {
                                                width: d,
                                                height: f,
                                                opacity: g,
                                                check: e,
                                                fi: h,
                                                Pe: k,
                                                Nf: l,
                                                ze: m
                                            }, null, null, !0)), b.r_cui && /^true$/.test(b.r_cui.toString()) && L(n, {
                                                height: `${f===null?0:f-48}px`,
                                                top: "24px"
                                            }), d != null && (b.nw = d), f != null && (b.nh = f), b.rsz =
                                            e.toString(), b.abl = K_(e), b.frsz = (h === "force").toString(), b.err = "0", d = !0) : (b.err = "1", d = !1)
                                    } else b.err = "3", d = !1
                                }
                            else b.err = "2", d = !1
                        }
                        UV(c.source, "sth", {
                            msg_type: "resize-result",
                            r_str: h,
                            r_status: d
                        }, "*");
                        this.g.dataset.googleQueryId || this.g.setAttribute("data-google-query-id", b.qid)
                    }
                }
            }
        }
    };
    var s2 = Y(function(a, b, c, d) {
        var e = a.ia,
            f = a.Ta,
            g = a.Ea;
        a = a.Mb;
        b && f && !c.no_resize && g(new r2(b, e, d, c, a));
        return {}
    }, {
        id: 1426,
        H: {}
    });

    function t2(a) {
        return b => !!(b.la() & a)
    }
    var u2 = class extends PZ {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.A = c;
            this.l = d
        }
        la() {
            return this.A
        }
        mh() {
            return this.l
        }
        j(a, b, c) {
            c.style.height = `${this.height}px`;
            b.rpe = !0
        }
    };
    const v2 = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        w2 = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        x2 = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function y2(a) {
        var b = 0;
        a.ub && b++;
        a.mb && b++;
        a.nb && b++;
        if (b < 3) return {
            ac: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.ub.split(",");
        var c = a.nb.split(",");
        a = a.mb.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            ac: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (b.length > 2) return {
            ac: `The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        var d = [],
            e = [];
        for (let g = 0; g < b.length; g++) {
            var f =
                Number(c[g]);
            if (Number.isNaN(f) || f === 0) return {
                ac: `Wrong value '${c[g]}' for data-matched-content-rows-num.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || f === 0) return {
                ac: `Wrong value '${a[g]}' for data-matched-content-columns-num.`
            };
            e.push(f)
        }
        return {
            nb: d,
            mb: e,
            nj: b
        }
    }

    function z2(a) {
        return a >= 1200 ? {
            width: 1200,
            height: 600
        } : a >= 850 ? {
            width: a,
            height: Math.floor(a * .5)
        } : a >= 550 ? {
            width: a,
            height: Math.floor(a * .6)
        } : a >= 468 ? {
            width: a,
            height: Math.floor(a * .7)
        } : {
            width: a,
            height: Math.floor(a * 3.44)
        }
    }

    function A2(a, b) {
        return a * v2[b] + w2[b]
    }

    function B2(a, b, c, d) {
        b = Math.floor(A2((a - 8 * b - 8) / b, d) * c + 8 * c + 8);
        return a > 1500 ? {
            width: 0,
            height: 0,
            mn: `Calculated slot width is too large: ${a}`
        } : b > 1500 ? {
            width: 0,
            height: 0,
            mn: `Calculated slot height is too large: ${b}`
        } : {
            width: a,
            height: b
        }
    }

    function C2(a, b) {
        var c = a - 8 - 8;
        --b;
        return {
            width: a,
            height: Math.floor(c / 1.91 + 70) + Math.floor(A2(c, "mobile_banner_image_sidebyside") * b + 8 * b + 8)
        }
    };
    const D2 = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var E2 = class extends PZ {
        constructor(a, b) {
            super(a, b)
        }
        g(a) {
            return Math.min(1200, Math.max(this.na, Math.round(a)))
        }
    };

    function F2(a, b) {
        G2(a, b);
        if (b.google_content_recommendation_ui_type === "pedestal" && !U(Ju)) return new NZ(9, new E2(a, Math.floor(a * 2.189)));
        if (U(Mu)) {
            var c = Vk(),
                d = V(Nu),
                e = V(Lu),
                f = V(Ku);
            a < 468 ? c ? (a = C2(a, d), a = {
                za: a.width,
                ya: a.height,
                mb: 1,
                nb: d,
                ub: "mobile_banner_image_sidebyside"
            }) : (a = B2(a, 1, d, "image_sidebyside"), a = {
                za: a.width,
                ya: a.height,
                mb: 1,
                nb: d,
                ub: "image_sidebyside"
            }) : (a = z2(a), e === 1 && (a.height = Math.floor(a.height * .5)), a = {
                za: a.width,
                ya: a.height,
                mb: f,
                nb: e,
                ub: "image_stacked"
            })
        } else U(Ju) ? (d = z2(a), e = 4, f = 2,
            a < 468 && (e = 1, f = 6, d = {
                width: a,
                height: Math.floor(A2(a, "image_stacked") * f + 8 * f + 8)
            }), a = {
                za: d.width,
                ya: d.height,
                mb: e,
                nb: f,
                ub: "image_stacked"
            }) : (d = Vk(), a < 468 ? d ? (a = C2(a, 12), a = {
            za: a.width,
            ya: a.height,
            mb: 1,
            nb: 12,
            ub: "mobile_banner_image_sidebyside"
        }) : (a = z2(a), a = {
            za: a.width,
            ya: a.height,
            mb: 1,
            nb: 13,
            ub: "image_sidebyside"
        }) : (a = z2(a), a = {
            za: a.width,
            ya: a.height,
            mb: 4,
            nb: 2,
            ub: "image_stacked"
        }));
        H2(b, a);
        return new NZ(9, new E2(a.za, a.ya))
    }

    function I2(a, b) {
        G2(a, b); {
            let f = y2({
                nb: b.google_content_recommendation_rows_num,
                mb: b.google_content_recommendation_columns_num,
                ub: b.google_content_recommendation_ui_type
            });
            if (f.ac) a = {
                za: 0,
                ya: 0,
                mb: 0,
                nb: 0,
                ub: "image_stacked",
                ac: f.ac
            };
            else {
                var c = f.nj.length === 2 && a >= 468 ? 1 : 0;
                var d = f.nj[c];
                d = d.indexOf("pub_control_") === 0 ? d : "pub_control_" + d;
                var e = x2[d];
                let g = f.mb[c];
                for (; a / g < e && g > 1;) g--;
                e = g;
                c = f.nb[c];
                a = B2(a, e, c, d);
                a = {
                    za: a.width,
                    ya: a.height,
                    mb: e,
                    nb: c,
                    ub: d
                }
            }
        }
        if (a.ac) throw new qA(a.ac);
        H2(b, a);
        return new NZ(9,
            new E2(a.za, a.ya))
    }

    function G2(a, b) {
        if (a <= 0) throw new qA(`Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`);
    }

    function H2(a, b) {
        a.google_content_recommendation_ui_type = b.ub;
        a.google_content_recommendation_columns_num = b.mb;
        a.google_content_recommendation_rows_num = b.nb
    };
    var J2 = class extends PZ {
        constructor(a, b) {
            super(a, b)
        }
        g() {
            return this.na
        }
        j(a, b, c) {
            DR(a, c);
            c.style.height = `${this.height}px`;
            b.rpe = !0
        }
    };
    var K2 = [{
            na: 970,
            height: 90,
            la: 2
        }, {
            na: 728,
            height: 90,
            la: 2
        }, {
            na: 468,
            height: 60,
            la: 2
        }, {
            na: 336,
            height: 280,
            la: 1
        }, {
            na: 320,
            height: 100,
            la: 2
        }, {
            na: 320,
            height: 50,
            la: 2
        }, {
            na: 300,
            height: 600,
            la: 4
        }, {
            na: 300,
            height: 250,
            la: 1
        }, {
            na: 250,
            height: 250,
            la: 1
        }, {
            na: 234,
            height: 60,
            la: 2
        }, {
            na: 200,
            height: 200,
            la: 1
        }, {
            na: 180,
            height: 150,
            la: 1
        }, {
            na: 160,
            height: 600,
            la: 4
        }, {
            na: 125,
            height: 125,
            la: 1
        }, {
            na: 120,
            height: 600,
            la: 4
        }, {
            na: 120,
            height: 240,
            la: 4
        }, {
            na: 120,
            height: 120,
            la: 1,
            mh: !0
        }].map(a => new u2(a.na, a.height, a.la, a.mh ? ? !1)),
        L2 = [6, 12, 3, 0, 7, 14, 1, 8,
            10, 4, 15, 2, 11, 5, 13, 9, 16
        ].map(a => K2[a]);
    const M2 = 2 / 3;

    function N2(a) {
        return b => b.na <= a
    }

    function O2(a) {
        return b => b.height <= a
    }

    function P2(a, b) {
        return b.jg && b.kh ? Math.max(250, is(a) * M2) : 250
    }

    function Q2(a, b, c) {
        var d = c.ka && UI(b, a),
            e = P2(a, {
                jg: c.jg,
                kh: c.kh
            });
        return f => !(d && f.height >= e)
    };

    function R2(a) {
        return b => {
            for (let c = a.length - 1; c >= 0; --c)
                if (!a[c](b)) return !1;
            return !0
        }
    }

    function S2(a, b) {
        var c = L2.length,
            d = null;
        for (let e = 0; e < c; ++e) {
            let f = L2[e];
            if (a(f)) {
                if (b == null || b(f)) return f;
                d === null && (d = f)
            }
        }
        return d
    };

    function T2(a, b, c, d, e) {
        e.google_full_width_responsive === "false" ? c = {
            ib: a,
            Ca: 1
        } : b === "autorelaxed" && e.google_full_width_responsive || U2(b) || e.google_ad_resize ? (b = xR(a, c, d, e), c = b !== !0 ? {
            ib: a,
            Ca: b
        } : {
            ib: hs(c) || a,
            Ca: !0
        }) : c = {
            ib: a,
            Ca: 2
        };
        var {
            ib: f,
            Ca: g
        } = c;
        return g !== !0 ? {
            ib: a,
            Ca: g
        } : d.parentElement ? {
            ib: f,
            Ca: g
        } : {
            ib: a,
            Ca: g
        }
    }

    function V2(a, b, c, d, e) {
        var {
            ib: f,
            Ca: g
        } = wA(247, () => T2(a, b, c, d, e)), h = g === !0, k = ml(d.style.width), l = ml(d.style.height), {
            Xb: m,
            Cb: n,
            la: p,
            mj: q
        } = W2(f, b, c, d, e, h);
        h = X2(b, p);
        var u, A = (u = RI(d, c, "marginLeft")) ? `${u}px` : "",
            D = (u = RI(d, c, "marginRight")) ? `${u}px` : "";
        u = WI(d, c) || "";
        return new NZ(h, m, p, null, q, g, n, A, D, l, k, u)
    }

    function U2(a) {
        return a === "auto" || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
    }

    function W2(a, b, c, d, e, f) {
        b = Y2(c, a, b);
        var g = hs(c) < 488,
            h = g ? QI(d, c) : void 0,
            k = [N2(a), t2(b)];
        U(fv) || k.push(Q2(c, d, {
            ka: g,
            jg: !(!h || !UI(d, c)),
            kh: Ur(c) === 0
        }));
        e.google_max_responsive_height != null && k.push(O2(e.google_max_responsive_height));
        g = [p => !p.mh()];
        if (h) {
            let p = VI(c, d);
            g.push(O2(p))
        }
        var l = S2(R2(k), R2(g));
        if (!l) throw new qA(`No slot size for availableWidth=${a}`);
        var {
            Xb: m,
            Cb: n
        } = wA(248, () => {
            var p;
            a: if (f) {
                if (e.gfwrnh && (p = ml(e.gfwrnh))) {
                    p = {
                        Xb: new J2(a, p),
                        Cb: !0
                    };
                    break a
                }
                if (e.google_resizing_allowed || e.google_full_width_responsive ===
                    "true") p = Infinity;
                else {
                    p = d;
                    let u = Infinity;
                    do {
                        var q = RI(p, c, "height");
                        q && (u = Math.min(u, q));
                        (q = RI(p, c, "maxHeight")) && (u = Math.min(u, q))
                    } while (p.parentElement && (p = p.parentElement) && p.tagName !== "HTML");
                    p = u
                }!(U(Zu) && p <= a * 2) && (p = Math.min(a, p), p < a * .5 || p < 100) && (p = a);
                p = {
                    Xb: new J2(a, Math.floor(p)),
                    Cb: p < a ? 102 : !0
                }
            } else p = {
                Xb: l,
                Cb: 100
            };
            return p
        });
        return e.google_ad_layout === "in-article" ? {
            Xb: Z2(a, c, d, m, e),
            Cb: !1,
            la: b,
            mj: h
        } : {
            Xb: m,
            Cb: n,
            la: b,
            mj: h
        }
    }

    function X2(a, b) {
        if (a === "auto") return 1;
        switch (b) {
            case 2:
                return 2;
            case 1:
                return 3;
            case 4:
                return 4;
            case 3:
                return 5;
            case 6:
                return 6;
            case 5:
                return 7;
            case 7:
                return 8;
            default:
                throw Error("bad mask");
        }
    }

    function Y2(a, b, c) {
        if (c === "auto") c = Math.min(1200, hs(a)), b = b / c <= .25 ? 4 : 3;
        else {
            b = 0;
            for (let d in sR) c.indexOf(d) !== -1 && (b |= sR[d])
        }
        return b
    }

    function Z2(a, b, c, d, e) {
        var f = e.google_ad_height || RI(c, b, "height");
        b = TZ(a, b, c, f, e).size();
        return b.na * b.height > a * d.height ? new u2(b.na, b.height, 1) : d
    };

    function $2(a, b, c, d, e) {
        var f;
        (f = hs(b)) ? hs(b) < 488 ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, DR(b, c), f = {
            ib: f,
            Ca: !0
        }) : f = {
            ib: a,
            Ca: 5
        } : f = {
            ib: a,
            Ca: 4
        }: f = {
            ib: a,
            Ca: 10
        };
        var {
            ib: g,
            Ca: h
        } = f;
        if (h !== !0 || a === g) return new NZ(12, new PZ(a, d), null, null, !0, h, 100);
        var {
            Xb: k,
            Cb: l,
            la: m
        } = W2(g, "auto", b, c, e, !0);
        return new NZ(1, k, m, 2, !0, h, l)
    };

    function a3(a) {
        var b = a.google_ad_format;
        if (b === "autorelaxed") {
            a: {
                if (a.google_content_recommendation_ui_type !== "pedestal")
                    for (let c of D2)
                        if (a[c] != null) {
                            a = !0;
                            break a
                        }
                a = !1
            }
            return a ? 9 : 5
        }
        if (U2(b)) return 1;
        if (b === "link") return 4;
        if (b === "fluid") return a.google_ad_layout === "in-article" ? (b3(a), 1) : 8;
        if (a.google_reactive_ad_format === 27) return b3(a), 1
    }

    function c3(a, b, c, d, e = !1) {
        var f = b.offsetWidth || (c.google_ad_resize || e) && RI(b, d, "width") || c.google_ad_width || 0;
        a === 4 && (c.google_ad_format = "auto", a = 1);
        e = (e = d3(a, f, b, c, d)) ? e : V2(f, c.google_ad_format, d, b, c);
        e.size().j(d, c, b);
        e.la != null && (c.google_responsive_formats = e.la);
        e.O != null && (c.google_safe_for_responsive_override = e.O);
        e.Ca != null && (e.Ca === !0 ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = e.Ca));
        e.Cb != null && e.Cb !== !0 && (c.gfwrnher = e.Cb);
        d = e.l || c.google_ad_width;
        d != null && (c.google_resizing_width = d);
        d = e.j || c.google_ad_height;
        d != null && (c.google_resizing_height = d);
        d = e.size().g(f);
        var g = e.size().height;
        c.google_ad_width = d;
        c.google_ad_height = g;
        var h = e.size();
        c.google_ad_format = `${h.g(f)}x${h.height}`;
        c.google_responsive_auto_format = e.D;
        e.g != null && (c.armr = e.g);
        c.google_ad_resizable = !0;
        c.google_override_format = 1;
        c.google_loader_features_used = 128;
        e.Ca === !0 && (c.gfwrnh = `${e.size().height}px`);
        e.A != null && (c.gfwroml = e.A);
        e.B != null && (c.gfwromr = e.B);
        e.j != null && (c.gfwroh =
            e.j);
        e.l != null && (c.gfwrow = e.l);
        e.C != null && (c.gfwroz = e.C);
        f = Tk(window) || window;
        uX(f.location, "google_responsive_dummy_ad") && (ib([1, 2, 3, 4, 5, 6, 7, 8], e.D) || e.g === 1) && e.g !== 2 && (f = JSON.stringify({
            googMsgType: "adpnt",
            key_value: [{
                key: "qid",
                value: "DUMMY_AD"
            }]
        }), c.dash = `<${MZ}>window.top.postMessage('${f}', '*'); 
          </${MZ}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`);
        a !== 1 && (a = e.size().height, b.style.height = `${a}px`)
    }

    function d3(a, b, c, d, e) {
        var f = d.google_ad_height || RI(c, e, "height") || 0;
        switch (a) {
            case 5:
                let {
                    ib: g,
                    Ca: h
                } = wA(247, () => T2(b, d.google_ad_format, e, c, d));
                h === !0 && b !== g && DR(e, c);
                h === !0 ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                return F2(g, d);
            case 9:
                return U(Ju) ? F2(b, d) : I2(b, d);
            case 8:
                return TZ(b, e, c, f, d);
            case 10:
                return $2(b, e, c, f, d)
        }
    }

    function b3(a) {
        a.google_ad_format = "auto";
        a.armr = 3
    };

    function e3(a, b) {
        a.google_resizing_allowed = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };
    var f3 = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function g3(a, b) {
        if (b == 15) {
            if (a >= 728) return 728;
            if (a >= 468) return 468
        } else if (b == 90) {
            if (a >= 200) return 200;
            if (a >= 180) return 180;
            if (a >= 160) return 160;
            if (a >= 120) return 120
        }
        return null
    };

    function h3(a, b) {
        var c = Tk(b);
        if (c) {
            c = hs(c);
            let d = il(a, b) || {},
                e = d.direction;
            if (d.width === "0px" && d.cssFloat !== "none") return -1;
            if (e === "ltr" && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if (e === "rtl" && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function i3(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            default:
                return b
        }
    }

    function j3(a) {
        if (U(rw) && Number(a.google_ad_intents_in_drawer_format) === 1) switch (Number(a.google_ad_intents_format)) {
            case 4:
                return 22;
            case 5:
                return 25;
            default:
                return 21
        }
        switch (Number(a.google_ad_intents_format)) {
            case 4:
                return 18;
            case 5:
                return 23;
            default:
                return 17
        }
    }

    function k3(a, b) {
        if (a = lr(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else {
            if (b.google_ad_intents_format)
                if (b.google_ad_intent_query) b = j3(b);
                else a: switch (Number(b.google_ad_intents_format)) {
                    case 4:
                        b = 20;
                        break a;
                    case 5:
                        b = 24;
                        break a;
                    default:
                        b = 19
                } else b = 12;
            return b
        }
    };

    function l3(a, b, c) {
        a.dataset.adsbygoogleStatus = "reserved";
        a.className += " adsbygoogle-noablate";
        c.adsbygoogle || (c.adsbygoogle = [], gl(c.document, ni `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`));
        c.adsbygoogle.push({
            element: a,
            params: b,
            ...null
        })
    };

    function m3(a, b) {
        if (!vR(b, a)) return () => {};
        a = n3(b, a);
        if (!a) return () => {};
        var c = Sz();
        b = $i(b);
        var d = {
            Wc: a,
            I: b,
            offsetWidth: a.offsetWidth
        };
        c.push(d);
        return () => jb(c, d)
    }

    function n3(a, b) {
        a = b.document.getElementById(a.google_async_iframe_id);
        if (!a) return null;
        for (a = a.parentElement; a && !ly.test(a.className);) a = a.parentElement;
        return a
    }

    function o3(a, b) {
        for (let c = 0; c < a.childNodes.length; c++) {
            let d = {},
                e = a.childNodes[c];
            tR(e.style, d);
            if (d.google_ad_width == b.google_ad_width && d.google_ad_height == b.google_ad_height) return e
        }
        return null
    }

    function p3(a, b) {
        a.style.display = b ? "inline-block" : "none";
        var c = a.parentElement;
        b ? c.dataset.adStatus = a.dataset.adStatus : (a.dataset.adStatus = c.dataset.adStatus, delete c.dataset.adStatus)
    }

    function q3(a, b) {
        var c = b.innerHeight >= b.innerWidth ? 1 : 2;
        if (a.g != c) {
            a.g = c;
            a = Sz();
            for (let d of a)
                if (d.Wc.offsetWidth != d.offsetWidth || d.I.google_full_width_responsive_allowed) d.offsetWidth = d.Wc.offsetWidth, wA(467, () => {
                    var e = d.Wc,
                        f = d.I,
                        g = o3(e, f);
                    f.google_full_width_responsive_allowed && (e.style.marginLeft = f.gfwroml || "", e.style.marginRight = f.gfwromr || "", e.style.height = f.gfwroh ? `${f.gfwroh}px` : "", e.style.width = f.gfwrow ? `${f.gfwrow}px` : "", e.style.zIndex = f.gfwroz || "", delete f.google_full_width_responsive_allowed);
                    delete f.google_ad_format;
                    delete f.google_ad_width;
                    delete f.google_ad_height;
                    delete f.google_content_recommendation_ui_type;
                    delete f.google_content_recommendation_rows_num;
                    delete f.google_content_recommendation_columns_num;
                    if (e.getAttribute("src")) {
                        var h = e.getAttribute("src") || "",
                            k = Ym(h, "client");
                        k && (f.google_ad_client = i3("google_ad_client", k));
                        (h = Ym(h, "host")) && (f.google_ad_host = i3("google_ad_host", h))
                    }
                    h = !1;
                    for (var l of e.attributes)
                        if (/data-/.test(l.name))
                            if (k = La(l.name.replace("data-matched-content",
                                    "google_content_recommendation").replace("data", "google").replace(/-/g, "_")), (l.name === "data-tag-for-child-directed-treatment" || l.name === "data-tag-for-under-age-of-consent") && l.value === "1") console.warn(`${l.name} is deprecated. Use data-tag-for-age-treatment="1" instead.`), h = !0;
                            else if (!f.hasOwnProperty(k)) {
                        var m = i3(k, l.value);
                        m !== null && (f[k] = m)
                    }
                    h && (f.google_tag_for_age_treatment = 1);
                    f.google_ad_intents_format && !f.google_ad_intent_query && (f.google_reactive_ad_format = 40);
                    if (b.document && b.document.body &&
                        !a3(f) && !f.google_reactive_ad_format && !f.google_ad_intent_query && (k = parseInt(e.style.width, 10), h = h3(e, b), h > 0 && k > h)) {
                        l = parseInt(e.style.height, 10);
                        k = !!f3[k + "x" + l];
                        m = h;
                        if (k) {
                            let n = g3(h, l);
                            if (n) m = n, f.google_ad_format = n + "x" + l + "_0ads_al";
                            else throw new qA("No slot size for availableWidth=" + h);
                        }
                        f.google_ad_resize = !0;
                        f.google_ad_width = m;
                        k || (f.google_ad_format = null, f.google_override_format = !0);
                        h = m;
                        e.style.width = `${h}px`;
                        e3(f, 4)
                    }
                    if (U(Ou) || hs(b) < 488) {
                        h = Tk(b) || b;
                        l = e.offsetWidth || RI(e, b, "width") || f.google_ad_width ||
                            0;
                        k = f.google_ad_client;
                        if (h = uX(h.location, "google_responsive_slot_preview") || XZ(h, k)) b: if (f.google_reactive_ad_format || f.google_ad_resize || a3(f) || uR(e, f)) h = !1;
                            else {
                                for (h = e; h; h = h.parentElement) {
                                    k = il(h, b);
                                    if (!k) {
                                        f.gfwrnwer = 18;
                                        h = !1;
                                        break b
                                    }
                                    if (!ib(["static", "relative"], k.position)) {
                                        f.gfwrnwer = 17;
                                        h = !1;
                                        break b
                                    }
                                }
                                if (!U(gv) && (h = V(Xu), l = wR(b, e, l, h, f), l !== !0)) {
                                    f.gfwrnwer = l;
                                    h = !1;
                                    break b
                                }
                                h = b === b.top ? !0 : !1
                            }
                        h ? (e3(f, 1), l = !0) : l = !1
                    } else l = !1;
                    if (h = a3(f)) c3(h, e, f, b, l);
                    else {
                        if (uR(e, f)) {
                            if (l = il(e, b)) e.style.width = l.width,
                                e.style.height = l.height, tR(l, f);
                            f.google_ad_width || (f.google_ad_width = e.offsetWidth);
                            f.google_ad_height || (f.google_ad_height = e.offsetHeight);
                            f.google_loader_features_used = 256;
                            f.google_responsive_auto_format = k3(b, f)
                        } else tR(e.style, f);
                        b.location && b.location.hash === "#gfwmrp" || f.google_responsive_auto_format === 12 && f.google_full_width_responsive === "true" ? c3(10, e, f, b, !1) : Math.random() < .01 && f.google_responsive_auto_format === 12 && (l = xR(e.offsetWidth || parseInt(e.style.width, 10) || f.google_ad_width, b, e, f), l !==
                            !0 ? (f.efwr = !1, f.gfwrnwer = l) : f.efwr = !0)
                    }
                    l = o3(e, f);
                    !l && g && e.childNodes.length == 1 ? (p3(g, !1), f.google_reactive_ad_format = 16, f.google_ad_section = "responsive_resize", l3(e, f, b)) : l && g && l != g && (p3(g, !1), p3(l, !0))
                })
        }
    }
    var r3 = class extends Gs {
        constructor() {
            super(...arguments);
            this.g = null
        }
        init(a) {
            var b = Hz();
            if (!Mz(b, 27, !1)) {
                Nz(b, 27, !0);
                this.g = a.innerHeight >= a.innerWidth ? 1 : 2;
                var c = () => {
                    q3(this, a)
                };
                gk(a, "resize", c);
                Is(this, () => {
                    hk(a, "resize", c)
                })
            }
        }
    };
    var s3 = Y(function(a, b, c, d) {
        b && (d.push(m3(b, c)), ar(r3).init(b));
        return {}
    }, {
        id: 1417,
        H: {}
    });

    function t3(a) {
        a.C = a.D;
        a.G.style.transition = "height 500ms";
        a.B.style.transition = "height 500ms";
        a.g.style.transition = "height 500ms";
        u3(a)
    }

    function v3(a, b) {
        UV(a.g.contentWindow, "sth", {
            msg_type: "expand-on-scroll-result",
            eos_success: !0,
            eos_amount: b
        }, "*")
    }

    function u3(a) {
        var b = `rect(0px, ${a.g.width}px, ${a.C}px, 0px)`;
        a.g.style.clip = b;
        a.B.style.clip = b;
        a.g.setAttribute("height", a.C.toString());
        a.g.style.height = `${a.C}px`;
        a.B.setAttribute("height", a.C.toString());
        a.B.style.height = `${a.C}px`;
        a.G.style.height = `${a.C}px`
    }

    function w3(a, b) {
        b = ll(b.r_nh);
        a.D = b == null ? 0 : b;
        if (a.D <= 0) return "1";
        a.T = Zj(a.G).y;
        a.J = qs(a.l);
        if (a.T + a.C < a.J) return "2";
        if (a.T > ls(a.l) - a.l.innerHeight) return "3";
        b = a.J;
        a.g.setAttribute("height", a.D.toString());
        a.g.style.height = `${a.D}px`;
        a.B.style.overflow = "hidden";
        a.G.style.position = "relative";
        a.G.style.transition = "height 100ms";
        a.B.style.transition = "height 100ms";
        a.g.style.transition = "height 100ms";
        b = Math.min(b + a.l.innerHeight - a.T, a.C);
        Qj(a.B, {
            position: "relative",
            top: "auto",
            bottom: "auto"
        });
        b = `rect(0px, ${a.g.width}px, ${b}px, 0px)`;
        Qj(a.g, {
            clip: b
        });
        Qj(a.B, {
            clip: b
        });
        return "0"
    }
    var x3 = class extends c2 {
        constructor(a, b) {
            super(a.K, b);
            this.Le = this.oi = !1;
            this.Aa = this.J = this.D = 0;
            this.B = a.da;
            this.G = this.B.parentElement && this.B.parentElement.classList.contains("adsbygoogle") ? this.B.parentElement : this.B;
            this.C = parseInt(this.B.style.height, 10);
            this.pk = this.C / 5;
            this.T = Zj(this.G).y;
            this.mk = zi(xA(651, () => {
                this.T = Zj(this.G).y;
                var c = this.J;
                this.J = qs(this.l);
                this.C < this.D ? (c = this.J - c, c > 0 && (this.Aa += c, this.Aa >= this.pk ? (t3(this), v3(this, this.D)) : (this.C = Math.min(this.D, this.C + c), v3(this,
                    c), u3(this)))) : hk(this.l, "scroll", this.W)
            }), this);
            this.W = () => {
                var c = this.mk;
                Kl.requestAnimationFrame ? Kl.requestAnimationFrame(c) : c()
            }
        }
        Z(a) {
            a["expand-on-scroll"] = (b, c) => {
                b = ss(b);
                this.oi || (this.oi = !0, b = w3(this, b), b === "0" && gk(this.l, "scroll", this.W, dk), UV(c.target, "sth", {
                    msg_type: "expand-on-scroll-result",
                    eos_success: b === "0"
                }, "*"))
            };
            a["expand-on-scroll-force-expand"] = () => {
                this.Le || (this.Le = !0, t3(this), hk(this.l, "scroll", this.W))
            }
        }
        j() {
            this.W && hk(this.l, "scroll", this.W, dk);
            super.j()
        }
    };
    var y3 = Y(function(a, b) {
        var c = a.ia,
            d = a.Ta;
        a = a.Ea;
        b.K && d && a(new x3(b, c));
        return {}
    }, {
        id: 1428,
        H: {}
    });

    function p2(a, b) {
        var c = a.g.getBoundingClientRect();
        if (z3(c)) {
            var d = document.createElement("div");
            d.dataset.googleAdEfd = "true";
            V(Hw) > 0 && (d.className = "google-aiuf");
            L(d, {
                width: `${c.width}px`,
                display: "flex",
                "flex-wrap": "wrap",
                "justify-content": "center",
                "align-items": "center",
                "align-content": "center",
                gap: "10px",
                "font-size": "initial"
            });
            c.bottom < 0 || c.top >= window.innerHeight ? (L(d, {
                height: "auto",
                "max-height": W(a.g.offsetHeight)
            }), L(a.g.parentElement, {
                height: "auto"
            }), L(a.g.parentElement.parentElement, {
                height: "auto",
                "background-color": "transparent"
            })) : L(d, {
                height: `${c.height}px`
            });
            c = a.g.parentElement;
            c.replaceChild(d, a.g);
            (c.parentElement ? .classList.contains("adsbygoogle") ? c.parentElement : c).dataset.adStatus = "unfill-optimized";
            fI(a.pubWin, a.l, a.I, b, a.P, a.sb, d)
        } else a = a.g.closest("INS"), hB(a) && T_(a, 0, 0)
    }

    function q2(a, b) {
        fI(a.pubWin, a.l, a.I, b, a.P, a.sb, a.g, !0)
    }

    function A3(a, b) {
        a.g.parentElement && (b = ss(b), b.r_affa && b.r_affa !== "" && (b = o2(b.r_affa), gx(Te(b, hx, 1)).filter(c => C(c, 12)).length >= V(vw) ? p2(a, b) : q2(a, b)))
    }

    function z3(a) {
        if (V(Hw) <= 0) return !0;
        var b = V(Hw) * window.innerHeight,
            c = document.getElementsByClassName("google-aiuf");
        if (c.length === 0) return !0;
        for (let d of c)
            if (c = d.getBoundingClientRect(), a.bottom <= c.top && c.top - a.bottom <= b || a.top >= c.bottom && a.top - c.bottom <= b) return !1;
        return !0
    }
    var B3 = class extends c2 {
        constructor(a, b, c, d, e, f, g) {
            super(a, b);
            this.I = c;
            this.pubWin = d;
            this.Ja = e;
            this.P = f;
            this.sb = g
        }
        Z(a) {
            a["unfill-fb"] = b => {
                A3(this, b)
            }
        }
    };
    var C3 = Y(function(a, b, c, d, e, f) {
        var g = a.ia,
            h = a.Ta,
            k = a.Ea;
        a = a.P;
        if (c && h) {
            if (!(h = U(fw))) try {
                h = !!c ? .location ? .hash ? .match(/\bgoog_uffb/)
            } catch (l) {
                h = !1
            }(b = h ? new B3(c, g, d, b, e, a, f.SLqBY ? ? "") : null) && k(b);
            return {
                Mb: b
            }
        }
        return {
            Mb: null
        }
    }, {
        id: 1422,
        H: {
            Mb: void 0
        }
    });

    function D3(a, b) {
        return new IntersectionObserver(b, a)
    }

    function E3(a, b, c) {
        gk(a, b, c);
        return () => hk(a, b, c)
    }
    let F3 = null;

    function G3() {
        F3 = um()
    }

    function H3(a, b) {
        return b ? F3 === null ? (gk(a, "mousemove", G3, {
            passive: !0
        }), gk(a, "scroll", G3, {
            passive: !0
        }), G3(), !1) : um() - F3 >= b * 1E3 : !1
    }

    function I3({
        win: a,
        element: b,
        An: c,
        vn: d,
        un: e = 0,
        Jb: f,
        Al: g,
        options: h = {},
        qm: k = !0,
        gp: l = D3
    }) {
        var m, n = !1,
            p = !1,
            q = [],
            u = l(h, (A, D) => {
                try {
                    let K = () => {
                        q.length || (d && (q.push(E3(b, "mouseenter", () => {
                            n = !0;
                            K()
                        })), q.push(E3(b, "mouseleave", () => {
                            n = !1;
                            K()
                        }))), q.push(E3(a.document, "visibilitychange", () => K())));
                        var I = H3(a, e),
                            G = CX(a.document);
                        if (p && !n && !I && !G) m = m || a.setTimeout(() => {
                            H3(a, e) ? K() : (f(), D.disconnect())
                        }, c * 1E3);
                        else if (k || n || I || G) a.clearTimeout(m), m = void 0
                    };
                    ({
                        isIntersecting: p
                    } = A[A.length - 1]);
                    K()
                } catch (K) {
                    g && g(K)
                }
            });
        u.observe(b);
        return () => {
            u.disconnect();
            for (let A of q) A();
            m != null && a.clearTimeout(m)
        }
    };

    function J3(a, b, c, d, e) {
        return new K3(a, b, c, d, e)
    }

    function L3(a, b, c) {
        var d = a.g,
            e = a.D;
        if (e != null && d != null && ps(c, d.contentWindow) && (b = b.config, v(b))) {
            try {
                var f = JSON.parse(b);
                if (!Array.isArray(f)) return;
                a.B = zg(Mk, f)
            } catch (g) {
                return
            }
            a.dispose();
            f = gf(a.B, 1);
            f <= 0 || (a.C = I3({
                win: a.l,
                element: e,
                An: f - .2,
                vn: !Vk(),
                un: gf(a.B, 3),
                Jb: () => void M3(a, e),
                Al: g => hr.Da(1223, g, void 0, void 0),
                options: {
                    threshold: jf(a.B, 2, 1)
                },
                qm: !0
            }))
        }
    }

    function M3(a, b) {
        a.G();
        setTimeout(hr.wc(1224, () => {
            var c = Number(a.I.rc);
            a.I.rc = c ? c + 1 : 1;
            c = b.parentElement || null;
            c && ly.test(c.className) || (c = yj(document, "INS"), c.className = "adsbygoogle", b.parentNode && b.parentNode.insertBefore(c, b.nextSibling));
            U(Ov) ? (N3(a, c, b), a.I.no_resize = !0, gt(wW(c), "filled", () => {
                zj(b)
            })) : zj(b);
            l3(c, a.I, a.l)
        }), 200)
    }

    function N3(a, b, c) {
        a.l.getComputedStyle(b).position === "static" && (b.style.position = "relative");
        c.style.position = "absolute";
        c.style.top = "0";
        c.style.left = "0";
        delete b.dataset.adsbygoogleStatus;
        delete b.dataset.adStatus;
        b.classList.remove("adsbygoogle-noablate")
    }
    var K3 = class extends c2 {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.I = c;
            this.D = d;
            this.G = e;
            this.B = this.C = null;
            (b = (b = b.contentWindow) && b.parent) && a !== b && this.pa.push(SV(b, "sth", this.Gb, this.ri))
        }
        Z(a) {
            a.av_ref = (b, c) => {
                L3(this, b, c)
            }
        }
        j() {
            super.j();
            this.D = null;
            this.C && this.C()
        }
    };
    var O3 = Y(function(a, b, c, d, e) {
        var f = a.ia,
            g = a.Ta,
            h = a.Ea,
            k = a.Ue;
        b && g && b.IntersectionObserver && h(J3(b, f, c, d, xA(1225, () => {
            k();
            for (let l of e) l();
            e.length = 0
        })));
        return {}
    }, {
        id: 1421,
        H: {}
    });
    var P3 = class extends S0 {
        constructor(a, b, c, d, e, f) {
            super(a);
            a = X(Z(this, g2, {
                ia: d
            }, b.K, b.I, b.Ja), e);
            e = X(Z(this, m2, {
                ia: d
            }, b), a.finished);
            var g = X(Z(this, h2, {
                ia: d,
                P: c,
                Va: f
            }, b.pubWin, b.Ja), e.finished);
            g = X(Z(this, C3, {
                ia: d,
                Ta: a.Ta,
                Ea: a.Ea,
                P: c
            }, b.pubWin, b.K, b.I, b.Ja, b.pageState), g.finished);
            g = X(Z(this, s2, {
                ia: d,
                Ta: a.Ta,
                Ea: a.Ea,
                Mb: g.Mb
            }, b.K, b.I, b.da), g.finished);
            g = X(Z(this, y3, {
                ia: d,
                Ta: a.Ta,
                Ea: a.Ea
            }, b), g.finished);
            g = X(Z(this, k2, {
                ia: d,
                Ta: a.Ta,
                Ea: a.Ea
            }, b.K, b.da), g.finished);
            e = X(Z(this, O3, {
                    ia: d,
                    Ta: a.Ta,
                    Ea: a.Ea,
                    Ue: e.Ue
                },
                b.K, b.I, b.da, b.Ja), g.finished);
            c = X(Z(this, f2, {
                ia: d,
                Ea: a.Ea,
                P: c,
                Va: f
            }, b.K, b.pageState), e.finished);
            c = X(Z(this, s3, {
                ia: d
            }, b.K, b.I, b.Ja), c.finished);
            this.g = X(Z(this, R1, {
                ia: d
            }, b.K, b.da, b.Ja), c.finished).finished
        }
    };
    var Q3 = Y(function(a, b, c) {
        var d = lr(b);
        if (d)
            if (d.container === "AMP-STICKY-AD") {
                let e = f => {
                    f.data === "fill_sticky" && d.renderStart ? .()
                };
                gk(b, "message", xA(616, e));
                c.push(() => {
                    hk(b, "message", e)
                })
            } else d.renderStart ? .();
        return {}
    }, {
        id: 1419,
        H: {}
    });
    var R3 = Y(function(a) {
        var b = a.ia;
        a = a.Id;
        var c = () => {
            b && b.setAttribute("data-load-complete", "true")
        };
        a ? a.then(c) : gk(b, "load", c);
        return {}
    }, {
        id: 1416,
        H: {}
    });
    var S3 = class extends Gs {
        constructor(a, b) {
            super();
            this.value = a;
            Is(this, b)
        }
    };

    function T3(a, b) {
        var c = U3(a.getBoundingClientRect()),
            d = new O(c),
            e = V3(a, b, f => {
                d.g(U3(f.boundingClientRect))
            });
        return new S3(ct(d), () => void e.disconnect())
    }

    function V3(a, b, c) {
        b = new IntersectionObserver(d => {
            d.filter(e => e.target === a).forEach(c)
        }, {
            root: b
        });
        b.observe(a);
        return b
    }

    function U3(a) {
        return a.height > 0 || a.width > 0
    };
    var W3 = {
        Co: 0,
        Vo: 1,
        Oo: 2,
        0: "INITIAL_RENDER",
        1: "UNRENDER",
        2: "RENDER_BACK"
    };

    function X3(a, b, c) {
        var d = [1, 2],
            e = T3(b, c),
            f = e.value,
            g = new nt;
        gt(f, !0, () => void Y3(a, f, g, d));
        return new S3(kt(g), () => void e.dispose())
    }

    function Y3(a, b, c, d) {
        var e = new SW(a),
            f = new SW(a);
        e.start();
        f.start();
        var g = 0,
            h = k => {
                k = {
                    type: k,
                    zj: ++g,
                    sm: QW(f),
                    rm: QW(e)
                };
                f = new SW(a);
                f.start();
                return k
            };
        d && !d.includes(0) || mt(c, h(0));
        b.listen(k => {
            k = k ? 2 : 1;
            d && !d.includes(k) || mt(c, h(k))
        })
    };

    function Z3(a, b) {
        var c = HA();
        wA(1282, () => void $3(a, b, c))
    }

    function $3(a, b, c) {
        var d = a4(a);
        if (!d) throw Error("No adsbygoogle INS found");
        var e = X3(a.pubWin, b, d);
        e.value.listen(f => {
            b4(f, d, c, () => void e.dispose())
        })
    }

    function a4(a) {
        return (a = a.da.parentElement) && ly.test(a.className) ? a : null
    }

    function b4(a, b, c, d) {
        if (a.zj > 5) d();
        else {
            var e = a.type === 1;
            d = a.type === 2;
            if (!e && !d) throw Error(`Unsupported event type: ${W3[a.type]}`);
            var f = wg(oW());
            f = vf(f, 1, a.sm);
            f = vf(f, 2, a.rm);
            a = vf(f, 3, a.zj);
            f = b.dataset.vignetteLoaded;
            var g = wg(mW());
            g = If(g, 1, b.dataset.adStatus);
            g = If(g, 2, b.dataset.sideRailStatus);
            g = If(g, 3, b.dataset.anchorStatus);
            f = rf(g, 4, f !== void 0 ? f === "true" : void 0);
            b = getComputedStyle(b);
            g = wg(pW());
            g = If(g, 1, b.display);
            g = If(g, 2, b.position);
            g = If(g, 3, b.width);
            b = If(g, 4, b.height);
            b = pe(b);
            b = y(f, 5, b);
            b = pe(b);
            a = y(a, 4, b);
            e = e ? qW() : void 0;
            e = z(a, 5, zn, e);
            d = d ? nW() : void 0;
            d = z(e, 6, zn, d);
            d = yg(wg(pe(d)));
            XA(c, d)
        }
    };
    var c4 = Y(function(a, b) {
        a = a.ia;
        U(Ru) && "IntersectionObserver" in window && Z3(b, a);
        return {}
    }, {
        id: 1420,
        H: {}
    });
    const d4 = g1(function(a) {
        return !a.ra && a.Xa
    }, {
        id: 1460
    });
    var e4 = class extends d1 {
        constructor(a, b, c, d, e, f, g, h, k) {
            super(a);
            this.ea = a;
            this.G = h;
            this.J = new TY;
            this.ra = g.ra;
            this.Xa = g.Xa;
            g = f.rf;
            f = f.Hl;
            ({
                ia: b
            } = Z(this, q1, {
                Ga: this.G.Ga,
                Gl: this.G.ne,
                In: b
            }));
            g = X(X(Z(this, O1, {
                P: e
            }, d.I, d.pubWin, d.pageState), g), f);
            f = Z(this, L1, {
                ia: b
            }, d.I, d.pubWin, d.da);
            X(f, g.finished);
            g = Z(this, R3, {
                ia: b,
                Id: this.G.Id
            });
            X(g, f.finished);
            a = Q0(this, new P3(a, d, e, b, g.finished, k));
            c = Z(this, p1, {
                ia: b,
                Na: c
            }, d.I, d.da);
            X(c, a.g);
            a = Z(this, Q3, {}, d.pubWin, d.Ja);
            X(a, c.finished);
            d = Z(this, c4, {
                ia: b
            }, d);
            X(d,
                a.finished);
            this.J = d.finished
        }
        async g() {
            return e1(this.ea, d4, {
                ra: this.ra,
                Xa: this.Xa
            })
        }
        l() {
            this.J.notify()
        }
    };

    function f4(a, b) {
        b.allow = b.allow && b.allow.length > 0 ? b.allow + ("; " + a) : a
    }

    function g4(a) {
        var b = hl("IFRAME");
        Nk(a, (c, d) => {
            c != null && b.setAttribute(d, c)
        });
        return b
    };
    var h4 = Y(function(a, b) {
        a = a.gd;
        c_("attribution-reporting", b) && f4("attribution-reporting", a);
        c_("run-ad-auction", b) && f4("run-ad-auction", a);
        return {
            ue: a
        }
    }, {
        id: 1380,
        H: {
            ue: void 0
        }
    });
    var i4 = Y(function(a, b, c) {
        a = a.hh;
        var d = c.google_async_iframe_id,
            e = c.google_ad_width,
            f = c.google_ad_height;
        b = pY(c);
        d = {
            id: d,
            name: d,
            style: b ? `width:${e}px !IMPORTANT;height:${f}px !IMPORTANT;` : `left:0;position:absolute;top:0;border:0;width:${e}px;height:${f}px;`
        };
        d.style += "min-height:auto;max-height:none;min-width:auto;max-width:none;";
        rl() && (d.sandbox = pl(["allow-top-navigation", "allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"]).join(" "));
        c.google_video_play_muted === !1 &&
            f4("autoplay", d);
        return {
            gd: d,
            adUrl: a,
            Bd: b
        }
    }, {
        id: 1346,
        H: {
            gd: void 0,
            adUrl: void 0,
            Bd: void 0
        }
    });

    function j4(a, b, c, d, e, f, g) {
        var h = d.K,
            k = d.pubWin;
        return a.google_reactive_ad_format === 9 && Ej(e, null, "fsi_container") ? (e.appendChild(f), Promise.resolve(f)) : lY(b.Kj, 525, l => {
            e.appendChild(f);
            l.createAdSlot(h, a, f, e.parentElement, xg(c), k, g);
            return f
        })
    }
    var k4 = M0(async function(a, b) {
        var c = a.Ug,
            d = a.P;
        if (!a.Bd) return null;
        var e = b.I,
            f = b.ni,
            g = b.da,
            h = b.Oa;
        b = b.Ac;
        var k = f.K;
        f = f.pubWin;
        c.src = a.Wa;
        a = g4(c);
        return j4(e, h, d, {
            K: k,
            pubWin: f
        }, g, a, b)
    }, {
        id: 1396
    });
    var l4 = Y(function(a, b) {
        var c = a.Ug;
        if (a.Bd) return {
            Ie: null
        };
        var d = b.da,
            e = b.Ja;
        b = b.ni.pubWin;
        c.src = KZ(a.Wa);
        a = b === b.top;
        c = g4(c);
        a && e.push(Pr(b, c));
        for (d.style.visibility = "visible"; e = d.firstChild;) d.removeChild(e);
        d.appendChild(c);
        return {
            Ie: c
        }
    }, {
        id: 1397,
        H: {
            Ie: void 0
        }
    });
    var m4 = Y(function(a, b, c, d) {
        if (!b.rpe) return {};
        X_(new g0(c, d, void 0, {
            height: b.google_ad_height,
            fi: "force",
            Pe: !0,
            Uh: !0,
            gg: b.google_ad_client
        }, null, null, !0));
        return {}
    }, {
        id: 1398,
        H: {}
    });
    var n4 = Y(function(a) {
        var b = a.Vm;
        return b ? {
            fg: b
        } : {
            fg: a.Ie
        }
    }, {
        id: 1402,
        H: {
            fg: void 0
        }
    });
    var o4 = Y(function(a, b) {
        a = a.gd;
        var c = b.google_ad_width;
        b = b.google_ad_height;
        c != null && (a.width = String(c));
        b != null && (a.height = String(b));
        a.frameborder = "0";
        a.marginwidth = "0";
        a.marginheight = "0";
        a.vspace = "0";
        a.hspace = "0";
        a.allowtransparency = "true";
        a.scrolling = "no";
        return {
            ue: a
        }
    }, {
        id: 1373,
        H: {
            ue: void 0
        }
    });
    const p4 = g1(function(a) {
        return !a.ra && a.Xa && !a.Ga
    }, {
        id: 1461
    });
    var q4 = class extends d1 {
        constructor(a, b, c, d, e, f, g, h) {
            super(a);
            this.ea = a;
            this.ra = f;
            this.Xa = g;
            this.Ga = h;
            var {
                gd: k,
                adUrl: l,
                Bd: m
            } = Z(this, i4, {
                hh: b,
                P: d
            }, c.pubWin, c.I);
            ({
                ue: a
            } = Z(this, o4, {
                gd: k
            }, c.I));
            ({
                ue: e
            } = Z(this, h4, {
                gd: a
            }, e.document));
            d = P0(this, k4, {
                Ug: e,
                Wa: l,
                Bd: m,
                P: d
            }, {
                I: c.I,
                ni: {
                    pubWin: c.pubWin,
                    K: c.K
                },
                da: c.da,
                Oa: c.Oa,
                Ja: c.Ja,
                Ac: c.Ac
            });
            e = Z(this, l4, {
                Ug: e,
                Wa: l,
                Bd: m
            }, {
                I: c.I,
                ni: {
                    pubWin: c.pubWin,
                    K: c.K
                },
                da: c.da,
                Oa: c.Oa,
                Ja: c.Ja,
                Ac: c.Ac
            });
            d = Z(this, n4, {
                Vm: d.output,
                Ie: e.Ie
            });
            this.G = d.fg;
            c = Z(this, m4, {}, c.I, c.pubWin,
                c.da);
            X(c, d.finished);
            this.rf = c.finished
        }
        async g() {
            return e1(this.ea, p4, {
                Ga: this.Ga,
                ra: this.ra,
                Xa: this.Xa
            })
        }
        l() {
            this.rf.notify();
            KY(this.G, null)
        }
    };
    var r4 = Y(function(a) {
        if (!a.L) return {};
        var b = a.tb.sn;
        if (b) {
            var c = a.L;
            b = di(b);
            c.srcdoc = Vh(b)
        }
        ij(a.L, "allowtransparency", "true");
        ij(a.L, "vspace", "0");
        ij(a.L, "hspace", "0");
        return {}
    }, {
        id: 1455,
        H: {}
    });
    var s4 = Y(function(a) {
        if (!a.L) return {};
        var b = a.tb.Ec,
            c = a.tb.Dc;
        a.L.style.top = "0";
        a.L.style.left = "0";
        a.L.style.position = "absolute";
        a.L.style.width = `${b}px`;
        a.L.style.height = `${c}px`;
        a.L.style.minHeight = "auto";
        a.L.style.maxHeight = "none";
        a.L.style.minWidth = "auto";
        a.L.style.maxWidth = "none";
        a.L.style.removeProperty("vertical-align");
        return {}
    }, {
        id: 1456,
        H: {}
    });
    var t4 = Y(function(a, b, c) {
        var d = c.google_async_iframe_id,
            e = c.google_ad_width,
            f = c.google_ad_height,
            g = c.google_video_play_muted === !1;
        c = c.dash || "";
        var h = oy(Rw),
            k = [];
        for (let l = 0; l < h.length; l += 2) Vm(h[l], h[l + 1], k);
        return {
            tb: {
                xd: d,
                Ec: e,
                Dc: f,
                da: b,
                Kk: g,
                sn: c,
                od: k.join("&"),
                bb: a.bb
            }
        }
    }, {
        id: 1482,
        H: {
            tb: void 0
        }
    });

    function u4(a) {
        var b = hl("IFRAME");
        v4(b, a);
        return b
    }

    function v4(a, b = {}) {
        var c = {
            frameborder: 0,
            allowTransparency: "true",
            style: "border:0;vertical-align:bottom;",
            src: "about:blank"
        };
        bj(c, b);
        sj(a, c)
    };

    function w4({
        La: a,
        size: b,
        rh: c
    }) {
        c || (a.style.width = ak(b.width), a.style.height = ak(b.height))
    }

    function x4(a) {
        w4(a);
        var b = a.L,
            c = a.La,
            d = a.od,
            e = a.zm,
            f = a.xd,
            g = a.ah,
            h = a.Sl,
            k = a.content,
            l = a.Sb,
            m = a.rh,
            n = a.size,
            p = m || !b;
        k = JSON.stringify({
            creative: m || !b ? k ? ? "" : ""
        });
        var q = null;
        a.Ae && (q = a.Ae);
        a = y4(f, k, n, g, h, l, p, q == null ? null : q.join(" "), d ? ? "", e ? `//${e}.safeframe.googlesyndication.com` : "//tpc.googlesyndication.com", c);
        m ? (c.removeChild(b), v4(b, a), m = b) : b ? (m = b, v4(b, a)) : m = u4(a);
        c.appendChild(m);
        return m
    }

    function y4(a, b, c, d = "3rd party ad content", e = "Advertisement", f, g, h, k, l, m) {
        a = {
            id: a,
            title: d,
            name: b,
            scrolling: "no",
            marginWidth: "0",
            marginHeight: "0",
            width: String(c.width),
            height: String(c.height),
            "data-is-nameframe": "true"
        };
        g && (g = xj(rj(m)), k && (k = "?" + k), l = l + "/nameframe.html" + k, (g = S1(g)) && (l += `${k?"&":"?"}n=${g}`), a.src = `https:${l}`);
        h !== null && (a.sandbox = h);
        f && (a.allow = f);
        a["aria-label"] = e;
        a.tabIndex = 0;
        return a
    };

    function z4(a, b, c) {
        a.D[b] = c
    }

    function A4(a, b, c) {
        var d = {};
        d.c = a.Ob;
        d.i = a.B;
        d.s = b;
        d.p = c;
        try {
            a.C.postMessage(JSON.stringify(d), a.l)
        } catch (e) {}
    }
    class B4 extends Gs {
        constructor(a, b, c) {
            super();
            this.Ob = a;
            this.status = 1;
            this.C = b;
            this.l = c;
            this.zd = !1;
            this.B = Math.random();
            this.D = {};
            this.g = null;
            this.G = Aa(this.J, this);
            this.Eb = void 0
        }
        J(a) {
            if (!(this.l !== "*" && a.origin !== this.l || !this.zd && a.source != this.C)) {
                var b = null;
                try {
                    b = JSON.parse(a.data)
                } catch (c) {}
                if (ra(b) && (a = b.i, b.c === this.Ob && a != this.B)) {
                    if (this.status !== 2) try {
                        this.status = 2, a = {}, a.c = this.Ob, a.i = this.B, this.Eb && (a.e = this.Eb), this.C.postMessage(JSON.stringify(a), this.l), this.g && (this.g(), this.g =
                            null)
                    } catch (c) {}
                    a = b.s;
                    b = b.p;
                    if (typeof a === "string" && (typeof b === "string" || ra(b)) && this.D.hasOwnProperty(a)) this.D[a](b)
                }
            }
        }
        connect(a) {
            a && (this.g = a);
            gk(window, "message", this.G)
        }
        j() {
            this.status = 3;
            hk(window, "message", this.G);
            super.j()
        }
    };
    var C4 = class {
        constructor(a) {
            this.uid = a;
            this.l = null;
            this.B = this.status = 0;
            this.g = null;
            this.Ob = `sfchannel${a}`
        }
        jh() {
            return this.B === 2
        }
    };

    function D4(a) {
        var b = {};
        bb(a, c => {
            b[c.g()] = c.j()
        });
        return b
    };

    function E4(a) {
        var b = b || window;
        var c = b.screenX || b.screenLeft || 0,
            d = b.screenY || b.screenTop || 0;
        b = new Lj(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
        c = Zj(a);
        d = bk(a);
        var e = new Nj(c.x, c.y, d.width, d.height);
        c = Oj(e);
        d = String(Wj(a, "zIndex"));
        var f = new Lj(0, Infinity, Infinity, 0);
        for (var g = pj(a), h = g.g.body, k = g.g.documentElement, l = wj(g.g); a = Yj(a);)
            if ((!xb || a.clientHeight != 0 || a != h) && a != h && a != k && Wj(a, "overflow") != "visible") {
                var m = Zj(a);
                let n = new Di(a.clientLeft, a.clientTop);
                m.x += n.x;
                m.y += n.y;
                f.top = Math.max(f.top, m.y);
                f.right = Math.min(f.right, m.x + a.clientWidth);
                f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                f.left = Math.max(f.left, m.x)
            }
        a = l.scrollLeft;
        l = l.scrollTop;
        f.left = Math.max(f.left, a);
        f.top = Math.max(f.top, l);
        g = vj(g.Ba() || window);
        f.right = Math.min(f.right, a + g.width);
        f.bottom = Math.min(f.bottom, l + g.height);
        l = (f = (f = f.top >= 0 && f.left >= 0 && f.bottom > f.top && f.right > f.left ? f : null) ? new Nj(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ?
            Pj(e, f) : null;
        g = a = 0;
        l && !(new Ei(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
        l = new Lj(0, 0, 0, 0);
        if (h = f)(h = Pj(e, f)) ? (k = Oj(f), m = Oj(h), e = m.right !== k.left && k.right !== m.left, k = m.bottom !== k.top && k.bottom !== m.top, h = (h.width !== 0 || e) && (h.height !== 0 || k)) : h = !1;
        h && (l = new Lj(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
        return new F4(b, c, d, l, a, g)
    }

    function G4(a) {
        return JSON.stringify({
            windowCoords_t: a.l.top,
            windowCoords_r: a.l.right,
            windowCoords_b: a.l.bottom,
            windowCoords_l: a.l.left,
            frameCoords_t: a.j.top,
            frameCoords_r: a.j.right,
            frameCoords_b: a.j.bottom,
            frameCoords_l: a.j.left,
            styleZIndex: a.A,
            allowedExpansion_t: a.g.top,
            allowedExpansion_r: a.g.right,
            allowedExpansion_b: a.g.bottom,
            allowedExpansion_l: a.g.left,
            xInView: a.B,
            yInView: a.C
        })
    }
    var F4 = class {
        constructor(a, b, c, d, e, f) {
            this.A = c;
            this.B = e;
            this.C = f;
            this.l = Mj(a);
            this.j = Mj(b);
            this.g = Mj(d)
        }
    };
    var H4 = class {
        constructor(a) {
            this.g = a
        }
        getValue(a, b) {
            a = this.g[a];
            if (a == null) return null;
            b = a[b];
            return b === null || b === void 0 ? null : b
        }
    };
    var I4 = class {
        constructor(a, b) {
            this.df = a;
            this.ef = b;
            this.j = this.g = !1
        }
    };
    var J4 = class {
        constructor(a, b, c, d, e, f, g, h = []) {
            this.uid = a;
            this.W = b;
            this.D = c;
            this.permissions = d;
            this.metadata = e;
            this.g = f;
            this.zd = g;
            this.hostpageLibraryTokens = h;
            this.Eb = ""
        }
    };

    function K4(a) {
        return qc(a) || v(a)
    }
    var L4 = class {
            constructor(a, b) {
                this.uid = a;
                this.Eb = b
            }
            g(a) {
                this.Eb && a && (a.sentinel = this.Eb);
                return JSON.stringify(a)
            }
        },
        M4 = class extends L4 {
            constructor(a, b, c = "") {
                super(a, c);
                this.version = b
            }
            g() {
                return super.g({
                    uid: this.uid,
                    version: this.version
                })
            }
        },
        N4 = class extends L4 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.l = b;
                this.j = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    initialWidth: this.l,
                    initialHeight: this.j
                })
            }
        },
        O4 = class extends L4 {
            constructor(a, b, c = "") {
                super(a, c);
                this.description = b
            }
            g() {
                return super.g({
                    uid: this.uid,
                    description: this.description
                })
            }
        },
        P4 = class extends L4 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.j = b;
                this.push = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    expand_t: this.j.top,
                    expand_r: this.j.right,
                    expand_b: this.j.bottom,
                    expand_l: this.j.left,
                    push: this.push
                })
            }
        },
        Q4 = class extends L4 {
            constructor(a, b = "") {
                super(a, b)
            }
            g() {
                return super.g({
                    uid: this.uid
                })
            }
        },
        R4 = class extends L4 {
            constructor(a, b, c = "") {
                super(a, c);
                this.l = b
            }
            g() {
                var a = {
                    uid: this.uid,
                    newGeometry: G4(this.l)
                };
                return super.g(a)
            }
        },
        S4 = class extends R4 {
            constructor(a, b, c, d, e) {
                super(a, c, "");
                this.success =
                    b;
                this.j = d;
                this.push = e
            }
            g() {
                var a = {
                    uid: this.uid,
                    success: this.success,
                    newGeometry: G4(this.l),
                    expand_t: this.j.top,
                    expand_r: this.j.right,
                    expand_b: this.j.bottom,
                    expand_l: this.j.left,
                    push: this.push
                };
                this.Eb && (a.sentinel = this.Eb);
                return JSON.stringify(a)
            }
        },
        T4 = class extends L4 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.width = b;
                this.height = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    width: this.width,
                    height: this.height
                })
            }
        };
    var U4 = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        V4 = ["allow-top-navigation"],
        W4 = ["allow-same-origin"],
        X4 = pl([...U4, ...V4]);
    pl([...U4, ...W4]);
    pl([...U4, ...V4, ...W4]);

    function Y4(a) {
        var b = null;
        a.Ae && (b = a.Ae);
        return b == null ? null : b.join(" ")
    }

    function Z4({
        La: a,
        size: b,
        rh: c
    }) {
        b === 1 || c || (a.style.width = ak(b.width), a.style.height = ak(b.height))
    }

    function $4(a, {
        L: b,
        content: c,
        xd: d,
        size: e,
        ah: f = "3rd party ad content",
        Sl: g = "Advertisement",
        Sb: h,
        rh: k
    }) {
        var l = k || !b,
            m = {
                shared: {
                    sf_ver: a.bb,
                    ck_on: mH() ? 1 : 0,
                    flash_ver: "0"
                }
            };
        c = k || !b ? c ? ? "" : "";
        var n = a.bb,
            p = c.length;
        m = new J4(a.uid, a.W, a.D, a.permissions, new H4(m), a.Ab && !a.Fe, a.zd, a.hostpageLibraryTokens);
        var q = m.uid,
            u = m.W,
            A = G4(m.D);
        var D = m.permissions;
        D = JSON.stringify({
            expandByOverlay: D.df,
            expandByPush: D.ef,
            readCookie: D.g,
            writeCookie: D.j
        });
        q = {
            uid: q,
            hostPeerName: u,
            initialGeometry: A,
            permissions: D,
            metadata: JSON.stringify(m.metadata.g),
            reportCreativeGeometry: m.g,
            isDifferentSourceWindow: m.zd,
            goog_safeframe_hlt: D4(m.hostpageLibraryTokens)
        };
        m.Eb && (q.Eb = m.Eb);
        m = JSON.stringify(q);
        u = q = 0;
        e !== 1 && (q = e.width, u = e.height);
        d = {
            id: d,
            title: f,
            name: `${n};${p};${c}${m}`,
            scrolling: "no",
            marginWidth: "0",
            marginHeight: "0",
            width: String(q),
            height: String(u),
            "data-is-safeframe": "true"
        };
        l && (d.src = T1(xj(rj(a.La)), a.bb, a.od, a.hostname));
        a.sandbox !== null && (d.sandbox = a.sandbox);
        h && (d.allow = h);
        d["aria-label"] = g;
        d.tabIndex = 0;
        k ? (a.La.removeChild(b), v4(b, d), a.L = b) :
            b ? (a.L = b, sj(a.L, d)) : a.L = u4(d);
        a.La.appendChild(a.L)
    }

    function a5(a) {
        if (a.status === 1 || a.status === 2) switch (a.A) {
            case 0:
                b5(a);
                c5(a);
                a.A = 1;
                break;
            case 1:
                a.A = 2;
                break;
            case 2:
                a.A = 2
        }
    }

    function d5(a) {
        a.g = new B4(a.Ob, a.L.contentWindow, a.Gb);
        z4(a.g, "init_done", b => {
            a.Z(b)
        });
        z4(a.g, "register_done", b => {
            a.Aa(b)
        });
        z4(a.g, "report_error", b => {
            a.reportError(b)
        });
        z4(a.g, "expand_request", b => {
            a.J(b)
        });
        z4(a.g, "collapse_request", b => {
            a.O(b)
        });
        a.Fe || z4(a.g, "creative_geometry_update", b => {
            a.G(b)
        });
        a.Ab && !a.Fe && a.fe ? .Tb.Zb.qf.Ab.cf.ua({
            Vf: 2,
            ca: a.ge
        });
        a.g.connect(() => {
            a.pa()
        })
    }

    function b5(a) {
        a.l = E4(a.L);
        A4(a.g, "geometry_update", (new R4(a.uid, a.l)).g())
    }

    function c5(a) {
        a.T = window.setTimeout(() => {
            if (a.status === 1 || a.status === 2) switch (a.A) {
                case 0:
                case 1:
                    a.A = 0;
                    break;
                case 2:
                    b5(a), c5(a), a.A = 1
            }
        }, 1E3)
    }
    var e5 = class extends C4 {
        constructor(a) {
            super(a.uniqueId);
            this.T = -1;
            this.ea = a.ea;
            this.fe = a.fe;
            this.ge = a.ge ? ? 1;
            this.Fe = !!a.Fe;
            (this.Ab = a.size === 1) && !this.Fe && this.fe ? .Tb.Zb.qf.Ab.cf.ua({
                Vf: 1,
                ca: this.ge
            });
            this.permissions = new I4(a.permissions.df && !this.Ab, a.permissions.ef && !this.Ab);
            this.La = a.La;
            this.hostpageLibraryTokens = a.hostpageLibraryTokens ? ? [];
            var {
                protocol: b,
                host: c
            } = window.location;
            this.W = b === "file:" ? "*" : `${b}//${c}`;
            this.zd = !!a.zd;
            this.hostname = a.Rj ? V1(a.Rj) : "//tpc.googlesyndication.com";
            this.Gb =
                a.L ? "*" : `https:${this.hostname}`;
            this.sandbox = Y4(a);
            this.j = new Oy;
            Z4(a);
            this.l = this.D = E4(a.La);
            this.bb = a.bb || "0-0-0";
            this.od = a.od ? ? "";
            this.L = null;
            $4(this, a);
            this.C = bK(412, () => {
                a5(this)
            }, a.kc);
            this.A = 0;
            var d = bK(415, () => {
                this.L && (this.L.name = "", a.Bj && a.Bj(), hk(this.L, "load", d))
            }, a.kc);
            gk(this.L, "load", d);
            this.Z = bK(413, this.Z, a.kc);
            this.Aa = bK(417, this.Aa, a.kc);
            this.reportError = bK(419, this.reportError, a.kc);
            this.J = bK(411, this.J, a.kc);
            this.O = bK(409, this.O, a.kc);
            this.G = bK(410, this.G, a.kc);
            this.pa = bK(416,
                this.pa, a.kc);
            d5(this)
        }
        pa() {
            gk(window, "resize", this.C);
            gk(window, "scroll", this.C)
        }
        Z(a) {
            try {
                if (this.status !== 0) throw Error("Container already initialized");
                if (!v(a)) throw Error("Could not parse serialized message");
                let c = JSON.parse(a);
                if (!(ra(c) && K4(c.uid) && v(c.version))) throw Error("Cannot parse JSON message");
                var b = new M4(c.uid, c.version, c.sentinel || "");
                if (this.uid !== b.uid || this.bb !== b.version) throw Error("Wrong source container");
                this.status = 1
            } catch (c) {
                this.ea ? .error(`Invalid INITIALIZE_DONE message. Reason: ${c.message}`)
            }
        }
        Aa(a) {
            try {
                if (this.status !==
                    1) throw Error("Container not initialized");
                if (!v(a)) throw Error("Could not parse serialized message");
                let b = JSON.parse(a);
                if (!(ra(b) && K4(b.uid) && qc(b.initialWidth) && qc(b.initialHeight))) throw Error("Cannot parse JSON message");
                if (this.uid !== (new N4(b.uid, b.initialWidth, b.initialHeight, b.sentinel || "")).uid) throw Error("Wrong source container");
                this.status = 2
            } catch (b) {
                this.ea ? .error(`Invalid REGISTER_DONE message. Reason: ${b.message}`)
            }
        }
        reportError(a) {
            try {
                if (!v(a)) throw Error("Could not parse serialized message");
                let c = JSON.parse(a);
                if (!(ra(c) && K4(c.uid) && v(c.description))) throw Error("Cannot parse JSON message");
                var b = new O4(c.uid, c.description, c.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                this.ea ? .info(`Ext reported an error. Description: ${b.description}`)
            } catch (c) {
                this.ea ? .error(`Invalid REPORT_ERROR message. Reason: ${c.message}`)
            }
        }
        J(a) {
            try {
                if (this.status !== 2) throw Error("Container is not registered");
                if (this.B !== 0) throw Error("Container is not collapsed");
                if (!v(a)) throw Error("Could not parse serialized message");
                let G = JSON.parse(a);
                if (!(ra(G) && K4(G.uid) && qc(G.expand_t) && qc(G.expand_r) && qc(G.expand_b) && qc(G.expand_l) && rc(G.push))) throw Error("Cannot parse JSON message");
                var b = new P4(G.uid, new Lj(G.expand_t, G.expand_r, G.expand_b, G.expand_l), G.push, G.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                if (!(b.j.top >= 0 && b.j.left >= 0 && b.j.bottom >= 0 && b.j.right >= 0)) throw Error("Invalid expansion amounts");
                var c;
                if (c = b.push && this.permissions.ef || !b.push && this.permissions.df) {
                    var d = b.j,
                        e = b.push,
                        f = this.l = E4(this.L);
                    if (d.top <= f.g.top && d.right <= f.g.right && d.bottom <= f.g.bottom && d.left <= f.g.left) {
                        if (!e)
                            for (let E = this.L.parentNode; E && E.style; E = E.parentNode) Ly(this.j, E, "overflowX", "visible", "important"), Ly(this.j, E, "overflowY", "visible", "important");
                        var g = Oj(new Nj(0, 0, this.l.j.getWidth(), this.l.j.getHeight()));
                        ra(d) ? (g.top -= d.top, g.right += d.right, g.bottom += d.bottom, g.left -= d.left) : (g.top -= d, g.right += Number(void 0), g.bottom += Number(void 0), g.left -= Number(void 0));
                        Ly(this.j, this.La, "position", "relative");
                        Ly(this.j, this.L, "position", "absolute");
                        if (e) {
                            var h = this.j,
                                k = this.La,
                                l = g.getWidth();
                            Ly(h, k, "width", W(l));
                            var m = this.j,
                                n = this.La,
                                p = g.getHeight();
                            Ly(m, n, "height", W(p))
                        } else Ly(this.j, this.L, "zIndex", "10000");
                        var q = this.j,
                            u = this.L,
                            A = g.getWidth();
                        Ly(q, u, "width", W(A));
                        var D = this.j,
                            K = this.L,
                            I = g.getHeight();
                        Ly(D, K, "height", W(I));
                        Ly(this.j, this.L, "left", W(g.left));
                        Ly(this.j, this.L, "top", W(g.top));
                        this.B = 2;
                        this.l = E4(this.L);
                        c = !0
                    } else c = !1
                }
                a = c;
                A4(this.g, "expand_response", (new S4(this.uid, a, this.l, b.j, b.push)).g());
                if (!a) throw Error("Viewport or document body not large enough to expand into.");
            } catch (G) {
                this.ea ? .error(`Invalid EXPAND_REQUEST message. Reason: ${G.message}`)
            }
        }
        O(a) {
            try {
                if (this.status !== 2) throw Error("Container is not registered");
                if (!this.jh()) throw Error("Container is not expanded");
                if (!v(a)) throw Error("Could not parse serialized message");
                let b = JSON.parse(a);
                if (!ra(b) || !K4(b.uid)) throw Error("Cannot parse JSON message");
                if (this.uid !== (new Q4(b.uid, b.sentinel || "")).uid) throw Error("Wrong source container");
                this.collapse();
                A4(this.g, "collapse_response", (new R4(this.uid, this.l)).g())
            } catch (b) {
                this.ea ? .error(`Invalid COLLAPSE_REQUEST message. Reason: ${b.message}`)
            }
        }
        collapse() {
            Ny(this.j);
            this.B = 0;
            this.L && (this.l = E4(this.L))
        }
        G(a) {
            try {
                if (!v(a)) throw Error("Could not parse serialized message");
                let c = JSON.parse(a);
                if (!(ra(c) && K4(c.uid) && qc(c.width) && qc(c.height)) || c.sentinel && !v(c.sentinel)) throw Error("Cannot parse JSON message");
                var b = new T4(c.uid, c.width, c.height, c.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                let d = String(b.height);
                this.Ab ? (this.fe ? .Tb.Zb.qf.Ab.cf.ua({
                    Vf: 3,
                    ca: this.ge
                }), d !== this.L.height && (this.L.height = d, this.fe ? .Tb.Zb.qf.Ab.cf.ua({
                    Vf: 4,
                    ca: this.ge
                }), a5(this))) : this.ea ? .error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            } catch (c) {
                this.ea ? .error(`Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: ${c.message}`)
            }
        }
        destroy() {
            this.status !== 100 && (this.jh() && (Ny(this.j), this.B = 0), window.clearTimeout(this.T), this.T = -1, this.A = 3, this.g && (this.g.dispose(),
                this.g = null), hk(window, "resize", this.C), hk(window, "scroll", this.C), this.La && this.L && this.La === (this.L.parentElement || null) && this.La.removeChild(this.L), this.La = this.L = null, this.status = 100)
        }
    };

    function f5(a, b, c, d) {
        var e = a.xd,
            f = a.Ec,
            g = a.Dc;
        a = a.da;
        var {
            promise: h,
            resolve: k
        } = ka(Promise, "withResolvers").call(Promise), l = x4({
            La: a,
            xd: e,
            ah: e,
            size: new Ei(f, g),
            content: b,
            Ae: c ? ? void 0,
            zm: Y1(),
            Sb: d ? .join(";")
        }), m = bK(415, () => {
            k();
            hk(l, "load", m)
        });
        gk(l, "load", m);
        return {
            ne: l,
            Id: h
        }
    }
    var g5 = Y(function(a) {
        if (U(Ow)) var b = f5(a.tb, a.si, a.Pd, a.Sb);
        else {
            var c = a.tb;
            b = a.si;
            var d = a.Pd;
            a = a.Sb;
            let e = c.xd,
                f = c.Ec,
                g = c.Dc,
                h = c.da,
                k = c.od;
            c = c.bb;
            let {
                promise: l,
                resolve: m
            } = ka(Promise, "withResolvers").call(Promise);
            b = {
                ne: (new e5({
                    La: h,
                    xd: e,
                    ah: e,
                    size: new Ei(f, g),
                    content: b,
                    Bj: m,
                    uniqueId: e,
                    Ae: d ? ? void 0,
                    permissions: {
                        df: !1,
                        ef: !1
                    },
                    Rj: Y1(),
                    od: k,
                    Sb: a ? .join(";"),
                    bb: c
                })).L,
                Id: l
            }
        }
        return b
    }, {
        id: 1453,
        H: {
            ne: void 0,
            Id: void 0
        }
    });
    var h5 = Y(function() {
        return rl() ? {
            Pd: X4
        } : {
            Pd: void 0
        }
    }, {
        id: 1475,
        H: {
            Pd: void 0
        }
    });
    const i5 = ["run-ad-auction", "attribution-reporting"];
    var j5 = Y(function(a, b) {
        a = a.tb.Kk;
        var c = i5.filter(d => c_(d, b));
        a && c.push("autoplay");
        return {
            Sb: c
        }
    }, {
        id: 1476,
        H: {
            Sb: void 0
        }
    });
    var k5 = class extends S0 {
        constructor(a, b, c, d) {
            super(a);
            this.uh = a;
            this.g = new TY;
            ({
                tb: a
            } = Z(this, t4, {
                bb: d
            }, b.da, b.I, b.pubWin));
            ({
                Pd: d
            } = Z(this, h5, {}));
            ({
                Sb: b
            } = Z(this, j5, {
                tb: a
            }, b.pubWin.document));
            var {
                ne: e,
                Id: f
            } = Z(this, g5, {
                si: c,
                Pd: d,
                Sb: b,
                tb: a
            });
            c = Z(this, r4, {
                L: e,
                tb: a
            });
            c = X(Z(this, s4, {
                L: e,
                tb: a
            }), c.finished);
            this.l = e;
            this.G = f;
            this.g = c.finished
        }
    };

    function l5(a, b) {
        var c = window,
            d = e => {
                e.blockedURI === a && e.disposition === "enforce" && (ZA(1), c.removeEventListener("securitypolicyviolation", d))
            };
        c.addEventListener("securitypolicyviolation", d);
        Is(b, () => {
            c.removeEventListener("securitypolicyviolation", d)
        });
        return d
    }

    function m5(a, b) {
        var c = new MutationObserver((d, e) => {
            a.isConnected || (e.disconnect(), b.abort())
        });
        c.observe(document.body, {
            childList: !0,
            subtree: !0
        });
        return c
    }
    var n5 = M0(async function(a, b, c) {
        var d = a.Vl;
        a = KZ(a.adUrl);
        var e;
        V(Mw) > 0 && (e = l5(a, c));
        c = !1;
        if (!b.isConnected) return {
            error: Error("Iframe wrapper element is not in the DOM at request time."),
            redirected: c
        };
        var f = new AbortController;
        b = m5(b, f);
        try {
            let g = await fetch(a, {
                credentials: d ? "include" : "omit",
                redirect: V(Mw) > 0 ? "manual" : "follow",
                signal: f.signal
            });
            if (g.type === "opaqueredirect" || g.status >= 300 && g.status < 400) {
                c = !0;
                let h = g.headers.get("Location") || a;
                g = await fetch(h, {
                    credentials: d ? "include" : "omit",
                    signal: f.signal
                })
            }
            return {
                response: g,
                redirected: c
            }
        } catch (g) {
            return {
                error: g,
                redirected: c
            }
        } finally {
            b.disconnect(), e && setTimeout(() => {
                window.removeEventListener("securitypolicyviolation", e)
            }, 0)
        }
    }, {
        id: 1452
    });

    function o5() {
        var a = ny(Sw) || "0-0-0",
            b = a.split("-").map(d => Number(d)),
            c = ["0", "0", "0"].map(d => Number(d));
        for (let d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "0-0-0"
    }
    var p5 = Y(function() {
        return {
            bb: o5()
        }
    }, {
        id: 1477,
        H: {
            bb: void 0
        }
    });
    var q5 = Y(function(a, b) {
        a = a.P.ha();
        b = !iX(b.I);
        return {
            output: a && b
        }
    }, {
        id: 1474,
        H: {
            output: void 0
        }
    });

    function r5(a, b) {
        var c = hl("IFRAME");
        dj(c, b);
        c.style.visibility = "hidden";
        c.style.display = "none";
        a = a.getElementsByTagName("script");
        a.length && (a = a[a.length - 1], a.parentNode && a.parentNode.insertBefore(c, a.nextSibling));
        return c
    }

    function s5(a, b, c) {
        if (!a.g[c.toString()]) {
            a.g[c.toString()] = 1;
            var d = r5(b.document, c);
            d.addEventListener("load", () => {
                d.remove()
            })
        }
    }

    function t5(a, b, c, d, e = []) {
        c = W1(U1.km({
            version: d,
            Xf: c
        }), b);
        if (e.length) {
            d = new Map;
            for (let f = 0; f < e.length; f += 2) d.set(e[f], e[f + 1]);
            c = oi(c, d)
        }
        s5(a, b, c)
    }

    function u5(a, b) {
        var c = new v5;
        if (!v(b)) throw new TypeError("subdomain is not a string");
        if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(b)) throw new RangeError(`Invalid subdomain: ${b}`);
        b = $h(`https://${b}.safeframe.googlesyndication.com/nameframe.html`);
        b = W1(b, a);
        s5(c, a, b)
    }
    var v5 = class {
        constructor() {
            this.g = {}
        }
    };

    function w5(a, b, c, d) {
        var e = f => {
            f.blockedURI.startsWith(`https://${a}`) && f.disposition === "enforce" && (c(), b.removeEventListener("securitypolicyviolation", e))
        };
        b.addEventListener("securitypolicyviolation", e);
        Is(d, () => {
            b.removeEventListener("securitypolicyviolation", e)
        })
    }
    var x5 = Y(function(a, b, c, d) {
        if (b.GLnKw || b.FJPve) return {};
        var e = Y1();
        V(Mw) > 0 && w5(e, c, () => {
            ZA(3)
        }, d);
        U(Ow) ? (u5(c, e), b.GLnKw = !0) : (t5(new v5, c, e, a.bb, oy(Rw)), b.FJPve = !0);
        return {}
    }, {
        id: 1575,
        H: {}
    });
    const y5 = ["Failed to fetch", "Load failed"];
    var z5 = Y(function(a) {
        var b = a.hf.error;
        a = a.hf.redirected;
        b && (AA(1610, b), V(Mw) > 0 && b instanceof TypeError && y5.includes(b.message) && a && ZA(2));
        return {}
    }, {
        id: 1610,
        H: {}
    });
    var A5 = class extends Error {
        constructor(a) {
            super(a)
        }
    };
    A5.prototype.name = "NetworkError";
    var B5 = M0(async function(a) {
        var b = Promise.resolve(null);
        (a = a.hf.response) && (a.status >= 300 ? AA(1454, new A5(`Received non-200 response from BOW, status: ${a.status}`)) : b = a.text());
        return b
    }, {
        id: 1454
    });
    var C5 = class extends S0 {
        constructor(a, b) {
            super(a);
            this.g = P0(this, B5, {
                hf: b
            }).output;
            Z(this, z5, {
                hf: b
            })
        }
    };
    const D5 = g1(function(a) {
        return a.Ga && !a.ra && a.Xa
    }, {
        id: 1487
    });
    var E5 = class extends d1 {
        constructor(a, b, c, d, e) {
            super(a);
            this.ea = a;
            this.Ga = e.Ga;
            this.ra = e.ra;
            this.Xg = e.Xg;
            ({
                bb: e
            } = Z(this, p5, {}));
            Z(this, x5, {
                bb: e
            }, c.pageState, c.pubWin, this);
            ({
                output: d
            } = Z(this, q5, {
                P: d
            }, c));
            ({
                output: b
            } = P0(this, n5, {
                Vl: d,
                adUrl: b
            }, c.da, this));
            ({
                g: b
            } = Q0(this, new C5(a, b)));
            var {
                l: f,
                G: g,
                g: h
            } = Q0(this, new k5(a, c, b, e));
            this.G = f;
            this.Gb = g;
            this.J = h
        }
        async g() {
            return e1(this.ea, D5, {
                Ga: this.Ga,
                ra: this.ra,
                Xa: this.Xg
            })
        }
        l() {
            KY(this.G, null);
            KY(this.Gb, null);
            this.J.notify()
        }
    };
    var F5 = class extends S0 {
        constructor(a, b, c, d) {
            super(a);
            var {
                P: e
            } = X(Z(this, U0, {}, b), c), f = X(Z(this, o1, {
                P: e
            }, b.pubWin, a), c);
            c = X(Z(this, k1, {}, b), c);
            f = f.Ni;
            c = X(Z(this, X0, {
                P: e,
                Va: f
            }, b.pubWin), c.finished);
            d = X(Z(this, V0, {
                P: e,
                zb: d
            }, b.pubWin, b.I, b.pageState), c.finished);
            var g = Q0(this, new i1(a, b, e, d.Qd, d.finished, f));
            c = X(Z(this, j1, {}, b), g.G).Ga;
            var h = Q0(this, new T0(a, b, e, g.G, c, f, g.lc, g.Na)),
                k = h.g.Fm;
            g = h.g.ra;
            h = h.g.Na;
            var l = Q0(this, new E5(a, k, b, e, {
                Ga: c,
                ra: g,
                Xg: d.Qd
            }));
            k = Q0(this, new q4(a, k, b, e, b.pubWin, g, d.Qd,
                c));
            this.g = Q0(this, new e4(a, k.G, h, b, e, {
                rf: k.rf,
                Hl: l.J
            }, {
                ra: g,
                Xa: d.Qd
            }, {
                Ga: c,
                ne: l.G
            }, f)).J
        }
    };
    var G5 = Y(function(a, b) {
        b.j |= a.gf;
        return {
            Wj: b
        }
    }, {
        id: 1412,
        H: {
            Wj: void 0
        }
    });
    const H5 = (a, b) => {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        I5 = (a, b) => {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        J5 = {
            Bf: a => a.listener,
            qe: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }
            }),
            Jd: (a, b) => {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        K5 = {
            Bf: a => a.listener,
            qe: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }
            }),
            Jd: (a, b) => {
                b = b.__gppReturn;
                var c = b.returnValue.data;
                a ? .(c, b.success)
            }
        };

    function L5(a) {
        var b = {};
        v(a.data) ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Nh: b.__gppReturn.callId
        }
    }

    function M5(a, b, c) {
        var d = !(b.includes(2) && c ? .idpcApplies),
            e = !1,
            f = !1;
        if (a && !a.startsWith("GPP_ERROR_STRING_")) {
            let c6 = FT(a.split("~")[0]),
                d6 = AT(a),
                QE = lf(c6, 3);
            for (let Jm = 0; Jm < QE.length; ++Jm) {
                let RE = QE[Jm];
                if (!b.includes(RE)) continue;
                let Kb = d6[Jm];
                switch (RE) {
                    case 2:
                        if (c ? .supportTcfeu) {
                            a: {
                                let la = qV(Kb);
                                if (!la || !Kb) {
                                    var g = null;
                                    break a
                                }
                                let lb = x(la, bV, 1),
                                    Km = x(la, FU, 2) || new FU,
                                    SE = {
                                        consents: sV(lf(lb, 17)),
                                        legitimateInterests: sV(lf(lb, 18))
                                    };
                                if (ze(la, zU, 3)) {
                                    var h = x(la, zU, 3);
                                    var k = lf(h, 1);
                                    SE.disclosedVendors =
                                        sV(k)
                                }
                                var l = gf(lb, 9),
                                    m = gf(lb, 4),
                                    n = gf(lb, 5),
                                    p = B(lb, 10),
                                    q = B(lb, 11),
                                    u = C(lb, 16),
                                    A = B(lb, 15),
                                    D = {
                                        consents: sV(mf(lb, 13), dV),
                                        legitimateInterests: sV(mf(lb, 14), dV)
                                    },
                                    K = sV(mf(lb, 12), eV),
                                    I = Ve(lb, AU, 19, w());
                                let Lm = {};
                                for (let Js of I) {
                                    let Ks = F(Js, 1);
                                    Lm[Ks] = Lm[Ks] || {};
                                    for (let e6 of lf(Js, 3)) Lm[Ks][e6] = F(Js, 2)
                                }
                                g = {
                                    tcString: Kb,
                                    tcfPolicyVersion: l,
                                    gdprApplies: !0,
                                    cmpId: m,
                                    cmpVersion: n,
                                    isServiceSpecific: p,
                                    useNonStandardStacks: q,
                                    publisherCC: u,
                                    purposeOneTreatment: A,
                                    purpose: D,
                                    vendor: SE,
                                    specialFeatureOptins: K,
                                    publisher: {
                                        restrictions: Lm,
                                        consents: sV(mf(Km, 1), dV),
                                        legitimateInterests: sV(mf(Km, 2), dV),
                                        customPurposes: {
                                            consents: sV(lf(Km, 3)),
                                            legitimateInterests: sV(lf(Km, 4))
                                        }
                                    }
                                }
                            }
                            let ta = g;
                            if (!ta) throw Error("Cannot decode TCF V2 section string.");d = gP(ta);!jP(ta) && (e = !0)
                        }
                        break;
                    case 7:
                        let TE = sU(Kb, c ? .supportUsnatV2 ? [1, 2] : [1]),
                            Mm = x(TE, lU, 1),
                            UE = x(Mm, iU, 12);
                        F(Mm, 8) !== 1 && F(Mm, 9) !== 1 && F(Mm, 10) !== 1 && UE ? .l() !== 1 && UE ? .g() !== 1 || (e = !0);
                        var G = x(TE, lU, 1);
                        let VE = x(G, iU, 12) ? .A();
                        VE !== 1 && VE !== 2 || (f = !0);
                        break;
                    case 8:
                        if (Kb.length === 0) throw Error("Cannot decode empty USCA section string.");
                        let Fj = Kb.split(".");
                        if (Fj.length > 2) throw Error(`Expected at most 1 sub-section but got ${Fj.length-1} when decoding ${Kb}.`);
                        var E = void 0,
                            Q = void 0,
                            wa = void 0,
                            Ca = void 0,
                            ia = void 0,
                            Fa = void 0,
                            Sb = void 0,
                            $c = void 0,
                            Lc = void 0,
                            ee = void 0,
                            ya = void 0,
                            Mc = void 0,
                            Qg = void 0,
                            Rg = void 0,
                            Sg = void 0,
                            Tg = void 0,
                            Ug = void 0,
                            Wg = void 0,
                            Xg = void 0,
                            Yg = void 0,
                            Zg = void 0,
                            $g = void 0,
                            ah = void 0,
                            bh = Fj[0];
                        if (bh.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Nm = ET(bh, OT),
                            Ls = CT(Nm.slice(0, 6));
                        Nm = Nm.slice(6);
                        if (Ls !==
                            1) throw Error(`Unable to decode unsupported USCA Section specification version ${Ls} - only version 1 is supported.`);
                        let Ms = 0,
                            Wa = [];
                        for (let ta = 0; ta < NT.length; ta++) {
                            let la = NT[ta];
                            Wa.push(CT(Nm.slice(Ms, Ms + la)));
                            Ms += la
                        }
                        var Ni = new JT;
                        ah = uf(Ni, 1, Ls);
                        var Oi = Wa.shift();
                        $g = H(ah, 2, Oi);
                        var Pi = Wa.shift();
                        Zg = H($g, 3, Pi);
                        var Qi = Wa.shift();
                        Yg = H(Zg, 4, Qi);
                        var Ri = Wa.shift();
                        Xg = H(Yg, 5, Ri);
                        var Si = Wa.shift();
                        Wg = H(Xg, 6, Si);
                        var Af = new IT,
                            Ti = Wa.shift();
                        Ug = H(Af, 1, Ti);
                        var dh = Wa.shift();
                        Tg = H(Ug, 2, dh);
                        var Ui = Wa.shift();
                        Sg =
                            H(Tg, 3, Ui);
                        var Df = Wa.shift();
                        Rg = H(Sg, 4, Df);
                        var Vi = Wa.shift();
                        Qg = H(Rg, 5, Vi);
                        var Wi = Wa.shift();
                        Mc = H(Qg, 6, Wi);
                        var Xi = Wa.shift();
                        ya = H(Mc, 7, Xi);
                        var Ef = Wa.shift();
                        ee = H(ya, 8, Ef);
                        var gh = Wa.shift();
                        Lc = H(ee, 9, gh);
                        $c = y(Wg, 7, Lc);
                        var Yi = new HT,
                            ih = Wa.shift();
                        Sb = H(Yi, 1, ih);
                        var xc = Wa.shift();
                        Fa = H(Sb, 2, xc);
                        ia = y($c, 8, Fa);
                        var jh = Wa.shift();
                        Ca = H(ia, 9, jh);
                        var Zi = Wa.shift();
                        wa = H(Ca, 10, Zi);
                        var Gf = Wa.shift();
                        Q = H(wa, 11, Gf);
                        var kh = Wa.shift();
                        let WE = E = H(Q, 12, kh);
                        if (Fj.length === 1) var Hf = LT(WE);
                        else {
                            var uc = LT(WE),
                                ad = void 0,
                                Va =
                                void 0,
                                Vb = void 0,
                                Pg = Fj[1];
                            if (Pg.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            let ta = ET(Pg, 3),
                                la = CT(ta.slice(0, 2));
                            if (la < 0 || la > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${la}.`);
                            Vb = la + 1;
                            let lb = CT(ta.charAt(2));
                            var Ge = new KT;
                            Va = H(Ge, 2, Vb);
                            ad = sf(Va, 1, !!lb);
                            Hf = y(uc, 2, ad)
                        }
                        let XE = Hf,
                            YE = x(XE, JT, 1);
                        F(YE, 5) !== 1 && F(YE, 6) !== 1 || (e = !0);
                        var Ff = x(XE, JT, 1);
                        let Om = x(Ff, HT, 8);
                        Om ? .g() !== 1 && Om ? .g() !== 2 && Om ? .l() !== 1 && Om ? .l() !== 2 || (f = !0);
                        break;
                    case 9:
                        if (Kb.length === 0) throw Error("Cannot decode empty USVA section string.");
                        let Pm = ET(Kb, xU),
                            Ns = CT(Pm.slice(0, 6));
                        Pm = Pm.slice(6);
                        if (Ns !== 1) throw Error(`Unable to decode unsupported USVA Section specification version ${Ns} - only version 1 is supported.`);
                        let Os = 0,
                            yb = [];
                        for (let ta = 0; ta < wU.length; ta++) {
                            let la = wU[ta];
                            yb.push(CT(Pm.slice(Os, Os + la)));
                            Os += la
                        }
                        var vc = Ns,
                            cc = new vU,
                            Zc = uf(cc, 1, vc),
                            md = yb.shift(),
                            Gb = H(Zc, 2, md),
                            wc = yb.shift(),
                            zf = H(Gb, 3, wc),
                            Mi = yb.shift(),
                            Vg = H(zf, 4, Mi),
                            nd = yb.shift(),
                            ch = H(Vg, 5, nd),
                            Bf = yb.shift();
                        var Cf = H(ch, 6, Bf);
                        var fe = new uU,
                            fh = yb.shift(),
                            hh = H(fe, 1, fh),
                            eh =
                            yb.shift(),
                            rr = H(hh, 2, eh),
                            sr = yb.shift(),
                            tr = H(rr, 3, sr),
                            ur = yb.shift(),
                            vr = H(tr, 4, ur),
                            wr = yb.shift(),
                            xr = H(vr, 5, wr),
                            yr = yb.shift(),
                            zr = H(xr, 6, yr),
                            Ar = yb.shift(),
                            Br = H(zr, 7, Ar),
                            Cr = yb.shift();
                        var Dr = H(Br, 8, Cr);
                        var Er = y(Cf, 7, Dr),
                            Fr = yb.shift(),
                            Gr = H(Er, 8, Fr),
                            Hr = yb.shift(),
                            Ir = H(Gr, 9, Hr),
                            Jr = yb.shift(),
                            Kr = H(Ir, 10, Jr),
                            Lr = yb.shift();
                        let Ps = H(Kr, 11, Lr);
                        F(Ps, 5) !== 1 && F(Ps, 6) !== 1 || (e = !0);
                        let ZE = F(Ps, 8);
                        ZE !== 1 && ZE !== 2 || (f = !0);
                        break;
                    case 10:
                        if (Kb.length === 0) throw Error("Cannot decode empty USCO section string.");
                        let Gj = Kb.split(".");
                        if (Gj.length > 2) throw Error(`Expected at most 2 segments but got ${Gj.length} when decoding ${Kb}.`);
                        var Mr = void 0,
                            bm = void 0,
                            cm = void 0,
                            dm = void 0,
                            em = void 0,
                            fm = void 0,
                            gm = void 0,
                            hm = void 0,
                            im = void 0,
                            jm = void 0,
                            km = void 0,
                            lm = void 0,
                            mm = void 0,
                            nm = void 0,
                            om = void 0,
                            pm = void 0,
                            qm = void 0,
                            rm = void 0,
                            sm = Gj[0];
                        if (sm.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Qm = ET(sm, VT),
                            Qs = CT(Qm.slice(0, 6));
                        Qm = Qm.slice(6);
                        if (Qs !== 1) throw Error(`Unable to decode unsupported USCO Section specification version ${Qs} - only version 1 is supported.`);
                        let Rs = 0,
                            Lb = [];
                        for (let ta = 0; ta < UT.length; ta++) {
                            let la = UT[ta];
                            Lb.push(CT(Qm.slice(Rs, Rs + la)));
                            Rs += la
                        }
                        var Nr = new QT;
                        rm = uf(Nr, 1, Qs);
                        var Or = Lb.shift();
                        qm = H(rm, 2, Or);
                        var tj = Lb.shift();
                        pm = H(qm, 3, tj);
                        var am = Lb.shift();
                        om = H(pm, 4, am);
                        var f6 = Lb.shift();
                        nm = H(om, 5, f6);
                        var g6 = Lb.shift();
                        mm = H(nm, 6, g6);
                        var h6 = new PT,
                            i6 = Lb.shift();
                        lm = H(h6, 1, i6);
                        var j6 = Lb.shift();
                        km = H(lm, 2, j6);
                        var k6 = Lb.shift();
                        jm = H(km, 3, k6);
                        var l6 = Lb.shift();
                        im = H(jm, 4, l6);
                        var m6 = Lb.shift();
                        hm = H(im, 5, m6);
                        var n6 = Lb.shift();
                        gm = H(hm, 6, n6);
                        var o6 = Lb.shift();
                        fm = H(gm, 7, o6);
                        em = y(mm, 7, fm);
                        var p6 = Lb.shift();
                        dm = H(em, 8, p6);
                        var q6 = Lb.shift();
                        cm = H(dm, 9, q6);
                        var r6 = Lb.shift();
                        bm = H(cm, 10, r6);
                        var s6 = Lb.shift();
                        let $E = Mr = H(bm, 11, s6);
                        if (Gj.length === 1) var aF = ST($E);
                        else {
                            var t6 = ST($E),
                                bF = void 0,
                                cF = void 0,
                                dF = void 0,
                                eF = Gj[1];
                            if (eF.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            let ta = ET(eF, 3),
                                la = CT(ta.slice(0, 2));
                            if (la < 0 || la > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${la}.`);
                            dF = la + 1;
                            let lb = CT(ta.charAt(2));
                            var u6 = new RT;
                            cF = H(u6, 2, dF);
                            bF = sf(cF, 1, !!lb);
                            aF = y(t6, 2, bF)
                        }
                        let fF = aF,
                            gF = x(fF, QT, 1);
                        F(gF, 5) !== 1 && F(gF, 6) !== 1 || (e = !0);
                        var v6 = x(fF, QT, 1);
                        let hF = F(v6, 8);
                        hF !== 1 && hF !== 2 || (f = !0);
                        break;
                    case 12:
                        if (Kb.length === 0) throw Error("Cannot decode empty usct section string.");
                        let Hj = Kb.split(".");
                        if (Hj.length > 2) throw Error(`Expected at most 2 segments but got ${Hj.length} when decoding ${Kb}.`);
                        var w6 = void 0,
                            iF = void 0,
                            jF = void 0,
                            kF = void 0,
                            lF = void 0,
                            mF = void 0,
                            nF = void 0,
                            oF = void 0,
                            pF = void 0,
                            qF = void 0,
                            rF = void 0,
                            sF = void 0,
                            tF = void 0,
                            uF =
                            void 0,
                            vF = void 0,
                            wF = void 0,
                            xF = void 0,
                            yF = void 0,
                            zF = void 0,
                            AF = void 0,
                            BF = void 0,
                            CF = void 0,
                            DF = Hj[0];
                        if (DF.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Rm = ET(DF, cU),
                            Ss = CT(Rm.slice(0, 6));
                        Rm = Rm.slice(6);
                        if (Ss !== 1) throw Error(`Unable to decode unsupported USCT Section specification version ${Ss} - only version 1 is supported.`);
                        let Ts = 0,
                            fb = [];
                        for (let ta = 0; ta < bU.length; ta++) {
                            let la = bU[ta];
                            fb.push(CT(Rm.slice(Ts, Ts + la)));
                            Ts += la
                        }
                        var x6 = new YT;
                        CF = uf(x6, 1, Ss);
                        var y6 = fb.shift();
                        BF = H(CF,
                            2, y6);
                        var z6 = fb.shift();
                        AF = H(BF, 3, z6);
                        var A6 = fb.shift();
                        zF = H(AF, 4, A6);
                        var B6 = fb.shift();
                        yF = H(zF, 5, B6);
                        var C6 = fb.shift();
                        xF = H(yF, 6, C6);
                        var D6 = new XT,
                            E6 = fb.shift();
                        wF = H(D6, 1, E6);
                        var F6 = fb.shift();
                        vF = H(wF, 2, F6);
                        var G6 = fb.shift();
                        uF = H(vF, 3, G6);
                        var H6 = fb.shift();
                        tF = H(uF, 4, H6);
                        var I6 = fb.shift();
                        sF = H(tF, 5, I6);
                        var J6 = fb.shift();
                        rF = H(sF, 6, J6);
                        var K6 = fb.shift();
                        qF = H(rF, 7, K6);
                        var L6 = fb.shift();
                        pF = H(qF, 8, L6);
                        oF = y(xF, 7, pF);
                        var M6 = new WT,
                            N6 = fb.shift();
                        nF = H(M6, 1, N6);
                        var O6 = fb.shift();
                        mF = H(nF, 2, O6);
                        var P6 = fb.shift();
                        lF = H(mF, 3, P6);
                        kF = y(oF, 8, lF);
                        var Q6 = fb.shift();
                        jF = H(kF, 9, Q6);
                        var R6 = fb.shift();
                        iF = H(jF, 10, R6);
                        var S6 = fb.shift();
                        let EF = w6 = H(iF, 11, S6);
                        if (Hj.length === 1) var FF = $T(EF);
                        else {
                            var T6 = $T(EF),
                                GF = void 0,
                                HF = void 0,
                                IF = void 0,
                                JF = Hj[1];
                            if (JF.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            let ta = ET(JF, 3),
                                la = CT(ta.slice(0, 2));
                            if (la < 0 || la > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${la}.`);
                            IF = la + 1;
                            let lb = CT(ta.charAt(2));
                            var U6 = new ZT;
                            HF = H(U6, 2, IF);
                            GF = sf(HF, 1, !!lb);
                            FF = y(T6, 2, GF)
                        }
                        let KF = FF,
                            Us = x(KF, YT, 1),
                            LF = x(Us, WT, 8);
                        F(Us, 5) !== 1 && F(Us, 6) !== 1 && LF ? .l() !== 1 && LF ? .A() !== 1 || (e = !0);
                        var V6 = x(KF, YT, 1);
                        let MF = x(V6, WT, 8);
                        MF ? .g() !== 1 && MF ? .g() !== 2 || (f = !0);
                        break;
                    case 13:
                        if (Kb.length === 0) throw Error("Cannot decode empty USFL section string.");
                        let Sm = ET(Kb, hU),
                            Vs = CT(Sm.slice(0, 6));
                        Sm = Sm.slice(6);
                        if (Vs !== 1) throw Error(`Unable to decode unsupported USFL Section specification version ${Vs} - only version 1 is supported.`);
                        let Ws = 0,
                            Xa = [];
                        for (let ta = 0; ta < gU.length; ta++) {
                            let la = gU[ta];
                            Xa.push(CT(Sm.slice(Ws, Ws + la)));
                            Ws += la
                        }
                        var W6 = Vs,
                            X6 = new fU,
                            Y6 = uf(X6, 1, W6),
                            Z6 = Xa.shift(),
                            $6 = H(Y6, 2, Z6),
                            a7 = Xa.shift(),
                            b7 = H($6, 3, a7),
                            c7 = Xa.shift(),
                            d7 = H(b7, 4, c7),
                            e7 = Xa.shift(),
                            f7 = H(d7, 5, e7),
                            g7 = Xa.shift();
                        var h7 = H(f7, 6, g7);
                        var i7 = new eU,
                            j7 = Xa.shift(),
                            k7 = H(i7, 1, j7),
                            l7 = Xa.shift(),
                            m7 = H(k7, 2, l7),
                            n7 = Xa.shift(),
                            o7 = H(m7, 3, n7),
                            p7 = Xa.shift(),
                            q7 = H(o7, 4, p7),
                            r7 = Xa.shift(),
                            s7 = H(q7, 5, r7),
                            t7 = Xa.shift(),
                            u7 = H(s7, 6, t7),
                            v7 = Xa.shift(),
                            w7 = H(u7, 7, v7),
                            x7 = Xa.shift();
                        var y7 = H(w7, 8, x7);
                        var z7 = y(h7, 7, y7);
                        var A7 = new dU,
                            B7 = Xa.shift(),
                            C7 = H(A7, 1, B7),
                            D7 = Xa.shift(),
                            E7 = H(C7, 2, D7),
                            F7 = Xa.shift();
                        var G7 = H(E7, 3, F7);
                        var H7 = y(z7, 8, G7),
                            I7 = Xa.shift(),
                            J7 = H(H7, 9, I7),
                            K7 = Xa.shift(),
                            L7 = H(J7, 10, K7),
                            M7 = Xa.shift(),
                            N7 = H(L7, 11, M7),
                            O7 = Xa.shift();
                        let Tm = H(N7, 12, O7),
                            NF = x(Tm, dU, 8);
                        F(Tm, 5) !== 1 && F(Tm, 6) !== 1 && NF ? .l() !== 1 && NF ? .A() !== 1 || (e = !0);
                        let OF = x(Tm, dU, 8) ? .g();
                        OF !== 1 && OF !== 2 || (f = !0)
                }
            }
        }
        return {
            wn: d,
            yj: e,
            Hi: f
        }
    }
    var Q5 = class extends Gs {
        constructor(a) {
            ({
                timeoutMs: b
            } = {});
            var b;
            super();
            this.caller = new WO(a, "__gppLocator", c => typeof c.__gpp === "function", L5);
            this.caller.D.set("addEventListener", H5);
            this.caller.C.set("addEventListener", J5);
            this.caller.D.set("removeEventListener", I5);
            this.caller.C.set("removeEventListener", K5);
            this.timeoutMs = b ? ? 500
        }
        j() {
            this.caller.dispose();
            super.j()
        }
        addEventListener(a) {
            var b = xi(() => {
                    a(N5, !0)
                }),
                c = this.timeoutMs === -1 ? void 0 : setTimeout(() => {
                    b()
                }, this.timeoutMs);
            VO(this.caller, "addEventListener", {
                listener: (d, e) => {
                    clearTimeout(c);
                    try {
                        if (d.pingData ? .gppVersion === void 0 || d.pingData.gppVersion === "1" || d.pingData.gppVersion === "1.0") {
                            this.removeEventListener(d.listenerId);
                            var f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 1,
                                    gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                    applicableSections: [-1]
                                }
                            }
                        } else Array.isArray(d.pingData.applicableSections) ? f = d : (this.removeEventListener(d.listenerId), f = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 2,
                                gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                                applicableSections: [-1]
                            }
                        });
                        a(f, e)
                    } catch {
                        if (d ? .listenerId) try {
                            this.removeEventListener(d.listenerId)
                        } catch {
                            a(O5, !0);
                            return
                        }
                        a(P5, !0)
                    }
                }
            })
        }
        removeEventListener(a) {
            VO(this.caller, "removeEventListener", {
                listener: () => {},
                listenerId: a
            })
        }
    };
    const P5 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        N5 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        O5 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function R5(a) {
        return !a || a.length === 1 && a[0] === -1
    };

    function S5(a) {
        a = new Q5(a);
        if (!TO(a.caller)) return Promise.resolve(null);
        var b = Hz(),
            c = Mz(b, 35);
        if (c) return Promise.resolve(c);
        var d = new Promise(e => {
            e = {
                resolve: e
            };
            var f = Mz(b, 36, []);
            f.push(e);
            Nz(b, 36, f)
        });
        c || c === null || (Nz(b, 35, null), a.addEventListener(e => {
            if (e.pingData.signalStatus === "ready" || R5(e.pingData.applicableSections)) {
                e = e.pingData;
                Nz(b, 35, e);
                for (let f of Mz(b, 36, [])) f.resolve(e);
                Nz(b, 36, [])
            }
        }));
        return d
    };

    function T5(a) {
        a = new pP(a, {
            timeoutMs: -1,
            md: !0
        });
        if (!lP(a)) return Promise.resolve(null);
        var b = Hz(),
            c = Rz(b);
        if (c) return Promise.resolve(c);
        var d = new Promise(e => {
            e = {
                resolve: e
            };
            var f = Mz(b, 25, []);
            f.push(e);
            Nz(b, 25, f)
        });
        c || c === null || (Nz(b, 24, null), a.addEventListener(e => {
            if (fP(e)) {
                Nz(b, 24, e);
                for (let f of Mz(b, 25, [])) f.resolve(e);
                Nz(b, 25, [])
            } else Nz(b, 24, null)
        }));
        return d
    };
    const U5 = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.Jb({
                    Xd: c ? ? void 0,
                    Vi: d ? void 0 : 2
                })
            })
        },
        V5 = {
            Bf: a => a.Jb,
            qe: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            Jd: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    Xd: b.returnValue ? ? void 0,
                    Vi: b.success ? void 0 : 2
                })
            }
        };

    function W5(a) {
        a = v(a.data) ? JSON.parse(a.data) : a.data;
        return {
            payload: a,
            Nh: a.__uspapiReturn.callId
        }
    }

    function X5(a, b) {
        var c = {};
        if (TO(a.caller)) {
            var d = xi(() => {
                b(c)
            });
            VO(a.caller, "getDataWithCallback", {
                Jb: e => {
                    e.Vi || (c = e.Xd);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    }
    var Y5 = class extends Gs {
        constructor(a) {
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new WO(a, "__uspapiLocator", b => typeof b.__uspapi === "function", W5);
            this.caller.D.set("getDataWithCallback", U5);
            this.caller.C.set("getDataWithCallback", V5)
        }
        j() {
            this.caller.dispose();
            super.j()
        }
    };

    function Z5(a) {
        var b = new Y5(a);
        return new Promise(c => {
            X5(b, d => {
                d && v(d.uspString) ? c(d.uspString) : c(null)
            })
        })
    }

    function $5(a, {
        zn: b,
        Fn: c,
        Ql: d
    }) {
        var e = new mT;
        var f = U(Jw) ? ef(d, 5) != null ? d.ha() : ef(b, 5) != null ? b.ha() : a.ha() : ef(b, 5) != null ? b.ha() : a.ha();
        e = kT(e, f);
        f = ef(b, 17) != null ? B(b, 17) : B(a, 17);
        e = rf(e, 17, f);
        a = ef(a, 14);
        a = rf(e, 14, a);
        f = ef(b, 3);
        a = rf(a, 3, f);
        f = Gd(ve(b, 2));
        a = If(a, 2, f);
        f = Gd(ve(b, 4));
        a = If(a, 4, f);
        f = gd(ve(b, 7));
        a = Kf(a, 7, f);
        b = ef(b, 9);
        b = rf(a, 9, b);
        a = Gd(ve(c, 1));
        b = If(b, 1, a);
        c = ef(c, 13);
        c = rf(b, 13, c);
        b = Gd(ve(d, 11));
        c = If(c, 11, b);
        b = df(d, 10);
        c = Ne(c, 10, b, ld);
        lT(c, ef(d, 12));
        return e
    }
    async function a6(a, {
        Ya: b = !1,
        gm: c
    }) {
        var [d, e, f] = await Promise.all([T5(a.pubWin), Z5(a.pubWin), S5(a.pubWin)]), g = kT(new mT, !b);
        c = rf(g, 14, c && navigator.globalPrivacyControl);
        c = rf(c, 17, !0);
        g = new mT;
        if (d) {
            var h = kT(g, gP(d, {
                idpcApplies: b
            }));
            h = If(h, 2, d.tcString);
            h = If(h, 4, d.addtlConsent || "");
            h = Kf(h, 7, d.internalErrorState);
            var k = !jP(d);
            h = rf(h, 9, k);
            rf(h, 17, d.gdprApplies ? d.vendor ? d.vendor.disclosedVendors === void 0 ? !0 : iP(d.vendor.consents, "755") || iP(d.vendor.legitimateInterests, "755") || iP(d.vendor.disclosedVendors,
                "755") : !1 : !0);
            d.gdprApplies != null && rf(g, 3, d.gdprApplies)
        }
        h = new mT;
        if (e) {
            k = If(h, 1, e);
            var l = e.toUpperCase();
            if (l.length == 4 && (l.indexOf("-") == -1 || l.substring(1) === "---") && l[0] >= "1" && l[0] <= "9" && yT.hasOwnProperty(l[1]) && yT.hasOwnProperty(l[2]) && yT.hasOwnProperty(l[3])) {
                var m = new xT;
                m = uf(m, 1, parseInt(l[0], 10));
                m = H(m, 2, yT[l[1]]);
                m = H(m, 3, yT[l[2]]);
                l = H(m, 4, yT[l[3]])
            } else l = null;
            l = l ? .Pl() === 2;
            rf(k, 13, l)
        }
        k = new mT;
        if (f)
            if (f.internalErrorState) If(k, 11, f.gppString);
            else if (R5(f.applicableSections)) lT(Ne(k, 10, f.applicableSections,
            ld), !1), U(Jw) && kT(k, !0);
        else if (l = Ne(k, 10, f.applicableSections, ld), If(l, 11, f.gppString), U(Jw)) try {
            let q = M5(f.gppString, f.applicableSections, {
                idpcApplies: b,
                supportTcfeu: !0,
                supportUsnatV2: !0
            });
            var n = lT(kT(k, q.wn), q.yj);
            rf(n, 16, q.Hi)
        } catch (q) {
            AA(1182, q), b = lT(kT(k, !b), !1), rf(b, 16, !1)
        } else try {
            let q = M5(f.gppString, f.applicableSections, {
                idpcApplies: b,
                supportUsnatV2: !0
            });
            var p = lT(k, q.yj);
            rf(p, 16, q.Hi)
        } catch (q) {
            AA(1182, q), b = lT(k, !1), rf(b, 16, !1)
        }
        a.P = $5(c, {
            zn: g,
            Fn: h,
            Ql: k
        })
    };
    var b6 = xh(class extends J {
        g() {
            return B(this, 1)
        }
    });
    async function P7(a) {
        var b = um(),
            c = a.pageState;
        PA(f => {
            F(f, 1) === 0 && (f = sf(f, 2, !!c.OSCLM.UWEfJ), f = sf(f, 6, !!c.OmOVT), H(f, 1, 1))
        });
        LV(a.pubWin, Q7(c.OSCLM));
        R7(a.I.google_ad_client);
        PA(f => {
            F(f, 1) === 1 && H(f, 1, 2)
        });
        var d = new cP(a.pubWin);
        await ($O(d, (c.SLqBY || "") === ".google.cn") ? aP(d) : Promise.resolve(null));
        PA(f => {
            F(f, 1) === 2 && (f = sf(f, 3, !0), H(f, 1, 3))
        });
        await a6(a, {
            Ya: c.OSCLM.UWEfJ,
            gm: c.OSCLM.YguOd
        });
        var e = um();
        PA(f => {
            if (F(f, 1) === 3) {
                f = sf(f, 3, e - b > 500);
                var g = !!a.P ? .g();
                f = sf(f, 4, g);
                g = !!a.P ? .ha();
                f = sf(f, 5, g);
                g = !!a.P ? .l();
                f = sf(f, 7, g);
                g = !!a.P ? .A();
                f = sf(f, 8, g);
                H(f, 1, 4)
            }
        })
    }

    function Q7(a) {
        var b = wg(b6());
        b = rf(b, 1, a.UWEfJ);
        b = rf(b, 2, a.YguOd);
        a = rf(b, 3, a.SVQEK);
        return pe(a)
    }

    function R7(a) {
        var b = sl(r.top, "googlefcPresent");
        r.googlefc && !b && zA("adsense_fc_has_namespace_but_no_iframes", {
            publisherId: a
        }, 1)
    };
    var S7 = M0(async function(a) {
        return P7(a.Ge)
    }, {
        id: 1404
    });

    function T7(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    }

    function U7(a) {
        if (a === a.top || Qk(a.top)) return Promise.resolve({
            status: 4
        });
        a: {
            try {
                var b = (a.top ? .frames ? ? {}).google_ads_top_frame;
                break a
            } catch (d) {}
            b = null
        }
        if (!b) return Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && T7(a.document.referrer)) return Promise.resolve({
            status: 3
        });
        var c = new XV;
        a = new MessageChannel;
        a.port1.onmessage = d => {
            d.data.msgType === "__goog_top_url_resp" && c.resolve({
                Mc: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };

    function V7(a) {
        var b = um();
        return Promise.race([U7(a), Dl(200)]).then(c => {
            zA("afc_etu", {
                etus: c ? .status ? ? 100,
                sig: um() - b,
                tms: 200
            });
            return c ? .Mc
        })
    }
    var W7 = M0(async function(a, b) {
        return V7(b)
    }, {
        id: 1411
    });
    var X7 = Y(function(a, b, c, d) {
        a = 0;
        Uk(b) !== b && (a |= 4);
        BX(b.document) === 3 && (a |= 32);
        var e;
        if (e = c) e = hs(c), e = !(ms(c).scrollWidth <= e);
        e && (a |= 1024);
        b.Prototype ? .Version && (a |= 16384);
        d && (a |= d);
        return {
            gf: a
        }
    }, {
        id: 1379,
        H: {
            gf: void 0
        }
    });
    var Y7 = Y(function(a) {
        var b = a.Ge;
        b.Mc = a.Mc || "";
        return {
            rn: b
        }
    }, {
        id: 1406,
        H: {
            rn: void 0
        }
    });

    function Z7(a, b, c, d) {
        var e = new XV,
            f = "",
            g = k => {
                try {
                    let l = typeof k.data === "object" ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (hk(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
                } catch (l) {}
            };
        var h = typeof a.gmaSdk ? .getQueryInfo === "function" ? a.gmaSdk : void 0;
        if (h) return gk(a, "message", g), f = c(h), e.promise;
        c = typeof a.webkit ? .messageHandlers ? .getGmaQueryInfo ? .postMessage === "function" || typeof a.webkit ? .messageHandlers ? .getGmaSig ? .postMessage === "function" ? a.webkit.messageHandlers : void 0;
        return c ?
            (f = String(Math.floor(bl() * 2147483647)), gk(a, "message", g), b(c, f), e.promise) : null
    }

    function $7(a) {
        return Z7(a, (b, c) => void(b.getGmaQueryInfo ? ? b.getGmaSig) ? .postMessage(c), b => b.getQueryInfo(), b => b.signal)
    }(function(a) {
        return pc(b => {
            if (!tc(b)) return !1;
            for (let [c, d] of Object.entries(a)) {
                let e = c,
                    f = d;
                if (!(e in b)) {
                    if (f.jm === !0) continue;
                    return !1
                }
                if (!f(b[e])) return !1
            }
            return !0
        })
    })({
        vc: v,
        pn: v,
        eid: yc(),
        vnm: yc(),
        js: v
    }, "RawGmaSdkStaticSignalObject");

    function a8(a) {
        var b = V($u);
        if (b <= 0) return null;
        var c = um(),
            d = $7(a.pubWin);
        if (!d) return null;
        a.l = "0";
        return Promise.race([d, Dl(b, "0")]).then(e => {
            zA("adsense_paw", {
                time: um() - c
            });
            e ? .length > 1E4 ? AA(809, Error(`ML:${e.length}`)) : a.l = e
        }).catch(e => {
            AA(809, e)
        })
    }
    var b8 = M0(async function(a) {
        return a8(a.Ge)
    }, {
        id: 1405
    });
    var c8 = class extends S0 {
        constructor(a, b, c, d) {
            super(a);
            var e = b.I.google_loader_features_used;
            e = Z(this, X7, {}, b.pubWin, b.K, e ? e : null);
            d && X(e, d);
            ({
                Wj: e
            } = Z(this, G5, {
                gf: e.gf
            }, b));
            var f = P0(this, S7, {
                    Ge: e
                }),
                g = P0(this, W7, {}, b.pubWin);
            X(g, f.complete);
            d = P0(this, b8, {
                Ge: e
            });
            X(d, f.complete);
            e = Z(this, Y7, {
                Ge: e,
                Mc: g.output
            });
            X(e, d.complete);
            this.g = Q0(this, new F5(a, b, e.finished, c)).g
        }
    };
    var d8 = Y(function(a, b) {
        j_(13, b);
        j_(11, b);
        return {}
    }, {
        id: 1486,
        H: {}
    });
    var e8 = Y(function(a, b, c) {
        b.googFloatingToolbarManagerAsyncPositionUpdate = !0;
        c && c !== b && (c.googFloatingToolbarManagerAsyncPositionUpdate = !0);
        return {}
    }, {
        id: 1483,
        H: {}
    });
    var f8 = Y(function() {
        return lr() || Ua() ? {
            Ia: !0,
            zg: new IY
        } : {
            Ia: new IY,
            zg: !0
        }
    }, {
        id: 1502,
        H: {
            Ia: void 0,
            zg: void 0
        }
    });

    function g8() {
        if (!r.IntersectionObserver) return {
            hidden: 0,
            visible: -1
        };
        var a = V(dv),
            b = V(ev);
        return {
            hidden: 0,
            visible: Vk() ? a : b
        }
    };
    var h8 = Y(function(a, b) {
        var c = b.da,
            d = b.I;
        a = b.pubWin;
        b = b.K;
        var e = g8().visible;
        if (!c || e < 0 || !os(d.google_reactive_ad_format) && (nY(d) || d.google_reactive_ads_config) || !mX(c) || oX(b, a, c) <= e) return {
            Ia: !0,
            Je: new IY
        };
        b = Hz();
        c = Mz(b, 8, {});
        b = Mz(b, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        a = !!a.google_apltlad;
        return c[d] || b[d] || a ? {
            Ia: new IY,
            Je: !0
        } : {
            Ia: !0,
            Je: new IY
        }
    }, {
        id: 1499,
        H: {
            Ia: void 0,
            Je: void 0
        }
    });
    var i8 = Y(function(a, b, c) {
        a = g8();
        return a.hidden < 0 && a.visible < 0 || !c ? {
            Ia: !0,
            Bg: new IY
        } : {
            Ia: new IY,
            Bg: !0
        }
    }, {
        id: 1491,
        H: {
            Ia: void 0,
            Bg: void 0
        }
    });
    var j8 = Y(function(a) {
        return a.result
    }, {
        id: 1498,
        H: {
            Qb: void 0,
            Ag: void 0
        }
    });
    var k8 = Y(function(a) {
        return a.result
    }, {
        id: 1496,
        H: {
            Qb: void 0,
            Ia: void 0
        }
    });
    var l8 = M0(async function(a, b, c) {
        c.notify();
        return new Promise(d => {
            b.da.addEventListener("adsbygoogle-close-to-visible-event", () => {
                d(!0)
            })
        })
    }, {
        id: 1501
    });
    var m8 = M0(async function(a, b, c) {
        c.notify();
        return new Promise(d => {
            var e = b.da,
                f = g8().visible;
            f = new r.IntersectionObserver((g, h) => {
                bb(g, k => {
                    k.intersectionRatio <= 0 || (h.unobserve(k.target), d(!0))
                })
            }, {
                rootMargin: `${f*100}%`
            });
            b.B = f;
            f.observe(e)
        })
    }, {
        id: 1500
    });
    var n8 = M0(async function(a, b, c) {
        var d = b.pubWin.document,
            e = BX(d) === 3;
        return new Promise(f => {
            e ? (c.notify(), DX(xA(332, () => {
                f({
                    Qb: !0,
                    Ag: new IY
                })
            }), d)) : f({
                Qb: new IY,
                Ag: !0
            })
        })
    }, {
        id: 1494
    });
    var o8 = M0(async function(a, b, c) {
        var d = b.I,
            e = b.pubWin;
        if (!d.google_pause_ad_requests) return !0;
        c.notify();
        var f = r.setTimeout(() => {
            zA("abg:cmppar", {
                client: d.google_ad_client,
                url: d.google_page_url
            })
        }, 1E4);
        return new Promise(g => {
            var h = xA(450, () => {
                d.google_pause_ad_requests = !1;
                r.clearTimeout(f);
                e.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", h);
                g(!0)
            });
            e.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", h)
        })
    }, {
        id: 1492
    });
    var p8 = M0(async function(a, b, c, d) {
        return new Promise(e => {
            var f = b.pubWin,
                g = b.K,
                h = b.da,
                k = f.document;
            if (CX(k))
                if (oX(g, f, h) <= g8().hidden) e({
                    Qb: new IY,
                    Ia: !0
                });
                else {
                    var l = xA(332, () => {
                        !CX(k) && l && (hk(k, d, l), e({
                            Qb: !0,
                            Ia: new IY
                        }), l = null)
                    });
                    gk(k, d, l) ? c.notify() : e({
                        Qb: new IY,
                        Ia: !0
                    })
                }
            else e({
                Qb: !0,
                Ia: new IY
            })
        })
    }, {
        id: 1493
    });
    var q8 = class extends S0 {
        constructor(a, b, c) {
            super(a);
            this.g = new TY;
            a = X(Z(this, f8, {}), c);
            c = X(P0(this, o8, {}, b, this.g), a.zg);
            c = X(P0(this, n8, {}, b, this.g), c.output);
            var d = Z(this, j8, {
                result: c.output
            });
            c = b.pubWin.document;
            var e;
            c.visibilityState ? e = "visibilitychange" : c.mozVisibilityState ? e = "mozvisibilitychange" : c.webkitVisibilityState && (e = "webkitvisibilitychange");
            c = e;
            e = X(Z(this, i8, {}, b, c), d.Ag);
            c = X(P0(this, p8, {}, b, this.g, c), e.Bg);
            c = Z(this, k8, {
                result: c.output
            });
            d = new UY([d.Qb, c.Qb]);
            d = X(Z(this, h8, {}, b), d);
            var f = X(P0(this, m8, {}, b, this.g), d.Je);
            b = X(P0(this, l8, {}, b, this.g), d.Je);
            b = new UY([f.output, b.output]);
            this.Oh = new UY([a.Ia, e.Ia, d.Ia, c.Ia, b])
        }
    };
    var r8 = Y(function(a, b, c, d) {
        var e = Hz(),
            f = Mz(e, 23, !1);
        f || Nz(e, 23, !0);
        if (!f) {
            a = a.Nl;
            try {
                var g = a ? GJ(a) : null
            } catch (h) {
                g = null
            }
            b = new uT(b, d.google_ad_client, g, !!c.OSCLM ? .UWEfJ, c.OmOVT);
            b.j = !0;
            c = b.A;
            if (b.j && (d = b.g, b.l && !DO(c) ? (g = new hT, g = Kf(g, 1, 1)) : g = null, g)) {
                g = xg(g);
                try {
                    d.localStorage.setItem("google_auto_fc_cmp_setting", g)
                } catch (h) {}
            }
            d = DO(c) && (b.l || b.C);
            c && d && GO(new HO(b.g, new sP(b.g, b.B), c, new EC(b.g)))
        }
        return {}
    }, {
        id: 1485,
        H: {}
    });
    var s8 = Y(function(a, b) {
        a = a.zb;
        b.zb = a;
        return {
            zb: a
        }
    }, {
        id: 1484,
        H: {
            zb: void 0
        }
    });
    var t8 = Y(function(a, b, c) {
        a = c.google_tag_partner;
        b = (a ? [a] : []).concat(eA(b).tag_partners || []).join("+");
        c.google_tag_partner = b;
        return {}
    }, {
        id: 1444,
        H: {}
    });
    var u8 = Y(function(a, b, c) {
        b && dY(b, oi(c.ll, new Map(Object.entries(AX()))));
        return {}
    }, {
        id: 1447,
        H: {}
    });
    var v8 = Y(function(a, b) {
        a = b.I;
        a.google_ad_output == null && (a.google_ad_output = "html");
        a.google_ad_client != null && (a.google_ad_client = Xr(String(a.google_ad_client)));
        a.google_ad_slot != null && (a.google_ad_slot = String(a.google_ad_slot));
        a.google_ad_section = a.google_ad_section || a.google_ad_region || "";
        a.google_country = a.google_country || a.google_gl || "";
        var c = (new Date).getTime(),
            d = "google_color_bg google_color_text google_color_link google_color_url google_color_border google_color_line".split(" ");
        for (let f of d)
            if (Array.isArray(a[f])) {
                d =
                    b;
                var e = a[f];
                d.j |= 2;
                a[f] = e[c % e.length]
            }
        return {}
    }, {
        id: 1446,
        H: {}
    });
    var w8 = Y(function(a, b, c, d, e, f) {
        wA(326, () => {
            if (Ur(d) === 1) {
                var g = U(dx);
                if ((g || U(cx)) && b === c) {
                    var h = new Ml;
                    let m = new Nl;
                    var k = h.setCorrelator(Cl(b));
                    var l = k_(b);
                    k = Jf(k, 5, l);
                    H(k, 2, 1);
                    h = y(m, 1, h);
                    k = new Ll;
                    k = sf(k, 10, !0);
                    l = U(Yw);
                    k = sf(k, 8, l);
                    l = U(Zw);
                    k = sf(k, 12, l);
                    l = U(bx);
                    k = sf(k, 7, l);
                    l = U(ax);
                    k = sf(k, 13, l);
                    y(h, 2, k);
                    b.google_rum_config = $d(m);
                    gl(b.document, f.xujKL && g ? e.Wm : e.Xm)
                } else Bm(uA)
            }
        });
        return {}
    }, {
        id: 1443,
        H: {}
    });
    var x8 = Y(function(a, b, c) {
        if (!b || eA(b).ads_density_stats_processed || lr(b)) return {};
        eA(b).ads_density_stats_processed = !0;
        if (U(Pv) || bl() < .01) {
            let d = () => {
                if (b) {
                    var e = PR(KR(b), c.google_ad_client, b.location.hostname, k_(c).split(","));
                    zA("ama_stats", e, 1)
                }
            };
            ik(b, () => {
                r.setTimeout(d, 1E3)
            })
        }
        return {}
    }, {
        id: 1445,
        H: {}
    });
    var y8 = Y(function(a, b) {
        nY(b) && (vX() && (b.google_adtest = b.google_adtest || "on"), b.google_pgb_reactive = b.google_pgb_reactive || 3);
        return {}
    }, {
        id: 1448,
        H: {}
    });
    var z8 = Y(function(a, b) {
        a = b.google_start_time;
        qc(a) && (Yr = a, b.google_start_time = null);
        return {}
    }, {
        id: 1463,
        H: {}
    });
    var A8 = class extends S0 {
        constructor(a, b, c) {
            super(a);
            this.g = new TY;
            var d = c.zb;
            c = c.Oh;
            var e = Z(this, w8, {}, b.pubWin, b.K, b.I, b.Oa, b.pageState);
            c && X(e, c);
            c = X(Z(this, t8, {}, b.pubWin, b.I), e.finished);
            c = X(Z(this, x8, {}, b.K, b.I), c.finished);
            c = X(Z(this, z8, {}, b.I), c.finished);
            c = X(Z(this, v8, {}, b), c.finished);
            c = X(Z(this, u8, {}, b.K, b.Oa), c.finished);
            c = X(Z(this, y8, {}, b.I), c.finished);
            this.g = Q0(this, new c8(a, b, d, c.finished)).g
        }
    };
    var B8 = class extends S0 {
        constructor(a, b, c) {
            super(a);
            this.g = new PY;
            if (/_sdo/.test(b.I.google_ad_format)) KY(this.g, null);
            else {
                var d = Z(this, d8, {}, b.pubWin);
                X(d, c);
                var e = new PY;
                c = new PY;
                OY(e, b.pageState.EGzMj);
                OY(c, b.pageState.tYcft);
                d = X(Z(this, s8, {
                    zb: e
                }, b), d.finished);
                c = X(Z(this, r8, {
                    Nl: c
                }, b.pubWin, b.pageState, b.I), d.finished);
                c = X(Z(this, e8, {}, b.pubWin, b.K), c.finished);
                c = Q0(this, new q8(a, b, c.finished));
                a = Q0(this, new A8(a, b, {
                    zb: d.zb,
                    Oh: c.Oh
                }));
                this.g = new UY([c.g, a.g], !0)
            }
        }
    };
    var C8 = Y(function(a, b, c, d, e, f) {
        var g = a.Ib,
            h = d(b, c.stavq, c.jTCuI, c.xVQAt || "");
        f.google_sa_impl = k => e({
            Oa: h,
            Tc: b,
            slot: k,
            pageState: c,
            Ib: g
        });
        f.google_process_slots ? .();
        return {}
    }, {
        id: 1338,
        H: {}
    });
    var D8 = Y(function(a, b) {
        a = (b.Prototype || {}).Version;
        a != null && zA("prtpjs", {
            version: a
        });
        return {}
    }, {
        id: 1339,
        H: {}
    });
    var E8 = class extends z_ {
        constructor(a) {
            super();
            this.promise = a;
            a.then(b => {
                this.value = b
            })
        }
        g() {
            return Promise.race([this.promise, Dl(V(Gu), null)]).then(a => {
                this.value = a
            })
        }
    };
    var F8 = Y(function() {
        return U(Su) ? {
            Ib: new E8(navigator.getBattery ? .() ? ? Promise.resolve(null))
        } : {
            Ib: new E8(Promise.resolve(null))
        }
    }, {
        id: 1413,
        H: {
            Ib: void 0
        }
    });
    var G8 = ni `https://pagead2.googlesyndication.com/pagead/s/eeframe.html`;
    var H8 = Y(function(a) {
        var b = !1,
            c = !1;
        for (let d of zk(a.Ce)) Mf(d, 5) && (c = !0, B(d, 4) && (b = !0));
        if (!b && !a.P.ha() || !c) return {
            L: void 0
        };
        a = document.createElement("iframe");
        a.name = "goog_ee_frame";
        a.style.display = "none";
        dj(a, G8);
        document.documentElement.appendChild(a);
        return {
            L: a
        }
    }, {
        id: 1389,
        H: {
            L: void 0
        }
    });
    var I8 = Y(function(a) {
        return (a = a.kn) ? {
            ye: zk(a).map(b => {
                var c = Mf(b, 2) ? C(b, Ce(b, Nf, 2)) : C(b, Ce(b, Nf, 5)),
                    d = b.jb();
                c = c && (c.startsWith(location.protocol) || c.startsWith("data:") && c.length <= 80) ? $h(c === null ? "null" : c === void 0 ? "undefined" : c) : void 0;
                return {
                    dl: d,
                    url: c,
                    fm: B(b, 4),
                    dm: Mf(b, 5)
                }
            })
        } : {
            ye: []
        }
    }, {
        id: 1040,
        H: {
            ye: void 0
        }
    });
    var K8 = Y(J8, {
        id: 1041,
        H: {}
    });

    function J8(a, b, c) {
        if (!a.U) return {};
        yZ().set(a.U, a.P, b) && a.U.g() && uZ(27, a.U.jb(), null, {}, c);
        return {}
    };
    var L8 = Y(function(a) {
        return BZ(a.U) !== 0 ? {
            U: a.U
        } : {
            U: new IY
        }
    }, {
        id: 1036,
        H: {
            U: void 0
        }
    });

    function M8(a, b) {
        a.g() && (b = oi(b, {
            gdpr: "1"
        }));
        var c = C(a, 2);
        c && (b = oi(b, {
            gdpr_consent: c
        }));
        (c = C(a, 11)) && (b = oi(b, {
            gpp: c
        }));
        (a = df(a, 10).map(d => d.toString()).join(",")) && (b = oi(b, {
            gpp_sid: a
        }));
        return b.toString()
    }
    var N8 = M0(async function(a, b, c, d) {
        if (c) {
            var e = a.U.jb();
            b = M8(a.P, b);
            uZ(59, e, null, {
                url: b
            }, d);
            var f = (new URL(G8.toString())).origin;
            c = lW({
                destination: window,
                L: c,
                origin: f,
                Ob: "echo-endpoint-channel"
            });
            var {
                data: g
            } = await c.j({
                id: e,
                url: b
            });
            switch (g.kind) {
                case 0:
                    window.googletag ? .secureSignalProviders ? .push({
                        id: e,
                        collectorFunction: () => Promise.resolve(g.data)
                    });
                    break;
                case 1:
                    return uZ(60, e, g.error, {}, d), a.U.setError(Fk(114));
                default:
                    Rc(g, void 0)
            }
        }
    }, {
        id: 1391
    });
    var O8 = M0(async function(a, b, c, d) {
        var e = a.U.jb(),
            f = b.toString();
        uZ(30, e, null, {
            url: f
        }, d);
        var g = document.createElement("script");
        g.setAttribute("esp-signal", "true");
        fj(g, b);
        var {
            promise: h,
            resolve: k
        } = ka(Promise, "withResolvers").call(Promise), l = () => {
            uZ(31, e, null, {
                url: f
            }, d);
            k(a.U.setError(Fk(109)));
            hk(g, "error", l)
        };
        document.head.appendChild(g);
        gk(g, "error", l);
        return h
    }, {
        id: 1035
    });
    var P8 = Y(function(a, b, c, d, e, f) {
        ({
            U: a
        } = yZ().get(b, d, c, f));
        if (a) return {
            eb: a,
            Ma: new IY("CACHED_ENTRY")
        };
        a = Jk(Hk(b));
        return {
            eb: a,
            Ma: a.setError(Fk(100))
        }
    }, {
        id: 1027,
        H: {
            eb: void 0,
            Ma: void 0
        }
    });
    var R8 = Y(Q8, {
        id: 1028,
        H: {
            gb: void 0
        }
    });

    function Q8(a, b) {
        var c = a.U.jb();
        bf(a.U, 3) != null || uZ(35, c, null, {}, b);
        return {
            gb: a.U
        }
    };
    var S8 = class extends S0 {
        constructor(a, b, c, d, e, f, g, h) {
            super(g);
            var k = Z(this, P8, {}, a, c, f, g, h);
            O0(this, k);
            a = new PY;
            KY(a, f);
            Z(this, K8, {
                U: k.Ma,
                P: a
            }, c, h);
            f = Z(this, L8, {
                U: k.eb
            });
            f = Z(this, R8, {
                U: f.U
            }, h);
            d ? {
                output: b
            } = P0(this, N8, {
                U: f.gb,
                P: a
            }, b, e, h) : {
                output: b
            } = P0(this, O8, {
                U: f.gb
            }, b, g, h);
            Z(this, K8, {
                U: b,
                P: a
            }, c, h)
        }
    };
    var T8 = new Set,
        U8 = Y(function(a, b, c, d, e) {
            var f = a.ye;
            c = a.Pb;
            a = a.zl;
            if (!f ? .length) return {};
            var g = c.ha();
            for (let {
                    dl: h,
                    url: k,
                    fm: l,
                    dm: m
                } of f) {
                if (!k || !g && !l || T8.has(k.toString())) continue;
                T8.add(k.toString());
                f = new S8(h, k, l, m, a, c, b, e);
                Hs(d, f);
                R0(f)
            }
            return {}
        }, {
            id: 813,
            H: {}
        });
    var V8 = class extends S0 {
        constructor(a, b, c, d) {
            super(a);
            this.l = b;
            this.g = c;
            ({
                L: b
            } = Z(this, H8, {
                P: this.g,
                Ce: this.l
            }));
            ({
                ye: c
            } = Z(this, I8, {
                kn: this.l
            }));
            Z(this, U8, {
                ye: c,
                Pb: this.g,
                zl: b
            }, a, {}, this, d)
        }
    };
    var W8 = Y(function(a) {
        var b = a.P;
        if (a = a.Zc)
            for (var c of a)
                for (let d of zk(c)) B(d, 4) && CZ(yZ(), d.jb(), b, !0);
        if (b.ha()) {
            if (b) {
                c = rZ(b) ? ? [];
                for (let d of c) d.startsWith("_GESPSK") && lZ(d, b)
            }
            zZ = new AZ
        }
        return {}
    }, {
        id: 1094,
        H: {}
    });
    var X8 = Y(function(a, b, c) {
        var d = a.U;
        a = e => {
            uZ(e, d.jb(), null, {
                tic: String(Math.round((Date.now() - IG(cf(d, 3))) / 6E4))
            }, c)
        };
        switch (BZ(d)) {
            case 0:
                return a(24), {
                    hc: new IY("FRESH_ENTRY"),
                    Jc: new IY("FRESH_ENTRY")
                };
            case 1:
                return a(25), {
                    hc: new IY("STALE_ENTRY"),
                    Jc: d
                };
            case 2:
                return a(26), {
                    hc: d,
                    Jc: new IY("EXPIRED_ENTRY")
                };
            case 3:
                return uZ(9, d.jb(), null, {}, c), {
                    hc: d,
                    Jc: new IY("ERROR_ENTRY")
                };
            case 4:
                return a(23), {
                    hc: d,
                    Jc: new IY("NEW_ENTRY")
                };
            default:
                return {
                    hc: new IY("DEFAULT_ENTRY"),
                    Jc: new IY("DEFAULT_ENTRY")
                }
        }
    }, {
        id: 1048,
        H: {
            hc: void 0,
            Jc: void 0
        }
    });
    var Z8 = Y(Y8, {
        id: 1046,
        H: {
            gb: void 0
        }
    });

    function Y8(a) {
        return {
            gb: a.eb
        }
    };
    var $8 = Y(function(a) {
        var b = a.Di;
        a = a.U;
        return b.Ma ? {
            gi: a.setError(b.Ma),
            eb: new IY,
            signal: new IY
        } : {
            eb: b.eb,
            gi: new IY,
            signal: b.signal
        }
    }, {
        id: 1479,
        H: {
            eb: void 0,
            gi: void 0,
            signal: void 0
        }
    });

    function a9(a) {
        return v(a) ? a : a instanceof Error ? a.message : null
    }
    var b9 = M0(async function(a, b, c) {
        var d = um(),
            e = Gd(ve(a.U, 1));
        uZ(18, e, null, {}, c);
        try {
            return b().then(f => {
                uZ(29, e, null, {
                    delta: String(um() - d)
                }, c);
                return {
                    eb: If(a.U, 2, f),
                    Ma: null,
                    signal: f
                }
            }).catch(f => {
                uZ(28, e, a9(f), {}, c);
                return {
                    eb: null,
                    Ma: Fk(106),
                    signal: null
                }
            })
        } catch (f) {
            return uZ(1, e, a9(f), {}, c), {
                eb: null,
                Ma: Fk(107),
                signal: null
            }
        }
    }, {
        id: 1478
    });
    var d9 = Y(c9, {
        id: 1050,
        H: {
            gb: void 0
        }
    });

    function c9(a, b, c) {
        var d = a.U.jb();
        if (a.signal == null) return uZ(41, d, null, {}, c), a.U.setError(Fk(111)), {
            gb: a.U
        };
        if (!v(a.signal)) return uZ(21, d, null, {}, c), {
            gb: a.U.setError(Fk(113))
        };
        if (a.signal.length > b) return uZ(12, d, null, {
            sl: String(a.signal.length)
        }, c), b = a.U.setError(Fk(108)), xe(b, 2), {
            gb: a.U
        };
        a.signal.length || uZ(20, d, null, {}, c);
        xe(a.U, 10);
        return {
            gb: a.U
        }
    };
    var e9 = class {
        constructor(a, b) {
            this.output = new TY;
            SY(this.output, a, c => void b.Ka({
                methodName: 1046,
                hb: c
            }))
        }
    };
    var f9 = class extends e9 {};
    var g9 = class extends S0 {
        constructor(a, b, c, d, e, f) {
            super(e);
            this.g = new PY;
            var g = Z(this, P8, {}, a, b, d, e),
                h = new PY;
            KY(h, d);
            Z(this, K8, {
                U: g.Ma,
                P: h
            }, b, f);
            d = Z(this, R8, {
                U: g.eb
            }, f);
            g = Z(this, X8, {
                U: d.gb
            }, e, f);
            d = P0(this, b9, {
                U: g.hc
            }, c, f);
            var {
                signal: k,
                eb: l,
                gi: m
            } = Z(this, $8, {
                Di: d.output,
                U: g.hc
            });
            Z(this, K8, {
                U: m,
                P: h
            }, b, f);
            d = Z(this, d9, {
                U: l,
                signal: k
            }, 1024, f);
            Z(this, K8, {
                U: d.gb,
                P: h
            }, b, f);
            e = new f9(wZ(), e);
            e = X(Z(this, Z8, {
                eb: g.Jc
            }), e.output);
            c = P0(this, b9, {
                U: e.gb
            }, c, f);
            ({
                eb: c
            } = Z(this, $8, {
                Di: c.output,
                U: e.gb
            }));
            Z(this, K8, {
                U: c,
                P: h
            }, b, f);
            b = d.gb.promise.then(n => ({
                id: a,
                collectorGeneratedData: n ? .l() ? ? null
            })).catch(() => ({
                id: a,
                collectorGeneratedData: null
            }));
            OY(this.g, b)
        }
    };
    var h9 = M0(async function(a, b, c, d, e) {
        var f = new HZ(a.Qf ? ? []),
            g = a.Db.id;
        d = a.Db.collectorFunction;
        var h = a.Db.networkCode ? ? g;
        f = !!g && !!EZ(f, g);
        if (!a.P.ha() && !f) return new IY("Storage consent not granted.");
        uZ(42, h, null, {
            ea: String(Number(b))
        }, e);
        a = new g9(h, f, d, a.P, c, e);
        R0(a);
        return a.g.promise
    }, {
        id: 1059
    });
    var i9 = Y(function(a, b, c, d = fZ, e) {
        if (!b) return uZ(39, "UNKNOWN_COLLECTOR_ID", null, {}, e), {
            Ma: Hk("UNKNOWN_COLLECTOR_ID").setError(Fk(110)),
            Db: new IY
        };
        if (typeof b !== "object") return uZ(46, "UNKNOWN_COLLECTOR_ID", null, {}, e), {
            Ma: Hk("UNKNOWN_COLLECTOR_ID").setError(Fk(112)),
            Db: new IY
        };
        a = b.id;
        c = b.networkCode;
        a && c && (delete b.id, uZ(47, `${a};${c}`, null, {}, e));
        a = c ? ? a;
        return v(a) ? typeof b.collectorFunction !== "function" ? (uZ(14, a, null, {}, e), {
            Ma: Hk(a).setError(Fk(105)),
            Db: new IY
        }) : d.Pi.includes(a) ? (uZ(22, a, null, {}, e), {
            Ma: Hk(a).setError(Fk(104)),
            Db: new IY
        }) : {
            Ma: null,
            Db: b
        } : (uZ(37, "INVALID_COLLECTOR_ID", null, {
            ii: JSON.stringify(a)
        }, e), {
            Ma: Hk("INVALID_COLLECTOR_ID").setError(Fk(102)),
            Db: new IY
        })
    }, {
        id: 1057,
        H: {
            Ma: void 0,
            Db: void 0
        }
    });

    function j9(a, b) {
        a.g.g.push(b)
    }
    var l9 = class {
        constructor(a, b, c, d = document, e, f, g = fZ, h) {
            this.A = b;
            this.J = c;
            this.C = d;
            this.T = e;
            this.D = f;
            this.l = g;
            this.j = h;
            this.G = [];
            this.O = [];
            this.g = new k9;
            this.B = 0;
            for (let k of a) this.push(k)
        }
        push(a) {
            this.J || this.T();
            var b = new S0(this.g);
            a = Z(b, i9, {}, a, this.g, this.l, this.j);
            var c = a.Db;
            Z(b, K8, {
                U: a.Ma,
                P: this.A
            }, void 0, this.j);
            a = P0(b, h9, {
                Db: c,
                P: this.A,
                Qf: void 0
            }, this.J, this.g, this.l, this.j).output.promise;
            R0(b);
            this.G.push(a);
            for (let d of this.O) a.then(d)
        }
        addOnSignalResolveCallback(a) {
            this.O.push(a);
            for (let b of this.G) b.then(a)
        }
        clearAllCache() {
            var a =
                this.C.currentScript instanceof HTMLScriptElement ? this.C.currentScript.src : "";
            if (this.B === 1) uZ(49, "", null, {
                url: a
            }, this.j);
            else if (this.l.Ji.includes(String(ou(a ? ? "")))) uZ(48, "", null, {
                url: a
            }, this.j);
            else {
                this.D && this.D();
                var b = new S0(this.g),
                    c = Z(b, W8, {
                        P: this.A,
                        Zc: void 0
                    }, this.g);
                R0(b);
                this.B = 1;
                setTimeout(() => {
                    this.B = 0
                }, this.l.Fi * 1E3);
                uZ(43, "", null, {
                    url: a
                }, this.j);
                return c.finished.promise
            }
        }
    };
    class k9 {
        constructor() {
            this.g = []
        }
        Ka(a) {
            this.g.forEach(b => void b.Ka(a))
        }
    }
    var m9 = class {
        constructor(a) {
            this.push = b => {
                a.push(b)
            };
            this.addOnSignalResolveCallback = b => {
                a.addOnSignalResolveCallback(b)
            };
            this.addErrorHandler = b => {
                j9(a, {
                    Ka: ({
                        methodName: c,
                        hb: d
                    }) => void b(c, d)
                })
            };
            this.clearAllCache = () => {
                a.clearAllCache()
            }
        }
    };

    function n9(a, b, c, d, e, f = fZ, g) {
        if (!o9(a, "encryptedSignalProviders", c) || !o9(a, "secureSignalProviders", c)) {
            uZ(38, "", null, {}, g);
            var h = {
                Ka: ({
                    methodName: k,
                    hb: l
                }) => void c(k, l)
            };
            p9(a, "encryptedSignalProviders", b, f, h, d, e, g);
            p9(a, "secureSignalProviders", b, f, h, () => {}, e, g)
        }
    }

    function o9(a, b, c) {
        a = b === "secureSignalProviders" ? a.secureSignalProviders : a.encryptedSignalProviders;
        if (a === void 0 || a instanceof Array) return !1;
        a.addErrorHandler(c);
        return !0
    }

    function p9(a, b, c, d, e, f, g, h) {
        var k = b === "secureSignalProviders" ? a.secureSignalProviders : a.encryptedSignalProviders;
        c = new l9(k instanceof Array ? k : [], c, b === "secureSignalProviders", document, f, g, d, h);
        d = new m9(c);
        b === "secureSignalProviders" ? a.secureSignalProviders = d : a.encryptedSignalProviders = d;
        j9(c, e)
    }

    function q9(a, b, c, d, e, f = fZ, g) {
        var h = new PY;
        KY(h, b);
        n9(a, h, c, d, e, f, g)
    };
    var s9 = Y(r9, {
        id: 1049,
        H: {}
    });

    function r9(a, b) {
        var c = new Set,
            d = new Set(xZ(a.Pb));
        for (var e of a.Zc ? ? [])
            for (let f of zk(e)) B(f, 4) && (d.add(f.jb()), c.add(f.jb()));
        for (let f of Array.from(d)) {
            ({
                U: d
            } = yZ().get(f, a.Pb, c.has(f), b));
            if (!d) continue;
            e = BZ(d);
            if (e === 2 || e === 3) CZ(yZ(), Gd(ve(d, 1)) ? ? "", a.Pb, c.has(f)), uZ(40, f, null, {}, b)
        }
        return {}
    };
    const u9 = g1(function(a) {
        return a.Pb.ha() || t9(a.Zc)
    }, {
        id: 1415
    });
    var v9 = class extends d1 {
        constructor(a, b, c, d) {
            super(c);
            this.Pb = a;
            this.Zc = b;
            c = new f9(wZ(), c);
            X(Z(this, s9, {
                Pb: a,
                Zc: b
            }, d), c.output)
        }
        async g() {
            return e1(this.C, u9, {
                Pb: this.Pb,
                Zc: this.Zc
            })
        }
        l() {}
    };

    function t9(a) {
        return a.some(b => zk(b).some(c => B(c, 4)))
    };

    function w9(a, b, c, d) {
        return e => {
            if (du(e) && ((c.gjPrg ? ? "") === b || (c.zeuLy ? ? "") === b && a.location.host && (c.ANqoe ? ? "") === a.location.host)) {
                var f = new r_;
                q9(r.googletag ? ? (r.googletag = {
                    cmd: []
                }), e.getValue(), (l, m) => void f.Ka({
                    methodName: l,
                    hb: m
                }), () => void r.console.warn("Using deprecated googletag.encryptedSignalProviders. Please usegoogletag.secureSignalProviders instead."), () => void r.console.warn("Calling this method may reduce the likelihood of signals being included in ad requests for the current and potentially later page views. Due to this, it should only be called when meaningful state changes occur, such as events that indicate a new user log in, log out, sign up, etc."), {
                    Ji: oy(Iu),
                    Fi: V(Hu),
                    Pi: oy(Pu)
                }, d);
                var g = new PY;
                NY(g, e.getValue());
                e = new S0(f);
                var {
                    Ce: h,
                    Qf: k
                } = Z(e, eZ, {}, c.jzoix);
                Q0(e, new V8(f, h, g, d));
                Q0(e, new v9(g, k, f, d));
                R0(e)
            }
        }
    };
    var x9 = Y(function(a, b, c, d, e) {
        if (!U(Uu)) return {};
        a = V(hv);
        qT({
            Jb: w9(window, gA(window), b, a > 0 ? {
                F: d,
                uh: e,
                Sj: a
            } : void 0),
            win: c,
            Ya: b.OSCLM.UWEfJ
        });
        return {}
    }, {
        id: 1378,
        H: {}
    });

    function y9(a, b, c, d) {
        var e = tA,
            f = z9,
            g = {
                Ka: k => {
                    var l = k.hb;
                    e.Da(k.methodName ? ? 0, l instanceof Error ? l : Error(String(l)))
                }
            },
            h = new S0(g);
        Z(h, x9, {}, a, r, d, g);
        ({
            Ib: d
        } = Z(h, F8, {}));
        a = Z(h, C8, {
            Ib: d
        }, b, a, c, f, r);
        X(Z(h, D8, {}, r), a.finished);
        R0(h)
    };
    var A9 = M0(async function(a, b) {
        !U(Su) || V(Gu) <= 0 || await b.Ib ? .g()
    }, {
        id: 1390
    });
    var B9 = class {
        constructor(a, b) {
            this.K = a;
            this.Wc = b;
            this.g = null;
            this.l = 0
        }
        j() {
            ++this.l >= 10 && r.clearInterval(this.g);
            var a = BR(this.K, this.Wc);
            CR(this.K, this.Wc, a);
            a = SI(this.Wc, this.K);
            a != null && a.x === 0 || r.clearInterval(this.g)
        }
    };
    var C9 = Y(function(a, b) {
        wA(639, () => {
            var c;
            var d = b.I;
            (c = b.K) && d.google_responsive_auto_format === 1 && d.google_full_width_responsive_allowed === !0 ? (d = (d = c.document.getElementById(d.google_async_iframe_id)) ? Ej(d, "INS", "adsbygoogle") : null) ? (c = new B9(c, d), c.g = r.setInterval(Aa(c.j, c), 500), c.j(), c = !0) : c = !1 : c = !1;
            return c
        });
        return {}
    }, {
        id: 1357,
        H: {}
    });
    var D9 = Y(function(a, b, c) {
        a = new Map;
        for (var d of Object.keys(b)) {
            var e = a,
                f = e.set;
            var g = b[d];
            g = g === void 0 ? 1 : g === null ? 2 : g === !1 ? 3 : g === 0 ? 4 : g === "" ? 5 : Array.isArray(g) && g.length === 0 ? 6 : typeof g === "object" && Object.keys(g).length === 0 ? 7 : 8;
            f.call(e, d, g)
        }
        c.g && (b = c.F, c = LA(c, c.win.performance.now()), d = new Do, re(d), a.forEach(Me, Le(d, 1, void 0, Kd)), a = d.setLocation(1), a = z(c, 21, Up, a), Pq(b, a));
        return {}
    }, {
        id: 1576,
        H: {}
    });
    var E9 = Y(function(a, b, c, d) {
        Qz() && r.setTimeout(xA(1244, () => void aX(b || c, {
            Ya: !!d.OSCLM.UWEfJ
        })), 1E3);
        return {}
    }, {
        id: 1385,
        H: {}
    });
    async function F9(a, b, c, d, e, f, g) {
        await aI(a, b, c, d, e, f, g)
    }
    var G9 = Y(function(a, b, c, d, e, f) {
        var g = b.K,
            h = b.pubWin;
        g ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/) ? yA(1008, F9(h, g, c, d, xg(new jx), e, f.SLqBY || ""), k => {
            k.es = dI(null)
        }) : TV(h, "affa", k => {
            yA(1008, F9(h, g, c, d, k.config, e, f.SLqBY || ""), l => {
                l.es = dI(null)
            });
            return !0
        });
        return {}
    }, {
        id: 1384,
        H: {}
    });

    function H9(a) {
        var b = tA,
            c = {
                Ka: f => {
                    var g = f.hb;
                    b.Da(f.methodName ? ? 0, g instanceof Error ? g : Error(String(g)))
                }
            },
            d = new S0(c);
        Z(d, D9, {}, a.I, HA());
        var e = P0(d, A9, {}, a);
        c = Q0(d, new B8(c, a, e.complete));
        e = X(X(Z(d, C9, {}, a), c.g), e.complete);
        e = X(Z(d, E9, {}, a.K, a.pubWin, a.pageState), e.finished);
        a = X(Z(d, G9, {}, {
            K: a.K,
            pubWin: a.pubWin
        }, a.I, a.Ja, a.P, a.pageState), e.finished);
        R0(d);
        return a.finished.promise
    };
    var I9 = class {
        constructor(a) {
            this.j = 0;
            this.P = this.B = null;
            this.A = 0;
            this.Ja = [];
            this.Mc = this.l = "";
            this.zb = !1;
            this.K = a.K;
            this.pubWin = a.pubWin;
            this.I = a.I;
            this.Oa = a.Oa;
            this.Tc = a.Tc;
            this.da = a.da;
            this.pageState = a.pageState;
            this.Ac = a.Ac
        }
    };

    function J9(a) {
        tA.l(b => {
            b.shv = String(a);
            b.mjsv = Yp();
            b.eid = k_(r)
        })
    };
    async function z9({
        Oa: a,
        Tc: b,
        slot: c,
        pageState: d,
        Ib: e
    }) {
        var f = c.vars,
            g = Tk(c.pubWin),
            h = c.innerInsElement;
        if (!h) throw Error("no_wrapper_element_in_loader_provided_slot");
        a = new I9({
            K: g,
            pubWin: c.pubWin,
            I: f,
            Oa: a,
            Tc: b,
            da: h,
            pageState: d,
            Ac: c.KCuMo
        });
        a.A = Date.now();
        a.Ib = e;
        Sl(1, [a.I]);
        try {
            await H9(a)
        } catch (k) {
            if (!AA(159, k)) throw k;
        }
        return a
    };
    (function(a, b) {
        wA(843, () => {
            if (!r.google_sa_impl) {
                var c = null;
                c = c ? ? new $q(a);
                try {
                    Mb(e => {
                        jA(c, 1192, e)
                    })
                } catch (e) {}
                var d = r.adsbygoogle && "pageState" in r.adsbygoogle && r.adsbygoogle.pageState ? r.adsbygoogle.pageState : {
                    stavq: 0,
                    jTCuI: "",
                    OmOVT: !1,
                    xujKL: !1,
                    AyxaY: void 0,
                    SLqBY: "",
                    xVQAt: "",
                    OSCLM: {
                        UWEfJ: !1,
                        YguOd: !1,
                        SVQEK: !1
                    },
                    jzoix: {
                        PygXN: []
                    },
                    FJPve: !1,
                    GLnKw: !1,
                    tYcft: Promise.resolve(void 0),
                    EGzMj: Promise.resolve(!0),
                    uNjDc: !1
                };
                J9(d.jTCuI);
                h_(b_(r));
                y9(d, a, b, c)
            }
        })
    })(Yp(), function(a, b, c, d) {
        b = b > 2012 ? `_fy${b}` : "";
        return {
            Xm: ni `https://pagead2.googlesyndication.com/pagead/js/${c}/${d}/rum${b}.js`,
            Wm: ni `https://pagead2.googlesyndication.com/pagead/js/${c}/${d}/rum_debug${b}.js`,
            Kj: ni `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/reactive_library${b}.js`,
            ll: ni `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/debug_card_library${b}.js`,
            lp: ni `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${b}.js`,
            cg: ni `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/video_feed${b}.js`,
            jk: ni `https://googleads.g.doubleclick.net/pagead/html/${c}/${d}/zrt_lookup${b}.html`,
            ik: ni `https://pagead2.googlesyndication.com/pagead/html/${c}/${d}/zrt_lookup${b}.html`
        }
    });
}).call(this, "");
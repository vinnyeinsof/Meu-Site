(function(sttc) {
    'use strict';
    var aa = Object.defineProperty,
        ba = globalThis,
        ca = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        da = {},
        ea = {};

    function fa(a, b, c) {
        if (!c || a != null) {
            c = ea[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function ha(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in da ? f = da : f = ba;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ca && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? aa(da, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ea[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ea[d] = ca ? ba.Symbol(d) : "$jscp$" + a + "$" + d), aa(f, ea[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    ha("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var r = this || self;

    function ia(a, b) {
        var c = ja("CLOSURE_FLAGS");
        a = c && c[a];
        return a != null ? a : b
    }

    function ja(a) {
        a = a.split(".");
        for (var b = r, c = 0; c < a.length; c++)
            if (b = b[a[c]], b == null) return null;
        return b
    }

    function ka(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function la(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function ma(a) {
        return Object.prototype.hasOwnProperty.call(a, na) && a[na] || (a[na] = ++oa)
    }
    var na = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        oa = 0;

    function pa(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function qa(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function ra(a, b, c) {
        ra = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? pa : qa;
        return ra.apply(null, arguments)
    }

    function sa(a, b, c) {
        a = a.split(".");
        c = c || r;
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    };

    function ta(a) {
        r.setTimeout(() => {
            throw a;
        }, 0)
    };

    function ua(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function va(a, b) {
        var c = 0;
        a = ua(String(a)).split(".");
        b = ua(String(b)).split(".");
        var d = Math.max(a.length, b.length);
        for (let g = 0; c == 0 && g < d; g++) {
            var e = a[g] || "",
                f = b[g] || "";
            do {
                e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                if (e[0].length == 0 && f[0].length == 0) break;
                c = wa(e[1].length == 0 ? 0 : parseInt(e[1], 10), f[1].length == 0 ? 0 : parseInt(f[1], 10)) || wa(e[2].length == 0, f[2].length == 0) || wa(e[2], f[2]);
                e = e[3];
                f = f[3]
            } while (c == 0)
        }
        return c
    }

    function wa(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var xa = ia(610401301, !1),
        ya = ia(748402147, !0);

    function Aa() {
        var a = r.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Ba;
    const Da = r.navigator;
    Ba = Da ? Da.userAgentData || null : null;

    function Ea(a) {
        if (!xa || !Ba) return !1;
        for (let b = 0; b < Ba.brands.length; b++) {
            let {
                brand: c
            } = Ba.brands[b];
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function t(a) {
        return Aa().indexOf(a) != -1
    };

    function Fa() {
        return xa ? !!Ba && Ba.brands.length > 0 : !1
    }

    function Ga() {
        return Fa() ? !1 : t("Trident") || t("MSIE")
    }

    function Ha() {
        return Fa() ? Ea("Chromium") : (t("Chrome") || t("CriOS")) && !(Fa() ? 0 : t("Edge")) || t("Silk")
    }

    function Ia(a) {
        var b = {};
        a.forEach(c => {
            b[c[0]] = c[1]
        });
        return c => b[c.find(d => d in b)] || ""
    }

    function Ja() {
        var a = Aa();
        if (Ga()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), c[1] == "7.0")
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        for (var d; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
        a = Ia(b);
        return (Fa() ? 0 : t("Opera")) ? a(["Version",
            "Opera"
        ]) : (Fa() ? 0 : t("Edge")) ? a(["Edge"]) : (Fa() ? Ea("Microsoft Edge") : t("Edg/")) ? a(["Edg"]) : t("Silk") ? a(["Silk"]) : Ha() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    };

    function Ka(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function La(a, b) {
        var c = a.length,
            d = [],
            e = 0,
            f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                let h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Ma(a, b) {
        var c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Na(a, b) {
        var c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Oa(a, b) {
        a: {
            var c = a.length;
            let d = typeof a === "string" ? a.split("") : a;
            for (--c; c >= 0; c--)
                if (c in d && b.call(void 0, d[c], c, a)) {
                    b = c;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    }

    function Pa(a, b) {
        return Ka(a, b) >= 0
    }

    function Qa(a) {
        var b = a.length;
        if (b > 0) {
            let c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Ra(a) {
        Ra[" "](a);
        return a
    }
    Ra[" "] = function() {};
    const Sa = {};
    let Ua = null;

    function Va(a) {
        var b = [];
        Wa(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Wa(a, b) {
        function c(e) {
            for (; d < a.length;) {
                let f = a.charAt(d++),
                    g = Ua[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        Xa();
        for (var d = 0;;) {
            let e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Xa() {
        if (!Ua) {
            Ua = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                let d = a.concat(b[c].split(""));
                Sa[c] = d;
                for (let e = 0; e < d.length; e++) {
                    let f = d[e];
                    Ua[f] === void 0 && (Ua[f] = e)
                }
            }
        }
    };

    function Ya(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    let Za = void 0,
        $a;

    function ab(a) {
        if ($a) throw Error("");
        $a = b => {
            r.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function bb(a) {
        if ($a) try {
            $a(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function cb(a) {
        a = Error(a);
        Ya(a, "warning");
        bb(a);
        return a
    };

    function db(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var eb = db(),
        fb = db(),
        gb = db(),
        hb = db("m_m", !0);
    const v = db("jas", !0);
    var ib;
    const jb = [];
    jb[v] = 7;
    ib = Object.freeze(jb);

    function kb(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function lb(a) {
        a[v] |= 32;
        return a
    };
    var mb = {};

    function nb(a, b) {
        return b === void 0 ? a.i !== ob && !!(2 & (a.C[v] | 0)) : !!(2 & b) && a.i !== ob
    }
    const ob = {};
    var qb = Object.freeze({}),
        rb = Object.freeze({});

    function sb(a) {
        a.Hc = !0;
        return a
    };
    var tb = sb(a => typeof a === "number"),
        w = sb(a => typeof a === "string"),
        ub = sb(a => typeof a === "boolean"),
        vb = sb(a => typeof a === "function"),
        wb = sb(a => Array.isArray(a));

    function xb() {
        return sb(a => wb(a) ? a.every(b => tb(b)) : !1)
    };

    function yb(a) {
        if (w(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (tb(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var Bb = sb(a => a >= zb && a <= Ab);
    const zb = BigInt(Number.MIN_SAFE_INTEGER),
        Ab = BigInt(Number.MAX_SAFE_INTEGER);
    let Cb = 0,
        Db = 0;

    function Eb(a) {
        var b = a >>> 0;
        Cb = b;
        Db = (a - b) / 4294967296 >>> 0
    }

    function Fb(a) {
        if (a < 0) {
            Eb(-a);
            a = Cb;
            var b = Db;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            let [c, d] = [a, b];
            Cb = c >>> 0;
            Db = d >>> 0
        } else Eb(a)
    }

    function Gb(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function Hb() {
        var a = Cb,
            b = Db,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = Gb(a, b);
        return c
    };

    function Ib(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const Jb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Lb = Number.isSafeInteger,
        Mb = Number.isFinite,
        Nb = Math.trunc;

    function Ob(a) {
        if (typeof a !== "number") throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);
        return a
    }

    function Pb(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function Qb(a) {
        if (a != null && typeof a !== "boolean") throw Error(`Expected boolean but got ${ka(a)}: ${a}`);
        return a
    }
    const Rb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Sb(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Mb(a);
            case "string":
                return Rb.test(a);
            default:
                return !1
        }
    }

    function Tb(a) {
        if (!Mb(a)) throw cb("enum");
        return a | 0
    }

    function Ub(a) {
        return a == null ? a : Mb(a) ? a | 0 : void 0
    }

    function Vb(a) {
        if (typeof a !== "number") throw cb("int32");
        if (!Mb(a)) throw cb("int32");
        return a | 0
    }

    function Wb(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Mb(a) ? a | 0 : void 0
    }

    function Xb(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Mb(a) ? a >>> 0 : void 0
    }

    function Yb(a) {
        if (!Sb(a)) throw cb("int64");
        switch (typeof a) {
            case "string":
                return Zb(a);
            case "bigint":
                return yb(Jb(64, a));
            default:
                return $b(a)
        }
    }

    function ac(a) {
        a = Nb(a);
        if (!Lb(a)) {
            Fb(a);
            var b = Cb,
                c = Db;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            let d = c * 4294967296 + (b >>> 0);
            b = Number.isSafeInteger(d) ? d : Gb(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function Zb(a) {
        var b = Nb(Number(a));
        if (Lb(b)) return yb(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return yb(Jb(64, BigInt(a)))
    }

    function $b(a) {
        Lb(a) ? a = yb(ac(a)) : (a = Nb(a), Lb(a) ? a = String(a) : (Fb(a), a = Hb()), a = yb(a));
        return a
    }

    function bc(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return yb(Jb(64, a));
        if (Sb(a)) return b === "string" ? Zb(a) : $b(a)
    }

    function cc(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function dc(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function x(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function ec(a, b, c, d) {
        if (a != null && a[hb] === mb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? b[eb] || (b[eb] = fc(b)) : new b : void 0;
        c = a[v] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[v] = d);
        return new b(a)
    }

    function fc(a) {
        a = new a;
        var b = a.C;
        b[v] |= 34;
        return a
    };

    function hc(a) {
        return a
    };

    function ic(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            k = !1,
            m = !!(b & 64),
            n = m ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var l = g && a[g - 1];
            l != null && typeof l === "object" && l.constructor === Object ? (g--, h = g) : l = void 0;
            !m || b & 128 || e || (k = !0, h = (jc ? ? hc)(h - n, n, a, l, void 0) + n)
        }
        b = void 0;
        for (e = 0; e < g; e++) {
            let p = a[e];
            if (p != null && (p = c(p, d)) != null)
                if (m && e >= h) {
                    let q = e - n;
                    (b ? ? (b = {}))[q] = p
                } else f[e] = p
        }
        if (l)
            for (let p in l) {
                if (!Object.prototype.hasOwnProperty.call(l, p)) continue;
                a = l[p];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +p;
                let q;
                m && !Number.isNaN(g) && (q = g + n) < h ? f[q] = a : (b ? ? (b = {}))[p] = a
            }
        b && (k ? f.push(b) : f[h] = b);
        return f
    }

    function kc(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return Bb(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[v] | 0;
                    return a.length === 0 && b & 1 ? void 0 : ic(a, b, kc)
                }
                if (a != null && a[hb] === mb) return z(a);
                return
        }
        return a
    }
    var lc = typeof structuredClone != "undefined" ? structuredClone : a => ic(a, 0, kc);
    let jc;

    function z(a) {
        a = a.C;
        return ic(a, a[v] | 0, kc)
    };

    function mc(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[v] | 0;
            if (ya && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && nc();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[v] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    let k = c[g];
                    if (k != null && typeof k === "object" && k.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in k) {
                            if (!Object.prototype.hasOwnProperty.call(k,
                                    h)) continue;
                            f = +h;
                            if (f < g) c[f + b] = k[h], delete k[h];
                            else break
                        }
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -16760833 | (h & 1023) << 14
                }
            }
        }
        a[v] = e | 64 | d;
        return a
    }

    function nc() {
        if (ya) throw Error("carr");
        if (gb != null) {
            var a = Za ? ? (Za = {});
            var b = a[gb] || 0;
            b >= 5 || (a[gb] = b + 1, a = Error(), Ya(a, "incident"), $a ? bb(a) : ta(a))
        }
    };

    function pc(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[v] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = qc(a, c, !1, b && !(c & 16)) : (a[v] |= 34, c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[hb] === mb) return b = a.C, c = b[v] | 0, nb(a, c) ? a : rc(a, b, c) ? sc(a, b) : qc(b, c)
    }

    function sc(a, b, c) {
        a = new a.constructor(b);
        c && (a.i = ob);
        a.A = ob;
        return a
    }

    function qc(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = ic(a, b, pc, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[v] = b;
        return a
    }

    function tc(a) {
        var b = a.C,
            c = b[v] | 0;
        return nb(a, c) ? rc(a, b, c) ? sc(a, b, !0) : new a.constructor(qc(b, c, !1)) : a
    }

    function uc(a) {
        var b = a.C,
            c = b[v] | 0;
        return nb(a, c) ? a : rc(a, b, c) ? sc(a, b) : new a.constructor(qc(b, c, !0))
    }

    function vc(a) {
        if (a.i !== ob) return !1;
        var b = a.C;
        b = qc(b, b[v] | 0);
        b[v] |= 2048;
        a.C = b;
        a.i = void 0;
        a.A = void 0;
        return !0
    }

    function wc(a) {
        if (!vc(a) && nb(a, a.C[v] | 0)) throw Error();
    }

    function xc(a, b) {
        b === void 0 && (b = a[v] | 0);
        b & 32 && !(b & 4096) && (a[v] = b | 4096)
    }

    function rc(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[v] = c | 2, a.i = ob, !0) : !1
    };
    const yc = yb(0),
        zc = {};

    function A(a, b, c, d, e) {
        b = Ac(a.C, b, c, e);
        if (b !== null || d && a.A !== ob) return b
    }

    function Ac(a, b, c, d) {
        if (b === -1) return null;
        var e = b + (c ? 0 : -1),
            f = a.length - 1;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f) {
                var g = a[f];
                if (g != null && typeof g === "object" && g.constructor === Object) {
                    c = g[b];
                    var h = !0
                } else if (e === f) c = g;
                else return
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function Bc(a, b, c) {
        wc(a);
        var d = a.C;
        B(d, d[v] | 0, b, c);
        return a
    }

    function B(a, b, c, d) {
        var e = c + -1,
            f = a.length - 1;
        if (f >= 0 && e >= f) {
            let g = a[f];
            if (g != null && typeof g === "object" && g.constructor === Object) return g[c] = d, b
        }
        if (e <= f) return a[e] = d, b;
        d !== void 0 && (f = (b ? ? (b = a[v] | 0)) >> 14 & 1023 || 536870912, c >= f ? d != null && (a[f + -1] = {
            [c]: d
        }) : a[e] = d);
        return b
    }

    function Cc(a, b, c) {
        a = a.C;
        return Dc(a, a[v] | 0, b, c) !== void 0
    }

    function C(a) {
        return a === qb ? 2 : 4
    }

    function Ec(a, b, c, d, e) {
        var f = a.C,
            g = f[v] | 0;
        d = nb(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && vc(a) && (f = a.C, g = f[v] | 0);
        a = Fc(f, b);
        var h = a === ib ? 7 : a[v] | 0,
            k = Gc(h, g);
        var m = 4 & k ? !1 : !0;
        if (m) {
            4 & k && (a = [...a], h = 0, k = Hc(k, g), g = B(f, g, b, a));
            let n = 0,
                l = 0;
            for (; n < a.length; n++) {
                let p = c(a[n]);
                p != null && (a[l++] = p)
            }
            l < n && (a.length = l);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (a[v] = k, 2 & k && Object.freeze(a));
        return a = Ic(a, k, f, g, b, d, m, e)
    }

    function Ic(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Jc(b) || (b |= !a.length || g && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== k && (a[v] = b), Object.freeze(a)) : (f === 2 && Jc(b) && (a = [...a], k = 0, b = Hc(b, d), d = B(c, d, e, a)), Jc(b) || (h || (b |= 16), b !== k && (a[v] = b)));
        2 & b || !(4096 & b || 16 & b) || xc(c, d);
        return a
    }

    function Fc(a, b) {
        a = Ac(a, b);
        return Array.isArray(a) ? a : ib
    }

    function Gc(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Jc(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Kc(a, b, c, d) {
        wc(a);
        var e = a.C,
            f = e[v] | 0;
        if (c == null) return B(e, f, b), a;
        var g = c === ib ? 7 : c[v] | 0,
            h = g,
            k = Jc(g),
            m = k || Object.isFrozen(c);
        k || (g = 0);
        m || (c = [...c], h = 0, g = Hc(g, f), m = !1);
        g |= 5;
        k = kb(g) ? ? 1024;
        g |= k;
        for (let n = 0; n < c.length; n++) {
            let l = c[n],
                p = d(l, k);
            Object.is(l, p) || (m && (c = [...c], h = 0, g = Hc(g, f), m = !1), c[n] = p)
        }
        g !== h && (m && (c = [...c], g = Hc(g, f)), c[v] = g);
        B(e, f, b, c);
        return a
    }

    function Lc(a, b, c, d) {
        wc(a);
        var e = a.C;
        B(e, e[v] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function Mc(a, b, c, d) {
        wc(a);
        var e = a.C,
            f = e[v] | 0;
        if (d == null) {
            var g = Nc(e);
            if (Oc(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = Nc(e);
            let h = Oc(g, e, f, c);
            h !== b && (h && (f = B(e, f, h)), g.set(c, b))
        }
        B(e, f, b, d);
        return a
    }

    function Pc(a, b, c) {
        return Qc(a, b) === c ? c : -1
    }

    function Qc(a, b) {
        a = a.C;
        return Oc(Nc(a), a, void 0, b)
    }

    function Nc(a) {
        return a[fb] ? ? (a[fb] = new Map)
    }

    function Oc(a, b, c, d) {
        var e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            let g = d[f];
            Ac(b, g) != null && (e !== 0 && (c = B(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function Rc(a, b, c) {
        wc(a);
        a = a.C;
        var d = a[v] | 0,
            e = Ac(a, c),
            f = void 0 === rb;
        b = ec(e, b, !f, d);
        if (!f || b) return b = tc(b), e !== b && (d = B(a, d, c, b), xc(a, d)), b
    }

    function Dc(a, b, c, d) {
        var e = !1;
        d = Ac(a, d, void 0, f => {
            var g = ec(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !nb(d) && xc(a, b), d
    }

    function Sc(a) {
        var b = Tc;
        a = a.C;
        return Dc(a, a[v] | 0, b, 4) || b[eb] || (b[eb] = fc(b))
    }

    function D(a, b, c) {
        var d = a.C,
            e = d[v] | 0;
        b = Dc(d, e, b, c);
        if (b == null) return b;
        e = d[v] | 0;
        if (!nb(a, e)) {
            let f = tc(b);
            f !== b && (vc(a) && (d = a.C, e = d[v] | 0), b = f, e = B(d, e, c, b), xc(d, e))
        }
        return b
    }

    function E(a, b, c, d) {
        var e = a.C,
            f = e;
        e = e[v] | 0;
        var g = nb(a, e),
            h = g ? 1 : d;
        d = h === 3;
        var k = !g;
        (h === 2 || k) && vc(a) && (f = a.C, e = f[v] | 0);
        a = Fc(f, c);
        var m = a === ib ? 7 : a[v] | 0,
            n = Gc(m, e);
        if (g = !(4 & n)) {
            var l = a,
                p = e;
            let q = !!(2 & n);
            q && (p |= 2);
            let u = !q,
                y = !0,
                M = 0,
                za = 0;
            for (; M < l.length; M++) {
                let Ta = ec(l[M], b, !1, p);
                if (Ta instanceof b) {
                    if (!q) {
                        let pb = nb(Ta);
                        u && (u = !pb);
                        y && (y = pb)
                    }
                    l[za++] = Ta
                }
            }
            za < M && (l.length = za);
            n |= 4;
            n = y ? n & -4097 : n | 4096;
            n = u ? n | 8 : n & -9
        }
        n !== m && (a[v] = n, 2 & n && Object.freeze(a));
        if (k && !(8 & n || !a.length && (h === 1 || (h !== 4 ? 0 : 2 & n || !(16 & n) && 32 &
                e)))) {
            Jc(n) && (a = [...a], n = Hc(n, e), e = B(f, e, c, a));
            b = a;
            k = n;
            for (m = 0; m < b.length; m++) l = b[m], n = tc(l), l !== n && (b[m] = n);
            k |= 8;
            n = k = b.length ? k | 4096 : k & -4097;
            a[v] = n
        }
        return a = Ic(a, n, f, e, c, h, g, d)
    }

    function Uc(a) {
        a == null && (a = void 0);
        return a
    }

    function F(a, b, c) {
        c = Uc(c);
        Bc(a, b, c);
        c && !nb(c) && xc(a.C);
        return a
    }

    function G(a, b, c, d) {
        d = Uc(d);
        Mc(a, b, c, d);
        d && !nb(d) && xc(a.C);
        return a
    }

    function Vc(a, b, c) {
        wc(a);
        var d = a.C,
            e = d[v] | 0;
        if (c == null) return B(d, e, b), a;
        var f = c === ib ? 7 : c[v] | 0,
            g = f,
            h = Jc(f),
            k = h || Object.isFrozen(c),
            m = !0,
            n = !0;
        for (let p = 0; p < c.length; p++) {
            var l = c[p];
            h || (l = nb(l), m && (m = !l), n && (n = l))
        }
        h || (f = m ? 13 : 5, f = n ? f & -4097 : f | 4096);
        k && f === g || (c = [...c], g = 0, f = Hc(f, e));
        f !== g && (c[v] = f);
        e = B(d, e, b, c);
        2 & f || !(4096 & f || 16 & f) || xc(d, e);
        return a
    }

    function Hc(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function Wc(a, b) {
        wc(a);
        a = Ec(a, 4, x, 2, !0);
        var c = kb(a === ib ? 7 : a[v] | 0) ? ? 1024;
        if (Array.isArray(b)) {
            var d = b.length;
            for (let e = 0; e < d; e++) a.push(cc(b[e], c))
        } else
            for (d of b) a.push(cc(d, c))
    }

    function Xc(a, b) {
        return A(a, b, void 0, void 0, bc)
    }

    function Yc(a, b, c) {
        a = A(a, b, void 0, c);
        return a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0
    }

    function Zc(a, b, c) {
        return Wb(A(a, b, void 0, c))
    }

    function H(a, b) {
        return Yc(a, b) ? ? !1
    }

    function I(a, b) {
        return Zc(a, b) ? ? 0
    }

    function $c(a, b) {
        return A(a, b, void 0, void 0, Pb) ? ? 0
    }

    function J(a, b) {
        return x(A(a, b)) ? ? ""
    }

    function K(a, b) {
        return Ub(A(a, b)) ? ? 0
    }

    function ad(a, b, c) {
        return K(a, Pc(a, c, b))
    }

    function bd(a, b, c, d) {
        return D(a, b, Pc(a, d, c))
    }

    function cd(a, b) {
        return x(A(a, b, void 0, zc))
    }

    function L(a, b) {
        return Ub(A(a, b, void 0, zc))
    }

    function dd(a, b, c) {
        return Bc(a, b, c == null ? c : Vb(c))
    }

    function ed(a, b, c) {
        return Lc(a, b, c == null ? c : Vb(c), 0)
    }

    function N(a, b, c) {
        return Bc(a, b, c == null ? c : Yb(c))
    }

    function fd(a, b, c) {
        return Lc(a, b, c == null ? c : Yb(c), "0")
    }

    function gd(a, b, c) {
        return Bc(a, b, c == null ? c : Ob(c))
    }

    function hd(a, b) {
        var c = performance.now();
        Lc(a, b, c == null ? c : Ob(c), 0)
    }

    function id(a, b, c) {
        return Bc(a, b, dc(c))
    }

    function jd(a, b, c) {
        return Lc(a, b, dc(c), "")
    }

    function kd(a, b, c) {
        return Bc(a, b, c == null ? c : Tb(c))
    }

    function ld(a, b, c) {
        return Lc(a, b, c == null ? c : Tb(c), 0)
    }

    function md(a, b, c, d) {
        return Mc(a, b, c, d == null ? d : Tb(d))
    };

    function nd(a) {
        return uc(a)
    }
    var O = class {
        constructor(a) {
            this.C = mc(a, void 0, void 0, 2048)
        }
        toJSON() {
            return z(this)
        }
        u() {
            return JSON.stringify(z(this))
        }
    };
    O.prototype[hb] = mb;

    function od(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error();
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error();
        return new a(lb(b))
    };

    function pd(a) {
        return () => a[eb] || (a[eb] = fc(a))
    }

    function qd(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(lb(b))
            }
            return b
        }
    };
    var rd = class extends O {};
    var sd = class extends O {};

    function td(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function ud(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    Ra(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch {
            return !1
        }
    }

    function vd(a) {
        return ud(a.top) ? a.top : null
    };

    function wd(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function xd(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function yd(a) {
        var b = a;
        return function() {
            if (b) {
                let c = b;
                b = null;
                c()
            }
        }
    };

    function zd() {
        return xa && Ba ? Ba.mobile : !Ad() && (t("iPod") || t("iPhone") || t("Android") || t("IEMobile"))
    }

    function Ad() {
        return xa && Ba ? !Ba.mobile && (t("iPad") || t("Android") || t("Silk")) : t("iPad") || t("Android") && !t("Mobile") || t("Silk")
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    let Bd = globalThis.trustedTypes,
        Cd;

    function Dd() {
        var a = null;
        if (!Bd) return a;
        try {
            let b = c => c;
            a = Bd.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    };
    var Ed = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Fd(a) {
        var b;
        Cd === void 0 && (Cd = Dd());
        a = (b = Cd) ? b.createScriptURL(a) : a;
        return new Ed(a)
    }

    function Gd(a) {
        if (a instanceof Ed) return a.g;
        throw Error("");
    };
    var Hd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Id(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };
    const Jd = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Kd(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    var Ld = xd(() => zd() ? 2 : Ad() ? 1 : 0);

    function Md() {
        if (!globalThis.crypto) return Math.random();
        try {
            let a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (a) {
            return Math.random()
        }
    };
    let Nd, Od = 64;

    function Pd() {
        try {
            return Nd ? ? (Nd = new Uint32Array(64)), Od >= 64 && (crypto.getRandomValues(Nd), Od = 0), Nd[Od++]
        } catch (a) {
            return Math.floor(Math.random() * 2 ** 32)
        }
    };

    function Qd(a, b) {
        if (!tb(a.goog_pvsid)) try {
            let c = Pd() + (Pd() & 2 ** 21 - 1) * 2 ** 32;
            Object.defineProperty(a, "goog_pvsid", {
                value: c,
                configurable: !1
            })
        } catch (c) {
            b.ia({
                methodName: 784,
                Ja: c
            })
        }
        a = Number(a.goog_pvsid);
        (!a || a <= 0) && b.ia({
            methodName: 784,
            Ja: Error(`Invalid correlator, ${a}`)
        });
        return a || -1
    };

    function Rd(a, ...b) {
        if (b.length === 0) return Fd(a[0]);
        var c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Fd(c)
    }

    function Sd(a, b) {
        a = Gd(a).toString();
        var c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return Td(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function Td(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(k => e(k, h)) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(g => e(g[1], g[0])) : d.forEach(e);
        return Fd(a + b + c)
    };

    function Ud(a, b) {
        var c = Vd("SCRIPT", a);
        c.src = Gd(b);
        (b = Id(c.ownerDocument)) && c.setAttribute("nonce", b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function Wd(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }
    var Xd = /^([0-9.]+)px$/,
        Yd = /^(-?[0-9.]{1,30})$/;

    function Zd(a) {
        if (!Yd.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function $d(a) {
        return (a = Xd.exec(a)) ? +a[1] : null
    }
    var ae = a => {
        td({
            display: "none"
        }, (b, c) => {
            a.style.setProperty(c, b, "important")
        })
    };

    function be() {
        var a = P(ce).i(de.g, de.defaultValue),
            b = Q.document;
        if (a.length && b.head)
            for (let c of a) a: {
                if (!c || !b.head) break a;a = Vd("META");b.head.appendChild(a);a.httpEquiv = "origin-trial";a.content = c
            }
    }
    var ee = a => Qd(a, {
        ia: () => {}
    });

    function Vd(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };
    let fe = [];

    function ge() {
        var a = fe;
        fe = [];
        for (let b of a) try {
            b()
        } catch {}
    };

    function he(a, b) {
        this.width = a;
        this.height = b
    }
    he.prototype.aspectRatio = function() {
        return this.width / this.height
    };
    he.prototype.isEmpty = function() {
        return !(this.width * this.height)
    };
    he.prototype.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    he.prototype.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    he.prototype.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    he.prototype.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function ie(a, b) {
        var c = {};
        for (let d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function je(a, b) {
        for (let c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function ke(a) {
        var b = [],
            c = 0;
        for (let d in a) b[c++] = a[d];
        return b
    };

    function le(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function me(a) {
        this.g = a || r.document || document
    }
    me.prototype.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };

    function ne(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    }

    function oe(a, b, c) {
        return typeof a.removeEventListener === "function" ? (a.removeEventListener(b, c, !1), !0) : !1
    }

    function pe(a) {
        var b = qe;
        b.readyState === "complete" || b.readyState === "interactive" ? (fe.push(a), fe.length === 1 && (window.Promise ? Promise.resolve().then(ge) : (a = window.setImmediate, vb(a) ? a(ge) : setTimeout(ge, 0)))) : b.addEventListener("DOMContentLoaded", a)
    };

    function re(a, b, c = null, d = !1, e = !1) {
        se(a, b, c, d, e)
    }

    function se(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        var f = Vd("IMG", a.document);
        if (c || d) {
            let g = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    let k = Ka(h, f);
                    k >= 0 && Array.prototype.splice.call(h, k, 1)
                }
                oe(f, "load", g);
                oe(f, "error", g)
            };
            ne(f, "load", g);
            ne(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function te(a, b) {
        var c = `https://pagead2.googlesyndication.com/pagead/gen_204?id=${b}`;
        td(a, (d, e) => {
            if (d || d === 0) c += `&${e}=${encodeURIComponent(String(d))}`
        });
        ue(c)
    }

    function ue(a) {
        var b = window;
        b.fetch ? b.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }) : re(b, a, void 0, !1, !1)
    };
    var qe = document,
        Q = window;
    let ve = null;
    var we = (a, b = []) => {
        var c = !1;
        r.google_logging_queue || (c = !0, r.google_logging_queue = []);
        r.google_logging_queue.push([a, b]);
        if (a = c) {
            if (ve == null) {
                ve = !1;
                try {
                    let d = vd(r);
                    d && d.location.hash.indexOf("google_logging") !== -1 && (ve = !0)
                } catch (d) {}
            }
            a = ve
        }
        a && Ud(r.document, Rd `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function xe(a) {
        return !!(a.error && a.meta && a.id)
    }
    var ye = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function ze(a) {
        return new ye(a, {
            message: Ae(a)
        })
    }

    function Ae(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    const Be = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Ce = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        De = class {
            constructor(a, b, c) {
                this.url = a;
                this.l = b;
                this.g = !!c;
                this.depth = null
            }
        };
    let Ee = null;

    function Fe() {
        var a = window;
        if (Ee === null) {
            Ee = "";
            try {
                let b = "";
                try {
                    b = a.top.location.hash
                } catch (c) {
                    b = a.location.hash
                }
                if (b) {
                    let c = b.match(/\bdeid=([\d,]+)/);
                    Ee = c ? c[1] : ""
                }
            } catch (b) {}
        }
        return Ee
    };

    function Ge() {
        var a = r.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function He() {
        var a = r.performance;
        return a && a.now ? a.now() : null
    };
    var Ie = class {
        constructor(a, b) {
            var c = He() || Ge();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const Je = r.performance,
        Le = !!(Je && Je.mark && Je.measure && Je.clearMarks),
        Me = xd(() => {
            var a;
            if (a = Le) a = Fe(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function Ne(a) {
        a && Je && Me() && (Je.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Je.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Oe(a) {
        a.g = !1;
        if (a.events !== a.i.google_js_reporting_queue) {
            if (Me()) {
                var b = a.events;
                let c = b.length;
                b = typeof b === "string" ? b.split("") : b;
                for (let d = 0; d < c; d++) d in b && Ne.call(void 0, b[d])
            }
            a.events.length = 0
        }
    }
    var Pe = class {
        constructor(a) {
            this.events = [];
            this.i = a || r;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.events = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = Me() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new Ie(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Je && Me() && Je.mark(b);
            return a
        }
        end(a) {
            if (this.g && tb(a.value)) {
                a.duration = (He() || Ge()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Je && Me() && Je.mark(b);
                !this.g || this.events.length >
                    2048 || this.events.push(a)
            }
        }
    };

    function Qe(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    }

    function Re(a, b, c, d, e) {
        var f = [];
        td(a, (g, h) => {
            (g = Se(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function Se(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        w(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                let f = [];
                for (let g = 0; g < a.length; g++) f.push(Se(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Re(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Te(a) {
        var b = 1;
        for (let c in a.i) c.length > b && (b = c.length);
        return 3997 - b - a.j.length - 1
    }

    function Ue(a, b, c) {
        b = "https://" + b + c;
        var d = Te(a) - c.length;
        if (d < 0) return "";
        a.g.sort((f, g) => f - g);
        c = null;
        var e = "";
        for (let f = 0; f < a.g.length; f++) {
            let g = a.g[f],
                h = a.i[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    c = c == null ? g : c;
                    break
                }
                let m = Re(h[k], a.j, ",$");
                if (m) {
                    m = e + m;
                    if (d >= m.length) {
                        d -= m.length;
                        b += m;
                        e = a.j;
                        break
                    }
                    c = c == null ? g : c
                }
            }
        }
        a = "";
        c != null && (a = `${e}trn=${c}`);
        return b + a
    }
    var Ve = class {
        constructor() {
            this.j = "&";
            this.i = {};
            this.u = 0;
            this.g = []
        }
    };
    const We = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Xe = /#|$/;

    function Ye(a, b) {
        var c = a.search(Xe);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    };
    var af = class {
        constructor(a = null) {
            this.H = Ze;
            this.j = a;
            this.i = null;
            this.B = !1;
            this.G = this.K
        }
        N(a) {
            this.G = a
        }
        A(a) {
            this.i = a
        }
        O(a) {
            this.B = a
        }
        g(a, b, c) {
            try {
                if (this.j && this.j.g) {
                    var d = this.j.start(a.toString(), 3);
                    var e = b();
                    this.j.end(d)
                } else e = b()
            } catch (f) {
                b = !0;
                try {
                    Ne(d), b = this.G(a, ze(f), void 0, c)
                } catch (g) {
                    this.K(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return e
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        K(a, b, c, d, e) {
            e = e || "jserror";
            var f = void 0;
            try {
                let Ca = new Ve;
                var g = Ca;
                g.g.push(1);
                g.i[1] =
                    Qe("context", a);
                xe(b) || (b = ze(b));
                g = b;
                if (g.msg) {
                    b = Ca;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.i[2] = Qe("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.i) try {
                    this.i(h)
                } catch (V) {}
                if (d) try {
                    d(h)
                } catch (V) {}
                d = Ca;
                k = [k];
                d.g.push(3);
                d.i[3] = k;
                var m;
                if (!(m = p)) {
                    d = r;
                    k = [];
                    h = null;
                    do {
                        var n = d;
                        if (ud(n)) {
                            var l = n.location.href;
                            h = n.document && n.document.referrer || null
                        } else l = h, h = null;
                        k.push(new De(l || "", n));
                        try {
                            d = n.parent
                        } catch (V) {
                            d = null
                        }
                    } while (d && n !== d);
                    for (let V = 0, dh = k.length - 1; V <= dh; ++V) k[V].depth = dh - V;
                    n = r;
                    if (n.location && n.location.ancestorOrigins &&
                        n.location.ancestorOrigins.length === k.length - 1)
                        for (l = 1; l < k.length; ++l) {
                            let V = k[l];
                            V.url || (V.url = n.location.ancestorOrigins[l - 1] || "", V.g = !0)
                        }
                    m = k
                }
                var p = m;
                let Kb = new De(r.location.href, r, !1);
                m = null;
                let oc = p.length - 1;
                for (n = oc; n >= 0; --n) {
                    var q = p[n];
                    !m && Be.test(q.url) && (m = q);
                    if (q.url && !q.g) {
                        Kb = q;
                        break
                    }
                }
                q = null;
                let Ke = p.length && p[oc].url;
                Kb.depth !== 0 && Ke && (q = p[oc]);
                f = new Ce(Kb, q);
                if (f.i) {
                    p = Ca;
                    var u = f.i.url || "";
                    p.g.push(4);
                    p.i[4] = Qe("top", u)
                }
                var y = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    let V = f.g.url.match(We);
                    var M =
                        V[1],
                        za = V[3],
                        Ta = V[4];
                    u = "";
                    M && (u += M + ":");
                    za && (u += "//", u += za, Ta && (u += ":" + Ta));
                    var pb = u
                } else pb = "";
                M = Ca;
                y = [y, {
                    url: pb
                }];
                M.g.push(5);
                M.i[5] = y;
                $e(this.H, e, Ca, this.B, c)
            } catch (Ca) {
                try {
                    $e(this.H, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Ae(Ca),
                        url: f ? .g.url ? ? ""
                    }, this.B, c)
                } catch (Kb) {}
            }
            return !0
        }
        ua(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.K(a, c instanceof Error ? c : Error(c), void 0, this.i || void 0)
            })
        }
    };
    var bf = class extends O {},
        cf = [2, 3, 4];
    var df = class extends O {},
        ef = [3, 4, 5],
        ff = [6, 7];
    var gf = class extends O {},
        hf = [4, 5];

    function jf(a, b) {
        var c = E(a, df, 2, C());
        if (!c.length) return kf(a, b);
        a = K(a, 1);
        if (a === 1) return c = jf(c[0], b), c.success ? {
            success: !0,
            value: !c.value
        } : c;
        c = Ma(c, d => jf(d, b));
        switch (a) {
            case 2:
                return c.find(d => d.success && !d.value) ? ? c.find(d => !d.success) ? ? {
                    success: !0,
                    value: !0
                };
            case 3:
                return c.find(d => d.success && d.value) ? ? c.find(d => !d.success) ? ? {
                    success: !0,
                    value: !1
                };
            default:
                return {
                    success: !1,
                    U: 3
                }
        }
    }

    function kf(a, b) {
        var c = Qc(a, ef);
        a: {
            switch (c) {
                case 3:
                    var d = ad(a, 3, ef);
                    break a;
                case 4:
                    d = ad(a, 4, ef);
                    break a;
                case 5:
                    d = ad(a, 5, ef);
                    break a
            }
            d = void 0
        }
        if (!d) return {
            success: !1,
            U: 2
        };
        b = (b = b[c]) && b[d];
        if (!b) return {
            success: !1,
            property: d,
            ka: c,
            U: 1
        };
        try {
            var e = Ec(a, 8, x, C());
            var f = b(...e)
        } catch (g) {
            return {
                success: !1,
                property: d,
                ka: c,
                U: 2
            }
        }
        e = K(a, 1);
        if (e === 4) return {
            success: !0,
            value: !!f
        };
        if (e === 5) return {
            success: !0,
            value: f != null
        };
        if (e === 12) a = J(a, Pc(a, ff, 7));
        else a: {
            switch (c) {
                case 4:
                    a = $c(a, Pc(a, ff, 6));
                    break a;
                case 5:
                    a = J(a,
                        Pc(a, ff, 7));
                    break a
            }
            a = void 0
        }
        if (a == null) return {
            success: !1,
            property: d,
            ka: c,
            U: 3
        };
        if (e === 6) return {
            success: !0,
            value: f === a
        };
        if (e === 9) return {
            success: !0,
            value: f != null && va(String(f), a) === 0
        };
        if (f == null) return {
            success: !1,
            property: d,
            ka: c,
            U: 4
        };
        switch (e) {
            case 7:
                c = f < a;
                break;
            case 8:
                c = f > a;
                break;
            case 12:
                c = w(a) && w(f) && (new RegExp(a)).test(f);
                break;
            case 10:
                c = f != null && va(String(f), a) === -1;
                break;
            case 11:
                c = f != null && va(String(f), a) === 1;
                break;
            default:
                return {
                    success: !1,
                    U: 3
                }
        }
        return {
            success: !0,
            value: c
        }
    }

    function lf(a, b) {
        return a ? b ? jf(a, b) : {
            success: !1,
            U: 1
        } : {
            success: !0,
            value: !0
        }
    };

    function mf(a) {
        return Ec(a, 4, x, C())
    }
    var Tc = class extends O {};
    var nf = class extends O {
        getValue() {
            return D(this, Tc, 2)
        }
    };
    var of = class extends O {}, pf = qd( of ), qf = [1, 2, 3, 6, 7, 8];
    var rf = class extends O {};

    function sf(a, b) {
        try {
            let c = d => [{
                [d.wa]: d.sa
            }];
            return JSON.stringify([a.filter(d => d.ja).map(c), z(b), a.filter(d => !d.ja).map(c)])
        } catch (c) {
            return tf(c, b), ""
        }
    }

    function tf(a, b) {
        try {
            te({
                m: Ae(a instanceof Error ? a : Error(String(a))),
                b: K(b, 1) || null,
                v: J(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }

    function uf(a) {
        if (a.A) {
            var b = a.j,
                c = Set;
            var d = Ec(a.j, 3, Wb, C());
            c = [...(new c([...d, ...a.A()]))];
            Kc(b, 3, c, Vb)
        }
        return uc(a.j)
    }
    var vf = class {
        constructor(a, b, c) {
            this.A = c;
            c = new rf;
            a = ld(c, 1, a);
            this.j = jd(a, 2, b)
        }
    };

    function wf(a) {
        var b = new CompressionStream("gzip"),
            c = (new Response(b.readable)).arrayBuffer(),
            d = b.writable.getWriter(),
            e = typeof a === "string" ? (new TextEncoder).encode(a) : a;
        return d.ready.then(() => d.write(e)).then(() => d.close()).then(() => c).then(f => new Uint8Array(f))
    };
    var xf = class extends O {
        getWidth() {
            return I(this, 3)
        }
        getHeight() {
            return I(this, 4)
        }
    };
    var yf = class extends O {};

    function zf(a, b) {
        return N(a, 1, b)
    }

    function Af(a, b) {
        return N(a, 2, b)
    }
    var Bf = class extends O {
        getWidth() {
            return Xc(this, 1) ? ? yc
        }
        getHeight() {
            return Xc(this, 2) ? ? yc
        }
    };
    var Cf = class extends O {};
    var Df = class extends O {};
    var Ef = class extends O {};

    function Ff(a) {
        var b = new Gf;
        return ld(b, 1, a)
    }
    var Gf = class extends O {},
        Hf = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
    var If = class extends O {};
    var Jf = class extends O {
        getValue() {
            return K(this, 1)
        }
    };
    var Kf = class extends O {
        getContentUrl() {
            return J(this, 4)
        }
    };
    var Lf = class extends O {};

    function Mf(a) {
        return Rc(a, Lf, 3)
    }
    var Nf = class extends O {};
    var Of = class extends O {
        getContentUrl() {
            return J(this, 1)
        }
    };
    var Pf = class extends O {};
    var Qf = class extends O {};
    var Rf = class extends O {},
        Sf = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24];
    var Tf = class extends O {};

    function Uf(a, b) {
        return ld(a, 1, b)
    }

    function Vf(a, b) {
        return ld(a, 2, b)
    }
    var Wf = class extends O {};
    var Xf = class extends O {},
        Yf = [1, 2];

    function Zf(a, b) {
        return F(a, 1, b)
    }

    function $f(a, b) {
        return Vc(a, 2, b)
    }

    function ag(a, b) {
        return Kc(a, 4, b, Vb)
    }

    function bg(a, b) {
        return Vc(a, 5, b)
    }

    function cg(a, b) {
        return ld(a, 6, b)
    }
    var dg = class extends O {};
    var eg = class extends O {},
        fg = [1, 2, 3, 4, 6];
    var gg = class extends O {};

    function hg(a) {
        var b = new ig;
        return G(b, 4, jg, a)
    }
    var ig = class extends O {
            getTagSessionCorrelator() {
                return Xc(this, 2) ? ? yc
            }
        },
        jg = [4, 5, 7, 8, 9];
    var kg = class extends O {};

    function lg() {
        var a = mg();
        a = tc(a);
        return jd(a, 1, ng())
    }
    var og = class extends O {};
    var pg = class extends O {};
    var qg = class extends O {
        getTagSessionCorrelator() {
            return Xc(this, 1) ? ? yc
        }
    };
    var rg = class extends O {},
        sg = [1, 7],
        tg = [4, 6, 8];

    function ug(a, b) {
        return gd(a, 2, b)
    }

    function vg(a, b) {
        return N(a, 3, b)
    }

    function wg(a, b) {
        gd(a, 4, b)
    }

    function xg(a, b) {
        return N(a, 6, b)
    }

    function yg(a, b) {
        gd(a, 7, b)
    }

    function zg(a, b) {
        N(a, 10, b)
    }

    function Ag(a, b) {
        return N(a, 13, b)
    }

    function Bg(a, b) {
        N(a, 14, b)
    }

    function Cg(a) {
        var b = Dg();
        return N(a, 16, b)
    }

    function Eg(a, b) {
        N(a, 18, b)
    }

    function Fg(a) {
        var b = Gg(window);
        return N(a, 19, b)
    }

    function Hg(a) {
        Bc(a, 20, Qb(r === r.top))
    }
    var Ig = class extends O {};
    class Jg extends vf {
        constructor() {
            super(...arguments)
        }
    }

    function Kg(a, ...b) {
        Lg(a, ...b.map(c => ({
            ja: !0,
            wa: 3,
            sa: z(c)
        })))
    }

    function Mg(a, ...b) {
        Lg(a, ...b.map(c => ({
            ja: !0,
            wa: 4,
            sa: z(c)
        })))
    }

    function Ng(a, ...b) {
        Lg(a, ...b.map(c => ({
            ja: !0,
            wa: 7,
            sa: z(c)
        })))
    }

    function Og(a, ...b) {
        Lg(a, ...b.map(c => ({
            ja: !0,
            wa: 39,
            sa: z(c)
        })))
    }
    var Pg = class extends Jg {};

    function Qg(a, b) {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    }

    function Rg(a, b, c = 1, d = !1) {
        if (d) {
            d = typeof CompressionStream === "function";
            var e = b.length > 1024;
            typeof document !== "undefined" && document.visibilityState !== "hidden" && d && e ? wf(b).then(f => {
                var g = c === 1 ? 5 : 6,
                    h;
                h === void 0 && (h = 0);
                Xa();
                h = Sa[h];
                for (var k = Array(Math.floor(f.length / 3)), m = h[64] || "", n = 0, l = 0; n < f.length - 2; n += 3) {
                    var p = f[n],
                        q = f[n + 1],
                        u = f[n + 2],
                        y = h[p >> 2];
                    p = h[(p & 3) << 4 | q >> 4];
                    q = h[(q & 15) << 2 | u >> 6];
                    u = h[u & 63];
                    k[l++] = y + p + q + u
                }
                y = 0;
                u = m;
                switch (f.length - n) {
                    case 2:
                        y = f[n + 1], u = h[(y & 15) << 2] || m;
                    case 1:
                        f = f[n], k[l] = h[f >> 2] + h[(f &
                            3) << 4 | y >> 4] + u + m
                }
                Qg(`${a}?e=${g}`, k.join(""))
            }).catch(() => {
                Qg(`${a}?e=${c}`, b)
            }) : Qg(`${a}?e=${c}`, b)
        } else Qg(`${a}?e=${c}`, b)
    };

    function Lg(a, ...b) {
        try {
            a.H && sf(a.g.concat(b), uf(a)).length >= 65536 && Sg(a), a.u && !a.B && (a.B = !0, Tg(a.u, () => {
                Sg(a)
            })), a.g.push(...b), a.g.length >= a.G && Sg(a), a.g.length && a.i === null && (a.i = setTimeout(() => {
                Sg(a)
            }, a.O))
        } catch (c) {
            tf(c, uf(a))
        }
    }

    function Sg(a) {
        a.i !== null && (clearTimeout(a.i), a.i = null);
        if (a.g.length) {
            var b = sf(a.g, uf(a));
            a.N("https://pagead2.googlesyndication.com/pagead/ping", b, 1, !1);
            a.g = []
        }
    }
    var Ug = class extends Pg {
            constructor(a, b, c, d, e, f, g) {
                super(a, b, g);
                this.N = Rg;
                this.O = c;
                this.G = d;
                this.H = e;
                this.u = f;
                this.g = [];
                this.i = null;
                this.B = !1
            }
        },
        Vg = class extends Ug {
            constructor(a, b, c = 1E3, d = 100, e = !1, f, g) {
                super(a, b, c, d, e && !0, f, g)
            }
        };

    function Wg(a, b) {
        var c = Date.now();
        c = Number.isFinite(c) ? Math.round(c) : 0;
        b = fd(b, 1, c);
        c = ee(window);
        b = fd(b, 2, c);
        return fd(b, 6, a.A)
    }

    function Xg(a, b, c, d, e, f) {
        if (a.j) {
            var g = Vf(Uf(new Wf, b), c);
            b = cg($f(Zf(bg(ag(new dg, d), e), g), a.g.slice()), f);
            b = hg(b);
            Mg(a.i, Wg(a, b));
            if (f === 1 || f === 3 || f === 4 && !a.g.some(h => K(h, 1) === K(g, 1) && K(h, 2) === c)) a.g.push(g), a.g.length > 100 && a.g.shift()
        }
    }

    function Yg(a, b, c, d) {
        if (a.j) {
            var e = new Tf;
            b = dd(e, 1, b);
            c = dd(b, 2, c);
            d = kd(c, 3, d);
            c = new ig;
            d = G(c, 8, jg, d);
            Mg(a.i, Wg(a, d))
        }
    }

    function Zg(a, b, c, d, e) {
        if (a.j) {
            var f = new gf;
            b = F(f, 1, b);
            c = kd(b, 2, c);
            d = dd(c, 3, d);
            if (e.ka === void 0) md(d, 4, hf, e.U);
            else switch (e.ka) {
                case 3:
                    c = new bf;
                    c = md(c, 2, cf, e.property);
                    e = kd(c, 1, e.U);
                    G(d, 5, hf, e);
                    break;
                case 4:
                    c = new bf;
                    c = md(c, 3, cf, e.property);
                    e = kd(c, 1, e.U);
                    G(d, 5, hf, e);
                    break;
                case 5:
                    c = new bf, c = md(c, 4, cf, e.property), e = kd(c, 1, e.U), G(d, 5, hf, e)
            }
            e = new ig;
            e = G(e, 9, jg, d);
            Mg(a.i, Wg(a, e))
        }
    }
    var $g = class {
        constructor(a, b, c, d = new Vg(6, "unknown", b)) {
            this.A = a;
            this.u = c;
            this.i = d;
            this.g = [];
            this.j = a > 0 && Md() < 1 / a
        }
    };
    var P = a => {
        var b = "Na";
        if (a.Na && a.hasOwnProperty(b)) return a.Na;
        b = new a;
        return a.Na = b
    };
    var ah = class {
        constructor() {
            this.T = {
                [3]: {},
                [4]: {},
                [5]: {}
            }
        }
    };
    var bh = /^true$/.test("false");

    function ch(a, b) {
        switch (b) {
            case 1:
                return ad(a, 1, qf);
            case 2:
                return ad(a, 2, qf);
            case 3:
                return ad(a, 3, qf);
            case 6:
                return ad(a, 6, qf);
            case 8:
                return ad(a, 8, qf);
            default:
                return null
        }
    }

    function eh(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return H(a, 1);
            case 7:
                return J(a, 3);
            case 2:
                return $c(a, 2);
            case 3:
                return J(a, 3);
            case 6:
                return mf(a);
            case 8:
                return mf(a);
            default:
                return null
        }
    }
    const fh = xd(() => {
        if (!bh) return {};
        try {
            var a = window;
            try {
                var b = a.sessionStorage.getItem("GGDFSSK")
            } catch {
                b = null
            }
            if (b) return JSON.parse(b)
        } catch {}
        return {}
    });

    function gh(a, b, c, d = 0) {
        P(hh).j[d] = P(hh).j[d] ? .add(b) ? ? (new Set).add(b);
        var e = fh();
        if (e[b] != null) return e[b];
        b = ih(d)[b];
        if (!b) return c;
        b = pf(JSON.stringify(b));
        b = jh(b);
        a = eh(b, a);
        return a != null ? a : c
    }

    function jh(a) {
        var b = P(ah).T;
        if (b && Qc(a, qf) !== 8) {
            let c = Oa(E(a, nf, 5, C()), d => {
                d = lf(D(d, df, 1), b);
                return d.success && d.value
            });
            if (c) return c.getValue() ? ? null
        }
        return D(a, Tc, 4) ? ? null
    }
    class hh {
        constructor() {
            this.i = {};
            this.u = [];
            this.j = {};
            this.g = new Map
        }
    }

    function kh(a, b = !1, c) {
        return !!gh(1, a, b, c)
    }

    function lh(a, b = 0, c) {
        a = Number(gh(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function mh(a, b = "", c) {
        a = gh(3, a, b, c);
        return w(a) ? a : b
    }

    function nh(a, b = [], c) {
        a = gh(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function oh(a, b = [], c) {
        a = gh(8, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function ih(a) {
        return P(hh).i[a] || (P(hh).i[a] = {})
    }

    function ph(a, b) {
        var c = ih(b);
        td(a, (d, e) => {
            if (c[e]) {
                var f = d = pf(JSON.stringify(d)),
                    g = Pc(d, qf, 8);
                Ub(A(f, g)) != null && (g = pf(JSON.stringify(c[e])), f = Rc(d, Tc, 4), g = mf(Sc(g)), Wc(f, g));
                c[e] = z(d)
            } else c[e] = d
        })
    }

    function qh(a, b, c, d, e = !1) {
        var f = [],
            g = [];
        for (let l of b) {
            b = ih(l);
            for (let p of a) {
                var h = Qc(p, qf);
                let q = ch(p, h);
                if (!q) continue;
                a: {
                    var k = q;
                    var m = h,
                        n = P(hh).g.get(l) ? .get(q) ? .slice(0) ? ? [];
                    let u = new eg;
                    switch (m) {
                        case 1:
                            md(u, 1, fg, k);
                            break;
                        case 2:
                            md(u, 2, fg, k);
                            break;
                        case 3:
                            md(u, 3, fg, k);
                            break;
                        case 6:
                            md(u, 4, fg, k);
                            break;
                        case 8:
                            md(u, 6, fg, k);
                            break;
                        default:
                            k = void 0;
                            break a
                    }
                    Kc(u, 5, n, Vb);k = u
                }
                k && P(hh).j[l] ? .has(q) && f.push(k);
                h === 8 && b[q] ? (k = pf(JSON.stringify(b[q])), h = Rc(p, Tc, 4), k = mf(Sc(k)), Wc(h, k)) : k && P(hh).g.get(l) ? .has(q) &&
                    g.push(k);
                e || (h = q, k = l, m = d, n = P(hh), n.g.has(k) || n.g.set(k, new Map), n.g.get(k).has(h) || n.g.get(k).set(h, []), m && n.g.get(k).get(h).push(m));
                b[q] = z(p)
            }
        }
        if (f.length || g.length) a = d ? ? void 0, c.j && c.u && (d = new gg, f = Vc(d, 2, f), g = Vc(f, 3, g), a && ed(g, 1, a), f = new ig, g = G(f, 7, jg, g), Mg(c.i, Wg(c, g)))
    }

    function rh(a, b) {
        b = ih(b);
        for (let c of a) {
            a = pf(JSON.stringify(c));
            let d = Qc(a, qf);
            (a = ch(a, d)) && (b[a] || (b[a] = c))
        }
    }

    function sh() {
        return Object.keys(P(hh).i).map(a => Number(a))
    }

    function th(a) {
        P(hh).u.includes(a) || ph(ih(4), a)
    };

    function R(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function uh(a, b, c) {
        return b[a] || c
    }

    function vh(a) {
        R(5, kh, a);
        R(6, lh, a);
        R(7, mh, a);
        R(8, nh, a);
        R(17, oh, a);
        R(13, rh, a);
        R(15, th, a)
    }

    function wh(a) {
        R(4, b => {
            P(ah).T = b
        }, a);
        R(9, (b, c) => {
            var d = P(ah);
            d.T[3][b] == null && (d.T[3][b] = c)
        }, a);
        R(10, (b, c) => {
            var d = P(ah);
            d.T[4][b] == null && (d.T[4][b] = c)
        }, a);
        R(11, (b, c) => {
            var d = P(ah);
            d.T[5][b] == null && (d.T[5][b] = c)
        }, a);
        R(14, b => {
            var c = P(ah);
            for (let d of [3, 4, 5]) Object.assign(c.T[d], b[d])
        }, a)
    }

    function xh(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };

    function yh(a, b, c) {
        a.i = uh(1, b, () => {});
        a.j = (d, e) => uh(2, b, () => [])(d, c, e);
        a.u = d => uh(3, b, () => [])(d ? ? c);
        a.g = d => {
            uh(16, b, () => {})(d, c)
        }
    }
    class zh {
        i() {}
        g() {}
        j() {
            return []
        }
        u() {
            return []
        }
    }

    function Ah(a) {
        return P(zh).u(a)
    };

    function $e(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Ve ? f = c : (f = new Ve, td(c, (h, k) => {
                var m = f,
                    n = m.u++;
                h = Qe(k, h);
                m.g.push(n);
                m.i[n] = h
            }));
            let g = Ue(f, a.domain, a.path + b + "&");
            g && re(r, g)
        } catch (f) {}
    }

    function Bh(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    var Ch = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.g = Math.random()
        }
    };
    let Ze, Dh;
    const Eh = new Pe(window);
    (function(a) {
        Ze = a ? ? new Ch;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        Bh(Ze, window.google_srt);
        Dh = new af(Eh);
        Dh.A(() => {});
        Dh.O(!0);
        window.document.readyState === "complete" ? window.google_measure_js_timing || Oe(Eh) : Eh.g && ne(window, "load", () => {
            window.google_measure_js_timing || Oe(Eh)
        })
    })();

    function Fh(a = r) {
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function Gh(a = Fh()) {
        return a ? ud(a.master) ? a.master : null : null
    };
    var Hh = a => {
            a = Gh(Fh(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1;
            return a.google_unique_id
        },
        Gg = a => {
            a = a.google_unique_id;
            return tb(a) ? a : 0
        },
        Ih = a => {
            if (!a) return "";
            a = a.toLowerCase();
            a.substring(0, 3) != "ca-" && (a = "ca-" + a);
            return a
        };
    let Jh = (new Date).getTime();
    var Kh = {
        nc: 0,
        mc: 1,
        jc: 2,
        bc: 3,
        kc: 4,
        dc: 5,
        lc: 6,
        fc: 7,
        hc: 8,
        ac: 9,
        ec: 10,
        oc: 11
    };
    var Lh = {
        rc: 0,
        sc: 1,
        qc: 2
    };

    function Mh(a) {
        if (a.g != 0) throw Error("Already resolved/rejected.");
    }
    var Ph = class {
        constructor() {
            this.i = new Nh(this);
            this.g = 0
        }
        resolve(a) {
            Mh(this);
            this.g = 1;
            this.u = a;
            Oh(this.i)
        }
        reject(a) {
            Mh(this);
            this.g = 2;
            this.j = a;
            Oh(this.i)
        }
    };

    function Oh(a) {
        switch (a.g.g) {
            case 0:
                break;
            case 1:
                a.i && a.i(a.g.u);
                break;
            case 2:
                a.j && a.j(a.g.j);
                break;
            default:
                throw Error("Unhandled deferred state.");
        }
    }
    var Nh = class {
        constructor(a) {
            this.g = a
        }
        then(a, b) {
            if (this.i) throw Error("Then functions already set.");
            this.i = a;
            this.j = b;
            Oh(this)
        }
    };
    var Qh = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new Qh(La(this.g, a))
        }
        apply(a) {
            return new Qh(a(this.g.slice(0)))
        }
        sort(a) {
            return new Qh(this.g.slice(0).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            var b = this.g.slice(0);
            b.push(a);
            return new Qh(b)
        }
    };

    function Rh(a, b) {
        var c = [],
            d = a.length;
        for (let e = 0; e < d; e++) c.push(a[e]);
        c.forEach(b, void 0)
    };
    var Th = class {
        constructor() {
            this.g = {};
            this.i = {}
        }
        set(a, b) {
            var c = Sh(a);
            this.g[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = Sh(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        clear() {
            this.g = {};
            this.i = {}
        }
    };

    function Sh(a) {
        return a instanceof Object ? String(ma(a)) : a + ""
    };

    function Uh(a) {
        return new Vh({
            value: a
        }, null)
    }

    function Wh(a) {
        return new Vh(null, a)
    }

    function Xh(a) {
        try {
            return Uh(a())
        } catch (b) {
            return Wh(b)
        }
    }

    function Yh(a) {
        return a.g != null ? a.getValue() : null
    }

    function Zh(a, b) {
        a.g != null && b(a.getValue());
        return a
    }

    function $h(a, b) {
        a.g != null || b(a.i);
        return a
    }
    var Vh = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return this.g != null ? (a = a(this.getValue()), a instanceof Vh ? a : Uh(a)) : this
        }
    };
    var ai = class {
        constructor(a) {
            this.g = new Th;
            if (a)
                for (let b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return this.g.g[Sh(a)] !== void 0
        }
    };
    var bi = class {
        constructor() {
            this.g = new Th
        }
        set(a, b) {
            var c = this.g.get(a);
            c || (c = new ai, this.g.set(a, c));
            c.add(b)
        }
    };
    var ci = class extends O {
        getId() {
            return cd(this, 3)
        }
    };
    var di = class {
        constructor({
            ub: a,
            uc: b,
            Gc: c,
            Rb: d
        }) {
            this.g = b;
            this.u = new Qh(a || []);
            this.j = d;
            this.i = c
        }
    };

    function ei(a) {
        var b = a.length;
        if (b === 0) return 0;
        var c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };
    const gi = a => {
            var b = [],
                c = a.u;
            c && c.g.length && b.push({
                da: "a",
                ha: fi(c)
            });
            a.g != null && b.push({
                da: "as",
                ha: a.g
            });
            a.i != null && b.push({
                da: "i",
                ha: String(a.i)
            });
            a.j != null && b.push({
                da: "rp",
                ha: String(a.j)
            });
            b.sort(function(d, e) {
                return d.da.localeCompare(e.da)
            });
            b.unshift({
                da: "t",
                ha: "aa"
            });
            return b
        },
        fi = a => {
            a = a.g.slice(0).map(hi);
            a = JSON.stringify(a);
            return ei(a)
        },
        hi = a => {
            var b = {};
            x(A(a, 7)) != null && (b.q = cd(a, 7));
            Zc(a, 2) != null && (b.o = Zc(a, 2, zc));
            Zc(a, 5) != null && (b.p = Zc(a, 5, zc));
            return b
        };

    function ii(a) {
        return L(a, 2)
    }
    var ji = class extends O {
        setLocation(a) {
            return kd(this, 1, a)
        }
    };

    function ki(a) {
        var b = [].slice.call(arguments).filter(wd(e => e === null));
        if (!b.length) return null;
        var c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Za || []);
            d = Object.assign(d, e.lb)
        });
        return new li(c, d)
    }

    function mi(a) {
        switch (a) {
            case 1:
                return new li(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new li(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new li(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new li(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function ni(a) {
        if (a == null) var b = null;
        else {
            b = li;
            var c = gi(a);
            a = [];
            for (let d of c) c = String(d.ha), a.push(d.da + "." + (c.length <= 20 ? c : c.slice(0, 19) + "_"));
            b = new b(null, {
                google_placement_id: a.join("~")
            })
        }
        return b
    }
    var li = class {
        constructor(a, b) {
            this.Za = a;
            this.lb = b
        }
    };
    var oi = new li(["google-auto-placed"], {
        google_reactive_ad_format: 40,
        google_tag_origin: "qs"
    });
    var pi = qd(class extends O {});

    function qi(a) {
        return D(a, ci, 1)
    }

    function ri(a) {
        return L(a, 2)
    }
    var si = class extends O {};
    var ti = class extends O {};
    var ui = class extends O {};

    function vi(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];
            var c = a.className ? a.className.split(/\s+/) : [];a = {};
            for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
            for (c = 0; c < b.length; ++c)
                if (!a[b[c]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    };

    function wi(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    let d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        vi(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    };
    var S = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        xi = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        yi = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var zi = new xi(619278254, 10),
        Ai = new S(1397, !0),
        Bi = new xi(1359),
        Ci = new xi(1358),
        Di = new S(1360),
        Ei = new xi(1357),
        Fi = new S(1345),
        Gi = new xi(1130, 100),
        Hi = new xi(1340, .2),
        Ii = new xi(1338, .3),
        Ji = new xi(1339, .3),
        Ki = new S(1337),
        Li = new class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        }(14),
        Mi = new S(1342, !0),
        Ni = new S(1344),
        Oi = new S(1399),
        Pi = new xi(1400),
        Qi = new S(316),
        Ri = new S(313),
        Si = new S(369),
        Ti = new S(45751075),
        Ui = new yi(45736067, "ca-pub-7178919035426667 ca-pub-6430486603399192 ca-pub-6217516951440692 ca-pub-3269777183832488 ca-pub-4286071012672876 ca-pub-6893876361346206 ca-pub-6865079278713445 ca-pub-6062692039613877 ca-pub-8700401253704627 ca-pub-7409460644561046 ca-pub-1807333429605702 ca-pub-4414232724432396 ca-pub-8878716159434368 ca-pub-1725310704471587 ca-pub-7286478979881995 ca-pub-5420212072167331 ca-pub-3001544606526418 ca-pub-7647808421428026 ca-pub-6109939056400055 ca-pub-6907038225839490 ca-pub-6462695325264077 ca-pub-9260533539525355 ca-pub-9284205722386242 ca-pub-0636857377230346 ca-pub-9067164180551135 ca-pub-9649286969563355 ca-pub-6150993149788596 ca-pub-0085763304086106".split(" ")),
        Vi = new class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        }(683929765),
        Wi = new S(839747468, !0),
        Xi = new S(506914611),
        Yi = new xi(9603, 4),
        Zi = new S(711741274),
        $i = new S(662101537),
        aj = new xi(930746950),
        bj = new S(932979855),
        cj = new S(834350237),
        dj = new xi(1079, 5),
        de = new yi(1934, ["AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
            "Amm8/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9",
            "A93bovR+QVXNx2/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A1S5fojrAunSDrFbD8OfGmFHdRFZymSM/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"
        ]),
        ej = new S(84);
    var ce = class {
        constructor() {
            var a = {};
            this.j = (b, c) => a[b] != null ? a[b] : c;
            this.A = (b, c) => a[b] != null ? a[b] : c;
            this.g = (b, c) => a[b] != null ? a[b] : c;
            this.i = (b, c) => a[b] != null ? a[b] : c;
            this.u = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.B = () => {}
        }
    };

    function T(a) {
        return P(ce).j(a.g, a.defaultValue)
    }

    function fj(a) {
        return P(ce).A(a.g, a.defaultValue)
    };

    function gj(a, b) {
        var c = e => {
                e = hj(e);
                return e == null ? !1 : 0 < e
            },
            d = e => {
                e = hj(e);
                return e == null ? !1 : 0 > e
            };
        switch (b) {
            case 0:
                return {
                    init: ij(a.previousSibling, c),
                    oa: e => ij(e.previousSibling, c),
                    ta: 0
                };
            case 2:
                return {
                    init: ij(a.lastChild, c),
                    oa: e => ij(e.previousSibling, c),
                    ta: 0
                };
            case 3:
                return {
                    init: ij(a.nextSibling, d),
                    oa: e => ij(e.nextSibling, d),
                    ta: 3
                };
            case 1:
                return {
                    init: ij(a.firstChild, d),
                    oa: e => ij(e.nextSibling, d),
                    ta: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function hj(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function ij(a, b) {
        return a && b(a) ? a : null
    };
    var jj = {
        overlays: 1,
        interstitials: 2,
        vignettes: 2,
        inserts: 3,
        immersives: 4,
        list_view: 5,
        full_page: 6,
        side_rails: 7
    };

    function kj(a) {
        a = a.document;
        var b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function U(a) {
        return kj(a).clientWidth ? ? void 0
    };

    function lj(a, b) {
        do {
            let c = Wd(a, b);
            if (c && c.position === "fixed") return !1
        } while (a = a.parentElement);
        return !0
    }

    function mj(a, b, c) {
        var d;
        return a.style && !!a.style[c] && $d(a.style[c]) || (d = Wd(a, b)) && !!d[c] && $d(d[c]) || null
    }

    function nj(a, b) {
        try {
            let c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function oj(a, b) {
        return (a = nj(a, b)) ? a.y : 0
    }

    function pj(a, b) {
        return oj(a, b) < kj(b).clientHeight - 100
    }

    function qj(a, b) {
        var c = mj(b, a, "height");
        if (c) return c;
        var d = b.style.height;
        b.style.height = "inherit";
        c = mj(b, a, "height");
        b.style.height = d;
        if (c) return c;
        c = Infinity;
        do(d = b.style && $d(b.style.height)) && (c = Math.min(c, d)), (d = mj(b, a, "maxHeight")) && (c = Math.min(c, d)); while (b.parentElement && (b = b.parentElement) && b.tagName !== "HTML");
        return c
    };

    function rj(a, b) {
        var c;
        return a.style && a.style.zIndex || (c = Wd(a, b)) && c.zIndex || null
    };
    var sj = {
        google_ad_channel: !0,
        google_ad_client: !0,
        google_ad_host: !0,
        google_ad_host_channel: !0,
        google_adtest: !0,
        google_tag_for_child_directed_treatment: !0,
        google_tag_for_age_treatment: !0,
        google_tag_for_under_age_of_consent: !0,
        google_tag_partner: !0,
        google_restrict_data_processing: !0,
        google_page_url: !0,
        google_debug_params: !0,
        google_adbreak_test: !0,
        google_ad_frequency_hint: !0,
        google_admob_interstitial_slot: !0,
        google_admob_rewarded_slot: !0,
        google_admob_ads_only: !0,
        google_ad_start_delay_hint: !0,
        google_max_ad_content_rating: !0,
        google_traffic_source: !0,
        google_overlays: !0,
        google_privacy_treatments: !0,
        google_special_category_data: !0,
        google_ad_intent_query: !0,
        google_ad_intent_rs_token: !0,
        google_ad_intents_format: !0,
        google_ad_intents_in_drawer_format: !0,
        google_ad_intents_encoded_verticals4_ids: !0,
        google_ad_intents_encoded_browseonomy_ids: !0,
        google_ad_intents_ad_position: !0
    };
    const tj = RegExp("(^| )adsbygoogle($| )");

    function uj(a, b) {
        for (let c = 0; c < b.length; c++) {
            let d = b[c],
                e = Kd(d.property);
            a[e] = d.value
        }
    };
    var vj = class extends O {
        g() {
            return Xc(this, 1)
        }
    };
    var wj = class extends O {};
    var xj = class extends O {};
    var yj = class extends O {};
    var zj = class extends O {};
    var Aj = class extends O {
            getName() {
                return cd(this, 4)
            }
        },
        Bj = [1, 2, 3];
    var Cj = class extends O {};
    var Dj = class extends O {};
    var Ej = class extends O {};
    var Gj = class extends O {
            g() {
                return bd(this, Ej, 2, Fj)
            }
        },
        Fj = [1, 2];
    var Hj = class extends O {
        g() {
            return D(this, Gj, 3)
        }
    };
    var Ij = class extends O {},
        Jj = qd(Ij);

    function Kj(a) {
        var b = [];
        Rh(a.getElementsByTagName("p"), function(c) {
            Lj(c) >= 100 && b.push(c)
        });
        return b
    }

    function Lj(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        var b = 0;
        Rh(a.childNodes, function(c) {
            b += Lj(c)
        });
        return b
    }

    function Mj(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Nj(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function Oj(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.u)
        } catch (d) {}
        if (!c.length) return [];
        b = Qa(c);
        b = Nj(a, b);
        typeof a.i === "number" && (c = a.i, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.j === "number") {
            c = [];
            for (let d = 0; d < b.length; d++) {
                let e = Kj(b[d]),
                    f = a.j;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    var Pj = class {
        constructor(a, b, c, d) {
            this.u = a;
            this.i = b;
            this.j = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.u,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.g
            })
        }
    };
    var Qj = class {
        constructor() {
            this.i = Rd `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        K(a, b, c = .01, d = "jserror") {
            if (Math.random() > c) return !1;
            xe(b) || (b = new ye(b, {
                context: a,
                id: d
            }));
            r.google_js_errors = r.google_js_errors || [];
            r.google_js_errors.push(b);
            r.error_rep_loaded || (Ud(r.document, this.i), r.error_rep_loaded = !0);
            return !1
        }
        g(a, b) {
            try {
                return b()
            } catch (c) {
                if (!this.K(a, c, .01, "jserror")) throw c;
            }
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        ua(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.K(a, c instanceof Error ? c : Error(c), void 0)
            })
        }
    };

    function Rj(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function Sj(a, b, c, d, e = !1) {
        var f = d || window,
            g = typeof queueMicrotask !== "undefined";
        return function(...h) {
            e && g && queueMicrotask(() => {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var k = He(),
                m = 3;
            try {
                var n = b.apply(this, h)
            } catch (l) {
                m = 13;
                if (!c) throw l;
                c(a, l)
            } finally {
                f.google_measure_js_timing && k && Rj({
                    label: a.toString(),
                    value: k,
                    duration: (He() || 0) - k,
                    type: m,
                    ...(e && g && {
                        taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                    })
                }, f)
            }
            return n
        }
    }

    function Tj(a, b) {
        return Sj(a, b, (c, d) => {
            (new Qj).K(c, d)
        }, void 0, !1)
    };

    function Uj(a, b, c) {
        return Sj(a, b, void 0, c, !0).apply()
    }

    function Vj(a) {
        if (!a) return null;
        var b = cd(a, 7);
        if (cd(a, 1) || a.getId() || Ec(a, 4, x, C()).length > 0) {
            var c = a.getId(),
                d = cd(a, 1),
                e = Ec(a, 4, x, C());
            b = Zc(a, 2, zc);
            var f = Zc(a, 5, zc);
            a = Wj(L(a, 6));
            let g = "";
            d && (g += d);
            c && (g += "#" + Mj(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + Mj(e[c]);
            b = (e = g) ? new Pj(e, b, f, a) : null
        } else b = b ? new Pj(b, Zc(a, 2, zc), Zc(a, 5, zc), Wj(L(a, 6))) : null;
        return b
    }
    const Xj = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Wj(a) {
        return a == null ? a : Xj[a]
    }
    const Yj = {
        1: 0,
        2: 1,
        3: 2,
        4: 3
    };

    function Zj(a) {
        return a.google_ama_state = a.google_ama_state || {}
    }

    function ak(a) {
        a = Zj(a);
        return a.optimization = a.optimization || {}
    };
    var bk = a => {
        switch (L(a, 8)) {
            case 1:
            case 2:
                if (a == null) var b = null;
                else b = D(a, ci, 1), b == null ? b = null : (a = L(a, 2), b = a == null ? null : new di({
                    ub: [b],
                    Rb: a
                }));
                return b != null ? Uh(b) : Wh(Error("Missing dimension when creating placement id"));
            case 3:
                return Wh(Error("Missing dimension when creating placement id"));
            default:
                return b = "Invalid type: " + L(a, 8), Wh(Error(b))
        }
    };
    var ck = qd(class extends O {});

    function ng() {
        return "m202606240101"
    };
    var dk = pd(kg);
    var mg = pd(og);

    function ek(a, b) {
        return b(a) ? a : void 0
    }

    function fk(a, b, c, d, e) {
        c = c instanceof ye ? c.error : c;
        var f = new rg,
            g = new qg;
        try {
            var h = ee(window);
            fd(g, 1, h)
        } catch (p) {}
        try {
            var k = Ah();
            Kc(g, 2, k, Vb)
        } catch (p) {}
        try {
            jd(g, 3, window.document.URL)
        } catch (p) {}
        h = F(f, 2, g);
        k = new pg;
        b = ld(k, 1, b);
        try {
            var m = w(c ? .name) ? c.name : "Unknown error";
            jd(b, 2, m)
        } catch (p) {}
        try {
            var n = w(c ? .message) ? c.message : `Caught ${c}`;
            jd(b, 3, n)
        } catch (p) {}
        try {
            var l = w(c ? .stack) ? c.stack : Error().stack;
            l && Kc(b, 4, l.split(/\n\s*/), cc)
        } catch (p) {}
        m = G(h, 1, sg, b);
        if (e) {
            n = 0;
            switch (e.errSrc) {
                case "LCC":
                    n = 1;
                    break;
                case "PVC":
                    n = 2
            }
            l = lg();
            b = ek(e.shv, w);
            l = jd(l, 2, b);
            n = ld(l, 6, n);
            l = dk();
            l = tc(l);
            b = ek(e.es, xb());
            l = Kc(l, 1, b, Vb);
            l = uc(l);
            n = F(n, 4, l);
            l = ek(e.client, w);
            n = id(n, 3, l);
            l = ek(e.slotname, w);
            n = jd(n, 7, l);
            e = ek(e.tag_origin, w);
            e = jd(n, 8, e);
            e = uc(e)
        } else e = nd(lg());
        e = G(m, 6, tg, e);
        d = fd(e, 5, d ? ? 1);
        Kg(a, d)
    };
    var hk = class {
        constructor() {
            this.g = gk
        }
    };

    function gk() {
        return {
            Nb: Pd() + (Pd() & 2 ** 21 - 1) * 2 ** 32,
            Ab: Number.MAX_SAFE_INTEGER
        }
    };
    var kk = class {
        constructor(a = !1) {
            var b = ik;
            this.G = jk;
            this.B = a;
            this.H = b;
            this.i = null;
            this.j = this.K
        }
        N(a) {
            this.j = a
        }
        A(a) {
            this.i = a
        }
        O() {}
        g(a, b, c) {
            try {
                var d = b()
            } catch (e) {
                b = this.B;
                try {
                    b = this.j(a, ze(e), void 0, c)
                } catch (f) {
                    this.K(217, f)
                }
                if (b) window.console ? .error ? .(e);
                else throw e;
            }
            return d
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        ua(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.K(a, c instanceof Error ? c : Error(c), void 0, void 0)
            })
        }
        K(a, b, c, d) {
            try {
                let g = c === void 0 ? 1 / this.H : c === 0 ? 0 : 1 / c;
                var e = (new hk).g();
                if (g > 0 && e.Nb * g <= e.Ab) {
                    var f = this.G;
                    c = {};
                    if (this.i) try {
                        this.i(c)
                    } catch (h) {}
                    if (d) try {
                        d(c)
                    } catch (h) {}
                    fk(f, a, b, g, c)
                }
            } catch (g) {}
            return this.B
        }
    };
    var W = class extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, W) : this.stack = Error().stack || ""
        }
    };
    let jk, lk, mk, nk, ik;
    const ok = new Pe(r);

    function pk(a) {
        a != null && (r.google_measure_js_timing = a);
        r.google_measure_js_timing || Oe(ok)
    }(function(a, b, c = !0) {
        ({
            Qb: ik,
            Eb: mk
        } = qk());
        lk = a || new Ch;
        Bh(lk, mk);
        jk = b || new Vg(2, ng(), 1E3, void 0, void 0, void 0, Ah);
        nk = new kk(c);
        r.document.readyState === "complete" ? pk() : ok.g && ne(r, "load", () => {
            pk()
        })
    })();

    function rk(a, b, c) {
        return nk.g(a, b, c)
    }

    function sk(a, b) {
        return nk.u(a, b)
    }

    function tk(a, b) {
        nk.ua(a, b)
    }

    function uk(a, b, c = .01) {
        var d = Ah();
        !b.eid && d.length && (b.eid = d.toString());
        $e(lk, a, b, !0, c)
    }

    function vk(a, b, c = ik, d, e) {
        return nk.K(a, b, c, d, e)
    }

    function wk(a, b, c = ik, d, e) {
        return (xe(b) ? b.msg || Ae(b.error) : Ae(b)).indexOf("TagError") === 0 ? ((xe(b) ? b.error : b).pbr = !0, !1) : vk(a, b, c, d, e)
    }

    function qk() {
        if (tb(r.google_srt)) {
            var a = r.google_srt;
            var b = r.google_srt === 0 ? 1 : .01
        } else a = Math.random(), b = .01;
        return {
            Qb: b,
            Eb: a
        }
    };

    function xk(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        var c = b;
        return c ? Xh(() => ck(c)) : Uh(null)
    };

    function yk() {
        if (zk) return zk;
        var a = Gh() || window;
        var b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? zk = b : a.google_persistent_state_async = zk = new Ak
    }

    function Bk(a) {
        return Ck[a] || `google_ps_${a}`
    }

    function Dk(a, b, c) {
        b = Bk(b);
        a = a.S;
        var d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function Ek(a, b, c) {
        return Dk(a, b, () => c)
    }
    var Ak = class {
            constructor() {
                this.S = {}
            }
        },
        zk = null;
    const Ck = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function Fk(a) {
        this.g = a || {
            cookie: ""
        }
    }
    Fk.prototype.set = function(a, b, c) {
        var d = !1;
        if (typeof c === "object") {
            var e = c.sameSite;
            d = c.secure || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.Kb
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        h === void 0 && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (h < 0 ? "" : h == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + h * 1E3)).toUTCString()) + (d ? ";secure" : "") + (e != null ?
            ";samesite=" + e : "")
    };
    Fk.prototype.get = function(a, b) {
        var c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = ua(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    Fk.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    Fk.prototype.clear = function() {
        var a = (this.g.cookie || "").split(";"),
            b = [],
            c = [];
        for (let f = 0; f < a.length; f++) {
            var d = ua(a[f]);
            var e = d.indexOf("=");
            e == -1 ? (b.push(""), c.push(d)) : (b.push(d.substring(0, e)), c.push(d.substring(e + 1)))
        }
        for (c = b.length - 1; c >= 0; c--) a = b[c], this.get(a), this.set(a, "", {
            Kb: 0,
            path: void 0,
            domain: void 0
        })
    };

    function Gk(a, b = window) {
        if (H(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    };

    function Hk(a) {
        var b = new Ik;
        return Bc(b, 5, Qb(a))
    }
    var Ik = class extends O {};

    function Jk() {
        this.A = this.A;
        this.i = this.i
    }
    Jk.prototype.A = !1;
    Jk.prototype.dispose = function() {
        this.A || (this.A = !0, this.G())
    };
    Jk.prototype[fa(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function Kk(a, b) {
        a.A ? b() : (a.i || (a.i = []), a.i.push(b))
    }
    Jk.prototype.G = function() {
        if (this.i)
            for (; this.i.length;) this.i.shift()()
    };

    function Lk(a) {
        a.addtlConsent === void 0 || w(a.addtlConsent) || (a.addtlConsent = void 0);
        a.gdprApplies === void 0 || ub(a.gdprApplies) || (a.gdprApplies = void 0);
        return a.tcString !== void 0 && !w(a.tcString) || a.listenerId !== void 0 && !tb(a.listenerId) ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }

    function Mk(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = Lk(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (te({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function Nk(a) {
        if (a.g) return a.g;
        a: {
            let d = a.j;
            for (let e = 0; e < 50; ++e) {
                try {
                    var b = !(!d.frames || !d.frames.__tcfapiLocator)
                } catch {
                    b = !1
                }
                if (b) {
                    b = d;
                    break a
                }
                b: {
                    try {
                        let f = d.parent;
                        if (f && f !== d) {
                            var c = f;
                            break b
                        }
                    } catch {}
                    c = null
                }
                if (!(d = c)) break
            }
            b = null
        }
        a.g = b;
        return a.g
    }

    function Ok(a, b, c, d) {
        c || (c = () => {});
        var e = a.j;
        typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : Nk(a) ? (Pk(a), e = ++a.H, a.B[e] = c, a.g && a.g.postMessage({
            __tcfapiCall: {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }
        }, "*")) : c({}, !1)
    }

    function Pk(a) {
        if (!a.u) {
            var b = c => {
                if (c.source === a.g) try {
                    var d = (w(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                    a.B[d.callId](d.returnValue, d.success)
                } catch (e) {}
            };
            a.u = b;
            ne(a.j, "message", b)
        }
    }
    var Qk = class extends Jk {
        constructor(a) {
            var b = {};
            super();
            this.g = null;
            this.B = {};
            this.H = 0;
            this.u = null;
            this.j = a;
            this.la = b.la ? ? 500;
            this.Ia = b.Ia ? ? !1
        }
        G() {
            this.B = {};
            this.u && (oe(this.j, "message", this.u), delete this.u);
            delete this.B;
            delete this.j;
            delete this.g;
            super.G()
        }
        addEventListener(a) {
            var b = {
                    internalBlockOnErrors: this.Ia
                },
                c = yd(() => {
                    a(b)
                }),
                d = 0;
            this.la !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.la));
            var e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = Lk(b),
                    b.internalBlockOnErrors = this.Ia, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                Ok(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && Ok(this, "removeEventListener", null, a.listenerId)
        }
    };
    var Vk = ({
            l: a,
            ca: b,
            la: c,
            yb: d,
            pa: e = !1,
            qa: f = !1
        }) => {
            b = Rk({
                l: a,
                ca: b,
                pa: e,
                qa: f
            });
            b.g != null || b.i.message != "tcunav" ? d(b) : Sk(a, c).then(g => g.map(Tk)).then(g => g.map(h => Uk(a, h))).then(d)
        },
        Rk = ({
            l: a,
            ca: b,
            pa: c = !1,
            qa: d = !1
        }) => {
            if (!Wk({
                    l: a,
                    ca: b,
                    pa: c,
                    qa: d
                })) return Uk(a, Hk(!0));
            b = yk();
            return (b = Ek(b, 24)) ? Uk(a, Tk(b)) : Wh(Error("tcunav"))
        };

    function Wk({
        l: a,
        ca: b,
        pa: c,
        qa: d
    }) {
        if (d = !d) d = new Qk(a), d = typeof d.j.__tcfapi === "function" || Nk(d) != null;
        if (!d) {
            if (c = !c) {
                if (b) {
                    a = xk(a);
                    if (a.g != null)
                        if ((a = a.getValue()) && Ub(A(a, 1)) != null) b: switch (a = K(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else vk(806, a.i), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function Sk(a, b) {
        return Promise.race([Xk(), Yk(a, b)])
    }

    function Xk() {
        return (new Promise(a => {
            var b = yk();
            a = {
                resolve: a
            };
            var c = Ek(b, 25, []);
            c.push(a);
            b.S[Bk(25)] = c
        })).then(Zk)
    }

    function Yk(a, b) {
        return new Promise(c => {
            a.setTimeout(c, b, Wh(Error("tcto")))
        })
    }

    function Zk(a) {
        return a ? Uh(a) : Wh(Error("tcnull"))
    }

    function Tk(a) {
        var b = {};
        if (Mk(a))
            if (a.gdprApplies === !1) a = !0;
            else if (a.tcString === "tcunavailable") a = !b.eb;
        else if ((b.eb || a.gdprApplies !== void 0 || b.xc) && (b.eb || w(a.tcString) && a.tcString.length)) {
            b: {
                if (a.publisher && a.publisher.restrictions && (b = a.publisher.restrictions["1"], b !== void 0)) {
                    b = b["755"];
                    break b
                }
                b = void 0
            }
            b === 0 ? a = !1 : a.purpose && a.vendor ? (b = a.vendor.consents, (b = !(!b || !b["755"])) && a.purposeOneTreatment && a.publisherCC === "CH" ? a = !0 : (b && (a = a.purpose.consents, b = !(!a || !a["1"])), a = b)) : a = !0
        }
        else a = !0;
        else a = !1;
        return Hk(a)
    }

    function Uk(a, b) {
        return (a = Gk(b, a)) ? Uh(a) : Wh(Error("unav"))
    };
    var $k = (a, b) => {
        var c = [],
            d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function al(a, b) {
        var c = new bi,
            d = new ai;
        b.forEach(e => {
            if (bd(e, yj, 1, Bj)) {
                e = bd(e, yj, 1, Bj);
                if (D(e, si, 1) && qi(D(e, si, 1)) && D(e, si, 2) && qi(D(e, si, 2))) {
                    let g = bl(a, qi(D(e, si, 1))),
                        h = bl(a, qi(D(e, si, 2)));
                    if (g && h)
                        for (var f of $k({
                                anchor: g,
                                position: ri(D(e, si, 1))
                            }, {
                                anchor: h,
                                position: ri(D(e, si, 2))
                            })) c.set(ma(f.anchor), f.position)
                }
                D(e, si, 3) && qi(D(e, si, 3)) && (f = bl(a, qi(D(e, si, 3)))) && c.set(ma(f), ri(D(e, si, 3)))
            } else bd(e, zj, 2, Bj) ? cl(a, bd(e, zj, 2, Bj), c) : bd(e, xj, 3, Bj) && dl(a, bd(e, xj, 3, Bj), d)
        });
        return new el(c, d)
    }
    var el = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };
    const cl = (a, b, c) => {
            D(b, si, 2) ? (b = D(b, si, 2), (a = bl(a, qi(b))) && c.set(ma(a), ri(b))) : D(b, ci, 1) && (a = fl(a, D(b, ci, 1))) && a.forEach(d => {
                d = ma(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        dl = (a, b, c) => {
            D(b, ci, 1) && (a = fl(a, D(b, ci, 1))) && a.forEach(d => {
                c.add(ma(d))
            })
        },
        bl = (a, b) => (a = fl(a, b)) && a.length > 0 ? a[0] : null,
        fl = (a, b) => (b = Vj(b)) ? Oj(b, a) : null;
    var gl = class {
        constructor() {
            var a = Math.random;
            this.g = Math.floor(a() * 2 ** 52);
            this.i = 0
        }
    };

    function hl(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (il(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function jl(a) {
        a = kl(a);
        return a.has("all") || a.has("after")
    }

    function ll(a) {
        a = kl(a);
        return a.has("all") || a.has("before")
    }

    function kl(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function il(a) {
        var b = kl(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var ml = class {
        constructor() {
            this.g = new Set;
            this.i = new gl
        }
    };

    function nl(a, b) {
        if (!a) return !1;
        a = Wd(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function ol(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function pl(a) {
        return !!a.nextSibling || !!a.parentNode && pl(a.parentNode)
    };

    function ql(a = []) {
        var b = Date.now();
        return La(a, c => b - c < 6E5)
    }

    function rl(a) {
        try {
            let b = a.getItem("__lsa__");
            if (!b) return [];
            let c;
            try {
                c = JSON.parse(b)
            } catch (d) {}
            if (!Array.isArray(c) || Na(c, d => !Number.isInteger(d))) return a.removeItem("__lsa__"), [];
            c = ql(c);
            c.length || a ? .removeItem("__lsa__");
            return c
        } catch (b) {
            return null
        }
    };

    function sl(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };

    function tl(a) {
        return {
            tc: ul(a),
            vc: X(a, "body ins.adsbygoogle"),
            rb: vl(a),
            sb: X(a, ".google-auto-placed"),
            tb: wl(a),
            Bb: xl(a),
            zc: yl(a),
            Ic: zl(a),
            Mb: Al(a),
            yc: X(a, "div.googlepublisherpluginad"),
            Yb: X(a, "html > ins.adsbygoogle")
        }
    }

    function yl(a) {
        return Bl(a) || X(a, "div[id^=div-gpt-ad]")
    }

    function Bl(a) {
        var b = sl(a);
        return b ? La(Ma(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
    }

    function X(a, b) {
        return Qa(a.document.querySelectorAll(b))
    }

    function wl(a) {
        return X(a, "ins.adsbygoogle[data-anchor-status]")
    }

    function vl(a) {
        return X(a, "iframe[id^=aswift_],iframe[id^=google_ads_frame]")
    }

    function zl(a) {
        return X(a, "ins.adsbygoogle[data-ad-format=autorelaxed]")
    }

    function xl(a) {
        return yl(a).concat(X(a, "iframe[id^=google_ads_iframe]"))
    }

    function Al(a) {
        return X(a, "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")
    }

    function ul(a) {
        return X(a, "ins.adsbygoogle-ablated-ad-slot")
    }

    function Cl(a) {
        return a.filter(b => !b.querySelector('[data-google-ad-efd="true"]'))
    }

    function Dl(a) {
        var b = [];
        for (let c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                let e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function El(a, b) {
        if (a.u) return !0;
        a.u = !0;
        var c = E(a.j, ui, 1, C());
        a.i = 0;
        var d = Fl(a.N);
        var e = a.g,
            f = H(a.j, 36),
            g = a.H,
            h;
        try {
            var k = (h = e.localStorage.getItem("google_ama_settings")) ? pi(h) : null
        } catch (y) {
            k = null
        }
        h = k !== null && H(k, 2);
        k = Zj(e);
        h && (k.eatf = !0, we(7, [!0, 0, !1]));
        b: {
            h = {
                Gb: !1,
                Hb: !1,
                Cb: !0
            };
            var m = X(e, ".google-auto-placed");
            let y = wl(e),
                M = zl(e),
                za = xl(e),
                Ta = Al(e),
                pb = ul(e),
                Ca = X(e, "div.googlepublisherpluginad"),
                Kb = X(e, "html > ins.adsbygoogle");
            var n = [].concat(...vl(e), ...X(e, "body ins.adsbygoogle")),
                l = [];h.Cb &&
            (l = l.concat(X(e, "ins.adsbygoogle[data-ad-hi]")));
            for (let [oc, Ke] of [
                    [h.Bc, m],
                    [h.Gb, y],
                    [h.Ec, M],
                    [h.Cc, za],
                    [h.Fc, Ta],
                    [h.Ac, pb],
                    [h.Dc, Ca],
                    [h.Hb, Kb]
                ]) m = Ke,
            oc === !1 ? l = l.concat(m) : n = n.concat(m);n = Dl(n);l = Dl(l);n = n.slice(0);
            for (p of l)
                for (l = 0; l < n.length; l++)(p.contains(n[l]) || n[l].contains(p)) && n.splice(l, 1);
            var p = n;p = h.wc ? Cl(p) : p;h = kj(e).clientHeight;
            for (l = 0; l < p.length; l++)
                if (!(p[l].getBoundingClientRect().top > h)) {
                    p = !0;
                    break b
                }
            p = !1
        }
        if (p) var q = k.eatfAbg = !0;
        else if (T(Ti) && f) {
            e = Rk({
                l: e,
                ca: g
            });
            if (f = e.g != null) {
                e =
                    Yh(e);
                if (!(f = e == null)) {
                    try {
                        e.setItem("__storage_test__", "__storage_test__");
                        var u = e.getItem("__storage_test__");
                        e.removeItem("__storage_test__");
                        q = u === "__storage_test__"
                    } catch (y) {
                        q = !1
                    }
                    f = !q
                }
                q = f ? null : rl(e);
                u = fj(zi);
                f = !(q ? .length && Math.floor((Date.now() - Math.max(...q)) / 6E4) <= u)
            }
            q = f
        } else q = !1;
        if (q) return !0;
        q = new ai([2]);
        for (u = 0; u < c.length; u++) {
            a: {
                e = a;g = c[u];f = u;k = b;
                (p = !D(g, ji, 4)) || (p = q, h = p.contains, l = D(g, ji, 4), l = L(l, 1), p = !h.call(p, l));
                if (p || L(g, 8) !== 1 || !Gl(g, d)) {
                    e = null;
                    break a
                }
                e.i++;
                if (k = Hl(e, g, k, d)) p =
                    Zj(e.g),
                p.numAutoAdsPlaced || (p.numAutoAdsPlaced = 0),
                (h = !D(g, ci, 1)) || (g = D(g, ci, 1), h = Zc(g, 5) == null),
                h || (p.numPostPlacementsPlaced ? p.numPostPlacementsPlaced++ : p.numPostPlacementsPlaced = 1),
                p.placed == null && (p.placed = []),
                p.numAutoAdsPlaced++,
                p.placed.push({
                    index: f,
                    element: k.ma
                }),
                we(7, [!1, e.i, !0]);e = k
            }
            if (e) return !0
        }
        we(7, [!1, a.i, !1]);
        return !1
    }

    function Hl(a, b, c, d) {
        if (!Gl(b, d) || Ub(A(b, 8)) != 1) return null;
        d = D(b, ci, 1);
        if (!d) return null;
        d = Vj(d);
        if (!d) return null;
        d = Oj(d, a.g.document);
        if (d.length == 0) return null;
        d = d[0];
        var e = L(b, 2);
        e = Yj[e];
        e = e === void 0 ? null : e;
        var f;
        if (!(f = e == null)) {
            a: {
                f = a.g;
                switch (e) {
                    case 0:
                        f = nl(ol(d), f);
                        break a;
                    case 3:
                        f = nl(d, f);
                        break a;
                    case 2:
                        var g = d.lastChild;
                        f = nl(g ? g.nodeType == 1 ? g : ol(g) : null, f);
                        break a
                }
                f = !1
            }
            if (c = !f && !(!c && e == 2 && !pl(d))) c = e == 1 || e == 2 ? d : d.parentNode,
            c = !(c && !vi(c) && c.offsetWidth <= 0);f = !c
        }
        if (!(c = f)) {
            c = a.B;
            f = L(b,
                2);
            g = c.i;
            var h = ma(d);
            g = g.g.get(h);
            if (!(g = g ? g.contains(f) : !1)) a: {
                if (c.g.contains(ma(d))) switch (f) {
                    case 2:
                    case 3:
                        g = !0;
                        break a;
                    default:
                        g = !1;
                        break a
                }
                for (f = d.parentElement; f;) {
                    if (c.g.contains(ma(f))) {
                        g = !0;
                        break a
                    }
                    f = f.parentElement
                }
                g = !1
            }
            c = g
        }
        if (!c) {
            c = a.G;
            g = L(b, 2);
            a: switch (g) {
                case 1:
                    f = jl(d.previousElementSibling) || ll(d);
                    break a;
                case 4:
                    f = jl(d) || ll(d.nextElementSibling);
                    break a;
                case 2:
                    f = ll(d.firstElementChild);
                    break a;
                case 3:
                    f = jl(d.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " +
                        g);
            }
            g = hl(c, d, g);
            c = c.i;
            uk("ama_exclusion_zone", {
                typ: f ? g ? "siuex" : "siex" : g ? "suex" : "noex",
                cor: c.g,
                num: c.i++,
                dvc: Ld()
            }, .1);
            c = f || g
        }
        if (c) return null;
        f = D(b, ti, 3);
        c = {};
        f && (c.pb = cd(f, 1), c.Xa = cd(f, 2), c.zb = !!Yc(f, 3, zc));
        f = D(b, ji, 4) && ii(D(b, ji, 4)) ? ii(D(b, ji, 4)) : null;
        f = mi(f);
        g = Zc(b, 12) != null ? Zc(b, 12, zc) : null;
        g = g == null ? null : new li(null, {
            google_ml_rank: g
        });
        b = Il(a, b);
        b = ki(a.A, f, g, b);
        f = a.g;
        a = a.O;
        h = f.document;
        var k = c.zb || !1;
        g = le((new me(h)).g, "DIV");
        var m = g.style;
        m.width = "100%";
        m.height = "auto";
        m.clear = k ? "both" : "none";
        k = g.style;
        k.textAlign = "center";
        c.Ob && uj(k, c.Ob);
        h = le((new me(h)).g, "INS");
        k = h.style;
        k.display = "block";
        k.margin = "auto";
        k.backgroundColor = "transparent";
        c.pb && (k.marginTop = c.pb);
        c.Xa && (k.marginBottom = c.Xa);
        c.qb && uj(k, c.qb);
        g.appendChild(h);
        c = {
            La: g,
            ma: h
        };
        c.ma.setAttribute("data-ad-format", "auto");
        g = [];
        if (h = b && b.Za) c.La.className = h.join(" ");
        h = c.ma;
        h.className = "adsbygoogle";
        h.setAttribute("data-ad-client", a);
        g.length && h.setAttribute("data-ad-channel", g.join("+"));
        a: {
            try {
                var n = c.La;
                if (T(Ri)) {
                    {
                        let y = gj(d,
                            e);
                        if (y.init) {
                            var l = y.init;
                            for (d = l; d = y.oa(d);) l = d;
                            var p = {
                                anchor: l,
                                position: y.ta
                            }
                        } else p = {
                            anchor: d,
                            position: e
                        }
                    }
                    n["google-ama-order-assurance"] = 0;
                    wi(n, p.anchor, p.position)
                } else wi(n, d, e);
                b: {
                    var q = c.ma;q.dataset.adsbygoogleStatus = "reserved";q.className += " adsbygoogle-noablate";n = {
                        element: q
                    };
                    var u = b && b.lb;
                    if (q.hasAttribute("data-pub-vars")) {
                        try {
                            u = JSON.parse(q.getAttribute("data-pub-vars"))
                        } catch (y) {
                            break b
                        }
                        q.removeAttribute("data-pub-vars")
                    }
                    u && (n.params = u);
                    (f.adsbygoogle = f.adsbygoogle || []).push(n)
                }
            } catch (y) {
                (q =
                    c.La) && q.parentNode && (u = q.parentNode, u.removeChild(q), vi(u) && (u.style.display = u.getAttribute("data-init-display") || "none"));
                q = !1;
                break a
            }
            q = !0
        }
        return q ? c : null
    }

    function Il(a, b) {
        return Yh($h(bk(b).map(ni), c => {
            Zj(a.g).exception = c
        }))
    }
    var Jl = class {
        constructor(a, b, c, d, e, f = !1) {
            this.g = a;
            this.O = b;
            this.j = c;
            this.A = e || null;
            this.H = f;
            (this.N = d) ? (a = a.document, d = E(d, Aj, 5, C()), d = al(a, d)) : d = al(a.document, []);
            this.B = d;
            this.G = new ml;
            this.i = 0;
            this.u = !1
        }
    };

    function Fl(a) {
        var b = {};
        a && Ec(a, 6, Ub, C()).forEach(c => {
            b[c] = !0
        });
        return b
    }

    function Gl(a, b) {
        return a && Cc(a, ji, 4) && b[ii(D(a, ji, 4))] ? !1 : !0
    };
    var Kl = class extends O {};
    var Ll = class extends O {};
    var Ml = class {
        constructor(a) {
            this.exception = a
        }
    };

    function Nl(a, b) {
        try {
            var c = a.i,
                d = c.resolve,
                e = a.g;
            Zj(e.g);
            E(e.j, ui, 1, C());
            d.call(c, new Ml(b))
        } catch (f) {
            a.i.reject(f)
        }
    }
    var Ol = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.i = c
        }
        start() {
            this.u()
        }
        u() {
            try {
                switch (this.j.document.readyState) {
                    case "complete":
                    case "interactive":
                        El(this.g, !0);
                        Nl(this);
                        break;
                    default:
                        El(this.g, !1) ? Nl(this) : this.j.setTimeout(ra(this.u, this), 100)
                }
            } catch (a) {
                Nl(this, a)
            }
        }
    };
    var Pl = class extends O {
        getVersion() {
            return I(this, 2)
        }
    };

    function Ql(a) {
        return Va(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function Rl(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function Sl(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        var b = [1, 2, 3, 5],
            c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function Tl(a) {
        var b = Ql(a),
            c = Rl(b.slice(0, 6));
        a = Rl(b.slice(6, 12));
        var d = new Pl;
        c = ed(d, 1, c);
        a = ed(c, 2, a);
        b = b.slice(12);
        c = Rl(b.slice(0, 12));
        d = [];
        var e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = Rl(e[0]) === 0;
            e = e.slice(1);
            var g = Ul(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = Sl(g) + h;
            e = e.slice(g.length);
            if (f) {
                d.push(h);
                continue
            }
            f = Ul(e, b);
            g = Sl(f);
            for (let m = 0; m <= g; m++) d.push(h + m);
            e = e.slice(f.length)
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return Kc(a, 3, d, Vb)
    }

    function Ul(a, b) {
        var c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var Vl = ke(Kh).map(a => Number(a)),
        Wl = ke(Lh).map(a => Number(a));

    function Xl() {
        var a = new Yl;
        return fd(a, 1, 0)
    }

    function Zl(a) {
        var b = Number;
        var c = A(a, 1, void 0, void 0, bc),
            d = typeof c;
        c != null && (d === "bigint" ? c = String(Jb(64, c)) : Sb(c) ? d === "string" ? (d = Nb(Number(c)), Lb(d) ? c = String(d) : (d = c.indexOf("."), d !== -1 && (c = c.substring(0, d)), d = c.length, (c[0] === "-" ? d < 20 || d === 20 && c <= "-9223372036854775808" : d < 19 || d === 19 && c <= "9223372036854775807") || (c.length < 16 ? Fb(Number(c)) : (c = BigInt(c), Cb = Number(c & BigInt(4294967295)) >>> 0, Db = Number(c >> BigInt(32) & BigInt(4294967295))), c = Hb()))) : c = ac(c) : c = void 0);
        b = b(c ? ? "0");
        a = I(a, 2);
        return new Date(b *
            1E3 + a / 1E6)
    }
    var Yl = class extends O {};

    function $l(a) {
        if (a != null) return am(a)
    }

    function am(a) {
        return Bb(a) ? Number(a) : String(a)
    };

    function Y(a, b) {
        if (a.g + b > a.i.length) throw Error(`Requested length ${b} is past end of string.`);
        var c = a.i.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function bm(a) {
        var b = () => {
            var c = Y(a, 6);
            if (c > 25 || c < 0) throw Error(`Invalid character code, expected in range [0,25], got: ${c}`);
            return String.fromCharCode(97 + c)
        };
        return b() + b()
    }

    function cm(a) {
        for (var b = Y(a, 12), c = []; b--;) {
            var d = !!Y(a, 1) === !0,
                e = Y(a, 16);
            if (d)
                for (d = Y(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function dm(a, b, c) {
        var d = [];
        for (let e = 0; e < b; e++)
            if (Y(a, 1)) {
                let f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function em(a) {
        var b = Y(a, 16);
        if (!!Y(a, 1) === !0) {
            a = cm(a);
            for (let c of a)
                if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
            return a
        }
        return dm(a, b)
    }
    var fm = class {
        constructor(a) {
            this.i = a;
            this.g = 0;
            if (/[^01]/.test(this.i)) throw Error(`Input bitstring ${this.i} is malformed!`);
        }
        skip(a) {
            this.g += a
        }
    };
    var gm = class extends O {
        g() {
            return x(A(this, 2)) != null
        }
    };
    var hm = class extends O {
        g() {
            return x(A(this, 2)) != null
        }
    };
    var im = class extends O {};
    var jm = qd(class extends O {});

    function km(a) {
        a = lm(a);
        try {
            var b = a ? jm(a) : null
        } catch (c) {
            b = null
        }
        return b ? D(b, im, 4) || null : null
    }

    function lm(a) {
        a = a ? .location ? .origin !== "null" ? (new Fk(a)).get("FCCDCF", "") : "";
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };
    ke(Kh).map(a => Number(a));
    ke(Lh).map(a => Number(a));

    function mm(a) {
        a.__tcfapiPostMessageReady || nm(new om(a))
    }

    function nm(a) {
        a.g = b => {
            var c = typeof b.data === "string";
            try {
                var d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            var e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.l.__tcfapi)(e.command, e.version, (f, g) => {
                var h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            }, e.parameter)
        };
        a.l.addEventListener("message", a.g);
        a.l.__tcfapiPostMessageReady = !0
    }
    var om = class {
        constructor(a) {
            this.l = a
        }
    };

    function pm(a) {
        a.__uspapiPostMessageReady || qm(new rm(a))
    }

    function qm(a) {
        a.g = b => {
            var c = typeof b.data === "string";
            try {
                var d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            var e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.l.__uspapi(e.command, e.version, (f, g) => {
                var h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.l.addEventListener("message", a.g);
        a.l.__uspapiPostMessageReady = !0
    }
    var rm = class {
        constructor(a) {
            this.l = a;
            this.g = null
        }
    };
    var sm = class extends O {};
    var tm = qd(class extends O {
        g() {
            return x(A(this, 1)) != null
        }
    });

    function um(a, b) {
        try {
            let c = a.split("."),
                d = Va(c[0]).map(g => g.toString(2).padStart(8, "0")).join(""),
                e = new fm(d);
            a = {
                tcString: a ? ? void 0,
                gdprApplies: b
            };
            e.skip(78);
            a.cmpId = Y(e, 12);
            a.cmpVersion = Y(e, 12);
            e.skip(30);
            a.tcfPolicyVersion = Y(e, 6);
            a.isServiceSpecific = !!Y(e, 1);
            a.useNonStandardStacks = !!Y(e, 1);
            a.specialFeatureOptins = vm(dm(e, 12, Wl), Wl);
            a.purpose = {
                consents: vm(dm(e, 24, Vl), Vl),
                legitimateInterests: vm(dm(e, 24, Vl), Vl)
            };
            a.purposeOneTreatment = !!Y(e, 1);
            a.publisherCC = bm(e);
            a.vendor = {
                consents: vm(em(e), null),
                legitimateInterests: vm(em(e),
                    null)
            };
            let f = wm(c);
            f && (a.vendor.disclosedVendors = f);
            return a
        } catch (c) {
            return null
        }
    }

    function wm(a) {
        a.shift();
        for (let b of a)
            if (a = Va(b).map(c => c.toString(2).padStart(8, "0")).join(""), a = new fm(a), Y(a, 3) === 1) return vm(em(a), null)
    }

    function vm(a, b) {
        var c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (let d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (let d of a) c[d] = !0;
        delete c[0];
        return c
    };

    function xm(a, b) {
        function c(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 4));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function d(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function e(l) {
            if (l.length < 12) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(8, 12));
            l = m(l);
            return "1" + p + l + "N"
        }

        function f(l) {
            if (l.length < 18) return null;
            var p = h(l.slice(0, 8));
            p = k(p);
            l = h(l.slice(12, 18));
            l = m(l);
            return "1" + p + l + "N"
        }

        function g(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function h(l) {
            var p = [],
                q = 0;
            for (let u = 0; u < l.length / 2; u++) p.push(Rl(l.slice(q, q + 2))), q += 2;
            return p
        }

        function k(l) {
            return l.every(p => p === 1) ? "Y" : "N"
        }

        function m(l) {
            return l.some(p => p === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = Ql(a[0]);
        var n = Rl(a.slice(0, 6));
        a = a.slice(6);
        if (n !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function ym(a, b) {
        var c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        let e = Vd("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };

    function zm(a) {
        Q === Q.top && (a = new Am(a), Bm(a), Cm(a))
    }

    function Bm(a) {
        !a.j || a.l.__uspapi || a.l.frames.__uspapiLocator || (a.l.__uspapiManager = "fc", ym(a.l, "__uspapiLocator"), sa("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && (b = a.i.j(), d({
                version: 1,
                uspString: b ? a.j : "1---"
            }, !0))
        }, a.l), pm(a.l))
    }

    function Cm(a) {
        !a.tcString || a.l.__tcfapi || a.l.frames.__tcfapiLocator || (a.l.__tcfapiManager = "fc", ym(a.l, "__tcfapiLocator"), a.l.__tcfapiEventListeners = a.l.__tcfapiEventListeners || [], sa("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.3 || c <= 1)) d(null, !1);
                else {
                    var f = a.l.__tcfapiEventListeners;
                    c = a.i.g();
                    switch (b) {
                        case "ping":
                            d({
                                gdprApplies: c,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.3",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            b = f.push(d) - 1;
                            a.tcString ?
                                (e = um(a.tcString, c), e.addtlConsent = a.g != null ? a.g : void 0, e.cmpStatus = "loaded", e.eventStatus = "tcloaded", b != null && (e.listenerId = b), b = e) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && f[e] ? (f[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
                }
        }, a.l), mm(a.l))
    }

    function Dm(a) {
        if (!a ? .g() || J(a, 1).length === 0 || E(a, sm, 2, C()).length === 0) return null;
        var b = J(a, 1);
        try {
            var c = Tl(b.split("~")[0]);
            var d = b.includes("~") ? b.split("~").slice(1) : []
        } catch (e) {
            return null
        }
        a = E(a, sm, 2, C()).reduce((e, f) => {
            var g = Em(e);
            g = Xc(g, 1) ? ? yc;
            g = am(g);
            var h = Em(f);
            h = Xc(h, 1) ? ? yc;
            return g > am(h) ? e : f
        });
        c = Ec(c, 3, Wb, C()).indexOf(I(a, 1));
        return c === -1 || c >= d.length ? null : {
            uspString: xm(d[c], I(a, 1)),
            Ka: Zl(Em(a))
        }
    }

    function Fm(a) {
        a = a.find(b => b && K(b, 1) === 13);
        if (a ? .g()) try {
            return tm(J(a, 2))
        } catch (b) {}
        return null
    }

    function Em(a) {
        return Cc(a, Yl, 2) ? D(a, Yl, 2) : Xl()
    }
    var Am = class {
        constructor(a) {
            var b = Q;
            this.l = b;
            this.i = a;
            a = lm(this.l.document);
            try {
                var c = a ? jm(a) : null
            } catch (e) {
                c = null
            }(a = c) ? (c = D(a, hm, 5) || null, a = E(a, gm, 7, C()), a = Fm(a ? ? []), c = {
                Ya: c,
                bb: a
            }) : c = {
                Ya: null,
                bb: null
            };
            a = c;
            c = Dm(a.bb);
            a = a.Ya;
            if (a ? .g() && J(a, 2).length !== 0) {
                var d = Cc(a, Yl, 1) ? D(a, Yl, 1) : Xl();
                a = {
                    uspString: J(a, 2),
                    Ka: Zl(d)
                }
            } else a = null;
            this.j = a && c ? c.Ka > a.Ka ? c.uspString : a.uspString : a ? a.uspString : c ? c.uspString : null;
            this.tcString = (c = km(b.document)) && x(A(c, 1)) != null ? J(c, 1) : null;
            this.g = (b = km(b.document)) && x(A(b,
                2)) != null ? J(b, 2) : null
        }
    };

    function Gm(a) {
        a = Number((a.charCodeAt(0) - 43 & -3 ? "0" : "") + a + ".");
        return Number.isInteger(a) ? a : void 0
    };
    const Hm = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function Im(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        uk("ama", b, .01)
    }

    function Jm(a) {
        var b = {};
        td(Hm, (c, d) => {
            a.hasOwnProperty(d) && (b[d] = a[d])
        });
        return b
    };

    function Km(a) {
        var b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                let e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function Lm(a) {
        var b = "",
            c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            let e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function Mm(a) {
        a = Ec(a, 2, Ub, C());
        if (!a) return !1;
        for (let b = 0; b < a.length; b++)
            if (a[b] == 1) return !0;
        return !1
    }

    function Nm(a, b) {
        a = Lm(Km(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        var c = ei(a),
            d = Om(a);
        return b.find(e => {
            if (Cc(e, wj, 7)) {
                var f = D(e, wj, 7);
                f = Xb(A(f, 1, void 0, zc))
            } else f = Xb(A(e, 1, void 0, zc));
            Cc(e, wj, 7) ? (e = D(e, wj, 7), e = L(e, 2)) : e = 2;
            if (!tb(f)) return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function Om(a) {
        for (var b = {};;) {
            b[ei(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };

    function Z(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function Pm(a) {
        a = Z(a);
        var b = a.space_collapsing || "none";
        return a.had_ads_ablation ? {
            Va: !0,
            Wb: b,
            Wa: a.ablation_viewport_offset
        } : null
    }

    function Qm(a) {
        a = Z(a);
        a.had_ads_ablation = !0;
        a.space_collapsing = "slot";
        a.ablation_viewport_offset = 1
    }

    function Rm(a) {
        Z(Q).allow_second_reactive_tag = a
    }

    function Sm() {
        var a = Z(window);
        a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
        return a.afg_slotcar_vars
    };

    function Tm(a) {
        return Z(a) ? .head_tag_slot_vars ? .google_ad_host ? ? Um(a)
    }

    function Um(a) {
        return a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };
    const Vm = [2, 7, 1];

    function Wm(a, b, c, d = "") {
        return b === 1 && c && (Xm(a, d, c) ? .H() ? ? !1) ? !0 : Ym(a, d, e => Na(E(e, rd, 2, C()), f => L(f, 1) === b), !!c ? .g() ? .g())
    }

    function Zm(a, b) {
        var c = vd(Q) || Q;
        return $m(c, a) ? !0 : Ym(Q, "", d => Na(Ec(d, 3, Ub, C()), e => e === a), b)
    }

    function $m(a, b) {
        a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
        return !!a && Pa(a.split(","), b.toString())
    }

    function Ym(a, b, c, d) {
        a = vd(a) || a;
        var e = an(a, d);
        b && (b = Ih(String(b)));
        return je(e, (f, g) => Object.prototype.hasOwnProperty.call(e, g) && (!b || b === g) && c(f))
    }

    function an(a, b) {
        a = bn(a, b);
        var c = {};
        td(a, (d, e) => {
            try {
                let f = od(sd, lc(d));
                c[e] = f
            } catch (f) {}
        });
        return c
    }

    function bn(a, b) {
        a = Rk({
            l: a,
            ca: b
        });
        return a.g != null ? cn(a.getValue()) : {}
    }

    function cn(a) {
        try {
            let b = a.getItem("google_adsense_settings");
            if (!b) return {};
            let c = JSON.parse(b);
            return c !== Object(c) ? {} : ie(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && w(e) && Array.isArray(d))
        } catch (b) {
            return {}
        }
    }

    function dn(a, b) {
        var c = [];
        a = Tm(r) ? Vm : (a = Xm(r, a, b) ? .ea()) ? [...Ec(a, 3, Ub, C())] : Vm;
        a.includes(1) || c.push(1);
        a.includes(2) || c.push(2);
        a.includes(7) || c.push(7);
        return c
    }

    function Xm(a, b, c) {
        if (!b) return null;
        var d = en(c) ? .j(),
            e = en(c) ? .g() ? .g();
        b = b ? ? "";
        d = d ? ? "";
        e = e ? ? "";
        var f = J(c, 17) || "";
        return d === b || e === b && a.location.host && f === a.location.host ? en(c) : null
    };

    function fn(a, b, c, d) {
        gn(new hn(a, b, c, d))
    }

    function gn(a) {
        var b = !!a.X.g() ? .g();
        $h(Zh(Rk({
            l: a.l,
            ca: b
        }), c => {
            jn(a, c, !0)
        }), () => {
            kn(a)
        })
    }

    function jn(a, b, c) {
        $h(Zh(ln(b), d => {
            mn("ok");
            a.g(d, {
                fromLocalStorage: !0
            })
        }), () => {
            var d = a.l;
            try {
                b.removeItem("google_ama_config")
            } catch (e) {
                Im(d, {
                    lserr: 1
                })
            }
            c ? kn(a) : a.g(null, null)
        })
    }

    function kn(a) {
        $h(Zh(nn(a), b => {
            a.g(b, {
                fromPABGSettings: !0
            })
        }), () => {
            on(a)
        })
    }

    function ln(a) {
        if (T(Qi)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? Jj(b) : null
        } catch (d) {
            c = null
        }
        return (a = (a = c) ? ($l(D(a, vj, 3) ? .g()) ? ? 0) > Date.now() ? a : null : null) ? Uh(a) : Wh(Error("invlocst"))
    }

    function nn(a) {
        if (Tm(a.l) && !H(a.X, 22)) return Wh(Error("invtag"));
        if (a = (a = Xm(a.l, a.i, a.X) ? .O()) && E(a, ui, 1, C()).length > 0 ? a : null) {
            var b = new Ij;
            var c = E(a, ui, 1, C());
            b = Vc(b, 1, c);
            c = E(a, Cj, 2, C());
            b = Vc(b, 7, c);
            a = H(a, 4);
            a = Bc(b, 36, Qb(a));
            a = Uh(a)
        } else a = Wh(Error("invtag"));
        return a
    }

    function on(a) {
        var b = !!a.X.g() ? .g();
        Vk({
            l: a.l,
            ca: b,
            la: 50,
            yb: c => {
                pn(a, c)
            }
        })
    }

    function pn(a, b) {
        $h(Zh(b, c => {
            jn(a, c, !1)
        }), c => {
            mn(c.message);
            a.g(null, null)
        })
    }

    function mn(a) {
        uk("abg::amalserr", {
            status: a,
            guarding: "true",
            timeout: 50,
            rate: .01
        }, .01)
    }
    class hn {
        constructor(a, b, c, d) {
            this.l = a;
            this.X = b;
            this.i = c;
            this.g = d
        }
    };

    function qn(a, b, c, d, e) {
        var f = rn;
        try {
            let g = Nm(a, E(c, Cj, 7, C()));
            if (g && Mm(g)) {
                if (x(A(g, 4))) {
                    let m = new li(null, {
                        google_package: x(A(g, 4))
                    });
                    d = ki(d, m)
                }
                let h = f(a, b, c, g, d, e);
                b = () => {
                    Uj(1E3, () => {
                        var m = new Ph;
                        (new Ol(a, h, m)).start();
                        return m.i
                    }, a).then(() => {
                        Im(a, {
                            atf: 1
                        })
                    }, m => {
                        (a.google_ama_state = a.google_ama_state || {}).exception = m;
                        Im(a, {
                            atf: 0
                        })
                    })
                };
                let k = T(Oi) ? fj(Pi) : null;
                k != null ? setTimeout(b, k) : b()
            }
        } catch (g) {
            Im(a, {
                atf: -1
            })
        }
    }

    function rn(a, b, c, d, e, f) {
        return new Jl(a, b, c, d, e, f)
    };

    function sn() {
        var a = P(ce).u(Vi.g, Vi.defaultValue);
        return a.length ? a.join("~") : void 0
    };

    function tn(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        var c = "";
        for (let d of b.split("_")) c += d.substring(0, 2);
        b = c;
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    };
    var un = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };

    function vn(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            let f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = $d(a[c[e]]);
                d = d === null ? null : Math.round(d);
                d != null && (b[f] = d)
            }
        }
    }

    function wn(a, b) {
        return !((Yd.test(b.google_ad_width) || Xd.test(a.style.width)) && (Yd.test(b.google_ad_height) || Xd.test(a.style.height)))
    }

    function xn(a, b, c, d, e) {
        if (a !== a.top) return vd(a) ? 3 : 16;
        if (!(U(a) < 488)) return 4;
        if (!(a.innerHeight >= a.innerWidth)) return 5;
        var f = U(a);
        if (!f || (f - c) / f > d) a = 6;
        else {
            if (c = e.google_full_width_responsive !== "true") a: {
                c = b.parentElement;
                for (b = U(a); c; c = c.parentElement) {
                    d = Wd(c, a);
                    if (!d) continue;
                    if ((e = $d(d.width)) && !(e >= b) && d.overflow !== "visible") {
                        c = !0;
                        break a
                    }
                }
                c = !1
            }
            a = c ? 7 : !0
        }
        return a
    }

    function yn(a, b, c, d) {
        var e = xn(b, c, a, fj(Ji), d);
        e !== !0 ? a = e : d.google_full_width_responsive === "true" || lj(c, b) ? (b = U(b), a = b - a, a = b && a >= 0 ? !0 : b ? a < -10 ? 11 : a < 0 ? 14 : 12 : 10) : a = 9;
        return a
    }

    function zn(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function An(a, b) {
        if (b.nodeType === 3) return /\S/.test(b.data);
        if (b.nodeType === 1) {
            if (/^(script|style)$/i.test(b.nodeName)) return !1;
            let c;
            try {
                c = Wd(b, a)
            } catch (d) {}
            return !c || c.display !== "none" && !(c.position === "absolute" && (c.visibility === "hidden" || c.visibility === "collapse"))
        }
        return !1
    }

    function Bn(a, b, c) {
        a = nj(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function Cn(a, b) {
        var c;
        c = (c = b.parentElement) ? (c = Wd(c, a)) ? c.direction : "" : "";
        if (c) {
            var d = b.style;
            d.border = d.borderStyle = d.outline = d.outlineStyle = d.transition = "none";
            d.borderSpacing = d.padding = "0";
            zn(b, c, "0px");
            d.width = `${U(a)}px`;
            if (Bn(a, b, c) !== 0) {
                zn(b, c, "0px");
                var e = Bn(a, b, c);
                zn(b, c, `${-1*e}px`);
                a = Bn(a, b, c);
                a !== 0 && a !== e && zn(b, c, `${e/(a-e)*e}px`)
            }
            d.zIndex = "30"
        }
    };

    function Dn() {
        var a = {};
        P(ce).g(Li.g, Li.defaultValue) && (a.bust = P(ce).g(Li.g, Li.defaultValue));
        return a
    };
    class En {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function Fn() {
        var {
            promise: a,
            resolve: b
        } = new En;
        return {
            promise: a,
            resolve: b
        }
    };

    function Gn(a = () => {}) {
        r.google_llp || (r.google_llp = {});
        var b = r.google_llp,
            c = b[7];
        if (c) return c;
        c = Fn();
        b[7] = c;
        a();
        return c
    }

    function Hn(a) {
        return Gn(() => {
            Ud(r.document, a)
        }).promise
    };
    var In = class {
        constructor() {
            this.u = this.A = 1;
            this.j = new Map;
            this.i = new Set;
            this.g = new Map;
            this.isDrawerVisible = !1
        }
        takeNextPageEventIndex() {
            return this.A++
        }
        takeNextAnnotationEntryId() {
            return this.u++
        }
        getTermUsageCount(a) {
            return this.j.get(a) ? ? 0
        }
        incrementTermUsageCount(a) {
            var b = this.j.get(a) ? ? 0;
            this.j.set(a, b + 1)
        }
        onDrawerCollapse(a) {
            this.i.add(a)
        }
        removeOnDrawerCollapse(a) {
            this.i.delete(a)
        }
        getClickPageEventIndex(a) {
            return this.g.get(a)
        }
        setClickPageEventIndex(a, b) {
            this.g.set(a, b)
        }
        removeClickPageEventIndex(a) {
            this.g.delete(a)
        }
        notifyDrawerCollapsed() {
            for (let a of this.i) a()
        }
    };

    function Jn(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = []), a.google_reactive_ads_global_state.adIntentsPageState == null && (a.google_reactive_ads_global_state.adIntentsPageState = new In)) : a.google_reactive_ads_global_state = new Kn;
        return a.google_reactive_ads_global_state
    }
    var Kn = class {
            constructor() {
                this.wasPlaTagProcessed = !1;
                this.wasReactiveAdConfigReceived = {};
                this.adCount = {};
                this.wasReactiveAdVisible = {};
                this.stateForType = {};
                this.reactiveTypeEnabledInAsfe = {};
                this.wasReactiveTagRequestSent = !1;
                this.reactiveTypeDisabledByPublisher = {};
                this.tagSpecificState = {};
                this.messageValidationEnabled = !1;
                this.floatingAdsStacking = new Ln;
                this.sideRailProcessedFixedElements = new Set;
                this.sideRailAvailableSpace = new Map;
                this.sideRailPlasParam = new Map;
                this.sideRailMutationCallbacks = [];
                this.clickTriggeredInterstitialMayBeDisplayed = !1;
                this.adIntentsPageState = new In
            }
        },
        Ln = class {
            constructor() {
                this.maxZIndexRestrictions = {};
                this.nextRestrictionId = 0;
                this.maxZIndexListeners = []
            }
        };
    Array.from({
        length: 11
    }, (a, b) => b / 10);

    function Mn(a) {
        if (r.google_apltlad || a.google_ad_intent_query || a.google_ad_intents_format) return null;
        var b = a.google_loader_used !== "sd" && (r.top == r ? 0 : ud(r.top) ? 1 : 2) === 1;
        if (r !== r.top && !b || !a.google_ad_client) return null;
        r.google_apltlad = !0;
        b = {
            enable_page_level_ads: {
                pltais: !0
            },
            google_ad_client: a.google_ad_client
        };
        var c = b.enable_page_level_ads;
        td(a, (d, e) => {
            sj[e] && e !== "google_ad_client" && (c[e] = d)
        });
        c.google_pgb_reactive = 7;
        c.asro = T(Xi);
        c.aimartd = fj(Yi);
        c.aiof = sn();
        if ("google_ad_section" in a || "google_ad_region" in
            a) c.google_ad_section = a.google_ad_section || a.google_ad_region;
        return b
    };

    function Nn(a, b) {
        Z(Q).ama_ran_on_page || Uj(1001, () => {
            On(new Pn(a, b))
        }, r)
    }

    function On(a) {
        fn(a.l, a.X, a.g.google_ad_client || "", (b, c) => {
            var d = a.l,
                e = a.g,
                f = a.X;
            Z(Q).ama_ran_on_page || b && Qn(d, e, b, c, f)
        })
    }
    class Pn {
        constructor(a, b) {
            this.l = r;
            this.g = a;
            this.X = b
        }
    }

    function Qn(a, b, c, d, e) {
        d && (Zj(a).configSourceInAbg = d);
        Cc(c, Hj, 24) && (d = ak(a), d.availableAbg = !0, d.ablationFromStorage = !!D(c, Hj, 24) ? .g() ? .g());
        if (la(b.enable_page_level_ads) && b.enable_page_level_ads.google_pgb_reactive === 7) {
            if (!Nm(a, E(c, Cj, 7, C()))) {
                uk("amaait", {
                    value: "true"
                });
                return
            }
            uk("amaait", {
                value: "false"
            })
        }
        Z(Q).ama_ran_on_page = !0;
        D(c, Hj, 24) ? .g() ? .g() && (ak(a).ablatingThisPageview = !0, Qm(a));
        we(3, [z(c)]);
        var f = b.google_ad_client || "";
        b = Jm(la(b.enable_page_level_ads) ? b.enable_page_level_ads : {});
        var g =
            ki(oi, new li(null, b));
        rk(782, () => {
            qn(a, f, c, g, e.g() ? .g())
        })
    };
    var Rn = function(a) {
        return b => {
            b = JSON.parse(b);
            if (!Array.isArray(b)) throw Error("Expected jspb data to be an array, got " + ka(b) + ": " + b);
            b[v] |= 34;
            return new a(b)
        }
    }(class extends O {});
    async function Sn(a, b) {
        try {
            let c = await globalThis.fetch(Sd(Rd `https://pagead2.googlesyndication.com/getconfig/abg_config`, new Map([
                ["client", a],
                ["plah", b],
                ["ama_t", "adsense"], ...Object.entries(Dn())
            ])).toString(), {
                method: "GET",
                credentials: "omit"
            });
            if (!c.ok) throw Error(`Fetch failed with status: ${c.status}`);
            let d = await c.text();
            if (!d) throw Error("AbgConfig endpoint returned empty response.");
            try {
                return Rn(d)
            } catch (e) {
                throw Error(`Error deserializing config: ${e instanceof Error?e.message:String(e)}`);
            }
        } catch (c) {
            throw c;
        }
    };

    function Tn(a, b) {
        a = a.document;
        for (var c = void 0, d = 0; !c || a.getElementById(c + "_host");) c = "aswift_" + d++;
        a = c;
        c = Number(b.google_ad_width || 0);
        b = Number(b.google_ad_height || 0);
        d = document.createElement("div");
        d.id = a + "_host";
        var e = d.style;
        e.border = "none";
        e.height = `${b}px`;
        e.width = `${c}px`;
        e.margin = "0px";
        e.padding = "0px";
        e.position = "relative";
        e.visibility = "visible";
        e.backgroundColor = "transparent";
        e.display = "inline-block";
        return {
            Fb: a,
            Zb: d
        }
    };
    var Un = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function Vn(a, b) {
        if (b == 15) {
            if (a >= 728) return 728;
            if (a >= 468) return 468
        } else if (b == 90) {
            if (a >= 200) return 200;
            if (a >= 180) return 180;
            if (a >= 160) return 160;
            if (a >= 120) return 120
        }
        return null
    };

    function Wn(a, b) {
        for (var c = [], d = 0; b && d < 25; ++d) {
            var e = void 0;
            e = (e = b.nodeType !== 9 && b.id) ? "/" + e : "";
            a: {
                if (b && b.nodeName && b.parentElement) {
                    var f = b.nodeName.toString().toLowerCase();
                    let g = b.parentElement.childNodes,
                        h = 0;
                    for (let k = 0; k < g.length; ++k) {
                        let m = g[k];
                        if (m.nodeName && m.nodeName.toString().toLowerCase() === f) {
                            if (b === m) {
                                f = "." + h;
                                break a
                            }++h
                        }
                    }
                }
                f = ""
            }
            c.push((b.nodeName && b.nodeName.toString().toLowerCase()) + e + f);
            b = b.parentElement
        }
        b = c.join();
        c = [];
        if (a) try {
            let g = a.parent;
            for (d = 0; g && g !== a && d < 25; ++d) {
                let h = g.frames;
                for (e = 0; e < h.length; ++e)
                    if (a === h[e]) {
                        c.push(e);
                        break
                    }
                a = g;
                g = a.parent
            }
        } catch (g) {}
        return ei(`${b}:${c.join()}`).toString()
    };
    var Xn = class extends O {
        getVersion() {
            return J(this, 2)
        }
    };

    function Yn(a, b) {
        return id(a, 2, b)
    }

    function Zn(a, b) {
        return id(a, 3, b)
    }

    function $n(a, b) {
        return id(a, 4, b)
    }

    function ao(a, b) {
        return id(a, 5, b)
    }

    function bo(a, b) {
        return id(a, 9, b)
    }

    function co(a, b) {
        return Vc(a, 10, b)
    }

    function eo(a, b) {
        return Bc(a, 11, Qb(b))
    }

    function fo(a, b) {
        return id(a, 1, b)
    }

    function go(a, b) {
        return Bc(a, 7, Qb(b))
    }
    var ho = class extends O {};
    const io = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function jo() {
        var a = Q;
        if (typeof a.navigator ? .userAgentData ? .getHighEntropyValues !== "function") return null;
        var b = a.google_tag_data ? ? (a.google_tag_data = {});
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(io).then(c => {
            b.uach ? ? (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function ko(a) {
        return eo(co(ao(Yn(fo($n(go(bo(Zn(new ho, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), a.fullVersionList ? .map(b => {
            var c = new Xn;
            c = id(c, 1, b.brand);
            return id(c, 2, b.version)
        }) || []), a.wow64 || !1)
    }

    function lo() {
        return jo() ? .then(a => ko(a)) ? ? null
    };

    function mo(a, b) {
        b.google_ad_host || (a = Um(a)) && (b.google_ad_host = a)
    }

    function no(a, b) {
        a.google_sa_queue = a.google_sa_queue || [];
        a.google_sa_impl ? b() : a.google_sa_queue.push(b)
    }

    function oo() {
        var a = vd(r);
        a && (a = Jn(a), a.tagSpecificState[1] || (a.tagSpecificState[1] = {
            debugCard: null,
            debugCardRequested: !1
        }))
    }

    function po() {
        var a = lo();
        a != null && a.then(b => {
            Q.google_user_agent_client_hint = b.u()
        });
        be()
    }

    function qo(a) {
        var b = a.google_ad_output,
            c = a.google_ad_format,
            d = a.google_ad_width || 0,
            e = a.google_ad_height || 0;
        c || b !== "html" && b != null || (c = `${d}x${e}`);
        b = !a.google_ad_slot || a.google_override_format || !Un[a.google_ad_width + "x" + a.google_ad_height] && a.google_loader_used === "aa";
        c = c && b ? c.toLowerCase() : "";
        a.google_ad_format = c
    }

    function ro(a, b) {
        b = [b.google_ad_slot, b.google_ad_format, b.google_ad_type, b.google_ad_width, b.google_ad_height];
        for (var c = [], d = 0; a && d < 25; a = a.parentNode, ++d) a.nodeType === 9 ? c.push("") : c.push(a.id);
        (a = c.join()) && b.push(a);
        return ei(b.join(":")).toString()
    }

    function so(a) {
        return (a = a ? .getAttribute("data-override-ady")) ? Gm(a) : void 0
    }

    function to(a) {
        return (a = a ? .getAttribute("data-override-adx")) ? Gm(a) : void 0
    };
    var uo = class {
        constructor(a, b) {
            this.F = a;
            this.height = b
        }
        g(a) {
            return a > 300 && this.height > 300 ? this.F : Math.min(1200, Math.round(a))
        }
    };
    var vo = class extends uo {
        i() {}
    };

    function wo(a) {
        return b => !!(b.D() & a)
    }
    var xo = class extends vo {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.u = c;
            this.j = d
        }
        D() {
            return this.u
        }
        Pa() {
            return this.j
        }
        i(a, b, c) {
            c.style.height = `${this.height}px`;
            b.rpe = !0
        }
    };
    const yo = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        zo = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        Ao = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function Bo(a) {
        var b = 0;
        a.P && b++;
        a.L && b++;
        a.M && b++;
        if (b < 3) return {
            ba: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.P.split(",");
        var c = a.M.split(",");
        a = a.L.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            ba: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (b.length >
            2) return {
            ba: `The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        var d = [],
            e = [];
        for (let g = 0; g < b.length; g++) {
            var f =
                Number(c[g]);
            if (Number.isNaN(f) || f === 0) return {
                ba: `Wrong value '${c[g]}' for data-matched-content-rows-num.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || f === 0) return {
                ba: `Wrong value '${a[g]}' for data-matched-content-columns-num.`
            };
            e.push(f)
        }
        return {
            M: d,
            L: e,
            hb: b
        }
    }

    function Co(a) {
        return a >= 1200 ? {
            width: 1200,
            height: 600
        } : a >= 850 ? {
            width: a,
            height: Math.floor(a * .5)
        } : a >= 550 ? {
            width: a,
            height: Math.floor(a * .6)
        } : a >= 468 ? {
            width: a,
            height: Math.floor(a * .7)
        } : {
            width: a,
            height: Math.floor(a * 3.44)
        }
    }

    function Do(a, b) {
        return a * yo[b] + zo[b]
    }

    function Eo(a, b, c, d) {
        b = Math.floor(Do((a - 8 * b - 8) / b, d) * c + 8 * c + 8);
        return a > 1500 ? {
            width: 0,
            height: 0,
            Ub: `Calculated slot width is too large: ${a}`
        } : b > 1500 ? {
            width: 0,
            height: 0,
            Ub: `Calculated slot height is too large: ${b}`
        } : {
            width: a,
            height: b
        }
    }

    function Fo(a, b) {
        var c = a - 8 - 8;
        --b;
        return {
            width: a,
            height: Math.floor(c / 1.91 + 70) + Math.floor(Do(c, "mobile_banner_image_sidebyside") * b + 8 * b + 8)
        }
    };
    const Go = Ra("script");
    var Ho = class {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, m = null, n = null, l = null) {
            this.G = a;
            this.aa = b;
            this.D = c;
            this.g = d;
            this.H = e;
            this.I = f;
            this.V = g;
            this.u = h;
            this.A = k;
            this.i = m;
            this.j = n;
            this.B = l
        }
        size() {
            return this.aa
        }
    };
    const Io = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var Jo = class extends vo {
        constructor(a, b) {
            super(a, b)
        }
        g(a) {
            return Math.min(1200, Math.max(this.F, Math.round(a)))
        }
    };

    function Ko(a, b) {
        Lo(a, b);
        if (b.google_content_recommendation_ui_type === "pedestal" && !T(Ai)) return new Ho(9, new Jo(a, Math.floor(a * 2.189)));
        if (T(Di)) {
            var c = zd(),
                d = fj(Ei),
                e = fj(Ci),
                f = fj(Bi);
            a < 468 ? c ? (a = Fo(a, d), a = {
                Z: a.width,
                Y: a.height,
                L: 1,
                M: d,
                P: "mobile_banner_image_sidebyside"
            }) : (a = Eo(a, 1, d, "image_sidebyside"), a = {
                Z: a.width,
                Y: a.height,
                L: 1,
                M: d,
                P: "image_sidebyside"
            }) : (a = Co(a), e === 1 && (a.height = Math.floor(a.height * .5)), a = {
                Z: a.width,
                Y: a.height,
                L: f,
                M: e,
                P: "image_stacked"
            })
        } else T(Ai) ? (d = Co(a), e = 4, f = 2, a < 468 && (e = 1,
            f = 6, d = {
                width: a,
                height: Math.floor(Do(a, "image_stacked") * f + 8 * f + 8)
            }), a = {
            Z: d.width,
            Y: d.height,
            L: e,
            M: f,
            P: "image_stacked"
        }) : (d = zd(), a < 468 ? d ? (a = Fo(a, 12), a = {
            Z: a.width,
            Y: a.height,
            L: 1,
            M: 12,
            P: "mobile_banner_image_sidebyside"
        }) : (a = Co(a), a = {
            Z: a.width,
            Y: a.height,
            L: 1,
            M: 13,
            P: "image_sidebyside"
        }) : (a = Co(a), a = {
            Z: a.width,
            Y: a.height,
            L: 4,
            M: 2,
            P: "image_stacked"
        }));
        Mo(b, a);
        return new Ho(9, new Jo(a.Z, a.Y))
    }

    function No(a, b) {
        Lo(a, b); {
            let f = Bo({
                M: b.google_content_recommendation_rows_num,
                L: b.google_content_recommendation_columns_num,
                P: b.google_content_recommendation_ui_type
            });
            if (f.ba) a = {
                Z: 0,
                Y: 0,
                L: 0,
                M: 0,
                P: "image_stacked",
                ba: f.ba
            };
            else {
                var c = f.hb.length === 2 && a >= 468 ? 1 : 0;
                var d = f.hb[c];
                d = d.indexOf("pub_control_") === 0 ? d : "pub_control_" + d;
                var e = Ao[d];
                let g = f.L[c];
                for (; a / g < e && g > 1;) g--;
                e = g;
                c = f.M[c];
                a = Eo(a, e, c, d);
                a = {
                    Z: a.width,
                    Y: a.height,
                    L: e,
                    M: c,
                    P: d
                }
            }
        }
        if (a.ba) throw new W(a.ba);
        Mo(b, a);
        return new Ho(9, new Jo(a.Z, a.Y))
    }

    function Lo(a, b) {
        if (a <= 0) throw new W(`Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`);
    }

    function Mo(a, b) {
        a.google_content_recommendation_ui_type = b.P;
        a.google_content_recommendation_columns_num = b.L;
        a.google_content_recommendation_rows_num = b.M
    };
    var Oo = class extends vo {
        constructor(a, b) {
            super(a, b)
        }
        g() {
            return this.F
        }
        i(a, b, c) {
            Cn(a, c);
            c.style.height = `${this.height}px`;
            b.rpe = !0
        }
    };
    const Po = {
        "image-top": a => a <= 600 ? 284 + (a - 250) * .414 : 429,
        "image-middle": a => a <= 500 ? 196 - (a - 250) * .13 : 164 + (a - 500) * .2,
        "image-side": a => a <= 500 ? 205 - (a - 250) * .28 : 134 + (a - 500) * .21,
        "text-only": a => a <= 500 ? 187 - .228 * (a - 250) : 130,
        "in-article": a => a <= 420 ? a / 1.2 : a <= 460 ? a / 1.91 + 130 : a <= 800 ? a / 4 : 200
    };
    var Qo = class extends vo {
        constructor(a, b) {
            super(a, b)
        }
        g() {
            return Math.min(1200, this.F)
        }
    };

    function Ro(a, b, c, d, e) {
        var f = e.google_ad_layout || "image-top";
        if (f === "in-article") {
            var g = a;
            if (e.google_full_width_responsive === "false") a = g;
            else if (a = xn(b, c, g, fj(Hi), e), a !== !0) e.gfwrnwer = a, a = g;
            else if (a = U(b))
                if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                    b: {
                        g = c;
                        for (let h = 0; h < 100 && g.parentElement; ++h) {
                            let k = g.parentElement.childNodes;
                            for (let m = 0; m < k.length; ++m) {
                                let n = k[m];
                                if (n !== g && An(b, n)) break b
                            }
                            g = g.parentElement;
                            g.style.width = "100%";
                            g.style.height = "auto"
                        }
                    }
                    Cn(b, c)
                }
            else a = g;
            else a = g
        }
        if (a <
            250) throw new W(`Fluid responsive ads must be at least 250px wide: availableWidth=${a}`);
        a = Math.min(1200, Math.floor(a));
        if (d && f !== "in-article") {
            f = Math.ceil(d);
            if (f < 50) throw new W(`Fluid responsive ads must be at least 50px tall: height=${f}`);
            return new Ho(11, new vo(a, f))
        }
        if (f !== "in-article" && (d = e.google_ad_layout_key)) {
            f = `${d}`;
            if (d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length)
                for (b = [], e = 0; e < d; e++) b.push(parseInt(c[e], 36) / 1E3);
            else b = null;
            if (!b) throw new W(`Invalid data-ad-layout-key value: ${f}`);
            f = (a + -725) / 1E3;
            c = 0;
            d = 1;
            e = b.length;
            for (g = 0; g < e; g++) c += b[g] * d, d *= f;
            f = Math.ceil(c * 1E3 - -725 + 10);
            if (isNaN(f)) throw new W(`Invalid height: height=${f}`);
            if (f < 50) throw new W(`Fluid responsive ads must be at least 50px tall: height=${f}`);
            if (f > 1200) throw new W(`Fluid responsive ads must be at most 1200px tall: height=${f}`);
            return new Ho(11, new vo(a, f))
        }
        d = Po[f];
        if (!d) throw new W("Invalid data-ad-layout value: " + f);
        c = pj(c, b);
        b = U(b);
        b = f !== "in-article" || c || a !== b ? Math.ceil(d(a)) : Math.ceil(d(a) * 1.25);
        return new Ho(11,
            f === "in-article" ? new Qo(a, b) : new vo(a, b))
    };
    var So = [{
            F: 970,
            height: 90,
            D: 2
        }, {
            F: 728,
            height: 90,
            D: 2
        }, {
            F: 468,
            height: 60,
            D: 2
        }, {
            F: 336,
            height: 280,
            D: 1
        }, {
            F: 320,
            height: 100,
            D: 2
        }, {
            F: 320,
            height: 50,
            D: 2
        }, {
            F: 300,
            height: 600,
            D: 4
        }, {
            F: 300,
            height: 250,
            D: 1
        }, {
            F: 250,
            height: 250,
            D: 1
        }, {
            F: 234,
            height: 60,
            D: 2
        }, {
            F: 200,
            height: 200,
            D: 1
        }, {
            F: 180,
            height: 150,
            D: 1
        }, {
            F: 160,
            height: 600,
            D: 4
        }, {
            F: 125,
            height: 125,
            D: 1
        }, {
            F: 120,
            height: 600,
            D: 4
        }, {
            F: 120,
            height: 240,
            D: 4
        }, {
            F: 120,
            height: 120,
            D: 1,
            Pa: !0
        }].map(a => new xo(a.F, a.height, a.D, a.Pa ? ? !1)),
        To = [6, 12, 3, 0, 7, 14, 1, 8, 10, 4, 15, 2, 11, 5, 13, 9, 16].map(a => So[a]);
    const Uo = 2 / 3;

    function Vo(a) {
        return b => b.F <= a
    }

    function Wo(a) {
        return b => b.height <= a
    }

    function Xo(a, b) {
        return b.Ha && b.Oa ? Math.max(250, kj(a).clientHeight * Uo) : 250
    }

    function Yo(a, b, c) {
        var d = c.Jb && pj(b, a),
            e = Xo(a, {
                Ha: c.Ha,
                Oa: c.Oa
            });
        return f => !(d && f.height >= e)
    };

    function Zo(a) {
        return b => {
            for (let c = a.length - 1; c >= 0; --c)
                if (!a[c](b)) return !1;
            return !0
        }
    }

    function $o(a, b) {
        var c = To.length,
            d = null;
        for (let e = 0; e < c; ++e) {
            let f = To[e];
            if (a(f)) {
                if (b == null || b(f)) return f;
                d === null && (d = f)
            }
        }
        return d
    };

    function ap(a, b, c, d, e) {
        e.google_full_width_responsive === "false" ? c = {
            J: a,
            I: 1
        } : b === "autorelaxed" && e.google_full_width_responsive || bp(b) || e.google_ad_resize ? (b = yn(a, c, d, e), c = b !== !0 ? {
            J: a,
            I: b
        } : {
            J: U(c) || a,
            I: !0
        }) : c = {
            J: a,
            I: 2
        };
        var {
            J: f,
            I: g
        } = c;
        return g !== !0 ? {
            J: a,
            I: g
        } : d.parentElement ? {
            J: f,
            I: g
        } : {
            J: a,
            I: g
        }
    }

    function cp(a, b, c, d, e) {
        var {
            J: f,
            I: g
        } = rk(247, () => ap(a, b, c, d, e)), h = g === !0, k = $d(d.style.width), m = $d(d.style.height), {
            aa: n,
            V: l,
            D: p,
            gb: q
        } = dp(f, b, c, d, e, h);
        h = ep(b, p);
        var u, y = (u = mj(d, c, "marginLeft")) ? `${u}px` : "",
            M = (u = mj(d, c, "marginRight")) ? `${u}px` : "";
        u = rj(d, c) || "";
        return new Ho(h, n, p, null, q, g, l, y, M, m, k, u)
    }

    function bp(a) {
        return a === "auto" || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
    }

    function dp(a, b, c, d, e, f) {
        b = fp(c, a, b);
        var g = U(c) < 488,
            h = g ? lj(d, c) : void 0,
            k = [Vo(a), wo(b)];
        T(Mi) || k.push(Yo(c, d, {
            Jb: g,
            Ha: !(!h || !pj(d, c)),
            Oa: Gg(c) === 0
        }));
        e.google_max_responsive_height != null && k.push(Wo(e.google_max_responsive_height));
        g = [p => !p.Pa()];
        if (h) {
            let p = qj(c, d);
            g.push(Wo(p))
        }
        var m = $o(Zo(k), Zo(g));
        if (!m) throw new W(`No slot size for availableWidth=${a}`);
        var {
            aa: n,
            V: l
        } = rk(248, () => {
            var p;
            a: if (f) {
                if (e.gfwrnh && (p = $d(e.gfwrnh))) {
                    p = {
                        aa: new Oo(a, p),
                        V: !0
                    };
                    break a
                }
                if (e.google_resizing_allowed || e.google_full_width_responsive ===
                    "true") p = Infinity;
                else {
                    p = d;
                    let u = Infinity;
                    do {
                        var q = mj(p, c, "height");
                        q && (u = Math.min(u, q));
                        (q = mj(p, c, "maxHeight")) && (u = Math.min(u, q))
                    } while (p.parentElement && (p = p.parentElement) && p.tagName !== "HTML");
                    p = u
                }!(T(Ki) && p <= a * 2) && (p = Math.min(a, p), p < a * .5 || p < 100) && (p = a);
                p = {
                    aa: new Oo(a, Math.floor(p)),
                    V: p < a ? 102 : !0
                }
            } else p = {
                aa: m,
                V: 100
            };
            return p
        });
        return e.google_ad_layout === "in-article" ? {
            aa: gp(a, c, d, n, e),
            V: !1,
            D: b,
            gb: h
        } : {
            aa: n,
            V: l,
            D: b,
            gb: h
        }
    }

    function ep(a, b) {
        if (a === "auto") return 1;
        switch (b) {
            case 2:
                return 2;
            case 1:
                return 3;
            case 4:
                return 4;
            case 3:
                return 5;
            case 6:
                return 6;
            case 5:
                return 7;
            case 7:
                return 8;
            default:
                throw Error("bad mask");
        }
    }

    function fp(a, b, c) {
        if (c === "auto") c = Math.min(1200, U(a)), b = b / c <= .25 ? 4 : 3;
        else {
            b = 0;
            for (let d in un) c.indexOf(d) !== -1 && (b |= un[d])
        }
        return b
    }

    function gp(a, b, c, d, e) {
        var f = e.google_ad_height || mj(c, b, "height");
        b = Ro(a, b, c, f, e).size();
        return b.F * b.height > a * d.height ? new xo(b.F, b.height, 1) : d
    };

    function hp(a, b, c, d, e) {
        var f;
        (f = U(b)) ? U(b) < 488 ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, Cn(b, c), f = {
            J: f,
            I: !0
        }) : f = {
            J: a,
            I: 5
        } : f = {
            J: a,
            I: 4
        }: f = {
            J: a,
            I: 10
        };
        var {
            J: g,
            I: h
        } = f;
        if (h !== !0 || a === g) return new Ho(12, new vo(a, d), null, null, !0, h, 100);
        var {
            aa: k,
            V: m,
            D: n
        } = dp(g, "auto", b, c, e, !0);
        return new Ho(1, k, n, 2, !0, h, m)
    };

    function ip(a) {
        var b = a.google_ad_format;
        if (b === "autorelaxed") {
            a: {
                if (a.google_content_recommendation_ui_type !== "pedestal")
                    for (let c of Io)
                        if (a[c] != null) {
                            a = !0;
                            break a
                        }
                a = !1
            }
            return a ? 9 : 5
        }
        if (bp(b)) return 1;
        if (b === "link") return 4;
        if (b === "fluid") return a.google_ad_layout === "in-article" ? (jp(a), 1) : 8;
        if (a.google_reactive_ad_format === 27) return jp(a), 1
    }

    function kp(a, b, c, d, e = !1) {
        var f = b.offsetWidth || (c.google_ad_resize || e) && mj(b, d, "width") || c.google_ad_width || 0;
        a === 4 && (c.google_ad_format = "auto", a = 1);
        e = (e = lp(a, f, b, c, d)) ? e : cp(f, c.google_ad_format, d, b, c);
        e.size().i(d, c, b);
        e.D != null && (c.google_responsive_formats = e.D);
        e.H != null && (c.google_safe_for_responsive_override = e.H);
        e.I != null && (e.I === !0 ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = e.I));
        e.V != null && e.V !== !0 && (c.gfwrnher = e.V);
        d = e.j || c.google_ad_width;
        d != null && (c.google_resizing_width = d);
        d = e.i || c.google_ad_height;
        d != null && (c.google_resizing_height = d);
        d = e.size().g(f);
        var g = e.size().height;
        c.google_ad_width = d;
        c.google_ad_height = g;
        var h = e.size();
        c.google_ad_format = `${h.g(f)}x${h.height}`;
        c.google_responsive_auto_format = e.G;
        e.g != null && (c.armr = e.g);
        c.google_ad_resizable = !0;
        c.google_override_format = 1;
        c.google_loader_features_used = 128;
        e.I === !0 && (c.gfwrnh = `${e.size().height}px`);
        e.u != null && (c.gfwroml = e.u);
        e.A != null && (c.gfwromr = e.A);
        e.i != null && (c.gfwroh =
            e.i);
        e.j != null && (c.gfwrow = e.j);
        e.B != null && (c.gfwroz = e.B);
        f = vd(window) || window;
        tn(f.location, "google_responsive_dummy_ad") && (Pa([1, 2, 3, 4, 5, 6, 7, 8], e.G) || e.g === 1) && e.g !== 2 && (f = JSON.stringify({
            googMsgType: "adpnt",
            key_value: [{
                key: "qid",
                value: "DUMMY_AD"
            }]
        }), c.dash = `<${Go}>window.top.postMessage('${f}', '*'); 
          </${Go}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`);
        a !== 1 && (a = e.size().height, b.style.height = `${a}px`)
    }

    function lp(a, b, c, d, e) {
        var f = d.google_ad_height || mj(c, e, "height") || 0;
        switch (a) {
            case 5:
                let {
                    J: g,
                    I: h
                } = rk(247, () => ap(b, d.google_ad_format, e, c, d));
                h === !0 && b !== g && Cn(e, c);
                h === !0 ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                return Ko(g, d);
            case 9:
                return T(Ai) ? Ko(b, d) : No(b, d);
            case 8:
                return Ro(b, e, c, f, d);
            case 10:
                return hp(b, e, c, f, d)
        }
    }

    function jp(a) {
        a.google_ad_format = "auto";
        a.armr = 3
    };

    function mp(a, b) {
        a.google_resizing_allowed = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };

    function np(a, b) {
        var c = vd(b);
        if (c) {
            c = U(c);
            let d = Wd(a, b) || {},
                e = d.direction;
            if (d.width === "0px" && d.cssFloat !== "none") return -1;
            if (e === "ltr" && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if (e === "rtl" && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function op(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            default:
                return b
        }
    }

    function pp(a, b) {
        if (a.getAttribute("src")) {
            var c = a.getAttribute("src") || "",
                d = Ye(c, "client");
            d && (b.google_ad_client = op("google_ad_client", d));
            (c = Ye(c, "host")) && (b.google_ad_host = op("google_ad_host", c))
        }
        c = !1;
        for (let e of a.attributes) /data-/.test(e.name) && ((a = ua(e.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_")), e.name !== "data-tag-for-child-directed-treatment" && e.name !== "data-tag-for-under-age-of-consent" || e.value !== "1") ? b.hasOwnProperty(a) ||
            (d = op(a, e.value), d !== null && (b[a] = d)) : (console.warn(`${e.name} is deprecated. Use data-tag-for-age-treatment="1" instead.`), c = !0));
        c && (b.google_tag_for_age_treatment = 1);
        b.google_ad_intents_format && !b.google_ad_intent_query && (b.google_reactive_ad_format = 40)
    }

    function qp(a) {
        if (T(Wi) && Number(a.google_ad_intents_in_drawer_format) === 1) switch (Number(a.google_ad_intents_format)) {
            case 4:
                return 22;
            case 5:
                return 25;
            default:
                return 21
        }
        switch (Number(a.google_ad_intents_format)) {
            case 4:
                return 18;
            case 5:
                return 23;
            default:
                return 17
        }
    }

    function rp(a, b) {
        if (a = Fh(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else {
            if (b.google_ad_intents_format)
                if (b.google_ad_intent_query) b = qp(b);
                else a: switch (Number(b.google_ad_intents_format)) {
                    case 4:
                        b = 20;
                        break a;
                    case 5:
                        b = 24;
                        break a;
                    default:
                        b = 19
                } else b = 12;
            return b
        }
    }

    function sp(a, b, c, d) {
        pp(a, b);
        if (c.document && c.document.body && !ip(b) && !b.google_reactive_ad_format && !b.google_ad_intent_query) {
            var e = parseInt(a.style.width, 10),
                f = np(a, c);
            if (f > 0 && e > f) {
                var g = parseInt(a.style.height, 10);
                e = !!Un[e + "x" + g];
                let h = f;
                if (e) {
                    let k = Vn(f, g);
                    if (k) h = k, b.google_ad_format = k + "x" + g + "_0ads_al";
                    else throw new W("No slot size for availableWidth=" + f);
                }
                b.google_ad_resize = !0;
                b.google_ad_width = h;
                e || (b.google_ad_format = null, b.google_override_format = !0);
                f = h;
                a.style.width = `${f}px`;
                mp(b, 4)
            }
        }
        if (T(Fi) ||
            U(c) < 488) {
            f = vd(c) || c;
            g = a.offsetWidth || mj(a, c, "width") || b.google_ad_width || 0;
            e = b.google_ad_client;
            if (d = tn(f.location, "google_responsive_slot_preview") || Wm(f, 1, d, e)) b: if (b.google_reactive_ad_format || b.google_ad_resize || ip(b) || wn(a, b)) d = !1;
                else {
                    for (d = a; d; d = d.parentElement) {
                        f = Wd(d, c);
                        if (!f) {
                            b.gfwrnwer = 18;
                            d = !1;
                            break b
                        }
                        if (!Pa(["static", "relative"], f.position)) {
                            b.gfwrnwer = 17;
                            d = !1;
                            break b
                        }
                    }
                    if (!T(Ni) && (d = fj(Ii), d = xn(c, a, g, d, b), d !== !0)) {
                        b.gfwrnwer = d;
                        d = !1;
                        break b
                    }
                    d = c === c.top ? !0 : !1
                }
            d ? (mp(b, 1), d = !0) : d = !1
        } else d = !1;
        if (g = ip(b)) kp(g, a, b, c, d);
        else {
            if (wn(a, b)) {
                if (d = Wd(a, c)) a.style.width = d.width, a.style.height = d.height, vn(d, b);
                b.google_ad_width || (b.google_ad_width = a.offsetWidth);
                b.google_ad_height || (b.google_ad_height = a.offsetHeight);
                b.google_loader_features_used = 256;
                b.google_responsive_auto_format = rp(c, b)
            } else vn(a.style, b);
            c.location && c.location.hash === "#gfwmrp" || b.google_responsive_auto_format === 12 && b.google_full_width_responsive === "true" ? kp(10, a, b, c, !1) : Math.random() < .01 && b.google_responsive_auto_format ===
                12 && (a = yn(a.offsetWidth || parseInt(a.style.width, 10) || b.google_ad_width, c, a, b), a !== !0 ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
        }
    };
    var tp = ["google_pause_ad_requests", "google_user_agent_client_hint"];

    function up(a) {
        var b = a.ib,
            c = a.ab,
            d = a.nb,
            e = a.l,
            f = a.X;
        c.dataset.adsbygoogleStatus = "done";
        var g = d.google_reactive_ads_config;
        b !== 2 && sp(c, d, e, f);
        mo(e, d);
        if (b !== 2 && vp(c, d, e)) wp(c, d, e);
        else if (T(cj) || b === 2 || Wd(c, e) ? .display !== "none" || d.google_adtest === "on" || d.google_reactive_ad_format > 0 || d.google_reactive_ads_config)
            if (xp(d)) r.console && r.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + String(d.google_reactive_ad_format) + " is deprecated. Check out page-level ads at https://www.google.com/adsense");
            else {
                if (b === 2) {
                    f = g.page_level_pubvars || {};
                    if (Z(Q).page_contains_reactive_tag && !Z(Q).allow_second_reactive_tag) {
                        if (f.pltais) {
                            Rm(!1);
                            return
                        }
                        throw new W("Only one 'enable_page_level_ads' allowed per page.");
                    }
                    Z(Q).page_contains_reactive_tag = !0;
                    Rm(f.google_pgb_reactive === 7)
                }
                d.google_unique_id = Hh(e);
                for (let h of tp) d[h] = d[h] || e[h];
                d.google_loader_used !== "sd" && (d.google_loader_used = "aa");
                d.google_reactive_tag_first = (Z(Q).first_tag_on_page || 0) === 1;
                rk(164, () => {
                    var {
                        Fb: h,
                        Zb: k
                    } = Tn(e, d);
                    c.appendChild(k);
                    qo(d);
                    tb(d.google_reactive_sra_index) && d.google_ad_unit_key || (d.google_ad_unit_key = ro(c, d), d.google_ad_dom_fingerprint = Wn(e, c), d.override_ady = so(c), d.override_adx = to(c));
                    var m = d.google_start_time ? ? Jh,
                        n = (new Date).getTime();
                    d.google_async_iframe_id = h;
                    d.google_start_time = m;
                    d.google_bpp = n > m ? n - m : 1;
                    b !== 2 && (m = e.fqjyf || {}, e.fqjyf = m, m[h] = {
                        LmpfC: d
                    });
                    no(e, () => {
                        var l = k,
                            p = b === 1 ? {
                                OSwJs: 1,
                                mqAVR: a.fb ? {
                                    bPXfr: a.fb
                                } : {}
                            } : {
                                OSwJs: 2,
                                mqAVR: {}
                            };
                        if (!l || !l.isConnected)
                            if (l = e.document.getElementById(String(d.google_async_iframe_id) +
                                    "_host"), l == null) throw Error("no_div");
                        (p = e.google_sa_impl({
                            pubWin: e,
                            vars: d,
                            innerInsElement: l,
                            KCuMo: p
                        })) && tk(911, p)
                    })
                })
            }
        else e.document.createComment && c.appendChild(e.document.createComment("No ad requested because of display:none on the adsbygoogle tag"))
    }

    function vp(a, b, c) {
        var d = Pm(c);
        !d ? .Va || b.google_adtest === "on" || w(a.className) && RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className) ? d = !1 : d.Wa ? (a = oj(a, c), c = kj(c).clientHeight, d = ((c === 0 ? null : a / c) || 0) >= d.Wa) : d = !0;
        return d
    }

    function wp(a, b, c) {
        a.className += " adsbygoogle-ablated-ad-slot";
        var d = c.fqjyf || {};
        c.fqjyf = d;
        var e = String(ma(a));
        d[e] = {
            LmpfC: b
        };
        a.setAttribute("google_element_uid", e);
        Pm(c) ? .Wb === "slot" && (Zd(a.getAttribute("width")) !== null && a.setAttribute("width", "0"), Zd(a.getAttribute("height")) !== null && a.setAttribute("height", "0"), a.style.width = "0px", a.style.height = "0px")
    }

    function xp(a) {
        var b = a.google_pgb_reactive == null || a.google_pgb_reactive === 3;
        return (a.google_reactive_ad_format === 1 || a.google_reactive_ad_format === 8) && b
    };

    function yp(a, b, c, d, e) {
        if (!Q.google_sa_queue) {
            Q.google_sa_queue = [];
            var f = zp(H(b, 4), e, b);
            f ? (f = !1, b = Ap(Q, e), Sn(b.client, b.plah).then(g => {
                c.resolve(D(g, Dj, 2) ? .u() || void 0);
                d.resolve(H(g, 1))
            }).catch(g => {
                var h = new Vg(2, ng(), void 0, void 0, void 0, void 0, Ah);
                fk(h, 1191, g);
                c.resolve(void 0);
                d.resolve(!0)
            })) : (c.resolve(en(b) ? .G() ? .u() || void 0), d.resolve(en(b) ? .B() ? ? !0));
            Q.google_process_slots = sk(215, () => {
                Bp(Q.google_sa_queue)
            });
            a = Cp(e, a, f);
            Ud(Q.document, a)
        }
    }

    function Bp(a) {
        var b = a.shift();
        vb(b) && rk(216, b);
        a.length && r.setTimeout(sk(215, () => {
            Bp(a)
        }), 0)
    }

    function zp(a, b, c) {
        var d = Q;
        if (a) {
            a = Ih(b ? ? "");
            b = en(c) ? .g() ? .g() || "";
            let e = en(c) ? .j() || "";
            c = !(a && (b === a || e === a) && d.location.host && J(c, 17) === d.location.host)
        } else c = !1;
        return c
    }

    function Cp(a, b, c) {
        var d = Q;
        b = c ? b.Sb : b.Tb;
        a = { ...(c ? Ap(d, a) : {}),
            ...Dn()
        };
        return Sd(b, new Map(Object.entries(a)))
    }

    function Ap(a, b) {
        if (b) {
            a: {
                try {
                    for (; a;) {
                        if (a.location ? .hostname) {
                            var c = a.location.hostname;
                            break a
                        }
                        a = a.parent
                    }
                } catch (d) {}
                c = ""
            }
            return {
                client: Ih(b),
                plah: c
            }
        }
        throw Error("PublisherCodeNotFoundForAma");
    };
    var Dp = class extends O {
        g() {
            return J(this, 1)
        }
        j() {
            return K(this, 2)
        }
    };
    var Ep = class extends O {
        getName() {
            return J(this, 1)
        }
    };
    var Fp = class extends O {
        g() {
            return E(this, Ep, 1, C())
        }
    };
    var Gp = class extends O {
        j() {
            return J(this, 1)
        }
        g() {
            return D(this, Dp, 2)
        }
        H() {
            return H(this, 3)
        }
        N() {
            return H(this, 4)
        }
        O() {
            return D(this, Kl, 5)
        }
        ea() {
            return D(this, Ll, 6)
        }
        ga() {
            return D(this, Fp, 7)
        }
        B() {
            return H(this, 8)
        }
        G() {
            return D(this, Dj, 9)
        }
        fa() {
            return H(this, 10)
        }
    };
    var Hp = class extends O {
        getId() {
            return I(this, 1)
        }
    };

    function Ip(a) {
        return E(a, Hp, 2, C())
    }
    var Jp = class extends O {};
    var Kp = class extends O {};
    var Lp = class extends O {
        g() {
            return Xc(this, 2) ? ? yc
        }
        j() {
            return Xc(this, 4) ? ? yc
        }
        B() {
            return H(this, 3)
        }
    };
    var Mp = class extends O {};
    var Np = class extends O {
        g() {
            return H(this, 1)
        }
        B() {
            return H(this, 2)
        }
        j() {
            return H(this, 3)
        }
    };

    function en(a) {
        return bd(a, Gp, 27, Op)
    }
    var Pp = class extends O {
            g() {
                return D(this, Np, 26)
            }
        },
        Op = [27, 28];

    function Qp(a) {
        var b = nk;
        try {
            if (!w(a)) throw Error(String(a));
            if (a.length > 0) return new Pp(JSON.parse(a))
        } catch (c) {
            b.K(838, c instanceof Error ? c : Error(String(c)))
        }
        return new Pp
    };

    function Rp(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && ud(b); b = b.parent) {
            let c = T(bj) ? b : a;
            if (c.sf_) return 2;
            if (c.$sf) return 3;
            if (c.inGptIF) return 4;
            if (c.inDapIF) return 5
        }
        return 1
    };

    function Sp(a, b, c) {
        for (let f of b) a: {
            b = a;
            var d = f,
                e = c;
            for (let g = 0; g < b.slots.length; g++) {
                if (b.slots[g].element.contains(d)) {
                    b.slots[g].labels.add(e);
                    break a
                }
                if (d.contains(b.slots[g].element)) {
                    b.slots[g].element = d;
                    b.slots[g].labels.add(e);
                    break a
                }
            }
            b.slots.push({
                element: d,
                labels: new Set([e])
            })
        }
    }
    class Tp {
        constructor() {
            this.slots = []
        }
        getSlots() {
            return this.slots
        }
    }

    function Up(a) {
        var b = tl(a),
            c = new Tp;
        Sp(c, b.rb, 1);
        Sp(c, b.sb, 2);
        Sp(c, b.Bb, 3);
        Sp(c, b.Yb, 4);
        Sp(c, b.tb, 5);
        Sp(c, b.Mb, 6);
        return c.getSlots().map(d => {
            var e = new yf;
            var f = [...d.labels];
            e = Kc(e, 1, f, Tb);
            d = d.element.getBoundingClientRect();
            f = new xf;
            f = dd(f, 1, d.left + a.scrollX);
            f = dd(f, 2, d.top + a.scrollY);
            f = dd(f, 3, d.width);
            d = dd(f, 4, d.height);
            d = uc(d);
            e = F(e, 2, d);
            return uc(e)
        }).sort((d, e) => {
            d = D(d, xf, 2);
            d = I(d, 2);
            e = D(e, xf, 2);
            e = I(e, 2);
            return d - e
        })
    };

    function Vp(a) {
        return a.google_ad_client ? String(a.google_ad_client) : Z(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? ""
    };

    function Tg(a, b, c = 0) {
        a.g.size > 0 || Wp(a);
        c = Math.min(Math.max(0, c), 9);
        var d = a.g.get(c);
        d ? d.push(b) : a.g.set(c, [b])
    }

    function Xp(a, b, c, d) {
        ne(b, c, d);
        Kk(a, () => oe(b, c, d))
    }

    function Yp(a, b) {
        a.state !== 1 && (a.state = 1, a.g.size > 0 && Zp(a, b))
    }

    function Wp(a) {
        a.l.document.visibilityState ? Xp(a, a.l.document, "visibilitychange", b => {
            a.l.document.visibilityState === "hidden" && Yp(a, b);
            a.l.document.visibilityState === "visible" && (a.state = 0)
        }) : "onpagehide" in a.l ? (Xp(a, a.l, "pagehide", b => {
            Yp(a, b)
        }), Xp(a, a.l, "pageshow", () => {
            a.state = 0
        })) : Xp(a, a.l, "beforeunload", b => {
            Yp(a, b)
        })
    }

    function Zp(a, b) {
        for (let c = 9; c >= 0; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var $p = class extends Jk {
        constructor(a) {
            super();
            this.l = a;
            this.state = 0;
            this.g = new Map
        }
    };
    async function aq(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} 200`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            var f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function bq(a) {
        var b = a.state.pc;
        return b !== null && b !== 0 ? b : a.state.pc = ee(a.l)
    }

    function cq(a) {
        var b = a.state.wpc;
        return b !== null && b !== "" ? b : a.state.wpc = Vp(a.l)
    }

    function dq(a, b) {
        var c = new Rf;
        var d = bq(a);
        c = fd(c, 1, d);
        d = cq(a);
        c = jd(c, 2, d);
        c = fd(c, 3, a.state.sd);
        return fd(c, 7, Math.round(b || a.l.performance.now()))
    }
    async function eq(a) {
        try {
            return await aq(a.l, () => !(!bq(a) || !cq(a))), !0
        } catch (b) {
            return !1
        }
    }

    function fq(a, b) {
        if (a.i) {
            var c = a.u;
            b(c);
            a.state.psi = z(c)
        }
    }

    function gq(a) {
        Tg(a.j, () => {
            var b = dq(a);
            b = G(b, 12, Sf, a.A);
            a.i && !a.state.le.includes(3) && (a.state.le.push(3), Ng(a.g, b))
        }, 9)
    }

    function hq(a) {
        var b = new Of;
        Tg(a.j, () => {
            F(b, 2, a.u);
            fd(b, 3, a.state.tar);
            var c = a.l;
            var d = new Cf;
            var e = Up(c);
            d = Vc(d, 1, e);
            e = nd(Af(zf(new Bf, U(c)), kj(c).clientHeight));
            d = F(d, 2, e);
            c = nd(Af(zf(new Bf, kj(c).scrollWidth), kj(c).scrollHeight));
            c = F(d, 3, c);
            c = uc(c);
            F(b, 4, c);
            c = a.g;
            d = dq(a);
            d = G(d, 8, Sf, b);
            Ng(c, d)
        }, 9)
    }
    async function iq(a) {
        var b = P(jq);
        if (b.i && !b.state.le.includes(1)) {
            b.state.le.push(1);
            var c = b.l.performance.now();
            if (await eq(b)) {
                var d = new Kf;
                a = Lc(d, 5, Qb(a), !1);
                d = Af(zf(new Bf, kj(b.l).scrollWidth), kj(b.l).scrollHeight);
                a = F(a, 2, d);
                d = Af(zf(new Bf, U(b.l)), kj(b.l).clientHeight);
                a = F(a, 1, d);
                for (var e = d = b.l; d && d !== d.parent;) d = d.parent, ud(d) && (e = d);
                a = jd(a, 4, e.location.href);
                d = Rp(b.l);
                d !== 0 && (e = new Jf, d = kd(e, 1, d), F(a, 3, d));
                d = b.g;
                c = dq(b, c);
                c = G(c, 4, Sf, a);
                Ng(d, c);
                gq(b);
                hq(b)
            }
        }
    }
    async function kq(a, b, c) {
        if (a.i && c.length && !a.state.lgdp.includes(Number(b))) {
            a.state.lgdp.push(Number(b));
            var d = a.l.performance.now();
            if (await eq(a)) {
                var e = a.g;
                a = dq(a, d);
                d = new If;
                b = ld(d, 1, b);
                c = Kc(b, 2, c, Vb);
                c = G(a, 9, Sf, c);
                Ng(e, c)
            }
        }
    }
    async function lq(a, b) {
        if (await eq(a)) {
            var c = a.g;
            a = dq(a);
            a = fd(a, 3, 1);
            b = G(a, 10, Sf, b);
            Ng(c, b)
        }
    }
    async function mq(a, b) {
        if (await eq(a)) {
            var c = a.g;
            a = dq(a);
            a = fd(a, 3, 1);
            b = G(a, 18, Sf, b);
            Ng(c, b)
        }
    }
    var jq = class {
        constructor(a, b) {
            this.l = Gh() || window;
            this.j = b ? ? new $p(this.l);
            this.g = a ? ? new Vg(2, ng(), 100, 100, !0, this.j, Ah);
            this.state = Dk(yk(), 33, () => {
                var c = fj(Gi);
                return {
                    sd: c,
                    ssp: c > 0 && Md() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get i() {
            return this.state.ssp
        }
        get u() {
            return rk(1178, () => od(Nf, lc(this.state.psi || []))) || new Nf
        }
        get A() {
            return rk(1227, () => od(Qf, lc(this.state.cc || []))) || new Qf
        }
    };

    function nq() {
        var a = window;
        return r.google_adtest === "on" || r.google_adbreak_test === "on" || a.location.host.endsWith("h5games.usercontent.goog") || a.location.host === "gamesnacks.com" ? a.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(b => Math.floor(Number(b))).filter(b => !isNaN(b) && b > 0) || [] : []
    };

    function oq(a, b) {
        return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1
    }

    function pq(a) {
        var b = Q.document;
        if (b.currentScript) return oq(b.currentScript, a);
        for (let c of b.scripts)
            if (oq(c, a) === 0) return 0;
        return 1
    };

    function qq(a, b) {
        var c = !!b.g() ? .g();
        return {
            [3]: {
                [55]: () => a === 0,
                [23]: d => Wm(Q, Number(d), b),
                [24]: d => Zm(Number(d), c),
                [61]: () => c,
                [63]: () => c || J(b, 8) === ".google.ch"
            },
            [4]: {},
            [5]: {
                [6]: () => J(b, 15)
            }
        }
    };

    function rq(a = r) {
        return a.ggeac || (a.ggeac = {})
    };

    function sq(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function tq(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    }

    function uq(a, b = navigator) {
        try {
            return !!b.protectedAudience ? .queryFeatureSupport ? .(a)
        } catch (c) {
            return !1
        }
    };

    function vq(a, b) {
        try {
            let d = a.split(".");
            a = r;
            let e = 0,
                f;
            for (; a != null && e < d.length; e++) f = a, a = a[d[e]], typeof a === "function" && (a = f[d[e]]());
            var c = a;
            if (typeof c === b) return c
        } catch {}
    }
    var wq = {
        [3]: {
            [8]: a => {
                try {
                    return ja(a) != null
                } catch {}
            },
            [9]: a => {
                try {
                    var b = ja(a)
                } catch {
                    return
                }
                if (a = typeof b === "function") b = b && b.toString && b.toString(), a = w(b) && b.indexOf("[native code]") != -1;
                return a
            },
            [10]: () => window === window.top,
            [6]: (a, b) => Pa(Ah(b ? Number(b) : void 0), Number(a)),
            [27]: a => {
                a = vq(a, "boolean");
                return a !== void 0 ? a : void 0
            },
            [60]: a => {
                try {
                    return !!r.document.querySelector(a)
                } catch {}
            },
            [80]: a => {
                try {
                    return !!r.matchMedia(a).matches
                } catch {}
            },
            [69]: a => sq(a, r.document),
            [70]: a => tq(a, r.document),
            [79]: a => uq(a,
                r.navigator)
        },
        [4]: {
            [3]: () => Ld(),
            [6]: a => {
                a = vq(a, "number");
                return a !== void 0 ? a : void 0
            }
        },
        [5]: {
            [2]: () => window.location.href,
            [3]: () => {
                try {
                    return window.top.location.hash
                } catch {
                    return ""
                }
            },
            [4]: a => {
                a = vq(a, "string");
                return a !== void 0 ? a : void 0
            },
            [12]: a => {
                try {
                    let b = vq(a, "string");
                    if (b !== void 0) return atob(b)
                } catch (b) {}
            }
        }
    };

    function xq(a) {
        return yq({
            [0]: new Map,
            [1]: new Map,
            [2]: new Map
        }, a)
    }

    function yq(a, b) {
        var c = new Map;
        for (let [f, g] of a[1].entries()) {
            var d = f,
                e = g;
            let {
                ob: h,
                jb: k,
                kb: m
            } = e[e.length - 1];
            c.set(d, h + k * m)
        }
        for (let f of b)
            for (let g of E(f, Jp, 2, C())) {
                if (Ip(g).length === 0) continue;
                b = Xb(A(g, 8)) ? ? 0;
                !K(g, 4) || K(g, 13) || K(g, 14) || (b = c.get(K(g, 4)) ? ? 0, d = (Xb(A(g, 1)) ? ? 0) * Ip(g).length, c.set(K(g, 4), b + d));
                d = [];
                for (e = 0; e < Ip(g).length; e++) {
                    let h = {
                        ob: b,
                        jb: Xb(A(g, 1)) ? ? 0,
                        kb: Ip(g).length,
                        Lb: e,
                        na: K(f, 1),
                        va: g,
                        W: Ip(g)[e]
                    };
                    d.push(h)
                }
                zq(a[2], K(g, 10), d) || zq(a[1], K(g, 4), d) || zq(a[0], Ip(g)[0].getId(), d)
            }
        return a
    }

    function zq(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        a.get(b).push(...c);
        return !0
    };

    function Aq(a = Md()) {
        return b => ei(`${b} + ${a}`) % 1E3
    };
    const Bq = [12, 13, 20];

    function Cq(a, b) {
        var c = P(ah).T,
            d = lf(D(b.va, df, 3), c);
        if (!d.success) return Zg(a.R, D(b.va, df, 3), b.na, b.W.getId(), d), !1;
        if (!d.value) return !1;
        c = lf(D(b.W, df, 3), c);
        return c.success ? c.value ? !0 : !1 : (Zg(a.R, D(b.W, df, 3), b.na, b.W.getId(), c), !1)
    }

    function Dq(a, b, c) {
        a.g[c] || (a.g[c] = []);
        a = a.g[c];
        a.includes(b) || a.push(b)
    }

    function Eq(a, b, c, d) {
        var e = [],
            f;
        if (f = b !== 9) a.u[b] ? f = !0 : (a.u[b] = !0, f = !1);
        if (f) return Xg(a.R, b, c, e, [], 4), e;
        f = Bq.includes(b);
        var g = [],
            h = [];
        for (let l of [0, 1, 2])
            for (let [p, q] of a.ra[l].entries()) {
                var k = p,
                    m = q;
                let u = new Xf;
                var n = m.filter(y => y.na === b && a.i[y.W.getId()] && Cq(a, y));
                if (n.length) {
                    for (let y of n) h.push(y.W);
                    continue
                }
                if (a.Ma) continue;
                l === 2 ? (n = d[1], md(u, 2, Yf, k)) : n = d[0];
                k = n ? .(String(k)) ? ? (l === 2 && K(m[0].va, 11) === 1 ? void 0 : d[0](String(k)));
                if (k !== void 0) {
                    for (let y of m) {
                        if (y.na !== b) continue;
                        m = k - y.ob;
                        n = y.jb;
                        let M = y.kb,
                            za = y.Lb;
                        if (m < 0 || m >= n * M || m % M !== za) continue;
                        if (!Cq(a, y)) continue;
                        m = K(y.va, 13);
                        m !== 0 && m !== void 0 && (n = a.j[String(m)], n !== void 0 && n !== y.W.getId() ? Yg(a.R, a.j[String(m)], y.W.getId(), m) : a.j[String(m)] = y.W.getId());
                        h.push(y.W)
                    }
                    Qc(u, Yf) !== 0 && (ed(u, 3, k), g.push(u))
                }
            }
        for (let l of h) d = l.getId(), e.push(d), Dq(a, d, f ? 4 : c), qh(E(l, of , 2, C()), f ? sh() : [c], a.R, d);
        Xg(a.R, b, c, e, g, 1);
        return e
    }

    function Fq(a, b) {
        b = b.map(c => new Kp(c)).filter(c => !Bq.includes(K(c, 1)));
        a.ra = yq(a.ra, b)
    }

    function Gq(a, b) {
        R(1, c => {
            a.i[c] = !0
        }, b);
        R(2, (c, d, e) => Eq(a, c, d, e), b);
        R(3, c => (a.g[c] || []).concat(a.g[4]), b);
        R(12, c => void Fq(a, c), b);
        R(16, (c, d) => void Dq(a, c, d), b)
    }
    var Hq = class {
        constructor(a, b, c, {
            Ma: d = !1,
            Jc: e = []
        } = {}) {
            this.ra = a;
            this.R = c;
            this.u = {};
            this.Ma = d;
            this.g = {
                [b]: [],
                [4]: []
            };
            this.i = {};
            this.j = {};
            if (a = Fe()) {
                a = a.split(",") || [];
                for (let f of a)(a = Number(f)) && (this.i[a] = !0)
            }
            for (let f of e) this.i[f] = !0
        }
    };

    function Iq(a, b) {
        a.g = uh(14, b, () => {})
    }
    class Jq {
        constructor() {
            this.g = () => {}
        }
    }

    function Kq(a) {
        P(Jq).g(a)
    };

    function Lq({
        Db: a,
        T: b,
        config: c,
        wb: d = rq(),
        xb: e = 0,
        R: f = new $g($l(D(a, Lp, 5) ? .g()) ? ? 0, $l(D(a, Lp, 5) ? .j()) ? ? 0, D(a, Lp, 5) ? .B() ? ? !1),
        ra: g = xq(E(a, Kp, 2, C(qb)))
    }) {
        d.hasOwnProperty("init-done") ? (uh(12, d, () => {})(E(a, Kp, 2, C()).map(h => z(h))), uh(13, d, () => {})(E(a, of , 1, C()).map(h => z(h)), e), b && uh(14, d, () => {})(b), Mq(e, d)) : (Gq(new Hq(g, e, f, c), d), vh(d), wh(d), xh(d), Mq(e, d), qh(E(a, of , 1, C(qb)), [e], f, void 0, !0), bh = bh || !(!c || !c.Ib), Kq(wq), b && Kq(b))
    }

    function Mq(a, b = rq()) {
        yh(P(zh), b, a);
        Nq(b, a);
        Iq(P(Jq), b);
        P(ce).B()
    }

    function Nq(a, b) {
        var c = P(ce);
        c.j = (d, e) => uh(5, a, () => !1)(d, e, b);
        c.A = (d, e) => uh(6, a, () => 0)(d, e, b);
        c.g = (d, e) => uh(7, a, () => "")(d, e, b);
        c.i = (d, e) => uh(8, a, () => [])(d, e, b);
        c.u = (d, e) => uh(17, a, () => [])(d, e, b);
        c.B = () => {
            uh(15, a, () => {})(b)
        }
    };

    function Oq(a, b) {
        b = {
            [0]: Aq(ee(b).toString())
        };
        b = P(zh).j(a, b);
        a = kq(P(jq), a, b);
        Dh.ua(1085, a)
    }

    function Pq(a, b, c) {
        var d = D(b, Mp, 12),
            e = H(b, 9);
        Lq({
            Db: d,
            T: qq(c, b),
            config: {
                Ma: e && !!a.google_disable_experiments,
                Ib: e
            },
            wb: rq(a),
            xb: 1
        });
        if (c = J(b, 15)) c = Number(c), P(zh).i(c);
        for (let f of Ec(b, 19, Wb, C())) P(zh).g(f);
        Oq(12, a);
        Oq(10, a)
    };

    function Qq(a) {
        nk.A(b => {
            b.shv = String(a);
            b.mjsv = ng();
            var c = Ah(),
                d = nq();
            b.eid = c.concat(d).join(",")
        })
    };

    function Rq(a, b, c) {
        return {
            stavq: I(a, 1),
            jTCuI: J(a, 2),
            OmOVT: H(a, 20),
            xujKL: H(a, 9),
            AyxaY: I(a, 18) !== -1 ? I(a, 18) : void 0,
            SLqBY: J(a, 8) || void 0,
            xVQAt: J(a, 3),
            OSCLM: {
                UWEfJ: !!a.g() ? .g(),
                YguOd: !!a.g() ? .B(),
                SVQEK: !!a.g() ? .j()
            },
            jzoix: {
                PygXN: (en(a) ? .ga() ? .g() || []).map(d => ({
                    aJhyn: d.getName(),
                    ihulF: J(d, 2)
                }))
            },
            gjPrg: en(a) ? .j() ? ? void 0,
            zeuLy: en(a) ? .g() ? .g() ? ? void 0,
            ANqoe: J(a, 17) ? ? void 0,
            FJPve: !1,
            GLnKw: !1,
            tYcft: b.promise,
            EGzMj: c.promise,
            uNjDc: !!en(a) ? .fa()
        }
    };

    function Sq(a, b, c) {
        if (c === "sd") return 0;
        if (H(b, 22)) return 7;
        if (H(b, 16)) return 6;
        c = en(b) ? .g() ? .g();
        b = en(b) ? .g() ? .j() ? ? 0;
        a = c === a;
        switch (b) {
            case 1:
                return a ? 9 : 8;
            case 2:
                return a ? 11 : 10;
            case 3:
                return a ? 13 : 12
        }
        return 1
    };

    function Tq(a, b) {
        var c = new Uq;
        try {
            let f = a.createElement("link");
            if (f.relList ? .supports ? .("compression-dictionary") && Ha()) {
                var d = f;
                if (b instanceof Ed) d.href = Gd(b).toString(), d.rel = "compression-dictionary";
                else {
                    if (Jd.indexOf("compression-dictionary") === -1) throw Error('TrustedResourceUrl href attribute required with rel="compression-dictionary"');
                    var e = Hd.test(b) ? b : void 0;
                    e !== void 0 && (d.href = e, d.rel = "compression-dictionary")
                }
                a.head.appendChild(f)
            }
        } catch (f) {
            c.ia({
                methodName: 1296,
                Ja: f
            })
        }
    }

    function Vq(a) {
        return Rd `https://googleads.g.doubleclick.net/pagead/managed/dict/${a}/adsbygoogle`
    };
    var Uq = class {
        constructor() {
            this.g = nk
        }
        ia(a) {
            var b = a.Ja;
            this.g.K(a.methodName ? ? 0, b instanceof Error ? b : Error(String(b)))
        }
    };

    function Wq(a, b, c) {
        ne(a, "message", d => {
            try {
                var e = JSON.parse(d.data)
            } catch (f) {
                return
            }!e || e.googMsgType !== b || c(e, d)
        })
    };

    function Xq(a, b) {
        return b == null ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function Yq(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function Zq() {
        var a = new Set,
            b = sl();
        try {
            if (!b) return a;
            let c = b.pubads();
            for (let d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function $q(a) {
        a = a.id;
        return a != null && (Zq().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function Dg() {
        var a = 0;
        for (let b of document.getElementsByTagName("iframe")) $q(b) && a++;
        return a
    }

    function ar(a, b, c) {
        if (!a.sources) return !1;
        switch (br(a)) {
            case 2:
                let d = cr(a);
                if (d) return c.some(f => dr(d, f));
                break;
            case 1:
                let e = er(a);
                if (e) return b.some(f => dr(e, f))
        }
        return !1
    }

    function br(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (a.length >= 1) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function er(a) {
        return fr(a, b => b.currentRect)
    }

    function cr(a) {
        return fr(a, b => b.previousRect)
    }

    function fr(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && d.width * d.height !== 0 ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function dr(a, b) {
        var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return c <= 0 || a <= 0 ? !1 : c * a * 100 / ((b.right - b.left) * (b.bottom - b.top)) >= 50
    }

    function gr() {
        var a = Array.from(document.getElementsByTagName("iframe")).filter($q),
            b = [...Zq()].map(c => document.getElementById(c)).filter(c => c !== null);
        hr = window.scrollX;
        ir = window.scrollY;
        return jr = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function kr() {
        var a = new lr;
        if (T($i)) {
            var b = window;
            if (!b.google_plmetrics && window.PerformanceObserver) {
                b.google_plmetrics = !0;
                b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask", "event"];
                for (let c of b) b = {
                    type: c,
                    buffered: !0
                }, c === "event" && (b.durationThreshold = 40), mr(a).observe(b);
                nr(a)
            }
        }
    }

    function or(a, b) {
        var c = hr !== window.scrollX || ir !== window.scrollY ? [] : jr,
            d = gr();
        for (let e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                pr(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Ba = Math.floor(b.renderTime || b.loadTime);
                a.Aa = b.size;
                break;
            case "first-input":
                b = e;
                a.ya = Number((b.processingStart - b.startTime).toFixed(3));
                a.za = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || qr(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.u += b;
                a.H =
                    Math.max(a.H, b);
                a.ea += 1;
                break;
            case "event":
                qr(a, e);
                break;
            default:
                Ib(b, void 0)
        }
    }

    function mr(a) {
        a.R || (a.R = new PerformanceObserver(Tj(640, b => {
            or(a, b)
        })));
        return a.R
    }

    function nr(a) {
        var b = Tj(641, () => {
                var d = document;
                (d.prerendering ? 3 : {
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5,
                    "": 0
                }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] ? ? 0) === 2 && rr(a)
            }),
            c = Tj(641, () => void rr(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.Qa = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            mr(a).disconnect()
        }
    }

    function rr(a) {
        if (!a.Ta) {
            a.Ta = !0;
            mr(a).takeRecords();
            var b = window,
                c = a.xa.Pb || 1,
                d = Math.min(a.g.length - 1, Math.floor((a.R ? a.Ra : performance.interactionCount || 0) / 50));
            if (c === 1 || c === 3) {
                let f = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
                b.LayoutShift && (f += Yq("cls", a.A), f += Yq("mls", a.N), f += Xq("nls", a.O), b.LayoutShiftAttribution && (f += Yq("cas", a.j), f += Xq("nas", a.Ea), f += Yq("was", a.Ga)), f += Yq("wls", a.ga), f += Yq("tls", a.Fa));
                b.LargestContentfulPaint && (f += Xq("lcp", a.Ba), f += Xq("lcps", a.Aa));
                window.PerformanceEventTiming && a.za && (f += Xq("fid", a.ya));
                b.PerformanceLongTaskTiming && (f += Xq("cbt", a.u), f += Xq("mbt", a.H), f += Xq("nlt", a.ea));
                f += Xq("nif", Dg());
                f += Xq("ifi", Gg(window));
                var e = Ah();
                f += `&eid=${encodeURIComponent(e.join())}`;
                f += `&top=${r===r.top?1:0}`;
                f += a.fa ? `&qqid=${encodeURIComponent(a.fa)}` : Xq("pvsid", ee(r));
                b.googletag && (f += "&gpt=1");
                d >= 0 && (e = a.g[d].latency, e >= 0 && (f += Xq("inp", e)));
                window.fetch(f, {
                    keepalive: !0,
                    credentials: "include",
                    redirect: "follow",
                    method: "get",
                    mode: "no-cors"
                })
            }!a.xa.mb ||
                c !== 2 && c !== 3 || (c = new Ig, b.LayoutShift && (wg(vg(ug(gd(c, 1, a.A), a.N), a.O), a.ga), b.LayoutShiftAttribution && yg(xg(gd(c, 5, a.j), a.Ea), a.Ga), gd(c, 8, a.Fa)), b.LargestContentfulPaint && zg(N(c, 9, a.Ba), a.Aa), window.PerformanceEventTiming && a.za && N(c, 11, a.ya), b.PerformanceLongTaskTiming && Bg(Ag(N(c, 12, a.u), a.H), a.ea), Hg(Fg(Cg(c))), a.fa ? id(c, 17, a.fa) : Eg(c, Qd(r, {
                    ia: () => {}
                })), b.googletag && Bc(c, 21, Qb(!0)), d >= 0 && (b = a.g[d].latency, b >= 0 && N(c, 15, b)), Og(a.xa.mb, c));
            a.Qa()
        }
    }

    function pr(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.A += Number(b.value);
            Number(b.value) > a.N && (a.N = Number(b.value));
            a.O += 1;
            if (c = ar(b, c, d)) a.j += b.value, a.Ea++;
            if (b.startTime - a.Sa > 5E3 || b.startTime - a.Ua > 1E3) a.Sa = b.startTime, a.i = 0, a.B = 0;
            a.Ua = b.startTime;
            a.i += b.value;
            c && (a.B += b.value);
            a.i > a.ga && (a.ga = a.i, a.Ga = a.B, a.Fa = b.startTime + b.duration)
        }
    }

    function qr(a, b) {
        sr(a, b);
        var c = a.g[a.g.length - 1],
            d = a.Ca[b.interactionId];
        if (d || a.g.length < 10 || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.Ca[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.Ca[e.id]
        })
    }

    function sr(a, b) {
        b.interactionId && (a.Da = Math.min(a.Da, b.interactionId), a.G = Math.max(a.G, b.interactionId), a.Ra = a.G ? (a.G - a.Da) / 7 + 1 : 0)
    }
    var lr = class {
            constructor() {
                this.xa = {
                    mb: jk,
                    Pb: fj(aj)
                };
                this.B = this.i = this.O = this.N = this.A = 0;
                this.Ua = this.Sa = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.Ca = {};
                this.Ra = 0;
                this.Da = Infinity;
                this.ya = this.Aa = this.Ba = this.Ea = this.Ga = this.j = this.Fa = this.ga = this.G = 0;
                this.za = !1;
                this.ea = this.H = this.u = 0;
                this.R = null;
                this.Ta = !1;
                this.Qa = () => {};
                var a = document.querySelector("[data-google-query-id]");
                this.fa = a ? a.getAttribute("data-google-query-id") : null
            }
        },
        hr, ir, jr = [];
    let tr = null;
    const ur = [],
        vr = new Map;
    let wr = -1;

    function xr(a) {
        return tj.test(a.className) && a.dataset.adsbygoogleStatus !== "done"
    }

    function yr(a) {
        var b = document.getElementsByTagName("INS");
        for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
            var c = e;
            if (xr(c) && c.dataset.adsbygoogleStatus !== "reserved" && (!a || e.id === a)) return e
        }
        return null
    }

    function zr(a, b, c, d, e) {
        if (a && "shift" in a) {
            fq(P(jq), g => {
                var h = Mf(g);
                $c(h, 2) || (g = Mf(g), hd(g, 2))
            });
            for (var f = 20; a.length > 0 && f > 0;) {
                try {
                    Ar(a.shift(), b, c, d, e)
                } catch (g) {
                    setTimeout(() => {
                        throw g;
                    })
                }--f
            }
        }
    }

    function Br() {
        var a = Vd("INS");
        a.className = "adsbygoogle";
        a.className += " adsbygoogle-noablate";
        ae(a);
        a.dataset.adHi = "true";
        return a
    }

    function Cr(a, b) {
        var c = {},
            d = dn(a.google_ad_client, b);
        td(jj, (g, h) => {
            a.enable_page_level_ads === !1 ? c[h] = !1 : a.hasOwnProperty(h) ? c[h] = a[h] : d.includes(g) && (c[h] = !1)
        });
        la(a.enable_page_level_ads) && (c.page_level_pubvars = a.enable_page_level_ads);
        var e = Br();
        qe.body.appendChild(e);
        var f = {
            google_reactive_ads_config: c,
            google_ad_client: a.google_ad_client
        };
        f.google_pause_ad_requests = !!Z(Q).pause_ad_requests;
        f.abgtt = Sq(Dr(a), b, f.google_loader_used) || void 0;
        up({
            ib: 2,
            ab: e,
            nb: f,
            l: window,
            X: b
        });
        fq(P(jq), g => {
            var h = Mf(g);
            $c(h, 6) || (g = Mf(g), hd(g, 6))
        })
    }

    function Er(a, b) {
        Jn(r).wasPlaTagProcessed = !0;
        var c = () => {
                Cr(a, b)
            },
            d = r.document;
        if (d.body || d.readyState === "complete" || d.readyState === "interactive") Cr(a, b);
        else {
            let e = yd(sk(191, c));
            ne(d, "DOMContentLoaded", e);
            r.MutationObserver != null && (new r.MutationObserver((f, g) => {
                d.body && (e(), g.disconnect())
            })).observe(d, {
                childList: !0,
                subtree: !0
            })
        }
    }

    function Ar(a, b, c, d, e) {
        var f = {};
        rk(165, () => {
            Fr(a, f, b, c, d, e)
        }, g => {
            g.client = g.client || f.google_ad_client || a.google_ad_client;
            g.slotname = g.slotname || f.google_ad_slot;
            g.tag_origin = g.tag_origin || f.google_tag_origin
        })
    }

    function Gr(a) {
        delete a.google_checked_head;
        td(a, (b, c) => {
            sj[c] || (delete a[c], r.console.warn(`AdSense head tag doesn't support ${c.replace("google","data").replace(/_/g,"-")} attribute.`))
        })
    }

    function Hr(a, b) {
        var c = Ir();
        if (c) {
            var d = {};
            pp(c, d);
            Gr(d);
            d.google_ad_intent_query && (d.google_responsive_auto_format = qp(d), d.google_reactive_ad_format = 42);
            c = Z(window);
            let f = {};
            for (var e in d) f[e] = d[e];
            c.head_tag_slot_vars = f;
            e = {
                google_ad_client: d.google_ad_client,
                enable_page_level_ads: d
            };
            if (d.google_ad_intent_query || d.google_ad_intents_format) e.enable_ad_intent_display_ads = !0;
            d.google_overlays === "bottom" && (e.overlays = {
                bottom: !0
            });
            d.google_overlays === "collapsed-bottom" && (e.overlays = {
                bottom: !0,
                ["collapsed-bottom"]: !0
            });
            delete d.google_overlays;
            Q.adsbygoogle || (Q.adsbygoogle = []);
            c = Q.adsbygoogle;
            c.loaded ? c.push(e) : c.splice && c.splice(0, 0, e);
            Jr(d, b, a)
        }
    }

    function Ir() {
        var a = Q;
        if (a = a.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js?client="]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js"][data-ad-client]:not([data-checked-head])'))
            if (a.setAttribute("data-checked-head", "true"),
                Z(window).head_tag_slot_vars) Kr(a);
            else return fq(P(jq), b => {
                b = Mf(b);
                Lc(b, 7, Qb(!0), !1)
            }), a
    }

    function Jr(a, b, c) {
        b = en(b) ? .N();
        a.google_adbreak_test || b ? Lr(a, c) : Wq(window, "sc-cnf", () => {
            Lr(a, c)
        })
    }

    function Kr(a) {
        var b = Z(window).head_tag_slot_vars,
            c = a.getAttribute("src") || "";
        if ((a = Ye(c, "client") || a.getAttribute("data-ad-client") || "") && a !== b.google_ad_client) throw new W(`Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page ${a}, ${String(b.google_ad_client)}`);
    }

    function Mr(a) {
        if (typeof a === "object" && a != null) {
            if (w(a.type)) return 2;
            if (w(a.sound) || w(a.preloadAdBreaks) || typeof a.h5AdsConfig === "object") return 3
        }
        return 0
    }

    function Fr(a, b, c, d, e, f) {
        if (a == null) throw new W("push() called with no parameters.");
        var g = P(jq);
        fq(g, k => {
            var m = Mf(k);
            $c(m, 3) || (k = Mf(k), hd(k, 3))
        });
        var h = Mr(a);
        if (h !== 0)
            if (d = Sm(), d.first_slotcar_request_processing_time || (d.first_slotcar_request_processing_time = Date.now(), d.adsbygoogle_execution_start_time = Jh), tr == null) Nr(a), ur.push(a);
            else if (h === 3) {
            let k = tr;
            rk(787, () => {
                k.handleAdConfig(a)
            })
        } else tk(730, tr.handleAdBreak(a));
        else {
            Jh = (new Date).getTime();
            yp(c, d, e, f, Dr(a));
            Or();
            a: {
                if (!a.enable_ad_intent_display_ads &&
                    a.enable_page_level_ads != void 0) {
                    if (w(a.google_ad_client)) {
                        h = !0;
                        break a
                    }
                    throw new W("'google_ad_client' is missing from the tag config.");
                }
                h = !1
            }
            if (h) fq(g, k => {
                var m = Mf(k);
                $c(m, 4) || (k = Mf(k), hd(k, 4))
            }), Pr(a, d);
            else if ((h = a.params) && td(h, (k, m) => {
                    b[m] = k
                }), b.google_ad_output === "js") console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
            else {
                b.abgtt = Sq(Dr(a), d, b.google_loader_used) || void 0;
                h = Qr(b, a);
                pp(h, b);
                c = Z(r).head_tag_slot_vars || {};
                td(c, (k, m) => {
                    b.hasOwnProperty(m) || (b[m] = k)
                });
                if (h.hasAttribute("data-require-head") && !Z(r).head_tag_slot_vars) throw new W("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
                if (!b.google_ad_client) throw new W("Ad client is missing from the slot.");
                if (c = (Z(Q).first_tag_on_page || 0) === 0 && Mn(b)) fq(g, k => {
                    var m = Mf(k);
                    $c(m, 5) || (k = Mf(k), hd(k, 5))
                }), Rr(c);
                (Z(Q).first_tag_on_page ||
                    0) === 0 && (Z(Q).first_tag_on_page = 2);
                b.google_pause_ad_requests = !!Z(Q).pause_ad_requests;
                g = a.ofxVI;
                (c = g ? .recYb ? .LmpfC) && td(c, (k, m) => {
                    b[m] = k
                });
                up({
                    ib: 1,
                    ab: h,
                    nb: b,
                    l: window,
                    X: d,
                    ...(g ? .bPXfr ? {
                        fb: g.bPXfr
                    } : {})
                })
            }
        }
    }

    function Dr(a) {
        return a.google_ad_client ? a.google_ad_client : (a = a.params) && a.google_ad_client ? a.google_ad_client : Vp(Q)
    }

    function Or() {
        if (T(Si)) {
            let a = Pm(Q);
            a && a.Va || Qm(Q)
        }
    }

    function Rr(a) {
        pe(() => {
            Jn(r).wasPlaTagProcessed || r.adsbygoogle && r.adsbygoogle.push(a)
        })
    }

    function Pr(a, b) {
        (Z(Q).first_tag_on_page || 0) === 0 && (Z(Q).first_tag_on_page = 1);
        if (a.tag_partner) {
            var c = a.tag_partner;
            let d = Z(r);
            d.tag_partners = d.tag_partners || [];
            d.tag_partners.push(c)
        }
        Nn(a, b);
        Er(a, b)
    }

    function Qr(a, b) {
        if (a.google_ad_format === "rewarded") {
            if (a.google_ad_slot == null) throw new W("Rewarded format does not have valid ad slot");
            if (a.google_ad_loaded_callback == null) throw new W("Rewarded format does not have ad loaded callback");
            a.google_reactive_ad_format = 11;
            a.google_wrap_fullscreen_ad = !0;
            a.google_video_play_muted = !1;
            a.google_acr = a.google_ad_loaded_callback;
            delete a.google_ad_loaded_callback;
            delete a.google_ad_format
        }
        var c = !!a.google_wrap_fullscreen_ad;
        if (c) b = Br(), b.dataset.adsbygoogleStatus =
            "reserved", qe.documentElement.appendChild(b);
        else if (b = b.element) {
            if (!xr(b) && (b.id ? b = yr(b.id) : b = null, !b)) throw new W("'element' has already been filled.");
            if (!("innerHTML" in b)) throw new W("'element' is not a good DOM element.");
        } else if (b = yr(), !b) throw new W("All 'ins' elements in the DOM with class=adsbygoogle already have ads in them.");
        if (c) {
            c = Q;
            try {
                let e = (c || window).document,
                    f = e.compatMode == "CSS1Compat" ? e.documentElement : e.body;
                var d = (new he(f.clientWidth, f.clientHeight)).round()
            } catch (e) {
                d =
                    new he(-12245933, -12245933)
            }
            a.google_ad_height = d.height;
            a.google_ad_width = d.width;
            a.fsapi = !0
        }
        return b
    }

    function Sr(a) {
        yk().S[Bk(26)] = !!Number(a)
    }

    function Tr(a) {
        Number(a) ? Z(Q).pause_ad_requests = !0 : (Z(Q).pause_ad_requests = !1, a = () => {
            if (!Z(Q).pause_ad_requests) {
                var b = {};
                let c;
                typeof window.CustomEvent === "function" ? c = new CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", b) : (c = document.createEvent("CustomEvent"), c.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !!b.bubbles, !!b.cancelable, b.detail));
                Q.dispatchEvent(c)
            }
        }, r.setTimeout(a, 0), r.setTimeout(a, 1E3))
    }

    function Ur(a, b = !1) {
        var c = a.revenueMicros,
            d = a.revenueCurrency;
        if (w(d) && tb(c)) {
            a = P(jq);
            var e = new Pf;
            e = id(e, 1, "CPM");
            e = id(e, 2, "PRECISE");
            d = id(e, 3, d);
            c = N(d, 4, c);
            b = Bc(c, 5, Qb(b));
            mq(a, uc(b))
        }
    }

    function Vr(a) {
        vb(a) && Wq(window, "aevi", b => {
            try {
                let c = b.revenueMicros,
                    d = b.revenueCurrency;
                tb(c) && w(d) && (Ur(b), a({
                    valueMicros: Math.floor(c / 1E3),
                    currencyCode: d
                }))
            } catch {
                console.log("onPaidEvent function call failed. Please follow the documentation: https://services.google.com/fh/files/helpcenter/adsense_ilar_implementation_guide.pdf")
            }
        })
    }

    function Wr(a) {
        vb(a) && window.setTimeout(a, 0)
    }

    function Xr(a) {
        var b = Math.floor(a / 1E3);
        a = a % 1E3 * 1E6;
        var c = new Df;
        b = fd(c, 1, b);
        return ed(b, 2, a)
    }

    function Lr(a, b) {
        var c = { ...Dn()
        };
        b = Hn(Sd(b.Vb, new Map(Object.entries(c)))).then(d => {
            tr == null && (d.init(a), tr = d, Yr(d))
        });
        tk(723, b);
        b.finally(() => {
            ur.length = 0;
            var d = Date.now(),
                e = d - Jh;
            var f = new Ef;
            e = Xr(e);
            f = F(f, 1, e);
            wr >= 0 && (d = Xr(d - wr), F(f, 2, d));
            d = P(jq);
            e = Ff(23);
            f = G(e, 14, Hf, f);
            lq(d, f)
        })
    }

    function Yr(a) {
        for (let [c, d] of vr) {
            var b = c;
            let e = d;
            e !== -1 && (r.clearTimeout(e), vr.delete(b))
        }
        for (b = 0; b < ur.length; b++) {
            if (vr.has(b)) continue;
            let c = ur[b],
                d = Mr(c);
            rk(723, () => {
                d === 3 ? a.handleAdConfig(c) : d === 2 && tk(730, a.handleAdBreakBeforeReady(c))
            })
        }
    }

    function Nr(a) {
        var b = ur.length;
        if (Mr(a) === 2 && a.type === "preroll" && a.adBreakDone != null) {
            var c = a.adBreakDone;
            wr === -1 && (wr = Date.now());
            var d = r.setTimeout(() => {
                try {
                    c({
                        breakType: "preroll",
                        breakName: a.name,
                        breakFormat: "preroll",
                        breakStatus: "timeout"
                    }), vr.set(b, -1), lq(P(jq), Ff(22))
                } catch (e) {
                    console.error("[Ad Placement API] adBreakDone callback threw an error:", e instanceof Error ? e : Error(String(e)))
                }
            }, fj(dj) * 1E3);
            vr.set(b, d)
        }
    };
    (function(a, b, c, d = () => {}) {
        nk.N(wk);
        rk(166, () => {
            var e = window;
            if (!e.BGtEY) {
                e.BGtEY = !0;
                var f = new Vg(2, a, void 0, void 0, void 0, void 0, Ah);
                try {
                    ab(q => {
                        fk(f, 1191, q)
                    })
                } catch (q) {}
                var g = Qp(b);
                Qq(J(g, 2));
                d();
                we(16, [1, z(g)]);
                var h = Gh(Fh(Q)) || Q,
                    k = c(a, g),
                    m = Q.document.currentScript === null ? 1 : pq(k.Xb);
                Pq(h, g, m);
                T(Zi) && J(g, 29) && Tq(h.document, Vq(J(g, 29)));
                fq(P(jq), q => {
                    var u = I(q, 1) + 1;
                    ed(q, 1, u);
                    Q.top === Q && (u = I(q, 2) + 1, ed(q, 2, u));
                    u = Mf(q);
                    $c(u, 1) || (q = Mf(q), hd(q, 1))
                });
                tk(1086, iq(m === 0));
                if (!Ga() || va(Ja(), 11) >= 0) {
                    pk(T(ej));
                    po();
                    zm(Rc(g, Np, 26));
                    try {
                        kr()
                    } catch {}
                    oo();
                    Hr(k, g);
                    h = e.adsbygoogle;
                    if (!h || !h.loaded) {
                        var n = new En,
                            l = new En;
                        m = {
                            push: q => {
                                Ar(q, k, g, n, l)
                            },
                            loaded: !0,
                            pageState: Rq(g, n, l)
                        };
                        try {
                            Object.defineProperty(m, "requestNonPersonalizedAds", {
                                set: Sr
                            }), Object.defineProperty(m, "pauseAdRequests", {
                                set: Tr
                            }), Object.defineProperty(m, "onload", {
                                set: Wr
                            }), Object.defineProperty(m, "onPaidEvent", {
                                set: Vr
                            })
                        } catch {}
                        var p = Vp(Q);
                        P(ce).i(Ui.g, Ui.defaultValue).includes(p) && Wq(Q, "aevi", q => {
                            Ur(q, !0)
                        });
                        if (h)
                            for (let q of ["requestNonPersonalizedAds",
                                    "pauseAdRequests", "onPaidEvent"
                                ]) h[q] !== void 0 && (m[q] = h[q]);
                        zr(h, k, g, n, l);
                        e.adsbygoogle = m;
                        h && (m.onload = h.onload)
                    }
                }
            }
        })
    })(ng(), typeof sttc === "undefined" ? void 0 : sttc, function(a, b, c = !1) {
        b = I(b, 1) > 2012 ? `_fy${I(b,1)}` : "";
        var d = Rd `data:text/javascript,`;
        return {
            Vb: Rd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${b}.js`,
            Tb: c ? d : Rd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl${b}.js`,
            Sb: c ? d : Rd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_with_ama${b}.js`,
            Xb: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle(_direct)?)\.js(?:[?#].*)?$/
        }
    });
}).call(this, "[2021,\"r20260624\",\"r20190131\",null,null,null,null,\".google.com.br\",null,null,null,[[[698926295,null,null,[1]],[null,619278254,null,[null,10]],[null,45696523,null,[]],[1397,null,null,[1]],[45693370,null,null,null,[[[6,null,null,3,null,2],[1]]]],[682658313,null,null,[1]],[null,1130,null,[null,100]],[null,1340,null,[null,0.2]],[null,1338,null,[null,0.3]],[null,1339,null,[null,0.3]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,500]]]],[null,728201648,null,[null,100]],[null,1224,null,[null,0.01]],[null,1346,null,[null,6]],[null,1347,null,[null,3]],[1342,null,null,[1]],[null,846334470,null,[null,1000]],[1393,null,null,[1]],[null,1394,null,[null,120]],[null,1396,null,[null,1000]],[null,1395,null,[null,500]],[null,1263,null,[null,-1]],[null,1323,null,[null,-1]],[null,1265,null,[null,-1]],[null,1264,null,[null,-1]],[1267,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[1241,null,null,[1]],[1402,null,null,[1]],[1300,null,null,[1]],[null,null,null,[null,null,null,[\"en\",\"de\",\"fr\",\"es\",\"ja\"]],null,1273],[null,null,null,[null,null,null,[\"44786015\",\"44786016\"]],null,1261],[812820063,null,null,[1]],[752401956,null,null,[1]],[null,770241922,null,[null,1000]],[null,null,null,[null,null,null,[\"ca-pub-7178919035426667\",\"ca-pub-6430486603399192\",\"ca-pub-6217516951440692\",\"ca-pub-3269777183832488\",\"ca-pub-4286071012672876\",\"ca-pub-6893876361346206\",\"ca-pub-6865079278713445\",\"ca-pub-6062692039613877\",\"ca-pub-8700401253704627\",\"ca-pub-7409460644561046\",\"ca-pub-1807333429605702\",\"ca-pub-4414232724432396\",\"ca-pub-8878716159434368\",\"ca-pub-1725310704471587\",\"ca-pub-7286478979881995\",\"ca-pub-5420212072167331\",\"ca-pub-3001544606526418\",\"ca-pub-7647808421428026\",\"ca-pub-6109939056400055\",\"ca-pub-6907038225839490\",\"ca-pub-6462695325264077\",\"ca-pub-9260533539525355\",\"ca-pub-9284205722386242\",\"ca-pub-0636857377230346\",\"ca-pub-9067164180551135\",\"ca-pub-9649286969563355\",\"ca-pub-6150993149788596\",\"ca-pub-0085763304086106\"]],null,45736067],[622128248,null,null,[]],[842638817,null,null,[1]],[829415421,null,null,[1]],[45783527,null,null,[1]],[767123927,null,null,[1]],[null,null,45718425,[null,null,\"max(100px, calc(\\u003cDH\\u003e - 356px))\"]],[null,null,45718424,[null,null,\"max(100px, calc(\\u003cDH\\u003e - 320px))\"]],[null,null,780033902,[null,null,\"calc(\\u003cDH\\u003e - 30px)\"]],[null,null,716722045,[null,null,\"calc(\\u003cDH\\u003e - 30px)\"]],[null,799568408,null,[null,10]],[null,null,null,[null,null,null,[\"\",\"ar\",\"bn\",\"en\",\"es\",\"fr\",\"hi\",\"id\",\"ja\",\"ko\",\"mr\",\"pt\",\"ru\",\"sr\",\"te\",\"th\",\"tr\",\"uk\",\"vi\",\"zh\"]],null,712458671],[null,855152761,null,[null,0.6]],[null,null,null,[],null,null,null,683929765],[null,null,872996096,[null,null,\"calc(\\u003cSW\\u003e \/ 1.2)\"]],[null,868282444,null,[null,1200]],[null,null,834418652,[null,null,\"calc(max(\\u003cDH\\u003e - 150px, 50px))\"]],[null,null,874614210,[]],[null,null,834418651,[null,null,\"calc(max(\\u003cDH\\u003e - 150px, 50px))\"]],[839747468,null,null,[1]],[869697744,null,null,[1]],[899601681,null,null,[1]],[null,775999093,null,[null,1]],[824550200,null,null,[1]],[null,9601,null,[null,0.0001]],[null,618163195,null,[null,8000]],[null,624950166,null,[null,3000]],[null,623405755,null,[null,300]],[null,508040914,null,[null,622]],[null,547455356,null,[null,49]],[null,9603,null,[null,4]],[null,650548030,null,[null,3]],[null,650548032,null,[null,300]],[null,650548031,null,[null,1]],[null,469675170,null,[null,68040]],[null,836239785,null,[null,0.6]],[null,913774067,null,[null,100]],[45775975,null,null,[1]],[458320011,null,null,[]],[null,458320009,null,[null,0.4]],[675298507,null,null,[]],[711741274,null,null,[]],[776685355,null,null,[]],[570863962,null,null,[]],[null,null,570879859,[null,null,\"control_1\\\\.\\\\d\"]],[null,570863961,null,[null,50]],[570879858,null,null,[1]],[null,null,754933823,[null,null,\"1-0-45\"]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1080,null,[null,5]],[null,10019,null,[null,5]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[null,1079,null,[null,5]],[null,1050,null,[null,30]],[715572365,null,null,[1]],[715572366,null,null,[1]],[562874197,null,null,[1]],[null,732217386,null,[null,10000]],[null,794150639,null,[null,5000]],[null,732217387,null,[null,500]],[null,811376351,null,[null,0.5]],[null,733329086,null,[null,30000]],[null,629808663,null,[null,100]],[null,736623795,null,[null,250]],[null,745376892,null,[null,1]],[null,745376893,null,[null,2]],[null,550718588,null,[null,250]],[897236184,null,null,[1]],[null,624290870,null,[null,50]],[null,815871887,null,[null,0.8]],[506738118,null,null,[1]],[null,null,null,[null,null,null,[\"AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"Amm8\/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq\/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A93bovR+QVXNx2\/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A1S5fojrAunSDrFbD8OfGmFHdRFZymSM\/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1\/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934]],[[12,[[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61],[40,[[95340252],[95340253,[[662101537,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5],[40,[[95340254],[95340255,[[662101539,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5],[1000,[[95387091,null,[6,null,null,6,null,3,null,[\"WH.bucket\"]]]],[12,null,null,null,4,null,\"www\\\\.wikihow\\\\.com\",[\"location.href\"]],165,null,null,null,null,null,null,null,null,37],[1000,[[95387092,null,[6,null,null,6,null,13,null,[\"WH.bucket\"]]]],[12,null,null,null,4,null,\"www\\\\.wikihow\\\\.com\",[\"location.href\"]],165,null,null,null,null,null,null,null,null,37]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\",\"4\"]]]]],[10,[[10,[[31084127],[31084128]]],[1000,[[31099320,[[null,null,14,[null,null,\"31099320\"]]],[6,null,null,null,6,null,\"31099320\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31099321,[[null,null,14,[null,null,\"31099321\"]]],[6,null,null,null,6,null,\"31099321\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[10,[[31099343],[31099344,[[932979855,null,null,[1]]]]]],[340,[[31099345],[31099346,[[929460549,null,null,[1]]]]]],[1000,[[31099359,[[null,null,14,[null,null,\"31099359\"]]],[6,null,null,null,6,null,\"31099359\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31099360,[[null,null,14,[null,null,\"31099360\"]]],[6,null,null,null,6,null,\"31099360\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31099410,[[null,null,14,[null,null,\"31099410\"]]],[6,null,null,null,6,null,\"31099410\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31099411,[[null,null,14,[null,null,\"31099411\"]]],[6,null,null,null,6,null,\"31099411\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[1,[[42532242],[42532243,[[1256,null,null,[1]],[290,null,null,[1]]]]]],[50,[[42532523],[42532524,[[1300,null,null,[]]]]]],[null,[[42532525],[42532526]]],[100,[[42533293],[42533294,[[1383,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]],null,145],[1,[[44801778],[44801779,[[506914611,null,null,[1]]]]],[4,null,55],143],[1,[[95345037],[95345038,[[1377,null,null,[1]]]]],[4,null,55]],[50,[[95386338,[[1397,null,null,[1]]]],[95386362]],null,160],[1,[[95388156],[95388157,[[1393,null,null,[]],[null,1394,null,[]],[null,1396,null,[]],[null,1395,null,[]]]]]],[null,[[95388158],[95388159]]],[424,[[95389919],[95389920,[[566279275,null,null,[1]],[622128248,null,null,[1]],[566279276,null,null,[1]]]]],[2,[[4,null,55],[12,null,null,null,2,null,\"gegen-hartz\\\\.de\/|maimai\\\\.pro\/|pixelpulsegame\\\\.com\/\"]]],143],[50,[[95390277],[95390278,[[566279275,null,null,[1]],[622128248,null,null,[1]],[566279276,null,null,[1]],[767123927,null,null,[]]]]],[4,null,55],143],[50,[[95393280],[95393281]],[4,null,55],161],[200,[[95394755],[95394756],[95394760]],[4,null,55],161]]],[17,[[10,[[31084487],[31084488]],null,null,null,null,32,null,null,142,1],[10,[[31089209],[31089210]],null,null,null,null,39,null,null,189,1],[10,[[31099033],[31099034,[[null,619278254,null,[null,-1]]]]],[4,null,55],null,null,null,null,200,null,234,1],[50,[[95373848],[95373849]],null,null,null,null,47,40,null,189,1],[10,[[95375758],[95375759]],null,null,null,null,48,140,null,189,1],[10,[[95379673],[95379674]],null,null,null,null,50,160,null,189,1],[250,[[95393484],[95393485,[[917171616,null,null,[1]],[917676946,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,242,1],[10,[[95394753],[95394754,[[903704925,null,null,[1]],[907534769,null,null,[1]]]]],[4,null,55],null,null,null,null,500,null,242,1]]],[11,[[5,[[95391228],[95391229],[95391230],[95391231],[95391232],[95391233]],null,167,null,null,null,150,null,null,null,null,null,11],[10,[[95394424],[95394425],[95394426],[95394427],[95394428]],null,167,null,null,null,null,null,null,null,null,null,13]]]],null,null,[null,1000,1,1000]],null,null,\"31099360\",1,\"www.next4.com.br\",664803988,null,null,null,null,null,null,null,[0,0,0],[\"ca-pub-1122471812070813\"],null,\"m202606180101\"]");